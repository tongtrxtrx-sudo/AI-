from pathlib import Path
import hashlib,json,subprocess,sys,re,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 sys.path.insert(0,'/workspace/epm-demo-vouchers/acceptance');from support import manifest
 current=manifest();meta=json.loads((ROOT/'release.json').read_text());assert current==meta['sourceSha256'] and meta['softwareChanged'] is False
 md=ROOT/'content/鸿旺2026年6月单体报表导入与小合并操作指南.md';review=json.loads((ROOT/'evidence/独立核对.json').read_text());assert review['passed'] and review['guideSha256']==sha(md)
 for field in ['dataFilesSha256','screenshotsSha256']:
  for name,h in review[field].items():assert sha(ROOT/name)==h,name
 qa=json.loads((ROOT/'acceptance/六月鸿旺小合并真实验收.json').read_text());assert qa['passed'] and qa['sourceUnchangedDuringRun'] and qa['inputFilesUnchangedDuringRun'] and qa['sourceSha256']==current
 assert len(qa['cases'])==6 and all(c['passed'] for c in qa['cases'])
 for name,h in qa['inputSha256'].items():assert sha(ROOT/name)==h,name
 shots=json.loads((ROOT/'evidence/六月操作截图与实机验证.json').read_text());assert shots['passed'] and shots['productSourceUnchanged'] and shots['inputFilesUnchanged'] and shots['sourceSha256']==current and not shots['javascriptErrors']
 for rec in shots['files']:assert sha(ROOT/'screenshots'/rec['file'])==rec['sha256']
 for name,h in shots['inputFilesSha256'].items():assert sha(ROOT/name)==h,name
 actual=shots['sample']['result'];assert actual['revenue']==840 and actual['net']==270 and actual['assets']==470 and actual['valid'] and actual['approvalStatus']=='已签核'
 stem='鸿旺2026年6月单体报表导入与小合并操作指南';word=ROOT/'output'/(stem+'.docx');pdf=ROOT/'output'/(stem+'.pdf');build=json.loads((ROOT/'evidence/word-build.json').read_text())[0];assert build['sourceSha256']==sha(md) and build['sha256']==sha(word) and build['figures']==16
 with zipfile.ZipFile(word) as z:
  assert z.testzip() is None;tree=ET.fromstring(z.read('word/document.xml'));ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';s=''.join(t.text or '' for t in tree.iter(ns+'t'))
  for term in ['杭州天元宠物用品有限公司','2026年06期','2026-06','2026年10月28日','840','270','470','160','54','CSV','万元']:assert term in s,term
  assert len([n for n in z.namelist() if n.startswith('word/media/')])==16
 assert pdf.read_bytes().startswith(b'%PDF-');info=subprocess.check_output(['pdfinfo',str(pdf)],text=True);pages=int(re.search(r'^Pages:\s+(\d+)',info,re.M).group(1));bbox=ROOT/'evidence/文字边界.html';subprocess.run(['pdftotext','-bbox-layout',str(pdf),str(bbox)],check=True);tree=ET.parse(bbox)
 for i,page in enumerate(tree.findall('.//{http://www.w3.org/1999/xhtml}page'),1):
  w,h=float(page.attrib['width']),float(page.attrib['height'])
  for item in page.iter('{http://www.w3.org/1999/xhtml}word'):
   b=[float(item.attrib[k]) for k in ['xMin','yMin','xMax','yMax']];assert b[0]>=-.5 and b[1]>=-.5 and b[2]<=w+.5 and b[3]<=h+.5,(i,item.text,b)
 result={'passed':True,'softwareBaseline':meta['softwareBaseline'],'businessPeriod':'2026-06','softwareChanged':False,'sourceSha256':current,'guideSha256':sha(md),'dataFileCount':len(qa['inputSha256']),'actualHttpGroups':6,'actualUiScreenshots':len(shots['files']),'wordFigures':16,'documents':{'word':{'file':word.name,'sha256':sha(word),'bytes':word.stat().st_size},'pdf':{'file':pdf.name,'sha256':sha(pdf),'bytes':pdf.stat().st_size,'pages':pages,'outOfPageWords':0}},'sample':shots['sample'],'scope':'当前软件的文档补充；三家单体报表CSV、万元、1-6累计与6月当月明确区分；不改变EXE。'}
 (ROOT/'evidence/交付校验.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':True,'pdfPages':pages,'wordFigures':16,'dataFiles':len(qa['inputSha256'])},ensure_ascii=False));return result
if __name__=='__main__':main()
