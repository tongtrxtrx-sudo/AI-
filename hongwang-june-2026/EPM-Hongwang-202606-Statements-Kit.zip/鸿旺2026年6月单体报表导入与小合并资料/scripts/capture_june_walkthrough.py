#!/usr/bin/env python3
"""Real isolated June report-source upload and manual-elimination walkthrough."""
from pathlib import Path
from datetime import datetime,timezone
import csv,io,json,hashlib,sys
PRODUCT=Path('/workspace/epm-demo-vouchers');KIT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PRODUCT/'acceptance'))
from support import Server,manifest
from run_multilevel_browser import state,wait,go,click,action,scope,retain_response_bodies
from playwright.sync_api import sync_playwright
SHOTS=KIT/'screenshots';RECORDS=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def photo(page,name,title,menu,button,api,purpose,selector=None,y=None):
 page.locator('#toast').wait_for(state='hidden',timeout=10000);assert 'token=' not in page.url
 if y is not None:page.get_by_role('dialog').evaluate('(e,y)=>e.scrollTop=y',y)
 if selector:page.locator(selector).first.evaluate("e=>{e.dataset.captureOutline=e.style.outline;e.style.outline='3px solid #e9594f';e.style.outlineOffset='3px';}")
 page.screenshot(path=str(SHOTS/name),full_page=False)
 if selector:page.locator(selector).first.evaluate("e=>{e.style.outline=e.dataset.captureOutline||'';e.style.outlineOffset='';delete e.dataset.captureOutline;}")
 RECORDS.append({'file':name,'title':title,'menu':menu,'button':button,'apiAction':api,'purpose':purpose,'context':state(page)['context'],'highlight':'仅截图时浏览器DOM描边，不改源文件' if selector else '无额外标注','sha256':sha(SHOTS/name)})
 print('PHOTO',name,flush=True)
def close(page):
 if page.get_by_role('dialog').count():click(page,'close-modal')
def main():
 files=[KIT/'data/示例CSV'/n for n in ['01_鸿旺单体_2026-06_已填示例.csv','02_猫爬架法人_2026-06_已填示例.csv','03_电子工厂法人_2026-06_已填示例.csv']]
 for p in files:assert p.is_file(),str(p)
 before=manifest();inputs={str(p.relative_to(KIT)):sha(p) for p in files};errors=[];SHOTS.mkdir(parents=True,exist_ok=True);(KIT/'evidence').mkdir(exist_ok=True)
 with Server() as server,sync_playwright() as play:
  browser=play.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1600,'height':1160},locale='zh-CN',accept_downloads=True);page.set_default_timeout(45000);retain_response_bodies(page);page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(server.info['url'],wait_until='networkidle');page.wait_for_selector('#nav [data-route="submissions"]');page.wait_for_function('()=>!location.hash.includes("token=")')
  scope(page,'HW_GROUP')
  with page.expect_response(lambda r:'/api/bootstrap?' in r.url) as pending:page.locator('#context-period').select_option('6')
  assert pending.value.status==200;page.wait_for_function('()=>window.EPMDemo.inspect().month===6');wait(page);assert state(page)['context']['month']==6
  go(page,'consolidation')
  photo(page,'01_选择六月与鸿旺范围.png','选择2026年06期与鸿旺小合并','顶部范围及期间','鸿旺小合并／2026年06期','GET /api/bootstrap','初始化数字不是本次已导入的结果；后续使用独立CSV重建。',selector='#context-period')
  page.locator('[data-action="unit-form"][data-id="HW_GROUP"]').first.click()
  assert set(page.locator('[data-member-type]:checked').evaluate_all('(xs)=>xs.map(x=>x.value)'))=={'HW','HW_CAT','HW_ELEC'}
  photo(page,'02_核对三个独立法人成员.png','核对三家独立法人范围','分级合并与结果','维护成员','GET /api/bootstrap','直接成员仅HW、HW_CAT、HW_ELEC；管理范围不代替真实持股。',y=0);close(page)
  click(page,'reopen-unit');page.locator('#reopen-reason').fill('导入2026年6月三家独立法人报表，核对后重算鸿旺小合并，保留历史。')
  photo(page,'03_重开本层与依赖祖先.png','重开本期鸿旺及依赖祖先','分级合并与结果','重新开启及祖先→确认重开并保留历史','unit_reopen','只解锁受影响范围；保留历史，不修改09期或旧ERP账套。');action(page,'reopen-unit-save')
  go(page,'submissions')
  with page.expect_download() as dl:click(page,'source-export')
  exported=KIT/'evidence/现场下载本期全量源CSV_2026-06.csv';dl.value.save_as(str(exported));export_rows=list(csv.DictReader(io.StringIO(exported.read_text('utf-8-sig'))));assert len(export_rows)==693
  # Illustrate real first-time capital setup; do not save/change this main scenario.
  page.locator('[data-action="source-form"][data-id="HW"]').first.click()
  page.get_by_role('dialog').locator('details.source-quick summary').click()
  page.locator('[data-source-section="opening"][data-source-key="capital"]').evaluate('e=>e.scrollIntoView({block:"center",inline:"nearest"})')
  photo(page,'附图A_真实期初资本在表单维护.png','真实期初资本不同先完整填源','财务三表报送','编辑三表→期初与期末资产负债','source_save','若实际资本与初始化100/50/50不同，完整实际三表表单保存会同步权益历史依据，不改实际数凑样例。')
  page.locator('#source-opening-retained-cny').scroll_into_view_if_needed()
  photo(page,'附图B_历史权益与保存入口.png','权益历史条件与校验保存','财务三表报送','期初已确认人民币留存收益→校验并保存三表源','source_save','同时填写实际完整期初期末/累计/各月数据，再保存；截图不提交示例变更。');close(page)
  for i,(p,eid,rev) in enumerate(zip(files,['HW','HW_CAT','HW_ELEC'],[600,200,100]),1):
   go(page,'submissions');click(page,'source-import');page.locator('#source-file').set_input_files(str(p));page.wait_for_function('name=>document.querySelector("#source-name").value===name',arg=p.name)
   rows=list(csv.DictReader(io.StringIO(page.locator('#source-csv').input_value().lstrip('\ufeff'))));assert len(rows)==99 and {r['期间'] for r in rows}=={'2026-06'}
   photo(page,f'04_{i}_导入{eid}六月报表.png',f'分别导入第{i}家六月单体报表','财务三表报送','导入完整三表CSV→选择UTF-8 CSV→整批校验并导入','source_import','弹窗2026-09是固定说明示例；实际文件为2026-06、本位币万元、每家99行。')
   data=action(page,'source-import-save');assert data['sources'][eid]['profit']['revenue']==rev and data['sources'][eid]['version']==2
  go(page,'submissions');photo(page,'05_三家源版本与收入核对.png','确认三个单体源均已入库','财务三表报送','法人本期源报送','source_import','三家源V2，收入600/200/100、净利180/60/30；还不是合并报表。')
  page.locator('[data-action="source-detail"][data-id="HW"]').first.click();photo(page,'06_单体源期初期末与累计.png','查看真实保存的单体源','财务三表报送','查看→本期原币源','GET /api/bootstrap','鸿旺期初现金100、期末现金280/留存180；当前是单体报表源，没有原始ERP凭证血缘。',y=0);close(page)
  go(page,'journals');old=next(e for e in state(page)['eliminations'] if e['id']=='HW-SALES-06');assert old['amount']==66.67
  photo(page,'07_先识别旧初始化抵销.png','停用本期本层初始化66.67','抵销与调整凭证','HW-SALES-06→停用','GET /api/bootstrap','本例真实内部销售是60，旧初始化66.67不能叠加；不碰其他期或集团投资抵销。',selector='[data-action="elimination-cancel"][data-id="HW-SALES-06"]')
  page.locator('[data-action="elimination-cancel"][data-id="HW-SALES-06"]').click();page.locator('#elimination-cancel-reason').fill('六月独立案例内部销售60万元，停用旧初始化66.67防止双扣，保留历史。');action(page,'elimination-cancel-save')
  click(page,'elimination-form');page.locator('#elimination-source').fill('HW-JUNE-2026-CSV-SALES-001');page.locator('#elimination-unit').select_option('HW_GROUP');page.locator('#elimination-kind').select_option('内部销售');page.locator('#elimination-currency').select_option('CNY');page.locator('#elimination-seller').select_option('HW');page.locator('#elimination-buyer').select_option('HW_CAT');page.locator('#elimination-amount').fill('60');page.locator('#elimination-month-mode').select_option('monthly')
  page.get_by_role('dialog').locator('summary').filter(has_text='各月内部销售抵销明细').click()
  for m in range(1,7):page.locator(f'#elimination-month-{m}').fill('10')
  photo(page,'08A_维护本层内部销售抵销.png','维护本层60万元销售草稿','抵销与调整凭证','新增分层抵销草稿','elimination_save','唯一来源号HW-JUNE-2026-CSV-SALES-001、鸿旺层、卖方HW、买方HW_CAT、CNY60万元。',y=0)
  photo(page,'08B_填写一至六月抵销明细.png','按1—6月每月10分配','抵销与调整凭证','按各月明细发生→六个月份金额','elimination_save','本例每月10合计60，不默认全部在6月；单体汇总报表不能自动找到交易。',y=490)
  data=action(page,'elimination-save');new=next(e for e in data['eliminations'] if e['sourceId']=='HW-JUNE-2026-CSV-SALES-001');assert new['status']=='草稿' and sum(new['monthlyAmounts'].values())==60
  page.locator(f'[data-action="elimination-approve"][data-id="{new["id"]}"]').click();photo(page,'09_负责人审批抵销.png','确认审批本层销售抵销','抵销与调整凭证','审批→确认审批抵销','elimination_approve','审批后还须计算并签核，未审批草稿不进入正式合并。');action(page,'elimination-approve-save')
  go(page,'consolidation');photo(page,'10_计算前检查全部通过.png','计算前核对三源与抵销','分级合并与结果','计算本层新版本','GET /api/bootstrap','明确在2026年06期计算；不沿用初始化或其他期间结果。',selector='[data-action="run-consolidation"]')
  data=action(page,'run-consolidation');a=data['statement']['actual'];assert (a['revenue'],a['cost'],a['expense'],a['net'],a['assets'])==(840,480,90,270,470)
  click(page,'approve-result');photo(page,'11_签核六月鸿旺新结果.png','签核当前六月新结果','分级合并与结果','签核当前结果→确认签核','result_approve','核对输入版本和三表后签核，上级才可引用本版。');data=action(page,'approve-result-save');r=data['currentResult'];assert r['approvalStatus']=='已签核' and r['valid']
  photo(page,'12_六月鸿旺已签核结果.png','有效结果及三个源V2','分级合并与结果','当前结果／直接输入／历史版本','GET /api/bootstrap','六月收入840、净利270、资产470；本指南不继续计算集团。')
  go(page,'statements')
  for key,label,name in [('profit','合并利润表','13A_合并利润表840与270.png'),('balance','合并资产负债表','13B_合并资产负债表470.png'),('cash','合并现金流量表','13C_合并现金流量表470.png')]:
   page.locator(f'[data-statement="{key}"]').click();wait(page);photo(page,name,label,'集团三张报表',label,'GET /api/bootstrap','顶部仍选鸿旺小合并、2026年06期；菜单叫集团三张报表不代表切到大合并。')
  go(page,'consolidation');page.locator('[data-action="result-detail"]').first.click();photo(page,'14_结果来源和抵销追溯.png','来源版本与60万元抵销','分级合并与结果','查看完整结果与钻取','GET /api/bootstrap','保留三家源版本和本层来源号；报表路径追源表，不假称能追ERP原始凭证。',y=0)
  evidence={'passed':True,'capturedUtc':datetime.now(timezone.utc).isoformat(),'softwareBaseline':'ERP-20261021','method':'全新临时SQLite、真实HTTP/Chromium表单，分别上传最终三份CSV，停旧预置/维护审批新抵销并计算签核。未改产品源码。','sourceSha256':manifest(),'productSourceUnchanged':manifest()==before,'inputFilesSha256':inputs,'inputFilesUnchanged':all(sha(KIT/p)==h for p,h in inputs.items()),'javascriptErrors':errors,'browser':{'engine':'Chromium','viewport':{'width':1600,'height':1160},'locale':'zh-CN'},'downloadedSourceExample':{'file':str(exported.relative_to(KIT)),'sha256':sha(exported),'rows':len(export_rows),'meaning':'本期全七家，不只鸿旺；每家99行'},'sample':{'month':6,'unitId':'HW_GROUP','sourceRevenues':{'HW':600,'HW_CAT':200,'HW_ELEC':100},'sourceVersions':{x:data['sources'][x]['version'] for x in ['HW','HW_CAT','HW_ELEC']},'manualElimination':{'sourceId':new['sourceId'],'amount':60,'monthlyAmounts':{str(i):10 for i in range(1,7)}},'result':{'id':r['id'],'revenue':840,'cost':480,'expense':90,'net':270,'assets':470,'approvalStatus':r['approvalStatus'],'valid':r['valid']}},'files':RECORDS,'notes':['六列CSV是本位币万元，不能直接上传XLSX或使用ERP凭证入口。','弹窗2026-09是固定示例，实际文件与期间2026-06。','独立新目录手工源，不篡改已有ERP源。','仅虚构数据，无token/数据库/私有日志。']}
  assert evidence['productSourceUnchanged'] and evidence['inputFilesUnchanged'] and not errors
  (KIT/'evidence/六月操作截图与实机验证.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n');browser.close()
 print(json.dumps({'passed':True,'screenshots':len(RECORDS),'JuneRevenue':840,'JuneNet':270,'JuneAssets':470},ensure_ascii=False))
if __name__=='__main__':main()
