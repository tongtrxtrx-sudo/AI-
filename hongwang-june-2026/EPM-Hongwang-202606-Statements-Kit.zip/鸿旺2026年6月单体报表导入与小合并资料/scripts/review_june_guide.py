#!/usr/bin/env python3
"""Bind the independently read June guide to the actual files and business proofs."""
from pathlib import Path
import argparse,csv,hashlib,json,re,sys
from datetime import datetime,timezone
from decimal import Decimal
ROOT=Path(__file__).resolve().parents[1]
PRODUCT=Path('/workspace/epm-demo-vouchers')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--confirm-semantic-review',action='store_true');args=parser.parse_args()
 assert args.confirm_semantic_review,'必须先逐章实读，不能仅凭关键词签署语义通过。'
 guides=list((ROOT/'content').glob('*.md'));assert len(guides)==1
 guide=guides[0];text=guide.read_text('utf-8');assert '{{' not in text
 sys.path.insert(0,str(PRODUCT/'acceptance'));from support import manifest
 current=manifest();release=json.loads((ROOT/'release.json').read_text());assert release['sourceSha256']==current and release['softwareChanged'] is False
 data=json.loads((ROOT/'data/案例与文件清单.json').read_text());assert data['period']=='2026-06' and data['softwareChanged'] is False and len(data['files'])==15
 inputs={r['file']:sha(ROOT/r['file']) for r in data['files']}
 assert all(inputs[r['file']]==r['sha256'] for r in data['files'])
 rows_by_entity={}
 for rec in data['files']:
  if rec.get('entityId') and rec['file'].endswith('.csv') and not rec['blank']:
   with (ROOT/rec['file']).open(encoding='utf-8-sig',newline='') as f:
    reader=csv.DictReader(f);assert reader.fieldnames==data['headers'];rows=list(reader)
   assert len(rows)==99 and {r['期间'] for r in rows}=={'2026-06'}
   assert {r['法人编码'] for r in rows}=={rec['entityCode']}
   assert len({(r['数据区'],r['项目编码'],r['月份']) for r in rows})==99
   values={(r['数据区'],r['项目编码'],r['月份']):Decimal(r['金额']) for r in rows}
   for area,keys in [('profit',['revenue','cost','expense','finance','tax']),('cashflow',['operating','investing','financing','fx'])]:
    monthly='monthlyProfit' if area=='profit' else 'monthlyCashflow'
    for key in keys:assert sum(values[(monthly,key,str(m))] for m in range(1,7))==values[(area,key,'')]
   rows_by_entity[rec['entityId']]=values
 assert set(rows_by_entity)=={'HW','HW_CAT','HW_ELEC'}
 rev=sum(v[('profit','revenue','')] for v in rows_by_entity.values());cost=sum(v[('profit','cost','')] for v in rows_by_entity.values());exp=sum(v[('profit','expense','')] for v in rows_by_entity.values())
 assert rev==900 and cost==540 and exp==90 and rev-cost-exp==270
 assert rev-60==840 and cost-60==480
 assert sum(v[('closing','cash','')] for v in rows_by_entity.values())==470
 qa=json.loads((ROOT/'acceptance/六月鸿旺小合并真实验收.json').read_text());assert qa['passed'] and qa['sourceUnchangedDuringRun'] and qa['inputFilesUnchangedDuringRun'] and qa['sourceSha256']==current
 assert len(qa['cases'])==6 and all(c['passed'] for c in qa['cases'])
 for path,digest in qa['inputSha256'].items():assert sha(ROOT/path)==digest
 photos=json.loads((ROOT/'evidence/六月操作截图与实机验证.json').read_text());assert photos['passed'] and photos['productSourceUnchanged'] and photos['inputFilesUnchanged'] and photos['sourceSha256']==current and not photos['javascriptErrors']
 screenshots={f'screenshots/{r["file"]}':sha(ROOT/'screenshots'/r['file']) for r in photos['files']}
 assert all(screenshots[f'screenshots/{r["file"]}']==r['sha256'] for r in photos['files'])
 for path,digest in photos['inputFilesSha256'].items():assert sha(ROOT/path)==digest
 used=[]
 for link in re.findall(r'!\[[^\]]*\]\(([^)]+)\)',text):
  from urllib.parse import unquote
  p=(guide.parent/unquote(link)).resolve();assert p.is_file();used.append(p.relative_to(ROOT).as_posix())
 assert used and all(name in screenshots for name in used)
 # Coverage only assists the semantic review recorded below; it does not replace it.
 for phrase in ['2026-06','99','297','万元','840','270','470','66.67','UTF-8','CSV','期初','1—6','现金','抵销','签核']:
  assert phrase in text,phrase
 findings=[
  {'topic':'期间与单位','conclusion':'2026年06期是6月30日期末及1—6累计，输入本位币万元，非ERP元；未套用9月1400金样。'},
  {'topic':'三独立法人及范围','conclusion':'HW/HW_CAT/HW_ELEC对应真实三个非重叠单体，HW00/HW01/HW02可作CSV编码；管理范围不改天元100%持股事实。'},
  {'topic':'所需资料与月明细','conclusion':'完整年初/期末资产负债、累计PL/CF和1—6月明细；未知不填0、不倒摊现金流或累计。'},
  {'topic':'导入文件及入口','conclusion':'财务三表报送/完整三表CSV，固定六表头，每家99行/三家297；Excel整理后仅首表另存UTF-8 CSV，非XLSX或NC凭证入口。'},
  {'topic':'文件逐行复核','conclusion':'已独立解析最终15资料文件摘要及三份已填CSV结构、月累计、900/540/90与840/480/270/470算术。'},
  {'topic':'全量下载范围','conclusion':'实际页面全量下载含七家693行，不能称选择HW就只导出三家；本次三份文件仅覆盖三家。'},
  {'topic':'锁与已有ERP账务','conclusion':'负责人在6月重开HW及TY祖先；已有ERP有效账务时手工CSV不能绕过ERP来源前置，独立目录保留原环境。'},
  {'topic':'真实资本历史条件','conclusion':'CSV不含equityHistory；真实年初资本变更需完整实际表单保存对齐历史依据，不改真实数凑100/50/50。'},
  {'topic':'手工内部销售','conclusion':'汇总报表不自动识别内部客商/金额，按对账依据手工录本期本层销售60、每月10；草稿审批后才算。'},
  {'topic':'预置抵销防双扣','conclusion':'停用或正确替换本月HW初始化66.67，不触其他期/集团投资；绿色勾稽不等于业务抵销依据正确。'},
  {'topic':'情景边界','conclusion':'60为已结算销售，假设购入已外销且无未结内部往来/未实现利润；实际特殊事项不得当作本路径已经自动完成。'},
  {'topic':'计算签核与追溯','conclusion':'逐一导入后检查源版本、审批、本层新计算、有效签核及三张报表；来源追源表和抵销，不伪称ERP原凭证血缘。'},
  {'topic':'后期和大合并','conclusion':'本次目标止于6月HW；重算集团/后期报送需对应期间另做，不自动替代后期独立源。'},
  {'topic':'截图及实际证据','conclusion':'实际交付三CSV经真实UI上传生成；截图绑定输入及源摘要，附图仅示意条件需正文解释；HTTP6组另有独立结果。'},
  {'topic':'文档补充身份','conclusion':'此次仅同软件基线操作指南，未升级EXE/未覆盖旧数据和四册；不以模板说明冒称生产准则全覆盖。'},
 ]
 out={'passed':True,'reviewedUtc':datetime.now(timezone.utc).isoformat(),'softwareBaseline':'ERP-20261021','guideId':release['guideId'],'businessPeriod':'2026-06','softwareChanged':False,'guideFile':guide.relative_to(ROOT).as_posix(),'guideSha256':sha(guide),'inputFilesSha256':inputs,'dataFilesSha256':inputs,'screenshotsSha256':screenshots,'usedScreenshots':used,'sourceSha256':current,'businessExpectation':data['expected'],'checks':findings,'independentHttpProof':{'file':'acceptance/六月鸿旺小合并真实验收.json','sha256':sha(ROOT/'acceptance/六月鸿旺小合并真实验收.json'),'passed':True,'caseCount':6},'realBrowserProof':{'file':'evidence/六月操作截图与实机验证.json','sha256':sha(ROOT/'evidence/六月操作截图与实机验证.json'),'passed':True},'scope':'逐章实际文稿语义、源代码契约、输入文件与现场截图复核；Word/PDF排版、公开下载另验，不以关键词替代语义阅读。'}
 (ROOT/'evidence/独立核对.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 lines=['# 2026年6月鸿旺单体报表到小合并：独立核对','', '结论：通过。已逐章实读最终指南，核对当前正式接口、实际15份资料、实机截图与独立HTTP证明。','', '|核对点|结论|','|---|---|']
 lines += [f'|{r["topic"]}|{r["conclusion"]}|' for r in findings]
 lines += ['', '指南SHA256：`'+sha(guide)+'`。完整文件及源摘要见同名JSON。','', '本核对不代替Word/PDF排版和公开下载验证，也不表示客户真实账务已审计。']
 (ROOT/'evidence/独立核对.md').write_text('\n'.join(lines)+'\n')
 print(json.dumps({'passed':True,'guideSha256':sha(guide),'dataFiles':len(inputs),'screenshots':len(screenshots),'usedScreenshots':len(used)},ensure_ascii=False))
if __name__=='__main__':main()
