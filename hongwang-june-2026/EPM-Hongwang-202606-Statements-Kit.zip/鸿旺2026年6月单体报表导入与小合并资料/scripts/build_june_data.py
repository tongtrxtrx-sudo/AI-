from pathlib import Path
from copy import deepcopy
import csv,hashlib,json
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.comments import Comment
ROOT=Path(__file__).resolve().parents[1]
BS='cash receivable inventory prepaid investment fixed intangible deferred_asset payable shortloan taxpayable otherliability longloan deferred_liability capital retained nci cta'.split();PL='revenue cost expense finance tax'.split();CF='operating investing financing fx'.split()
HEAD=['法人编码','期间','数据区','项目编码','金额','月份']
SPECS=[('HW','HW00','01_鸿旺单体','鸿旺单体',100,[90,90,100,100,110,110],[50,50,60,60,70,70],[10]*6),('HW_CAT','HW01','02_猫爬架法人','鸿旺猫爬架生产事业部',50,[30,30,30,30,40,40],[20]*6,[3,3,3,3,4,4]),('HW_ELEC','HW02','03_电子工厂法人','杭州鸿旺宠物用品有限公司电子工厂',50,[15,15,15,15,20,20],[10]*6,[1,1,2,2,2,2])]
LABELS=dict(zip(BS,['货币资金','应收账款','存货','预付款','长期股权投资','固定资产','无形资产','递延所得税资产','应付账款','短期借款','应交税费','其他负债','长期借款','递延所得税负债','实收资本','留存收益','少数股东权益','折算差额']))
LABELS.update(dict(zip(PL,['营业收入','营业成本','期间费用','财务费用','所得税'])));LABELS.update(dict(zip(CF,['经营现金流','投资现金流','筹资现金流','现金汇率影响'])))
def matrix(spec,blank=False):
 eid,code,stem,name,capital,rv,co,ex=spec;net=sum(rv)-sum(co)-sum(ex);op=dict.fromkeys(BS,0);op.update(cash=capital,capital=capital);cl=deepcopy(op);cl.update(cash=capital+net,retained=net)
 data={'opening':op,'closing':cl,'profit':dict(zip(PL,[sum(rv),sum(co),sum(ex),0,0])),'cashflow':dict(zip(CF,[net,0,0,0]))};rows=[]
 for area,d in data.items():rows.extend([[code,'2026-06',area,k,None if blank else v,''] for k,v in d.items()])
 for area,keys in [('monthlyProfit',PL),('monthlyCashflow',CF)]:
  for m in range(1,7):
   vals=[rv[m-1],co[m-1],ex[m-1],0,0] if area=='monthlyProfit' else [rv[m-1]-co[m-1]-ex[m-1],0,0,0]
   rows.extend([[code,'2026-06',area,k,None if blank else v,str(m)] for k,v in zip(keys,vals)])
 assert len(rows)==99;return rows

def writecsv(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f,lineterminator='\r\n');w.writerow(HEAD);w.writerows(rows)
def style(s,widths):
 s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
 for cell in s[1]:cell.fill=PatternFill('solid',fgColor='173F6E');cell.font=Font(name='微软雅黑',bold=True,color='FFFFFF');cell.alignment=Alignment(wrap_text=True)
 for k,v in widths.items():s.column_dimensions[k].width=v
 for row in s.iter_rows(min_row=2):
  for c in row:c.font=Font(name='微软雅黑',size=10);c.alignment=Alignment(wrap_text=True,vertical='top');c.number_format='0.000000' if c.column==5 else '@'
 s.sheet_properties.pageSetUpPr.fitToPage=True;s.page_setup.orientation='landscape';s.page_setup.fitToWidth=1;s.page_setup.fitToHeight=0;s.print_title_rows='1:1'
def writexlsx(p,rows):
 w=Workbook();s=w.active;s.title='整理数据_另存UTF8CSV';s.append(HEAD)
 for row in rows:s.append(row)
 style(s,dict(zip('ABCDEF',[18,16,25,24,20,14])));s['E1'].comment=Comment('金额为本位币万元，最多六位小数。1人民币元=0.0001万元。无余额应明确填0，待填模板不能直接计算。','天元EPM')
 s=w.create_sheet('填写与导入说明');s.append(['事项','说明'])
 notes=[('不能直接上传XLSX','财务三表报送→导入完整三表CSV只接受CSV。首表填写完成，另存为CSV UTF-8（逗号分隔），只导出首表，再上传.csv。不使用ERP凭证导入入口。'),('表头和行数','保留六列表头，数据从第2行开始。每法人99行，零项也保留填0，无效标题/合计行和第7列不得混入。'),('金额单位','所有六区均本位币万元，不是ERP凭证模板的元。最多六位小数。期间2026-06。'),('六区含义','opening为2026年年初，closing为6月30日，profit/cashflow为1—6月累计。累计区月份留空，monthlyProfit/monthlyCashflow是1至6月各月真实发生额；各月合计等于累计，不能把累计复制6遍。'),('空白文件','待填模板金额为空，不能直接作为零账上传。无发生项目填0，不删行；不保留公式，只粘贴值。'),('法人代码','按UI导出采用HW00/HW01/HW02；系统亦接受对应ID HW/HW_CAT/HW_ELEC。三套报表互不重叠。'),('历史资本','本例年初资本100/50/50与初始源一致。真实年初资本不同时，须先在该法人编辑本期三表源表单完整保存实际数据，表单同步历史资本，再使用CSV；不要为过校验改成示例金额。'),('独立练习','已载入ERP凭证的旧账套不要混用此手工三表练习，应备份并另用独立Demo数据目录。若6月已签，先重开鸿旺及祖先。'),('抵销准备','仅本例：HW向HW_CAT已结算销售60，1—6月各10。报表聚合不能自动识别内部交易，须凭内部资料新建并审批；停用本期旧演示HW-SALES-06约66.67防双扣。'),('虚构例预期','三家收入900成本540费用90净270，抵销销售成本各60后收入840成本480费用90净270。资产现金470、负债0、资本200、留存270；期初现金200+经营现金270=期末470。')]
 for row in notes:s.append(row)
 style(s,{'A':25,'B':115})
 s=w.create_sheet('数据区与字段字典');s.append(['数据区','口径','项目编码','中文含义','月份规则','金额单位'])
 for area,keys in [('opening',BS),('closing',BS),('profit',PL),('cashflow',CF),('monthlyProfit',PL),('monthlyCashflow',CF)]:
  meaning={'opening':'2026年年初','closing':'2026-06-30','profit':'1—6月累计损益','cashflow':'1—6月累计现金流','monthlyProfit':'每月损益发生额','monthlyCashflow':'每月现金流发生额'}[area]
  for k in keys:s.append([area,meaning,k,LABELS[k],'填1至6' if area.startswith('monthly') else '留空','本位币万元'])
 style(s,dict(zip('ABCDEF',[26,27,24,28,20,20])));w.save(p)

def main():
 records=[];allrows=[]
 def record(p,**kw):records.append({'file':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**kw})
 for spec in SPECS:
  eid,code,stem,name,*_=spec;allrows+=matrix(spec)
  for blank in [False,True]:
   suffix='待填模板' if blank else '已填示例';p=ROOT/'data'/('空白CSV' if blank else '示例CSV')/(stem+'_2026-06_'+suffix+'.csv');writecsv(p,matrix(spec,blank));record(p,entityId=eid,entityCode=code,name=name,rows=99,blank=blank,directImport=True)
   p=ROOT/'data/Excel整理表'/(stem+'_2026-06_'+suffix+'_需另存CSV.xlsx');writexlsx(p,matrix(spec,blank));record(p,entityId=eid,entityCode=code,name=name,rows=99,blank=blank,directImport=False)
 p=ROOT/'data/示例CSV/04_鸿旺三法人_2026-06_合并导入示例.csv';writecsv(p,allrows);record(p,rows=297,blank=False,directImport=True)
 p=ROOT/'data/Excel整理表/04_鸿旺三法人_2026-06_已填示例_需另存CSV.xlsx';writexlsx(p,allrows);record(p,rows=297,blank=False,directImport=False)
 w=Workbook();s=w.active;s.title='页面照填_不直接导入';s.append(['事项','填写值'])
 for row in [('合并单元','HW_GROUP / 鸿旺小合并'),('期间','2026-06'),('交易唯一标识','HW-JUNE-2026-CSV-SALES-001'),('卖方','HW / 鸿旺单体'),('买方','HW_CAT / 鸿旺猫爬架生产事业部'),('币种单位','CNY / 人民币万元'),('累计已结算内部销售',60),('适用边界','全部已结算，无期末内部应收应付和未实现存货利润；不代表通用自动抵销'),('操作','抵销与调整凭证新建销售草稿，月度1至6各10，负责人审批再合并；本准备表没有上传入口'),('旧事项','停用本期HW-SALES-06约66.67；保留其他期间及历史')]:s.append(row)
 style(s,{'A':30,'B':110});s=w.create_sheet('逐月内部交易依据');s.append(['月份','已结算销售万元','卖方','买方','依据（虚构）'])
 for m in range(1,7):s.append([str(m),10,'HW','HW_CAT',f'内部对账2026-{m:02d}销售10已结算'])
 style(s,dict(zip('ABCDE',[15,25,20,20,60])));p=ROOT/'data/Excel整理表/05_内部销售抵销准备表_页面维护.xlsx';w.save(p);record(p,directImport=False)
 expected={'inputEntities':3,'rowsPerEntity':99,'allSourceRows':297,'revenueBeforeElimination':900,'revenue':840,'cost':480,'expense':90,'net':270,'assets':470,'liabilities':0,'cash':470,'capital':200,'retained':270,'openingCash':200,'operatingCash':270,'salesElimination':60,'monthlySalesElimination':{str(m):10 for m in range(1,7)}}
 meta={'softwareBaseline':'ERP-20261021','period':'2026-06','unit':'本位币万元（六位小数）','headers':HEAD,'softwareChanged':False,'sourcePath':'财务三表报送→导入完整三表CSV','notERP':True,'files':records,'expected':expected,'sourceMonthlyDesign':[{'id':s[0],'code':s[1],'revenue':s[5],'cost':s[6],'expense':s[7]} for s in SPECS]}
 (ROOT/'data/案例与文件清单.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(records),'allRows':297,'expected':expected},ensure_ascii=False))
if __name__=='__main__':main()
