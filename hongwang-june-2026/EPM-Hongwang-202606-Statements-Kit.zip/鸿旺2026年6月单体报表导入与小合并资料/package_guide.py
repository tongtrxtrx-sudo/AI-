from pathlib import Path
import hashlib,json,shutil,zipfile
from verify_guide import ROOT,main as verify
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 proof=verify();stage=ROOT/'package/鸿旺2026年6月单体报表导入与小合并资料';stage.parent.mkdir(exist_ok=True)
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir()
 stem='鸿旺2026年6月单体报表导入与小合并操作指南'
 for ext in ['docx','pdf']:shutil.copy2(ROOT/'output'/(stem+'.'+ext),stage/(stem+'.'+ext))
 for folder in ['data','screenshots','content']:shutil.copytree(ROOT/folder,stage/folder)
 for name in ['先读我.md','render_guide.py','release.json','verify_guide.py','package_guide.py']:shutil.copy2(ROOT/name,stage/name)
 for folder in ['evidence','acceptance','scripts']:
  dest=stage/folder;dest.mkdir()
  for p in (ROOT/folder).iterdir():
   if p.is_file() and p.suffix in {'.json','.md','.py','.csv'}:shutil.copy2(p,dest/p.name)
 files=sorted(p for p in stage.rglob('*') if p.is_file())
 for p in files:
  assert p.suffix not in {'.db','.sqlite','.sqlite3','.log','.pyc','.pdb','.private'} and p.name not in {'instance.json','launcher.lock','.env'}
 records=[{'file':p.relative_to(stage).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
 (stage/'交付文件清单.json').write_text(json.dumps({'passed':True,'businessPeriod':'2026-06','softwareChanged':False,'files':records,'note':'清单不包含自身和SHA256SUMS，ZIP自身摘要放在外部.sha256文件以避免自引用。'},ensure_ascii=False,indent=2)+'\n')
 files=sorted(p for p in stage.rglob('*') if p.is_file());(stage/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(stage).as_posix()+'\n' for p in files))
 out=ROOT/'EPM-Hongwang-202606-Statements-Kit.zip'
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(stage.rglob('*')):
   if p.is_file():z.write(p,stage.name+'/'+p.relative_to(stage).as_posix())
 with zipfile.ZipFile(out) as z:assert z.testzip() is None
 out.with_suffix('.zip.sha256').write_text(sha(out)+'  '+out.name+'\n')
 print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'files':len(files)+1},ensure_ascii=False))
if __name__=='__main__':main()
