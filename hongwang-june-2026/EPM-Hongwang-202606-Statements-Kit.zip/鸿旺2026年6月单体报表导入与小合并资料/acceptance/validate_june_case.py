#!/usr/bin/env python3
from pathlib import Path
from copy import deepcopy
from datetime import datetime,timezone
import csv,hashlib,io,json,sys
ROOT=Path(__file__).resolve().parents[1]
PRODUCT=Path('/workspace/epm-demo-vouchers')
sys.path.insert(0,str(PRODUCT/'acceptance'))
from support import Server,manifest
HEAD=['法人编码','期间','数据区','项目编码','金额','月份']
IDS=['HW','HW_CAT','HW_ELEC'];CODES={'HW00':'HW','HW01':'HW_CAT','HW02':'HW_ELEC'}
FILE_NAMES=['01_鸿旺单体_2026-06_已填示例.csv','02_猫爬架法人_2026-06_已填示例.csv','03_电子工厂法人_2026-06_已填示例.csv']
ALL_FILE=ROOT/'data/示例CSV/04_鸿旺三法人_2026-06_合并导入示例.csv'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def text(p):return p.read_text(encoding='utf-8-sig')
def encode(rows):
 out=io.StringIO();w=csv.writer(out);w.writerow(HEAD);w.writerows(rows);return out.getvalue()
def rows(p):return list(csv.reader(io.StringIO(text(p))))[1:]
def open_hw(c):
 c.bootstrap('HW_GROUP',month=6,currency='CNY');c.act('unit_reopen',{'unitId':'HW_GROUP','reason':'6月独立报表导入测试，保留既有历史。','cascade':True});return c

def setup_elimination(c):
 old=next(e for e in c.state['eliminations'] if e['id']=='HW-SALES-06');assert round(old['amount'],2)==66.67
 c.act('elimination_cancel',{'id':old['id'],'reason':'替换6月初始化66.67虚构抵销，使用本例内部交易60的明确月度依据。'})
 c.act('elimination_save',{'unitId':'HW_GROUP','kind':'sales','sourceId':'HW-JUNE-2026-CSV-SALES-001','amount':60,'currency':'CNY','sellerId':'HW','buyerId':'HW_CAT','monthlyAmounts':{str(m):10 for m in range(1,7)},'reason':'虚构HW向猫爬架已结算内部销售，1—6月各10万元，共60。'})
 return next(e for e in c.state['eliminations'] if e['sourceId']=='HW-JUNE-2026-CSV-SALES-001')
def finish(c,journal):
 c.act('elimination_approve',{'id':journal['id']});c.act('consolidation_run',{'unitId':'HW_GROUP'});r=c.state['currentResult'];assert r['passed'];c.act('result_approve',{'resultId':r['id']});r=deepcopy(c.state['currentResult']);a=c.state['statement']['actual']
 assert (a['revenue'],a['cost'],a['expense'],a['net'],a['assets'],a['liabilities'],a['cash'])==(840,480,90,270,470,0,470),a
 assert r['approvalStatus']=='已签核' and r['valid'] is True
 assert set(r['sourceSnapshots'])==set(IDS)
 assert r['report']['opening']['cash']==200 and r['report']['cashflow']['operating']==270
 assert r['report']['closing']['capital']==200 and r['report']['closing']['retained']==270
 assert len(r['report']['monthlyProfit'])==6
 june=r['report']['monthlyProfit']['6'];assert (june['revenue'],june['cost'],june['expense'])==(160,90,16)
 assert r['report']['monthlyCashflow']['6']['operating']==54
 return r,a

def case_files():
 meta=json.loads((ROOT/'data/案例与文件清单.json').read_text());assert meta['period']=='2026-06';allrows=[]
 for name in FILE_NAMES:
  p=ROOT/'data/示例CSV'/name;rs=rows(p);assert len(rs)==99;allrows+=rs
  assert list(csv.reader(io.StringIO(text(p))))[0]==HEAD
  for r in rs:assert len(r)==6 and r[1]=='2026-06'
  assert sum(r[2]=='opening' for r in rs)==18 and sum(r[2]=='closing' for r in rs)==18
  assert sum(r[2]=='monthlyProfit' for r in rs)==30 and sum(r[2]=='monthlyCashflow' for r in rs)==24
  assert {r[5] for r in rs if r[2].startswith('monthly')}=={str(m) for m in range(1,7)}
  assert all(not r[5] for r in rs if not r[2].startswith('monthly'))
 assert allrows==rows(ALL_FILE)
 from openpyxl import load_workbook
 for item in meta['files']:
  p=ROOT/item['file'];assert sha(p)==item['sha256']
  if p.suffix=='.xlsx':
   w=load_workbook(p,data_only=False);assert not any(cell.data_type=='f' for s in w for row in s for cell in row)
 return {'三份各99行':True,'合并文件297行且等同三份顺序拼接':True,'六月及六个发生月正确':True,'Excel整理表非直接入口且无公式':True}

def case_reject_atomic():
 with Server() as s:
  c=open_hw(s.client);before=deepcopy(c.state['sources']);rev=c.state['revision'];rs=rows(ALL_FILE)
  bads=[]
  bad=deepcopy(rs);next(r for r in bad if r[0]=='HW02' and r[2]=='closing' and r[3]=='cash')[4]='81';bads.append(('批内第三家期末不平',encode(bad)))
  bads.append(('期间错为9月',text(ALL_FILE).replace('2026-06','2026-09')))
  bad=[r for r in rs if not(r[0]=='HW01' and r[2]=='monthlyProfit' and r[3]=='revenue' and r[5]=='6')];bads.append(('缺6月明细',encode(bad)))
  bad=deepcopy(rs);bad.append(deepcopy(bad[0]));bads.append(('重复法人区字段月份',encode(bad)))
  bad=deepcopy(rs);next(r for r in bad if r[2]=='opening')[5]='1';bads.append(('累计区误填月份',encode(bad)))
  checks=[]
  for label,raw in bads:
   v=c.act('source_import',{'csv':raw,'sourceName':label+'.csv'},expected=(400,409,422));c.bootstrap('HW_GROUP',month=6,currency='CNY');assert c.state['revision']==rev and c.state['sources']==before;checks.append({'name':label,'rejected':True,'zeroWrite':True,'message':v.get('message') or v.get('error')})
  return {'negativeCases':checks}

def case_three_individual():
 with Server() as s:
  c=s.client;c.bootstrap('HW_GROUP',month=9,currency='CNY');sep=deepcopy(c.state['currentResult']);c=open_hw(c);oldsrc=deepcopy(c.state['sources']);versions={}
  for eid,name in zip(IDS,FILE_NAMES):
   c.act('source_import',{'csv':text(ROOT/'data/示例CSV'/name),'sourceName':name});versions[eid]=c.state['sources'][eid]['version'];assert versions[eid]==oldsrc[eid]['version']+1
  # Six-month seed elimination is not the customer's fact; preview alone is not proof.
  before_actual=deepcopy(c.state['statement']['actual']);assert round(before_actual['revenue'],2)==833.33
  j=setup_elimination(c);rev=c.state['revision'];c.act('consolidation_run',{'unitId':'HW_GROUP'},expected=(400,409,422));c.bootstrap('HW_GROUP',month=6,currency='CNY');assert c.state['revision']==rev
  r,a=finish(c,j);saved=deepcopy(r);assert {k:v['version'] for k,v in r['sourceSnapshots'].items()}==versions
  rev=c.state['revision'];c.act('source_import',{'csv':text(ALL_FILE),'sourceName':'签核后禁止改源.csv'},expected=409);c.bootstrap('HW_GROUP',month=6,currency='CNY');assert c.state['revision']==rev
  c.act('unit_reopen',{'unitId':'HW_GROUP','reason':'验证重导形成新源与新结果，原签核仍只读。','cascade':True});c.act('source_import',{'csv':text(ALL_FILE),'sourceName':'完整相同源重导形成新版本.csv'});c.act('consolidation_run',{'unitId':'HW_GROUP'});new=c.state['currentResult'];assert new['id']!=saved['id']
  old=next(x for x in c.state['results'] if x['id']==saved['id']);assert old['report']==saved['report'] and old['sourceSnapshots']==saved['sourceSnapshots']
  c.bootstrap('HW_GROUP',month=9,currency='CNY');assert c.state['currentResult']['id']==sep['id'] and c.state['currentResult']['valid'] is True
  return {'依次三份CSV实际导入':True,'sourceVersions':versions,'替换旧抵销前预览收入':before_actual['revenue'],'新手工抵销':{'amount':60,'monthlyAmounts':j['monthlyAmounts'],'seller':'HW','buyer':'HW_CAT'},'草稿未审批阻止计算且零写入':True,'signedResult':{'id':r['id'],'version':r['version'],'actual':{k:a[k] for k in ['revenue','cost','expense','net','assets','liabilities','cash']},'sourceVersions':versions},'期初现金200经营270期末470':True,'sixthMonthOnly':{'revenue':160,'cost':90,'expense':16,'net':54,'operatingCash':54},'签核后改源拒绝':True,'重开重导新版本但历史源金额不变':True,'9月历史不受6月修改影响':True}

def case_combined():
 with Server() as s:
  c=open_hw(s.client);c.act('source_import',{'csv':text(ALL_FILE),'sourceName':ALL_FILE.name});assert c.state['trialBalances'][-1]['rowCount']==297
  j=setup_elimination(c);r,a=finish(c,j)
  return {'一次三家297行导入':True,'单独与合并文件同样结果':True,'actual':{k:a[k] for k in ['revenue','net','assets','cash']}}

def case_capital_history():
 with Server() as s:
  c=open_hw(s.client);p=ROOT/'data/示例CSV'/FILE_NAMES[0];rs=rows(p)
  for r in rs:
   if (r[2],r[3]) in {('opening','cash'),('opening','capital'),('closing','cash'),('closing','capital')}:r[4]=str(int(r[4])+10)
  raw=encode(rs);rev=c.state['revision'];old=deepcopy(c.state['sources']['HW']);v=c.act('source_import',{'csv':raw,'sourceName':'真实资本110而旧历史100.csv'},expected=(400,409,422));c.bootstrap('HW_GROUP',month=6,currency='CNY');assert c.state['revision']==rev and c.state['sources']['HW']==old
  src={k:{} for k in ['opening','closing','profit','cashflow','monthlyProfit','monthlyCashflow']}
  for _,_,area,key,amount,m in rs:
   if area.startswith('monthly'):src[area].setdefault(m,{})[key]=float(amount)
   else:src[area][key]=float(amount)
  src.update(currency='CNY',sourceName='表单完整实际三表110资本同步保存',capitalMovement=0,equityHistory={'capitalByEntity':{'HW':110},'openingRetainedCny':0,'dividendsByMonth':{}})
  # Exact public action sent by the actual source-edit form after readSource().
  c.act('source_save',{'entityId':'HW','source':src});assert c.state['sources']['HW']['equityHistory']['capitalByEntity']['HW']==110
  c.act('source_import',{'csv':raw,'sourceName':'历史资本已同步后相同真实CSV.csv'});s1=c.state['sources']['HW'];assert s1['opening']['capital']==110 and s1['closing']['cash']==290
  return {'改变期初资本但CSV不含历史参数时拒绝且零写入':True,'rejection':v.get('message') or v.get('error'),'source_save完整源同步历史资本110后相同CSV可导入':True,'未强迫套示例100':True,'sourceVersion':s1['version']}

def case_erp_separate():
 with Server() as s:
  c=s.client;c.act('erp_sample_load',{'replace':True,'reason':'只在独立临时账套验证手工与凭证模式不混。'});c.bootstrap('HW_GROUP',month=6,currency='CNY');c.act('erp_report_generate',{'entityIds':IDS})
  assert all(c.state['sources'][eid].get('sourceType')=='erp' for eid in IDS)
  c.act('source_import',{'csv':text(ALL_FILE),'sourceName':'混用手工报表CSV不能视作凭证源.csv'})
  rev=c.state['revision'];v=c.act('consolidation_run',{'unitId':'HW_GROUP'},expected=(400,409,422));c.bootstrap('HW_GROUP',month=6,currency='CNY');assert c.state['revision']==rev
  bad=[x for x in c.state['preconditions'] if x.get('code','').startswith('erp_source_') and x['passed'] is False];assert len(bad)==3
  return {'ERP有效凭证后手工CSV不能绕过凭证源指纹':True,'failedEntityChecks':[x['code'] for x in bad],'rejection':v.get('message') or v.get('error'),'建议': '独立数据目录练习，不删旧账套，不把当前ERP凭证账套强改为手工源。'}

def main():
 before=manifest();meta=json.loads((ROOT/'data/案例与文件清单.json').read_text());inputs={x['file']:sha(ROOT/x['file']) for x in meta['files']};results=[]
 for name,fn in [('资料结构与明确月份单位',case_files),('五类错误整批零写入',case_reject_atomic),('三份逐一导入与草稿审批签核历史',case_three_individual),('三家合并297行一次导入',case_combined),('真实期初资本变化与历史参数',case_capital_history),('已存在ERP凭证模式不能混绕',case_erp_separate)]:
  try:ev=fn();results.append({'case':name,'passed':True,'evidence':ev});print(name,'PASS',flush=True)
  except Exception as exc:results.append({'case':name,'passed':False,'error':repr(exc)});print(name,'FAIL',repr(exc),flush=True)
 after=manifest();input_after={x['file']:sha(ROOT/x['file']) for x in meta['files']};ok=all(x['passed'] for x in results) and before==after and inputs==input_after
 report={'passed':ok,'verifiedUtc':datetime.now(timezone.utc).isoformat(),'softwareBaseline':'ERP-20261021','period':'2026-06','method':'独立新私有临时SQLite、真实HTTP公开接口；未导入产品计算函数；CSV为实际交付文件。','sourceSha256':after,'sourceUnchangedDuringRun':before==after,'harnessSha256':sha(Path(__file__)),'inputSha256':input_after,'inputFilesUnchangedDuringRun':inputs==input_after,'cases':results,'limitations':['这是单体报表完整源CSV路径，不是NC凭证导入；当前此入口仅CSV，Excel整理后须另存UTF-8 CSV。','聚合报表不能自动辨识内部客商和共同交易；本例手工审批已结算销售60，不演示期末未结往来或未实现存货利润。','金额本位币万元，6月指6月30日余额及1—6月累计，逐月1—6必须完整；不把累计倒摊。','原EXE和产品代码未改，实际客户数据仍须按会计政策和适用范围核对。']}
 out=ROOT/'acceptance/六月鸿旺小合并真实验收.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 lines=['# 2026年6月鸿旺单体报表导入与小合并：真实验收','',f'结论：{len(results)}组，'+('全部通过。' if ok else '存在阻断，不能作为最终交付。'),'','方法：新独立临时账套，经真实HTTP接口导入交付CSV，不修改产品内存或复用9月金样。金额全部本位币万元。','', '|检查组|结果|','|---|---|']
 for x in results:lines.append('|'+x['case']+'|'+('通过' if x['passed'] else '失败')+'|')
 lines+=['','预期：三家收入900、成本540、费用90、净利润270；核实已结算内部销售60（每月10），先停用旧演示66.67再新建审批，鸿旺收入840、成本480、费用90、净利润270、资产现金470、负债0、资本200、留存270。期初现金200+经营现金流270=期末470。','',*['- '+x for x in report['limitations']],'','明细、文件及软件摘要见同名JSON。无数据库、启动token或凭据随证据发布。']
 (ROOT/'acceptance/六月鸿旺小合并真实验收.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'passed':ok,'groups':len(results),'sourceUnchanged':before==after,'inputsUnchanged':inputs==input_after},ensure_ascii=False));raise SystemExit(0 if ok else 1)
if __name__=='__main__':main()
