#!/usr/bin/env python3
"""Generate an editable Chinese Word manual from the reviewed Markdown text."""
from pathlib import Path
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import re

BASE=Path(__file__).resolve().parent

def font(run,name='微软雅黑',size=None):
    run.font.name=name
    run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),name)
    if size:run.font.size=Pt(size)

def simple(p,s):
    # Backtick markers do not belong in visible Word body.
    r=p.add_run(s.replace('`','')); font(r)

def generate():
    doc=Document(); section=doc.sections[0]
    section.page_width=Cm(21);section.page_height=Cm(29.7)
    section.top_margin=Cm(2);section.bottom_margin=Cm(2);section.left_margin=Cm(2.1);section.right_margin=Cm(2.1)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3']:
        style=doc.styles[name]; style.font.name='微软雅黑';style._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'微软雅黑')
    doc.styles['Normal'].font.size=Pt(10.5)
    doc.styles['Normal'].paragraph_format.space_after=Pt(6)
    for name in ['Heading 1','Heading 2','Heading 3']:
        doc.styles[name].font.color.rgb=RGBColor.from_string('173F5F')
    footer=section.footer.paragraphs[0];footer.alignment=2
    simple(footer,'天元 EPM · 多层合并演示版  |  ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    lines=(BASE/'多层合并Demo安装与演示手册.md').read_text(encoding='utf-8').splitlines()
    code=False;i=0
    while i<len(lines):
        line=lines[i]
        if line.startswith('```'):code=not code;i+=1;continue
        if not line.strip():i+=1;continue
        picture=re.fullmatch(r'!\[([^\]]*)\]\(([^)]+)\)',line.strip())
        if picture:
            target=(BASE/picture.group(2)).resolve()
            doc.add_picture(str(target),width=Cm(16.6))
            p=doc.add_paragraph();p.alignment=1;simple(p,picture.group(1))
            for r in p.runs:font(r,size=9)
            i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):
                cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(set(c)<=set('-: ') for c in cells): rows.append(cells)
                i+=1
            if not rows:continue
            table=doc.add_table(rows=len(rows),cols=len(rows[0]));table.style='Table Grid'
            for n,row in enumerate(rows):
                for c,value in enumerate(row):
                    cell=table.cell(n,c);cell.text='';simple(cell.paragraphs[0],value)
                    if n==0:
                        for r in cell.paragraphs[0].runs:r.bold=True
                        shading=OxmlElement('w:shd');shading.set(qn('w:fill'),'E9F2F8');cell._tc.get_or_add_tcPr().append(shading)
                    for p in cell.paragraphs:
                        p.paragraph_format.space_after=Pt(3)
                        for r in p.runs:font(r,size=9)
            for row in table.rows:
                props=row._tr.get_or_add_trPr()
                keep=OxmlElement('w:cantSplit');props.append(keep)
            doc.add_paragraph();continue
        if line.startswith('# '):
            p=doc.add_paragraph(style='Title');simple(p,line[2:])
        elif line.startswith('## '):
            p=doc.add_heading(level=1);simple(p,line[3:])
        elif line.startswith('### '):
            p=doc.add_heading(level=2);simple(p,line[4:])
        elif line.startswith('> '):
            p=doc.add_paragraph();r=p.add_run(line[2:]);font(r);r.italic=True
        else:
            p=doc.add_paragraph();simple(p,line.rstrip())
            if code:
                p.paragraph_format.left_indent=Cm(.25)
                for r in p.runs:font(r,name='等线',size=9)
        i+=1
    doc.core_properties.title='天元 EPM 多层合并 Demo 安装与演示手册'
    doc.core_properties.subject='杭州天元宠物用品有限公司：鸿旺分级合并、美元折算、集团上卷及版本追溯'
    doc.core_properties.author='天元 EPM 项目'
    target=BASE/'天元EPM_多层合并Demo安装与演示手册.docx'
    doc.save(target)
    return target

if __name__=='__main__': print(generate().name)
