#!/usr/bin/env python3
"""可移植的本机 EPM 演示服务。仅使用 Python 标准库。"""
from __future__ import annotations
import argparse
import json
import mimetypes
import os
from pathlib import Path
import secrets
import sys
import threading
import traceback
import time
import webbrowser
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse
# -I 隔离模式不把脚本目录加入搜索路径，显式仅加入已知的本产品目录。
sys.path.insert(0,str(Path(__file__).resolve().parent))
from engine import ROLES, bootstrap, context, apply, seed
from store import Store, DomainError

PRODUCT='SelfDevelopedEPM-Multilevel-Demo'
MAX_BODY=2_100_000

class Server(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=False
    def __init__(self,port,data_dir,static_dir):
        super().__init__(('127.0.0.1',port),Handler)
        self.store=Store(data_dir,seed)
        self.static_dir=Path(static_dir).resolve()
        self.token=secrets.token_urlsafe(32)
        self.instance_id=secrets.token_hex(16)
        self.sessions={}
        self.session_lock=threading.Lock()
        self.origin=f'http://127.0.0.1:{self.server_port}'
        self.data_dir=str(Path(data_dir).resolve())

class Handler(BaseHTTPRequestHandler):
    server_version='EPMDemo/1.0'
    def log_message(self,*args):pass
    def response(self,status,value,headers=None):
        raw=json.dumps(value,ensure_ascii=False,allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        for k,v in (headers or {}).items():self.send_header(k,v)
        self.end_headers()
        if self.command!='HEAD':self.wfile.write(raw)
    def error(self,ex):
        self.response(ex.status,{'error':{'code':ex.code,'message':ex.message},'message':ex.message})
    def origin_check(self,required=True):
        origin=self.headers.get('Origin')
        if (required or origin) and origin!=self.server.origin:
            raise DomainError('请求来源与本机演示服务不一致。','invalid_origin',403)
        host=self.headers.get('Host','')
        if host!=self.server.origin.split('://',1)[1]:
            raise DomainError('仅允许通过本机指定地址访问。','invalid_host',403)
    def body(self):
        if self.headers.get('Transfer-Encoding'):raise DomainError('不支持分块请求。')
        if self.headers.get_content_type()!='application/json':raise DomainError('请求必须为JSON格式。','content_type',415)
        try:length=int(self.headers.get('Content-Length','0'))
        except ValueError:raise DomainError('请求长度无效。')
        if length<=0 or length>MAX_BODY:raise DomainError('请求正文为空或超过2MB。','body_too_large',413)
        try:
            def invalid(s):raise ValueError(s)
            result=json.loads(self.rfile.read(length).decode('utf-8'),parse_constant=invalid)
        except (UnicodeDecodeError,ValueError):raise DomainError('JSON格式无效，数字不能为NaN或无穷值。')
        if not isinstance(result,dict):raise DomainError('请求JSON必须为对象。')
        return result
    def session(self,csrf=False):
        cookie=SimpleCookie()
        try:cookie.load(self.headers.get('Cookie',''))
        except Exception:raise DomainError('登录会话无效，请重新打开启动器。','unauthorized',401)
        sid=cookie.get('epm_group_session')
        sid=sid.value if sid else ''
        with self.server.session_lock:session=self.server.sessions.get(sid)
        if not session:raise DomainError('尚未登录，请从自研EPM启动器打开本机演示。','unauthorized',401)
        if csrf and not secrets.compare_digest(self.headers.get('X-CSRF-Token',''),session['csrf']):
            raise DomainError('安全校验已失效，请刷新页面。','csrf',403)
        return session
    def view(self,session,c):
        revision,data,activities=self.server.store.read()
        result=bootstrap(data,revision,activities,session['role'],c)
        result['csrfToken']=session['csrf']
        result['demoNotice']='本机持久化演示环境；示例数据不用于正式会计报表。'
        return result
    def do_HEAD(self):self.do_GET()
    def do_GET(self):
        try:
            self.origin_check(False)
            parsed=urlparse(self.path)
            if parsed.path=='/api/health':
                self.response(200,{'ready':True,'instanceId':self.server.instance_id,'product':PRODUCT});return
            if parsed.path=='/api/runtime':
                self.session();self.response(200,{'dataDir':self.server.data_dir,'logDir':str(Path(self.server.data_dir)/'logs'),'platform':'Windows' if os.name=='nt' else '本机开发环境'});return
            if parsed.path=='/api/bootstrap':
                session=self.session();q=parse_qs(parsed.query,keep_blank_values=True)
                c={k:v[-1] for k,v in q.items() if k in ('group','month','currency','entity')}
                self.response(200,self.view(session,context(c)));return
            if parsed.path.startswith('/api/'):
                raise DomainError('接口不存在。','not_found',404)
            requested=unquote(parsed.path)
            relative='index.html' if requested in ('','/') else requested.lstrip('/')
            path=(self.server.static_dir/relative).resolve()
            try:path.relative_to(self.server.static_dir)
            except ValueError:raise DomainError('文件路径无效。','not_found',404)
            if not path.is_file():
                raise DomainError('页面文件不存在，请重新解压完整软件包。','not_found',404)
            raw=path.read_bytes();mime=mimetypes.guess_type(str(path))[0] or 'application/octet-stream'
            self.send_response(200);self.send_header('Content-Type',mime+('; charset=utf-8' if mime.startswith('text/') or mime=='application/javascript' else ''))
            self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-cache');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
            self.end_headers()
            if self.command!='HEAD':self.wfile.write(raw)
        except DomainError as ex:self.error(ex)
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception:
            traceback.print_exc(file=sys.stderr)
            self.error(DomainError('读取数据失败，请查看本机安装是否完整。','internal',500))
    def do_POST(self):
        try:
            path=urlparse(self.path).path
            launcher=self.headers.get('X-EPM-Token','')
            if path=='/api/shutdown' and launcher and secrets.compare_digest(launcher,self.server.token):
                self.origin_check(False);self.response(200,{'stopped':True,'message':'正在安全退出，数据已保存。'});threading.Thread(target=self.server.shutdown,daemon=True).start();return
            self.origin_check(True)
            if path=='/api/session':
                p=self.body();token=p.get('token')
                if not isinstance(token,str) or not secrets.compare_digest(token,self.server.token):raise DomainError('启动凭证无效，请重新从启动器打开。','unauthorized',401)
                sid=secrets.token_urlsafe(32);session={'csrf':secrets.token_urlsafe(32),'role':ROLES[0]}
                with self.server.session_lock:self.server.sessions[sid]=session
                self.response(200,{'csrfToken':session['csrf'],'sessionRole':session['role']},{'Set-Cookie':f'epm_group_session={sid}; Path=/; HttpOnly; SameSite=Strict'});return
            session=self.session(csrf=True)
            if path=='/api/open-data-dir':
                self.body()
                opened=False
                if os.name=='nt':
                    try:os.startfile(self.server.data_dir);opened=True
                    except OSError:raise DomainError('无法自动打开数据目录，请复制目录路径到资源管理器。','open_directory',500)
                self.response(200,{'opened':opened,'dataDir':self.server.data_dir,'message':'已打开数据目录。' if opened else '请复制数据目录路径到本机文件管理器打开。'});return
            if path=='/api/shutdown':
                self.body();self.response(200,{'stopped':True,'message':'正在安全退出，数据已保存。'});threading.Thread(target=self.server.shutdown,daemon=True).start();return
            if path!='/api/action':raise DomainError('接口不存在。','not_found',404)
            body=self.body();action=body.get('action');p=body.get('payload',{});c=context(body.get('context'))
            if not isinstance(action,str) or not isinstance(p,dict):raise DomainError('操作名称或参数无效。')
            if action=='role_switch':
                role=p.get('role')
                if role not in ROLES:raise DomainError('演示角色无效。')
                session['role']=role
            else:self.server.store.mutate(body.get('revision'),session['role'],action,p,c,apply)
            # 命令按提交时的上下文验证；范围保存后报表币种可能改变。
            # 成功响应使用当前范围币种，避免业务已提交却返回旧币种校验错误。
            view_context={**c,'currency':None,'entity':'all'} if action=='unit_save' else c
            self.response(200,self.view(session,view_context))
        except DomainError as ex:self.error(ex)
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception:
            traceback.print_exc(file=sys.stderr)
            self.error(DomainError('操作未完成，数据未提交。请检查输入或重新启动演示。','internal',500))


def main():
    parser=argparse.ArgumentParser(description='自研EPM中文持久化演示服务')
    parser.add_argument('--data-dir',required=True)
    parser.add_argument('--port',type=int,default=0)
    parser.add_argument('--no-browser',action='store_true')
    parser.add_argument('--static-dir',default=str(Path(__file__).resolve().parent.parent/'frontend'/'dist'))
    args=parser.parse_args()
    if not 0<=args.port<=65535:parser.error('端口必须为0至65535。')
    server=Server(args.port,args.data_dir,args.static_dir)
    url=server.origin+'/#token='+server.token
    print(json.dumps({'ready':True,'url':url,'port':server.server_port,'token':server.token,'instanceId':server.instance_id},ensure_ascii=False),flush=True)
    if not args.no_browser:threading.Timer(.3,lambda:webbrowser.open(url)).start()
    try:server.serve_forever(poll_interval=.2)
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':main()
