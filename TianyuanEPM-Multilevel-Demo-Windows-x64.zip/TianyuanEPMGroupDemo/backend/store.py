"""SQLite事务存储。客户端只能提交领域命令，不能写入状态快照。"""
from __future__ import annotations
import json
import sqlite3
from pathlib import Path
from contextlib import closing
from datetime import datetime, timezone

class DomainError(Exception):
    def __init__(self, message, code='validation', status=400):
        super().__init__(message)
        self.message, self.code, self.status = message, code, status

class Store:
    def __init__(self, data_dir, seed):
        self.path = Path(data_dir).resolve() / 'epm-demo.sqlite3'
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # 先只读识别产品版本，不对旧版或未知数据库执行DDL、WAL或迁移。
        if self.path.exists():
            try:
                with closing(sqlite3.connect(self.path.as_uri()+'?mode=ro&immutable=1',uri=True)) as check:
                    row=check.execute('SELECT document FROM state WHERE id=1').fetchone()
                    existing=json.loads(row[0]) if row else {}
                if existing.get('schemaVersion')!=2 or existing.get('product')!='SelfDevelopedEPM-Multilevel-Demo':
                    raise ValueError('wrong product')
            except (sqlite3.Error,ValueError,TypeError,KeyError):
                raise DomainError('所选数据目录属于旧版或未知系统，本版拒绝改写。请使用独立的TianyuanEPMGroupDemo数据目录。','incompatible_database',409) from None
        # 首次种子在内存完整生成成功后才创建数据库，失败不会遗留空壳文件。
        initial=seed() if not self.path.exists() else None
        with closing(self.connect()) as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL, document TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT NOT NULL, role TEXT NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL, revision INTEGER NOT NULL);''')
            if not db.execute('SELECT 1 FROM state WHERE id=1').fetchone():
                if initial is None:initial=seed()
                db.execute('INSERT INTO state VALUES(1,0,?)', (json.dumps(initial,ensure_ascii=False,allow_nan=False),))
                now=datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')
                db.execute('INSERT INTO audit(time,role,action,detail,revision) VALUES(?,?,?,?,?)',(now,'系统初始化','demo_initialize','虚构演示账套：通过正式合并计算与签核规则建立三层初始结果版本。',0))
            db.commit()
    def connect(self):
        db=sqlite3.connect(self.path,timeout=15)
        db.execute('PRAGMA busy_timeout=15000')
        db.execute('PRAGMA journal_mode=WAL')
        return db
    def read(self):
        with closing(self.connect()) as db:
            revision,raw=db.execute('SELECT revision,document FROM state WHERE id=1').fetchone()
            activities=[{'id':r[0],'time':r[1],'role':r[2],'action':r[3],'text':r[4],'revision':r[5]} for r in db.execute('SELECT id,time,role,action,detail,revision FROM audit ORDER BY id DESC LIMIT 200')]
            return revision,json.loads(raw),activities
    def mutate(self, expected_revision, role, action, payload, context, apply):
        if isinstance(expected_revision,bool) or not isinstance(expected_revision,int):
            raise DomainError('缺少有效的数据版本，请刷新页面。')
        with closing(self.connect()) as db:
            try:
                db.execute('BEGIN IMMEDIATE')
                revision,raw=db.execute('SELECT revision,document FROM state WHERE id=1').fetchone()
                if revision!=expected_revision:
                    raise DomainError('数据已被其他页面更新，请刷新后重试。','revision_conflict',409)
                state=json.loads(raw)
                detail=apply(state,role,action,payload,context)
                revision+=1
                now=datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')
                db.execute('UPDATE state SET revision=?,document=? WHERE id=1',(revision,json.dumps(state,ensure_ascii=False,allow_nan=False)))
                db.execute('INSERT INTO audit(time,role,action,detail,revision) VALUES(?,?,?,?,?)',(now,role,action,detail,revision))
                db.commit()
                return revision
            except BaseException:
                db.rollback()
                raise
