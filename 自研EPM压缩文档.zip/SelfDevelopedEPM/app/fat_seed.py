"""A small FAT16 superfloppy with an actual VFAT long filename.

The guest mounts this read-only as label EPMSEED. No third-party runtime code
is needed by the Windows launcher. Independent FAT readers validate it in the
build evidence; the implementation does not use its own writer as a verifier.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import struct
import tempfile

SECTOR = 512
SECTORS = 32768  # 16 MiB: 8167 clusters, genuinely FAT16 (not a FAT12 BPB).
CLUSTER_SECTORS = 4
FAT_SECTORS = 32
ROOT_ENTRIES = 512
ROOT_SECTORS = ROOT_ENTRIES * 32 // SECTOR
DATA_SECTOR = 1 + 2 * FAT_SECTORS + ROOT_SECTORS
SHORT_NAME = b"EPMSEE~1JSO"
LONG_NAME = "epm-seed.json"
LABEL = b"EPMSEED    "


def _checksum(name: bytes) -> int:
    value = 0
    for byte in name:
        value = (((value & 1) << 7) | (value >> 1)) + byte
        value &= 255
    return value


def write_seed_image(path: Path, seed: dict) -> dict:
    payload = (json.dumps(seed, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    if not payload or len(payload) > 64 * 1024:
        raise ValueError("Seed JSON must contain 1..65536 bytes")
    clusters = (len(payload) + CLUSTER_SECTORS * SECTOR - 1) // (CLUSTER_SECTORS * SECTOR)
    boot = bytearray(SECTOR)
    boot[0:3] = b"\xeb\x3c\x90"
    boot[3:11] = b"MSDOS5.0"
    struct.pack_into("<HBHBHHBHHHII", boot, 11,
                     SECTOR, CLUSTER_SECTORS, 1, 2, ROOT_ENTRIES, SECTORS,
                     0xF8, FAT_SECTORS, 63, 255, 0, 0)
    boot[36] = 0x80
    boot[38] = 0x29
    struct.pack_into("<I", boot, 39, int.from_bytes(hashlib.sha256(payload).digest()[:4], "little"))
    boot[43:54] = LABEL
    boot[54:62] = b"FAT16   "
    boot[510:512] = b"\x55\xaa"
    fat = bytearray(FAT_SECTORS * SECTOR)
    struct.pack_into("<HH", fat, 0, 0xFFF8, 0xFFFF)
    for cluster in range(2, 2 + clusters):
        following = 0xFFFF if cluster == 1 + clusters else cluster + 1
        struct.pack_into("<H", fat, cluster * 2, following)
    root = bytearray(ROOT_SECTORS * SECTOR)
    root[0:11] = LABEL
    root[11] = 0x08
    # Exactly 13 UTF-16 code units fit in one LFN entry without a terminator.
    encoded = LONG_NAME.encode("utf-16le")
    assert len(encoded) == 26
    lfn = bytearray(32)
    lfn[0] = 0x41  # final entry | ordinal 1
    lfn[11:14] = bytes((0x0F, 0, _checksum(SHORT_NAME)))
    lfn[1:11], lfn[14:26], lfn[28:32] = encoded[:10], encoded[10:22], encoded[22:]
    root[32:64] = lfn
    entry = bytearray(32)
    entry[0:11] = SHORT_NAME
    entry[11] = 0x20
    now = datetime.datetime.now()
    date = ((max(1980, min(2107, now.year)) - 1980) << 9) | (now.month << 5) | now.day
    clock = (now.hour << 11) | (now.minute << 5) | (now.second // 2)
    struct.pack_into("<HH", entry, 22, clock, date)
    struct.pack_into("<H", entry, 26, 2)
    struct.pack_into("<I", entry, 28, len(payload))
    root[64:96] = entry
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".seed-", suffix=".img", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(boot)
            stream.write(fat)
            stream.write(fat)
            stream.write(root)
            stream.write(payload)
            stream.truncate(SECTORS * SECTOR)
            stream.flush()
            os.fsync(stream.fileno())
        if os.name != "nt":
            os.chmod(temp_name, 0o600)
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)
    return {"filesystem": "FAT16", "volume_label": "EPMSEED", "filename": LONG_NAME,
            "short_alias": "EPMSEE~1.JSO", "bytes": SECTORS * SECTOR,
            "payload_sha256": hashlib.sha256(payload).hexdigest()}
