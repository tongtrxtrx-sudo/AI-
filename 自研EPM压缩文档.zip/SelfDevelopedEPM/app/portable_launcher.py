"""Private-Python host for the complete Linux/QEMU EPM platform.

Default: start automatically and open a local progress page; no numbered menu.
CLI: status / stop / check (also --status / --stop / --check). Never uses Docker,
WSL, an installed Python, shell=True, taskkill, PID-based kills or a demo app.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import http.server
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser

APP = Path(__file__).resolve().parent
if str(APP) not in sys.path:
    sys.path.insert(0, str(APP))
from fat_seed import write_seed_image

KIND = "self-developed-epm-portable-vm-v1"
MAX_PART = 90 * 1024 * 1024
LOG = logging.getLogger("epm-host")


class HostError(RuntimeError):
    pass


def emit(value):
    if sys.stdout is not None:
        try:
            print(json.dumps(value, ensure_ascii=False), flush=True)
        except UnicodeEncodeError:
            print(json.dumps(value, ensure_ascii=True), flush=True)


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".epm-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        if os.name != "nt":
            os.chmod(name, 0o600)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def read_json(path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return default


def digest_file(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def copy_cancelled(source, destination, cancelled):
    """Bounded-copy cancellation also covers offline bases and part merges."""
    while True:
        if cancelled.is_set():
            raise HostError("已取消复制；不会启动虚拟机或覆盖现有业务盘。")
        block = source.read(1024 * 1024)
        if not block:
            return
        destination.write(block)


def prepare_runtime(assets, root, cancelled):
    """Avoid QEMU's narrow Windows argv: all guest-file arguments are ASCII.

    CreateProcessW selects the absolute executable and Unicode cwd. QEMU only
    receives paths relative to data/. Kernels and firmware are content-bound
    copies; updating a bundle cannot mutate files used by an existing VM.
    """
    sources = {"vmlinuz": assets["kernel"], "initrd.img": assets["initrd"]}
    share = assets["qemu_dir"] / "share"
    if not share.is_dir() or share.is_symlink():
        raise HostError("缺少内置QEMU share固件目录，或该目录是未知符号链接。")
    for folder, directories, files in os.walk(share, followlinks=False):
        for name in directories:
            if (Path(folder) / name).is_symlink():
                raise HostError("QEMU固件目录含未知符号链接，拒绝复制。")
        for name in files:
            file = Path(folder) / name
            relative = "share/" + file.relative_to(share).as_posix()
            if not relative.isascii() or file.is_symlink() or not file.is_file():
                raise HostError("QEMU固件包含非ASCII文件名或非常规文件，拒绝生成不可靠启动参数。")
            sources[relative] = file
    records = []
    content_hash = hashlib.sha256()
    for relative, file in sorted(sources.items()):
        record = {"path": relative, "bytes": file.stat().st_size, "sha256": digest_file(file)}
        records.append(record)
        content_hash.update(json.dumps(record, sort_keys=True, separators=(",", ":")).encode("ascii"))
    runtime_root = root / "data/runtime"
    if runtime_root.is_symlink():
        raise HostError("持久runtime目录是未知符号链接，拒绝写入。")
    runtime_root.mkdir(parents=True, exist_ok=True)
    runtime = runtime_root / content_hash.hexdigest()
    if runtime.is_symlink():
        raise HostError("持久固件目录是未知符号链接，拒绝启动。")

    def verified(directory):
        expected = {record["path"] for record in records}
        actual = set()
        for folder, directories, files in os.walk(directory, followlinks=False):
            if any((Path(folder) / name).is_symlink() for name in directories):
                return False
            for name in files:
                file = Path(folder) / name
                relative = file.relative_to(directory).as_posix()
                if relative != "files.json":
                    actual.add(relative)
                if file.is_symlink():
                    return False
        if actual != expected:
            return False
        return all((directory / record["path"]).stat().st_size == record["bytes"] and
                   digest_file(directory / record["path"]) == record["sha256"] for record in records)

    if runtime.exists():
        if not runtime.is_dir() or not verified(runtime):
            raise HostError("持久内核/固件副本与包内内容校验不符，拒绝启动；不会静默覆盖。")
    else:
        temporary = Path(tempfile.mkdtemp(prefix=".runtime-", dir=runtime_root))
        try:
            for relative, source in sources.items():
                destination = temporary / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                with source.open("rb") as src, destination.open("xb") as dst:
                    copy_cancelled(src, dst, cancelled)
            if not verified(temporary):
                raise HostError("内核/固件复制校验失败，未启动虚拟机。")
            atomic_json(temporary / "files.json", {"schema_version": 1, "files": records})
            os.replace(temporary, runtime)
        finally:
            if temporary.exists():
                shutil.rmtree(temporary)
    relative = runtime.relative_to(root / "data").as_posix()
    return {"kernel": relative + "/vmlinuz", "initrd": relative + "/initrd.img", "share": relative + "/share"}


def user_root():
    if os.environ.get("LOCALAPPDATA"):
        return Path(os.environ["LOCALAPPDATA"]) / "SelfDevelopedEPM"
    if os.name == "nt":
        raise HostError("Windows未提供LOCALAPPDATA，无法安全选择用户持久数据目录。")
    # Linux is for build verification, not a claim of Windows execution.
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local/share"))) / "SelfDevelopedEPM"


class UserLock:
    def __init__(self, path):
        self.path, self.stream = path, None

    def acquire(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        stream = self.path.open("a+b")
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            stream.close()
            return False
        self.stream = stream
        return True

    def close(self):
        if self.stream is not None:
            if os.name == "nt":
                import msvcrt
                self.stream.seek(0)
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(), fcntl.LOCK_UN)
            self.stream.close()
            self.stream = None


def local_port(preferred=0):
    with socket.socket() as sock:
        try:
            sock.bind(("127.0.0.1", preferred))
        except OSError:
            sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def local_json(url, *, token=None, method="GET", timeout=3, allow_unready=False):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1":
        raise HostError("拒绝向非本机控制地址发送请求。")
    headers = {"Host": parsed.netloc, "Accept": "application/json"}
    if token:
        headers["X-EPM-Token"] = token
    data = b"{}" if method == "POST" else None
    if method == "POST":
        headers.update({"Content-Type": "application/json", "Origin": "http://" + parsed.netloc})
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    # Never route machine-local passwords/capabilities through a configured proxy.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        response = opener.open(req, timeout=timeout)
    except urllib.error.HTTPError as exc:
        if not allow_unready or exc.code != 503:
            raise
        response = exc
    with response:
        result = json.loads(response.read(1024 * 1024).decode("utf-8"))
        if allow_unready:
            if not isinstance(result, dict):
                raise HostError("guest健康响应不是JSON对象，拒绝宣称就绪。")
            result["_http_status"] = response.status
        return result


def qmp_command(port, machine_id, command):
    """Authenticate VM identity before any control command; never use a PID kill."""
    with socket.create_connection(("127.0.0.1", int(port)), timeout=4) as sock:
        sock.settimeout(5)
        stream = sock.makefile("rwb")
        greeting = json.loads(stream.readline(1024 * 1024))
        if not isinstance(greeting, dict) or "QMP" not in greeting:
            raise HostError("该端口没有QMP握手，拒绝控制。")

        def call(name):
            request_id = uuid.uuid4().hex
            stream.write((json.dumps({"execute": name, "id": request_id}) + "\n").encode())
            stream.flush()
            while True:
                line = stream.readline(1024 * 1024)
                if not line:
                    raise HostError("QMP连接已关闭。")
                message = json.loads(line)
                if not isinstance(message, dict):
                    raise HostError("QMP返回无效消息。")
                if message.get("id") == request_id:
                    if "error" in message:
                        raise HostError("QMP命令失败：" + name)
                    return message.get("return")
        call("qmp_capabilities")
        identity = call("query-uuid")
        try:
            same_machine = isinstance(identity, dict) and uuid.UUID(str(identity.get("UUID", ""))) == uuid.UUID(str(machine_id))
        except (ValueError, TypeError, AttributeError):
            same_machine = False
        if not same_machine:
            raise HostError("QMP虚拟机UUID与本机记录不符，拒绝停止其他虚拟机。")
        return call(command)


def _asset_name(value):
    if not isinstance(value, str) or Path(value).name != value or value in {"", ".", ".."} or any(c in value for c in ("/", "\\", "\r", "\n")):
        raise HostError("资产清单含非法文件名。")
    return value


def read_assets(bundle):
    candidates = (bundle / "vm", bundle / "bundle/vm", bundle / "guest")
    vm = next((p for p in candidates if (p / "assets.json").is_file()), candidates[0])
    manifest = read_json(vm / "assets.json")
    if not isinstance(manifest, dict) or manifest.get("schema_version") != 1:
        raise HostError("缺少或不支持vm/assets.json；请完整解压免Docker运行包。")
    base = manifest.get("base", {})
    if not isinstance(base, dict):
        raise HostError("资产清单base格式无效。")
    _asset_name(base.get("filename", "base.qcow2"))
    if not isinstance(base.get("bytes"), int) or base["bytes"] <= 0 or not re.fullmatch(r"[0-9a-f]{64}", base.get("sha256", "")):
        raise HostError("资产清单缺少基础盘的固定长度和SHA256。")
    parts = base.get("parts", [])
    if parts:
        if not isinstance(parts, list) or len(parts) > 1000:
            raise HostError("基础盘分块清单无效。")
        names = set()
        for part in parts:
            if not isinstance(part, dict):
                raise HostError("基础盘块必须是对象。")
            name = _asset_name(part.get("filename"))
            url = urllib.parse.urlsplit(part.get("url", ""))
            if name in names or not isinstance(part.get("bytes"), int) or not 0 < part["bytes"] <= MAX_PART:
                raise HostError("基础盘块重复或超过90MiB上限。")
            names.add(name)
            if not re.fullmatch(r"[0-9a-f]{64}", part.get("sha256", "")):
                raise HostError("基础盘块缺少固定SHA256。")
            if url.scheme != "https" or url.hostname != "raw.githubusercontent.com" or url.username or url.password or url.fragment:
                raise HostError("基础盘只允许固定清单中的GitHub raw HTTPS分块来源。")
        if sum(p["bytes"] for p in parts) != base["bytes"]:
            raise HostError("各块长度之和与基础盘总长不一致。")
    kernel_spec = manifest.get("kernel", {})
    initrd_spec = manifest.get("initrd", {})
    if not isinstance(kernel_spec, dict) or not isinstance(initrd_spec, dict):
        raise HostError("kernel/initrd资产字段必须是对象。")
    kernel = vm / _asset_name(kernel_spec.get("filename", "vmlinuz"))
    initrd = vm / _asset_name(initrd_spec.get("filename", "initrd.img"))
    for label, file, spec in (("Linux内核", kernel, kernel_spec), ("启动内存盘", initrd, initrd_spec)):
        if not file.is_file() or file.is_symlink():
            raise HostError("缺少" + label + "：" + file.name)
        if spec.get("sha256") and digest_file(file) != spec["sha256"]:
            raise HostError(label + "SHA256不符，拒绝启动。")
    qemu_dir = next((p for p in (bundle / "bundle/qemu", bundle / "qemu") if (p / "qemu-system-x86_64.exe").is_file()), bundle / "qemu")
    qemu = qemu_dir / "qemu-system-x86_64.exe"
    image_tool = qemu_dir / "qemu-img.exe"
    for file in (qemu, image_tool):
        if not file.is_file() or file.is_symlink():
            raise HostError("缺少内置QEMU组件：" + file.name)
    return {"vm": vm, "base": base, "kernel": kernel, "initrd": initrd,
            "qemu": qemu, "image_tool": image_tool, "qemu_dir": qemu_dir,
            "append": manifest.get("kernel_append", "root=LABEL=EPMROOT rw console=ttyS0 net.ifnames=0")}


def load_seed(root):
    file = root / "data/epm-seed.json"
    if file.exists():
        seed = read_json(file)
        required = {"schema_version", "machine_id", "admin_password", "clickhouse_password", "cube_api_secret", "site_name"}
        if not isinstance(seed, dict) or not required <= seed.keys() or seed["schema_version"] != 1 or seed["site_name"] != "epm.local":
            raise HostError("本机初始化种子损坏；已拒绝替换已有密码。请先备份持久数据。")
        try:
            uuid.UUID(seed["machine_id"])
        except (ValueError, TypeError, AttributeError) as exc:
            raise HostError("本机machine_id格式损坏，拒绝重新生成。") from exc
        if not all(isinstance(seed[k], str) and len(seed[k]) >= 24 for k in ("admin_password", "clickhouse_password", "cube_api_secret")):
            raise HostError("本机种子凭据格式不符，拒绝替换已有密码。")
        return seed
    if (root / "data/disk.qcow2").exists():
        raise HostError("已有持久业务盘但epm-seed.json缺失。为保留原machine_id和密码，拒绝生成新种子；请恢复完整data备份。")
    seed = {"schema_version": 1, "machine_id": str(uuid.uuid4()), "admin_password": secrets.token_urlsafe(30),
            "clickhouse_password": secrets.token_urlsafe(30), "cube_api_secret": secrets.token_urlsafe(48), "site_name": "epm.local"}
    atomic_json(file, seed)
    return seed


def download_part(part, cache, notify, cancelled):
    final = cache / part["filename"]
    partial = final.with_name(final.name + ".partial")
    if final.is_symlink() or partial.is_symlink():
        raise HostError("缓存文件是未知符号链接，拒绝写入。")
    if final.is_file():
        if final.stat().st_size == part["bytes"] and digest_file(final) == part["sha256"]:
            return final
        os.replace(final, final.with_name(final.name + ".corrupt-" + uuid.uuid4().hex))
        raise HostError("缓存分块校验失败，已隔离异常缓存；重试会重新获取固定发布分块。")
    offset = partial.stat().st_size if partial.exists() else 0
    if offset > part["bytes"]:
        raise HostError("未完成缓存长度异常，拒绝使用：" + partial.name)
    if offset < part["bytes"]:
        headers = {"User-Agent": "SelfDevelopedEPM-Portable/1", "Accept-Encoding": "identity"}
        if offset:
            headers["Range"] = f"bytes={offset}-"
        req = urllib.request.Request(part["url"], headers=headers)
        with urllib.request.urlopen(req, timeout=45) as response:
            url = urllib.parse.urlsplit(response.geturl())
            if url.scheme != "https" or url.hostname != "raw.githubusercontent.com":
                raise HostError("分块下载重定向到未允许的地址，拒绝继续。")
            if offset and response.status == 206:
                expected = f"bytes {offset}-{part['bytes'] - 1}/{part['bytes']}"
                if response.headers.get("Content-Range") != expected:
                    raise HostError("续传响应范围与固定清单不一致。")
            elif response.status == 200:
                offset = 0
            else:
                raise HostError("分块下载HTTP状态无效。")
            with partial.open("ab" if offset else "wb") as stream:
                while True:
                    if cancelled.is_set():
                        raise HostError("已取消下载；已下载内容保留供下次续传。")
                    data = response.read(256 * 1024)
                    if not data:
                        break
                    offset += len(data)
                    if offset > part["bytes"]:
                        raise HostError("下载块超出清单长度，拒绝使用。")
                    stream.write(data)
                    notify(offset)
                stream.flush()
                os.fsync(stream.fileno())
    if not partial.is_file() or partial.stat().st_size != part["bytes"] or digest_file(partial) != part["sha256"]:
        if partial.is_file():
            os.replace(partial, partial.with_name(partial.name + ".corrupt-" + uuid.uuid4().hex))
        raise HostError("下载块SHA256或长度不符，拒绝启动；异常缓存已隔离，重试可重新下载。")
    os.replace(partial, final)
    return final


def prepare_base(assets, root, notify, cancelled):
    data = root / "data"
    data.mkdir(parents=True, exist_ok=True)
    base = data / "base.qcow2"
    overlay = data / "disk.qcow2"
    metadata_file = data / "base.json"
    metadata = read_json(metadata_file)
    spec = assets["base"]
    if base.is_symlink() or overlay.is_symlink():
        raise HostError("持久基础盘或业务盘是未知符号链接，拒绝修改。")
    if metadata and metadata.get("sha256") != spec["sha256"]:
        raise HostError("新运行包的基础盘版本与持久盘不同。为保护账务数据，拒绝自动覆盖/升级；请使用旧包或先完成受控迁移。")
    if overlay.exists() and not base.exists():
        raise HostError("发现持久overlay但基础盘缺失，拒绝下载新基础盘替换其backing。请恢复原基础盘备份。")
    if base.exists():
        notify("校验持久基础盘；已有账务overlay保持不变。", 0)
        if base.stat().st_size != spec["bytes"] or digest_file(base) != spec["sha256"]:
            raise HostError("持久基础盘与发布哈希不符，拒绝改写；请从备份恢复。")
        if not metadata:
            atomic_json(metadata_file, {"schema_version": 1, "sha256": spec["sha256"], "bytes": spec["bytes"]})
        return base, overlay
    if overlay.exists():
        raise HostError("缺少原基础盘，不能创建新backing。")
    local = assets["vm"] / spec.get("filename", "base.qcow2")
    if local.is_symlink():
        raise HostError("包内基础盘是符号链接，拒绝跟随未知文件。")
    required_free = spec["bytes"] * (3 if spec.get("parts") and not local.is_file() else 1) + 1024 ** 3
    notify(f"基础盘{spec['bytes'] / 1024 ** 3:.2f}GiB；建议本次至少留出{required_free / 1024 ** 3:.2f}GiB空闲，业务盘后续会增长。" + ("首次分块版需要联网。" if not local.is_file() else "当前使用离线基础盘。"), 0)
    if shutil.disk_usage(root).free < required_free:
        raise HostError(f"持久数据盘空间不足，本次至少需要约{required_free / 1024 ** 3:.2f}GiB空闲；业务数据增长还需要更多空间。")
    temporary = data / (".base-" + uuid.uuid4().hex + ".qcow2")
    try:
        if local.is_file():
            notify("首次复制离线基础盘到用户持久目录并校验。", 0)
            with local.open("rb") as src, temporary.open("xb") as dst:
                copy_cancelled(src, dst, cancelled)
        elif spec.get("parts"):
            cache = root / "cache" / spec["sha256"]
            cache.mkdir(parents=True, exist_ok=True)
            completed = 0
            chunks = []
            for index, part in enumerate(spec["parts"], 1):
                notify(f"首次启动需联网下载内置完整Linux环境：{spec['bytes'] / 1024 ** 3:.2f}GiB；第{index}/{len(spec['parts'])}块。", int(completed * 100 / spec["bytes"]))
                chunk = download_part(part, cache, lambda n: notify("下载并校验固定发布分块，可中断续传。", int((completed + n) * 100 / spec["bytes"])), cancelled)
                chunks.append(chunk)
                completed += part["bytes"]
            notify("分块已校验，正在合并并校验基础盘总SHA256。", 100)
            with temporary.open("xb") as dst:
                for chunk in chunks:
                    with chunk.open("rb") as src:
                        copy_cancelled(src, dst, cancelled)
        else:
            raise HostError("包内缺少base.qcow2，且清单没有已固定哈希的公开分块来源；未启动虚拟机。")
        if temporary.stat().st_size != spec["bytes"] or digest_file(temporary) != spec["sha256"]:
            raise HostError("基础盘总SHA256或总长度不符；未启动虚拟机。")
        if cancelled.is_set():
            raise HostError("已取消初始化；不会覆盖基础盘。")
        os.replace(temporary, base)
        atomic_json(metadata_file, {"schema_version": 1, "sha256": spec["sha256"], "bytes": spec["bytes"]})
    finally:
        if temporary.exists():
            temporary.unlink()
    return base, overlay


PAGE = r'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>自研EPM启动</title><style>body{font:16px system-ui;max-width:820px;margin:60px auto;padding:24px;color:#16334d;background:#f3f7fb}section{background:white;padding:32px;border-radius:14px}button,a{margin:8px;padding:10px 16px}pre{white-space:pre-wrap;overflow-wrap:anywhere}progress{width:100%}.bad{color:#a42020}</style><section><h1>自研EPM</h1><p>正在启动内置完整财务平台。无需安装Docker、Python或WSL。首次分块版需联网下载内置Linux环境，TCG启动可能需要较长时间。关闭浏览器不会停止平台；离开前请点“安全退出”。</p><h2 id="phase">连接启动器…</h2><progress id="progress" max="100"></progress><pre id="detail"></pre><p id="result"></p><button onclick="act('open')">打开平台</button><button onclick="act('credentials')">查看本机登录信息</button><button onclick="act('data-folder')">打开数据位置</button><button onclick="act('retry')">重试失败步骤</button><button onclick="act('stop')">安全退出（保留数据）</button><pre id="secret"></pre></section><script>const token=location.hash.slice(1);let opened=false;async function api(p,method='GET'){const r=await fetch('/api/'+p,{method,headers:{'X-EPM-Token':token,'Content-Type':'application/json'},body:method==='POST'?'{}':undefined});const d=await r.json();if(!r.ok)throw Error(d.error||'请求失败');return d}async function act(a){try{if(a==='credentials'){let d=await api(a,'POST');document.getElementById('secret').textContent='用户名：Administrator\n本机管理员密码：'+d.admin_password;return}await api(a,'POST')}catch(e){document.getElementById('result').textContent=e.message}}async function tick(){try{let d=await api('status');document.getElementById('phase').textContent=d.state;document.getElementById('detail').textContent=d.message+(d.resource_notice?'\n'+d.resource_notice:'')+'\n数据目录：'+d.data_dir+'\n日志：'+d.log_file;document.getElementById('progress').value=d.progress||0;document.getElementById('result').textContent=d.ready?'完整平台已就绪。停止时请使用安全退出。':'';if(d.ready&&!opened){opened=true}if(d.state==='Stopped'){document.getElementById('result').textContent='已安全停止，可关闭本页。';return}}catch(e){document.getElementById('result').textContent=token?'正在等待启动器响应；请勿删除持久数据。':'请双击自研EPM.exe打开带本机授权的启动页面。'}setTimeout(tick,2000)}tick();</script></html>'''


class Controller:
    def __init__(self, bundle, root, global_root, args):
        self.bundle, self.root, self.global_root, self.args = bundle, root, global_root, args
        self.seed = load_seed(root)
        self.token = secrets.token_urlsafe(32)
        self.cancelled = threading.Event()
        self.guard = threading.RLock()
        self.process = None
        self.qmp_port = None
        self.web_port = None
        self.worker = None
        self.stopping = False
        self.platform_opened = False
        self.state = {"instance_kind": KIND, "machine_id": self.seed["machine_id"], "state": "Preparing", "message": "检查内置组件和持久数据。", "progress": 0, "ready": False,
                      "data_dir": str(root), "log_file": str(root / "data/logs/host.log"), "platform_url": None, "platform_entry_url": None}
        self.previous = read_json(root / "data/vm.json")
        self.server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), self.handler())
        self.ui_url = "http://127.0.0.1:" + str(self.server.server_address[1])

    def public(self):
        with self.guard:
            return dict(self.state)

    def update(self, state=None, message=None, progress=None, **values):
        with self.guard:
            before = dict(self.state)
            if state is not None:
                self.state["state"] = state
            if message is not None:
                self.state["message"] = message
            if progress is not None:
                self.state["progress"] = progress
            self.state.update(values)
            if self.state == before:
                return
            atomic_json(self.root / "data/status.json", self.state)
        if state:
            LOG.info("state=%s", state)

    def handler(self):
        owner = self
        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass  # no URL/capability/password logging

            def send(self, code, body, content="application/json; charset=utf-8"):
                data = body.encode("utf-8") if isinstance(body, str) else json.dumps(body, ensure_ascii=False).encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", content)
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "no-referrer")
                self.end_headers()
                self.wfile.write(data)

            def permitted(self):
                host = "127.0.0.1:" + str(owner.server.server_address[1])
                origin = self.headers.get("Origin")
                return self.headers.get("Host") == host and secrets.compare_digest(self.headers.get("X-EPM-Token", ""), owner.token) and (not origin or origin == "http://" + host)

            def do_GET(self):
                if self.path == "/":
                    if self.headers.get("Host") != urllib.parse.urlsplit(owner.ui_url).netloc:
                        self.send(403, {"error": "Host不匹配"})
                    else:
                        self.send(200, PAGE, "text/html; charset=utf-8")
                elif self.path == "/api/status" and self.permitted():
                    self.send(200, owner.public())
                else:
                    self.send(403, {"error": "需要本机启动器授权"})

            def do_POST(self):
                if not self.permitted():
                    self.send(403, {"error": "需要本机启动器授权"})
                    return
                if self.path == "/api/stop":
                    self.send(202, {"accepted": True})
                    threading.Thread(target=owner.stop, daemon=True).start()
                elif self.path == "/api/retry":
                    if owner.public()["state"] != "Failed":
                        self.send(409, {"error": "只有失败且无运行VM时可重试"})
                    else:
                        if owner.start_worker():
                            self.send(202, {"accepted": True})
                        else:
                            self.send(409, {"error": "停止或启动步骤仍在执行，请等待当前步骤完成"})
                elif self.path == "/api/open":
                    if owner.public()["ready"]:
                        webbrowser.open(owner.public()["platform_entry_url"])
                        self.send(200, {"opened": True})
                    else:
                        self.send(409, {"error": "平台尚未通过完整就绪检查"})
                elif self.path == "/api/credentials":
                    self.send(200, {"username": "Administrator", "admin_password": owner.seed["admin_password"]})
                elif self.path == "/api/data-folder":
                    if os.name == "nt":
                        os.startfile(str(owner.root / "data"))
                    else:
                        webbrowser.open((owner.root / "data").as_uri())
                    self.send(200, {"opened": True})
                else:
                    self.send(404, {"error": "未知操作"})
        return Handler

    def start_worker(self):
        with self.guard:
            if self.stopping or (self.worker is not None and self.worker.is_alive()):
                return False
            if self.process is not None and self.process.poll() is not None:
                self.process = None
                self.qmp_port = self.web_port = None
            self.previous = read_json(self.root / "data/vm.json")
            self.cancelled.clear()
            self.worker = threading.Thread(target=self.boot, daemon=True)
            self.worker.start()
            return True

    def apply_health(self, health):
        machine = health.get("machine_id")
        if machine and machine != self.seed["machine_id"]:
            raise HostError("端口上的平台身份不匹配，拒绝宣称本机EPM就绪。")
        failed = health.get("failed_units", [])
        if not isinstance(failed, list):
            failed = []
        safe_units = [u for u in failed if isinstance(u, str) and re.fullmatch(r"[A-Za-z0-9_.@-]{1,100}\.service", u)][:8]
        if health.get("status") == "failed" or safe_units:
            suffix = "（" + ", ".join(safe_units) + "）" if safe_units else ""
            raise HostError("内置平台初始化失败" + suffix + "。业务盘已保留，请查看guest-console.log并安全停止后排查。")
        if health.get("_http_status", 200) == 200 and health.get("ready") is True and machine == self.seed["machine_id"]:
            if not self.public()["ready"]:
                self.update("Ready", "完整原平台已通过guest服务、Frappe站点及首轮dbt就绪检查。", 100, ready=True)
            if not self.platform_opened and not self.args.no_browser:
                self.platform_opened = True
                webbrowser.open(self.public()["platform_entry_url"])
            return True
        stages = {"firstboot": (15, "首次初始化系统和每机配置"), "database": (30, "准备本机数据库"),
                  "site_init": (50, "创建/校验Frappe站点并安装原平台"), "dbt": (80, "运行首轮dbt仓库构建"),
                  "services": (90, "检查全部原平台服务和站点响应")}
        progress, text = stages.get(health.get("stage", health.get("phase")), (10, "等待内置平台初始化"))
        self.update("Booting", text + "；正常503表示尚未就绪，并非已成功。", progress, ready=False)
        return False

    def boot(self):
        try:
            self.update("Preparing", "检查内置完整平台组件。", 0, ready=False)
            assets = read_assets(self.bundle)
            local_base = assets["vm"] / assets["base"].get("filename", "base.qcow2")
            online = bool(assets["base"].get("parts")) and not local_base.is_file()
            first_free = assets["base"]["bytes"] * (3 if online else 1) + 1024 ** 3
            self.update(resource_notice=f"基础盘约{assets['base']['bytes'] / 1024 ** 3:.2f}GiB；" +
                        ("首次缺少持久基础盘时需要联网下载。" if online else "当前提供离线基础盘。") +
                        f"首次安装建议数据盘至少留出{first_free / 1024 ** 3:.2f}GiB空闲，并为后续业务数据增长另留空间。")
            previous = self.previous or {}
            if previous.get("machine_id") == self.seed["machine_id"] and previous.get("qmp_port"):
                try:
                    qmp_command(previous["qmp_port"], self.seed["machine_id"], "query-status")
                except (OSError, HostError, ValueError):
                    pass  # Expired/reused port never receives a power command.
                else:
                    if Path(previous.get("data_dir", "")).resolve() != self.root.resolve():
                        raise HostError("发现同一machine_id仍在其他数据位置运行；请先在原位置安全停止，不复用或重开业务盘。")
                    self.qmp_port, self.web_port = previous["qmp_port"], previous["web_port"]
                    # A running VM may be adopted, but a new incompatible bundle
                    # must not bypass the same base-version protection as boot.
                    prepare_base(assets, self.root, lambda text, percent: self.update("Preparing", text, percent), self.cancelled)
                    self.update("Booting", "发现本用户仍在运行的同一虚拟机，已复用；不会另开业务盘。")
            if self.qmp_port is None:
                self.update("Preparing", "首次环境可能需要下载；正在校验基础盘和磁盘空间。")
                base, overlay = prepare_base(assets, self.root, lambda text, percent: self.update("Preparing", text, percent), self.cancelled)
                seed_image = self.root / "data/seed.img"
                runtime = prepare_runtime(assets, self.root, self.cancelled)
                flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
                if not overlay.exists():
                    self.update("Preparing", "创建持久业务overlay；不修改只读基础盘。")
                    output = self.root / "data/logs/qemu-img.log"
                    with output.open("ab") as stream:
                        proc = subprocess.run([str(assets["image_tool"]), "create", "-f", "qcow2", "-F", "qcow2", "-b", "base.qcow2", "disk.qcow2"], cwd=base.parent, stdout=stream, stderr=subprocess.STDOUT, creationflags=flags, check=False)
                    if proc.returncode:
                        raise HostError("创建业务盘失败；详情见qemu-img.log。未启动平台。")
                inspection = subprocess.run([str(assets["image_tool"]), "info", "--output=json", "disk.qcow2"], cwd=base.parent, capture_output=True, creationflags=flags, check=False)
                try:
                    details = json.loads(inspection.stdout) if inspection.returncode == 0 else {}
                except ValueError:
                    details = {}
                backing = details.get("backing-filename")
                backing_path = (overlay.parent / backing).resolve() if isinstance(backing, str) else None
                if details.get("format") != "qcow2" or backing_path != base.resolve():
                    raise HostError("业务盘backing不是持久目录中的匹配base.qcow2，或业务盘正被其他进程占用。已拒绝打开/重建。")
                if self.cancelled.is_set():
                    raise HostError("启动已取消。")
                self.qmp_port, self.web_port = local_port(), local_port(18480)
                self.seed["host_web_port"] = self.web_port
                atomic_json(self.root / "data/epm-seed.json", self.seed)
                write_seed_image(seed_image, self.seed)
                disk = {"driver": "qcow2", "node-name": "epm-disk", "file": {"driver": "file", "filename": "disk.qcow2"}}
                seed_disk = {"driver": "raw", "node-name": "epm-seed", "read-only": True, "file": {"driver": "file", "filename": "seed.img", "read-only": True}}
                args = [str(assets["qemu"]), "-L", runtime["share"], "-machine", "q35", "-accel", "tcg,thread=multi", "-cpu", "max", "-smp", str(self.args.cpus), "-m", str(self.args.memory_mb),
                        "-uuid", str(uuid.UUID(self.seed["machine_id"])), "-name", "SelfDevelopedEPM-" + self.seed["machine_id"], "-display", "none", "-monitor", "none",
                        "-kernel", runtime["kernel"], "-initrd", runtime["initrd"], "-append", assets["append"],
                        "-blockdev", json.dumps(disk, ensure_ascii=False), "-device", "virtio-blk-pci,drive=epm-disk", "-blockdev", json.dumps(seed_disk, ensure_ascii=False), "-device", "virtio-blk-pci,drive=epm-seed",
                        "-netdev", f"user,id=net0,hostfwd=tcp:127.0.0.1:{self.web_port}-:80", "-device", "virtio-net-pci,netdev=net0",
                        "-qmp", f"tcp:127.0.0.1:{self.qmp_port},server=on,wait=off", "-serial", "file:logs/guest-console.log"]
                with (self.root / "data/logs/qemu.log").open("ab") as stream:
                    try:
                        self.process = subprocess.Popen(args, cwd=self.root / "data", stdout=stream, stderr=subprocess.STDOUT, creationflags=flags, close_fds=True)
                    except Exception:
                        # Allocated port numbers are not a running VM. A
                        # CreateProcess failure must still allow clean UI exit.
                        self.qmp_port = self.web_port = None
                        raise
                atomic_json(self.root / "data/vm.json", {"schema_version": 1, "machine_id": self.seed["machine_id"], "qmp_port": self.qmp_port, "web_port": self.web_port, "pid": self.process.pid, "data_dir": str(self.root)})
            self.update("Booting", "内置Linux平台启动中；首次初始化数据库、建站和dbt可能较久，请勿强制断电。", 0, platform_url=f"http://127.0.0.1:{self.web_port}/", platform_entry_url=f"http://127.0.0.1:{self.web_port}/app")
            readiness_deadline = time.monotonic() + self.args.startup_timeout
            while not self.cancelled.wait(2):
                if time.monotonic() >= readiness_deadline:
                    raise HostError(f"平台未在{self.args.startup_timeout}秒内通过完整就绪检查。VM及业务盘未强制终止，请查看guest日志并使用安全退出。")
                if self.process is not None and self.process.poll() is not None:
                    raise HostError("内置虚拟机已退出（代码" + str(self.process.returncode) + "）；请查看qemu.log和guest-console.log。")
                try:
                    health = local_json(f"http://127.0.0.1:{self.web_port}/epm-ready", allow_unready=True)
                    if self.apply_health(health):
                        readiness_deadline = time.monotonic() + self.args.startup_timeout
                except (OSError, urllib.error.URLError, ValueError):
                    if self.public()["ready"]:
                        self.update("Booting", "平台服务暂未响应，正在重新检查。", ready=False)
        except Exception as exc:
            LOG.error("startup failed: %s", str(exc) if isinstance(exc, HostError) else type(exc).__name__)
            self.update("Failed", str(exc) if isinstance(exc, HostError) else "启动失败（" + type(exc).__name__ + "），请查看持久日志。", ready=False)

    def stop(self):
        with self.guard:
            if self.stopping:
                return
            self.stopping = True
        try:
            self._stop()
        finally:
            with self.guard:
                self.stopping = False

    def _stop(self):
        self.cancelled.set()
        self.update("Stopping", "正在请求guest安全关机并等待业务数据库停止。", ready=False)
        if self.worker is not None:
            self.worker.join(timeout=50)
        if self.qmp_port is None:
            # Startup can fail on a new/missing bundle before adopting a VM
            # left by a previous controller. Stop may still use only the exact
            # same data-directory record and a fresh verified UUID handshake.
            previous = self.previous or {}
            if (previous.get("machine_id") == self.seed["machine_id"] and previous.get("qmp_port")
                    and Path(previous.get("data_dir", "")).resolve() == self.root.resolve()):
                try:
                    qmp_command(previous["qmp_port"], self.seed["machine_id"], "query-status")
                except (OSError, HostError, ValueError):
                    pass
                else:
                    self.qmp_port, self.web_port = previous["qmp_port"], previous["web_port"]
        if self.qmp_port is not None:
            try:
                qmp_command(self.qmp_port, self.seed["machine_id"], "system_powerdown")
            except (OSError, HostError, ValueError):
                if self.process is None or self.process.poll() is None:
                    self.update("Failed", "无法验证QMP身份或发送安全关机。没有终止任何进程；请保留数据并检查日志。")
                    return
            deadline = time.monotonic() + 180
            missing_checks = 0
            while time.monotonic() < deadline:
                if self.process is not None and self.process.poll() is not None:
                    break
                try:
                    qmp_command(self.qmp_port, self.seed["machine_id"], "query-status")
                except (OSError, HostError, ValueError):
                    if self.process is None:
                        # Adopted instances have no Popen handle. Require both
                        # owned VM endpoints to disappear repeatedly; a single
                        # QMP timeout is never evidence of safe shutdown.
                        try:
                            with socket.create_connection(("127.0.0.1", self.web_port), timeout=1):
                                missing_checks = 0
                        except OSError:
                            missing_checks += 1
                        if missing_checks >= 3:
                            break
                time.sleep(2)
            else:
                self.update("Failed", "guest未在180秒内关机。未强制杀进程；请查看guest日志并重试安全停止。")
                return
        if self.process is not None and self.process.poll() not in (None, 0):
            self.update("Failed", "虚拟机已异常退出（代码" + str(self.process.returncode) + "）。数据已保留，但不能确认数据库安全停止；请检查日志和备份。", ready=False)
            threading.Timer(2, self.server.shutdown).start()
            return
        self.update("Stopped", "平台已安全停止。持久业务盘和每机密码已保留。", ready=False)
        threading.Timer(2, self.server.shutdown).start()

    def run(self):
        atomic_json(self.global_root / "instance.json", {"instance_kind": KIND, "machine_id": self.seed["machine_id"], "data_dir": str(self.root), "ui_url": self.ui_url, "token": self.token, "controller_pid": os.getpid()})
        self.start_worker()
        if not self.args.no_browser:
            webbrowser.open(self.ui_url + "/#" + self.token)
        try:
            self.server.serve_forever(poll_interval=0.5)
        except KeyboardInterrupt:
            self.stop()
        finally:
            self.server.server_close()
        return 0 if self.public()["state"] == "Stopped" else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", nargs="?", choices=("start", "status", "stop", "check"), default="start")
    modes = parser.add_mutually_exclusive_group()
    for name in ("status", "stop", "check"):
        modes.add_argument("--" + name, action="store_true")
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--bundle-dir", type=Path, default=APP.parent)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--memory-mb", type=int, default=6144)
    parser.add_argument("--cpus", type=int, default=2)
    parser.add_argument("--startup-timeout", type=int, default=7200, help="guest初始化/完整就绪等待秒数，默认7200，超时保留VM和业务盘")
    args = parser.parse_args(argv)
    command = next((name for name in ("status", "stop", "check") if getattr(args, name)), args.command)
    if not 2048 <= args.memory_mb <= 65536 or not 1 <= args.cpus <= 16:
        parser.error("memory-mb应为2048..65536，cpus应为1..16；默认TCG 6144MiB/2核")
    if not 60 <= args.startup_timeout <= 86400:
        parser.error("startup-timeout应为60..86400秒")
    global_root = user_root().resolve()
    root = (args.data_dir or global_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    if os.name != "nt":
        os.chmod(root, 0o700)
    logs = root / "data/logs"
    logs.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(logs / "host.log", maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    LOG.addHandler(handler)
    LOG.setLevel(logging.INFO)
    if command == "check":
        try:
            assets = read_assets(args.bundle_dir.resolve())
            emit({"ok": True, "data_dir": str(root), "base_bytes": assets["base"]["bytes"], "offline_base_present": (assets["vm"] / assets["base"].get("filename", "base.qcow2")).is_file(), "download_parts": len(assets["base"].get("parts", [])), "windows_execution_verified": False})
            return 0
        except HostError as exc:
            emit({"ok": False, "error": str(exc), "windows_execution_verified": False})
            return 1
    existing = read_json(global_root / "instance.json", {})
    def remote_status():
        if existing.get("instance_kind") != KIND:
            raise HostError("没有可验证的本用户实例。")
        state = local_json(existing["ui_url"] + "/api/status", token=existing["token"])
        if state.get("machine_id") != existing.get("machine_id") or state.get("instance_kind") != KIND:
            raise HostError("实例身份不匹配。")
        return state
    if command in {"status", "stop"}:
        try:
            state = remote_status()
            if command == "stop":
                local_json(existing["ui_url"] + "/api/stop", token=existing["token"], method="POST")
                for _ in range(240):
                    time.sleep(1)
                    try:
                        state = remote_status()
                    except OSError:
                        state = read_json(Path(existing["data_dir"]) / "data/status.json", {})
                    if state.get("state") in {"Stopped", "Failed"}:
                        break
            emit(state)
            return 0 if command == "status" or state.get("state") == "Stopped" else 1
        except (OSError, HostError, ValueError, KeyError):
            emit({"running": False, "message": "没有可验证的本用户启动器；没有终止任何进程。", "data_dir": str(root)})
            return 1
    lock = UserLock(global_root / "host.lock")
    if not lock.acquire():
        for _ in range(20):
            try:
                existing = read_json(global_root / "instance.json", {})
                state = remote_status()
                if not args.no_browser:
                    webbrowser.open(existing["ui_url"] + "/#" + existing["token"])
                emit({"reused": True, "state": state["state"], "data_dir": state["data_dir"]})
                return 0
            except (OSError, HostError, ValueError, KeyError):
                time.sleep(0.5)
        emit({"ok": False, "error": "同一OS用户已有启动操作持锁；请等待或查看持久日志。没有新建第二个虚拟机。"})
        return 1
    try:
        return Controller(args.bundle_dir.resolve(), root, global_root, args).run()
    finally:
        lock.close()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except HostError as exc:
        LOG.error("host error: %s", str(exc))  # HostError messages are curated; no credentials.
        emit({"ok": False, "error": str(exc)})
        raise SystemExit(1)
