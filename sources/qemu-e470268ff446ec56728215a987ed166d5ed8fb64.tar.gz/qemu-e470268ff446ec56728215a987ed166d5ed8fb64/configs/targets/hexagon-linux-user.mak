TARGET_ARCH=hexagon
TARGET_XML_FILES=hexagon-core.xml hexagon-hvx.xml
TARGET_SYSTBL=syscall.tbl
TARGET_SYSTBL_ABI=common,32,hexagon,time32,stat64,rlimit,renameat
TARGET_LONG_BITS=32
TARGET_NOT_USING_LEGACY_NATIVE_ENDIAN_API=y
