# Copyright (c) 2022, Frappe Technologies Pvt. Ltd. and Contributors
# License: MIT. See LICENSE
import base64
import json
import os
import shutil
import tempfile
import zipfile
from contextlib import contextmanager
from typing import TYPE_CHECKING
from unittest.mock import patch

import frappe
from frappe import _
from frappe.core.api.file import (
	create_new_folder,
	get_attached_images,
	get_files_in_folder,
	move_file,
	unzip_file,
)
from frappe.core.doctype.file.exceptions import FileTypeNotAllowed
from frappe.core.doctype.file.utils import get_corrupted_image_msg, get_extension
from frappe.desk.form.utils import add_comment
from frappe.exceptions import ValidationError
from frappe.tests.utils import FrappeTestCase, change_settings
from frappe.utils import get_files_path, set_request

if TYPE_CHECKING:
	from frappe.core.doctype.file.file import File

test_content1 = "Hello"
test_content2 = "Hello World"


def make_test_doc(ignore_permissions=False):
	d = frappe.new_doc("ToDo")
	d.description = "Test"
	d.assigned_by = frappe.session.user
	d.save(ignore_permissions)
	return d.doctype, d.name


@contextmanager
def make_test_image_file(private=False):
	file_path = frappe.get_app_path("frappe", "tests/data/sample_image_for_optimization.jpg")
	with open(file_path, "rb") as f:
		file_content = f.read()

	test_file = frappe.get_doc(
		{
			"doctype": "File",
			"file_name": "sample_image_for_optimization.jpg",
			"content": file_content,
			"is_private": private,
		}
	).insert()
	# remove those flags
	_test_file: File = frappe.get_doc("File", test_file.name)

	try:
		yield _test_file
	finally:
		_test_file.delete()


class TestSimpleFile(FrappeTestCase):
	def setUp(self):
		self.attached_to_doctype, self.attached_to_docname = make_test_doc()
		self.test_content = test_content1
		_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "test1.txt",
				"attached_to_doctype": self.attached_to_doctype,
				"attached_to_name": self.attached_to_docname,
				"content": self.test_content,
			}
		)
		_file.save()
		self.saved_file_url = _file.file_url

	def test_save(self):
		_file = frappe.get_doc("File", {"file_url": self.saved_file_url})
		content = _file.get_content()
		self.assertEqual(content, self.test_content)


class TestFSRollbacks(FrappeTestCase):
	def test_rollback_from_file_system(self):
		file_name = content = frappe.generate_hash()
		file = frappe.new_doc("File", file_name=file_name, content=content).insert()
		self.assertTrue(file.exists_on_disk())

		frappe.db.rollback()
		self.assertFalse(file.exists_on_disk())


class TestWriteFileContainment(FrappeTestCase):
	def test_write_file_rejects_target_outside_files_dir(self):
		from frappe.utils.file_manager import write_file

		files_path = get_files_path(is_private=1)
		bad_names = (
			"../../../../ESCAPE_TEST.txt",  # parent traversal
			"sub/../../ESCAPE_TEST.txt",  # traversal via a nested segment
			"/tmp/ESCAPE_TEST.txt",  # absolute path outside the files dir
			"subdir/ESCAPE_TEST.txt",  # nested name: not a direct child of the files dir
		)
		for fname in bad_names:
			with self.subTest(fname=fname):
				# where the bytes would land if the target were not confined
				would_be = os.path.realpath(os.path.join(files_path, fname))
				self.assertRaises(ValidationError, write_file, b"data\n", fname, is_private=1)
				self.assertFalse(os.path.exists(would_be))

	def test_write_file_allows_plain_basename(self):
		from frappe.utils.file_manager import write_file

		content = b"safe content\n"
		for is_private in (0, 1):
			with self.subTest(is_private=is_private):
				fname = f"{frappe.generate_hash()}.txt"
				write_file(content, fname, is_private=is_private)

				on_disk = get_files_path(fname, is_private=is_private)
				self.addCleanup(lambda p=on_disk: os.path.exists(p) and os.remove(p))
				self.assertEqual(
					os.path.realpath(os.path.dirname(on_disk)),
					os.path.realpath(get_files_path(is_private=is_private)),
				)
				with open(on_disk, "rb") as f:
					self.assertEqual(f.read(), content)


class TestExtensionValidations(FrappeTestCase):
	@change_settings("System Settings", {"allowed_file_extensions": "JPG\nCSV"})
	def test_allowed_extension(self):
		set_request(method="POST", path="/")
		file_name = content = frappe.generate_hash()
		bad_file = frappe.new_doc("File", file_name=f"{file_name}.png", content=content)
		self.assertRaises(FileTypeNotAllowed, bad_file.insert)

		bad_file = frappe.new_doc("File", file_name=f"{file_name}.csv", content=content).insert()
		frappe.db.rollback()
		self.assertFalse(bad_file.exists_on_disk())

	@change_settings("System Settings", {"allowed_file_extensions": "JPG\nCSV"})
	def test_allowlist_blocks_extension_without_known_mimetype(self):
		set_request(method="POST", path="/")
		file_name = content = frappe.generate_hash()
		bad_file = frappe.new_doc("File", file_name=f"{file_name}.phtml", content=content)
		self.assertRaises(FileTypeNotAllowed, bad_file.insert)


class TestBase64File(FrappeTestCase):
	def setUp(self):
		self.attached_to_doctype, self.attached_to_docname = make_test_doc()
		self.test_content = base64.b64encode(test_content1.encode("utf-8"))
		_file: File = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "test_base64.txt",
				"attached_to_doctype": self.attached_to_doctype,
				"attached_to_name": self.attached_to_docname,
				"content": self.test_content,
				"decode": True,
			}
		)
		_file.save()
		self.saved_file_url = _file.file_url

	def test_saved_content(self):
		_file = frappe.get_doc("File", {"file_url": self.saved_file_url})
		content = _file.get_content()
		self.assertEqual(content, test_content1)


class TestSameFileName(FrappeTestCase):
	def test_saved_content(self):
		self.attached_to_doctype, self.attached_to_docname = make_test_doc()
		self.test_content1 = test_content1
		self.test_content2 = test_content2
		_file1 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "testing.txt",
				"attached_to_doctype": self.attached_to_doctype,
				"attached_to_name": self.attached_to_docname,
				"content": self.test_content1,
			}
		)
		_file1.save()
		_file2 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "testing.txt",
				"attached_to_doctype": self.attached_to_doctype,
				"attached_to_name": self.attached_to_docname,
				"content": self.test_content2,
			}
		)
		_file2.save()
		self.saved_file_url1 = _file1.file_url
		self.saved_file_url2 = _file2.file_url

		_file = frappe.get_doc("File", {"file_url": self.saved_file_url1})
		content1 = _file.get_content()
		self.assertEqual(content1, self.test_content1)
		_file = frappe.get_doc("File", {"file_url": self.saved_file_url2})
		content2 = _file.get_content()
		self.assertEqual(content2, self.test_content2)

	def test_saved_content_private(self):
		_file1 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "testing-private.txt",
				"content": test_content1,
				"is_private": 1,
			}
		).insert()
		_file2 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "testing-private.txt",
				"content": test_content2,
				"is_private": 1,
			}
		).insert()

		_file = frappe.get_doc("File", {"file_url": _file1.file_url})
		self.assertEqual(_file.get_content(), test_content1)

		_file = frappe.get_doc("File", {"file_url": _file2.file_url})
		self.assertEqual(_file.get_content(), test_content2)


class TestSameContent(FrappeTestCase):
	def setUp(self):
		self.attached_to_doctype1, self.attached_to_docname1 = make_test_doc()
		self.attached_to_doctype2, self.attached_to_docname2 = make_test_doc()
		self.test_content1 = test_content1
		self.test_content2 = test_content1
		self.orig_filename = "hello.txt"
		self.dup_filename = "hello2.txt"
		_file1 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": self.orig_filename,
				"attached_to_doctype": self.attached_to_doctype1,
				"attached_to_name": self.attached_to_docname1,
				"content": self.test_content1,
			}
		)
		_file1.save()

		_file2 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": self.dup_filename,
				"attached_to_doctype": self.attached_to_doctype2,
				"attached_to_name": self.attached_to_docname2,
				"content": self.test_content2,
			}
		)

		_file2.save()

	def test_saved_content(self):
		self.assertFalse(os.path.exists(get_files_path(self.dup_filename)))

	def test_attachment_limit(self):
		doctype, docname = make_test_doc()
		from frappe.custom.doctype.property_setter.property_setter import make_property_setter

		limit_property = make_property_setter("ToDo", None, "max_attachments", 1, "int", for_doctype=True)
		file1 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "test-attachment",
				"attached_to_doctype": doctype,
				"attached_to_name": docname,
				"content": "test",
			}
		)

		file1.insert()

		file2 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "test-attachment",
				"attached_to_doctype": doctype,
				"attached_to_name": docname,
				"content": "test2",
			}
		)

		self.assertRaises(frappe.exceptions.AttachmentLimitReached, file2.insert)
		limit_property.delete()
		frappe.clear_cache(doctype="ToDo")

	def test_create_attachment_copy(self):
		doctype, docname = make_test_doc()
		source_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": f"existing-file-{frappe.generate_hash(length=8)}.txt",
				"content": "Existing attachment content",
			}
		).insert()
		comment_count_before = frappe.db.count(
			"Comment", {"reference_doctype": doctype, "reference_name": docname}
		)

		copied_file = source_file.create_attachment_copy(doctype, docname)
		comment_count_after = frappe.db.count(
			"Comment", {"reference_doctype": doctype, "reference_name": docname}
		)

		self.assertNotEqual(copied_file.name, source_file.name)
		self.assertEqual(copied_file.file_url, source_file.file_url)
		self.assertEqual(copied_file.attached_to_doctype, doctype)
		self.assertEqual(copied_file.attached_to_name, docname)
		self.assertEqual(
			copied_file.folder,
			frappe.db.get_value("File", {"is_attachments_folder": 1}),
		)
		self.assertEqual(comment_count_after, comment_count_before + 1)

	def test_create_attachment_copy_respects_attachment_limit(self):
		doctype, docname = make_test_doc()
		from frappe.custom.doctype.property_setter.property_setter import make_property_setter

		limit_property = make_property_setter("ToDo", None, "max_attachments", 1, "int", for_doctype=True)
		source_file_1 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": f"existing-limit-file-{frappe.generate_hash(length=8)}.txt",
				"content": "Existing attachment content 1",
			}
		).insert()
		source_file_2 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": f"existing-limit-file-{frappe.generate_hash(length=8)}.txt",
				"content": "Existing attachment content 2",
			}
		).insert()

		try:
			source_file_1.create_attachment_copy(doctype, docname)
			self.assertRaises(
				frappe.exceptions.AttachmentLimitReached,
				source_file_2.create_attachment_copy,
				doctype,
				docname,
			)
		finally:
			limit_property.delete()
			frappe.clear_cache(doctype="ToDo")


class TestFile(FrappeTestCase):
	def setUp(self):
		frappe.set_user("Administrator")
		self.delete_test_data()
		self.upload_file()

	def tearDown(self):
		try:
			frappe.get_doc("File", {"file_name": "file_copy.txt"}).delete()
		except frappe.DoesNotExistError:
			pass

	def delete_test_data(self):
		test_file_data = frappe.get_all(
			"File",
			pluck="name",
			filters={"is_home_folder": 0, "is_attachments_folder": 0},
			order_by="creation desc",
		)
		for f in test_file_data:
			frappe.delete_doc("File", f)

	def upload_file(self):
		_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "file_copy.txt",
				"attached_to_name": "",
				"attached_to_doctype": "",
				"folder": self.get_folder("Test Folder 1", "Home").name,
				"content": "Testing file copy example.",
			}
		)
		_file.save()
		self.saved_folder = _file.folder
		self.saved_name = _file.name
		self.saved_filename = get_files_path(_file.file_name)

	def get_folder(self, folder_name, parent_folder="Home"):
		return frappe.get_doc(
			{"doctype": "File", "file_name": _(folder_name), "is_folder": 1, "folder": _(parent_folder)}
		).insert()

	def tests_after_upload(self):
		self.assertEqual(self.saved_folder, _("Home/Test Folder 1"))
		file_folder = frappe.db.get_value("File", self.saved_name, "folder")
		self.assertEqual(file_folder, _("Home/Test Folder 1"))

	def test_file_copy(self):
		folder = self.get_folder("Test Folder 2", "Home")

		file = frappe.get_doc("File", {"file_name": "file_copy.txt"})
		move_file([{"name": file.name}], folder.name, file.folder)
		file = frappe.get_doc("File", {"file_name": "file_copy.txt"})

		self.assertEqual(_("Home/Test Folder 2"), file.folder)

	def test_folder_depth(self):
		result1 = self.get_folder("d1", "Home")
		self.assertEqual(result1.name, "Home/d1")
		result2 = self.get_folder("d2", "Home/d1")
		self.assertEqual(result2.name, "Home/d1/d2")
		result3 = self.get_folder("d3", "Home/d1/d2")
		self.assertEqual(result3.name, "Home/d1/d2/d3")
		result4 = self.get_folder("d4", "Home/d1/d2/d3")
		_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "folder_copy.txt",
				"attached_to_name": "",
				"attached_to_doctype": "",
				"folder": result4.name,
				"content": "Testing folder copy example",
			}
		)
		_file.save()

	def test_folder_copy(self):
		folder = self.get_folder("Test Folder 2", "Home")
		folder = self.get_folder("Test Folder 3", "Home/Test Folder 2")
		_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "folder_copy.txt",
				"attached_to_name": "",
				"attached_to_doctype": "",
				"folder": folder.name,
				"content": "Testing folder copy example",
			}
		)
		_file.save()

		move_file([{"name": folder.name}], "Home/Test Folder 1", folder.folder)

		file = frappe.get_doc("File", {"file_name": "folder_copy.txt"})
		file_copy_txt = frappe.get_value("File", {"file_name": "file_copy.txt"})
		if file_copy_txt:
			frappe.get_doc("File", file_copy_txt).delete()

		self.assertEqual(_("Home/Test Folder 1/Test Folder 3"), file.folder)

	def test_default_folder(self):
		d = frappe.get_doc({"doctype": "File", "file_name": _("Test_Folder"), "is_folder": 1})
		d.save()
		self.assertEqual(d.folder, "Home")

	def test_folder_file_url_is_always_empty(self):
		folder = self.get_folder("Test Folder URL", "Home")
		self.assertFalse(folder.file_url)

		folder.file_url = "/private/files/somewhere.txt"
		self.assertRaises(ValidationError, folder.save)

		self.assertRaises(
			ValidationError,
			frappe.get_doc(
				{
					"doctype": "File",
					"file_name": "another_folder",
					"is_folder": 1,
					"folder": "Home",
					"file_url": "/private/files/somewhere_else.txt",
				}
			).insert,
		)

	def test_on_delete(self):
		file = frappe.get_doc("File", {"file_name": "file_copy.txt"})
		file.delete()

		self.assertEqual(frappe.db.get_value("File", _("Home/Test Folder 1"), "file_size"), 0)

		folder = self.get_folder("Test Folder 3", "Home/Test Folder 1")
		_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "folder_copy.txt",
				"attached_to_name": "",
				"attached_to_doctype": "",
				"folder": folder.name,
				"content": "Testing folder copy example",
			}
		)
		_file.save()

		folder = frappe.get_doc("File", "Home/Test Folder 1/Test Folder 3")
		self.assertRaises(ValidationError, folder.delete)

	def test_same_file_url_update(self):
		attached_to_doctype1, attached_to_docname1 = make_test_doc()
		attached_to_doctype2, attached_to_docname2 = make_test_doc()

		file1 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "file1.txt",
				"attached_to_doctype": attached_to_doctype1,
				"attached_to_name": attached_to_docname1,
				"is_private": 1,
				"content": test_content1,
			}
		).insert()

		file2 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "file2.txt",
				"attached_to_doctype": attached_to_doctype2,
				"attached_to_name": attached_to_docname2,
				"is_private": 1,
				"content": test_content1,
			}
		).insert()

		self.assertEqual(file1.is_private, file2.is_private, 1)
		self.assertEqual(file1.file_url, file2.file_url)
		self.assertTrue(os.path.exists(file1.get_full_path()))

		file1.is_private = 0
		file1.save()

		file2 = frappe.get_doc("File", file2.name)

		self.assertEqual(file1.is_private, file2.is_private, 0)
		self.assertEqual(file1.file_url, file2.file_url)
		self.assertTrue(os.path.exists(file2.get_full_path()))

	def test_parent_directory_validation_in_file_url(self):
		file1 = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "parent_dir.txt",
				"is_private": 1,
				"content": test_content1,
			}
		).insert()

		file1.file_url = "/private/files/../test.txt"
		self.assertRaises(ValidationError, file1.save)

		# No validation to see if file exists
		file1.reload()
		file1.file_url = "/private/files/parent_dir2.txt"
		self.assertRaises(OSError, file1.save)

	def test_file_url_validation(self):
		test_file: File = frappe.new_doc("File")
		test_file.update({"file_name": "logo", "file_url": "https://frappe.io/files/frappe.png"})

		self.assertIsNone(test_file.validate())

		# bad path
		test_file.file_url = "/usr/bin/man"
		self.assertRaisesRegex(
			ValidationError, f"Cannot access file path {test_file.file_url}", test_file.validate
		)

		test_file.file_url = None
		test_file.file_name = "/usr/bin/man"
		self.assertRaisesRegex(ValidationError, "There is some problem with the file url", test_file.validate)

		test_file.file_url = None
		test_file.file_name = "_file"
		self.assertRaisesRegex(IOError, "does not exist", test_file.validate)

		test_file.file_url = None
		test_file.file_name = "/private/files/_file"
		self.assertRaisesRegex(ValidationError, "File name cannot have", test_file.validate)

	def test_make_thumbnail(self):
		# test web image
		test_file: File = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "logo",
				"file_url": frappe.utils.get_url("/_test/assets/image.jpg"),
			}
		).insert(ignore_permissions=True)

		test_file.make_thumbnail()
		self.assertEqual(test_file.thumbnail_url, "/files/image_small.jpg")

		# test web image without extension
		test_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "logo",
				"file_url": frappe.utils.get_url("/_test/assets/image"),
			}
		).insert(ignore_permissions=True)

		test_file.make_thumbnail()
		self.assertTrue(test_file.thumbnail_url.endswith("_small.jpg"))

		# test local image
		test_file.db_set("thumbnail_url", None)
		test_file.reload()
		test_file.file_url = "/files/image_small.jpg"
		test_file.make_thumbnail(suffix="xs", crop=True)
		self.assertEqual(test_file.thumbnail_url, "/files/image_small_xs.jpg")

		frappe.clear_messages()
		test_file.db_set("thumbnail_url", None)
		test_file.reload()
		test_file.file_url = frappe.utils.get_url("unknown.jpg")
		test_file.make_thumbnail(suffix="xs")
		self.assertEqual(
			frappe.message_log[0].get("message"),
			f"File '{frappe.utils.get_url('unknown.jpg')}' not found",
		)
		self.assertEqual(test_file.thumbnail_url, None)

	def test_file_unzip(self):
		file_path = frappe.get_app_path("frappe", "www/_test/assets/file.zip")
		public_file_path = frappe.get_site_path("public", "files")
		try:
			import shutil

			shutil.copy(file_path, public_file_path)
		except Exception:
			pass

		test_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_url": "/files/file.zip",
			}
		).insert(ignore_permissions=True)

		self.assertListEqual(
			[file.file_name for file in unzip_file(test_file.name)],
			["css_asset.css", "image.jpg", "js_asset.min.js"],
		)

		test_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_url": frappe.utils.get_url("/_test/assets/image.jpg"),
			}
		).insert(ignore_permissions=True)
		self.assertRaisesRegex(ValidationError, "not a zip file", test_file.unzip)

	def test_file_unzip_respects_dedicated_extract_size_setting(self):
		file_path = frappe.get_app_path("frappe", "www/_test/assets/file.zip")
		public_file_path = frappe.get_site_path("public", "files")
		try:
			shutil.copy(file_path, public_file_path)
		except Exception:
			pass

		test_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_url": "/files/file.zip",
			}
		).insert(ignore_permissions=True)
		self.addCleanup(test_file.delete)

		file_count_before = frappe.db.count("File")

		# a dedicated, tighter zip-extraction budget must be enforced even though
		# max_file_size (used for ordinary uploads) stays at its generous default
		with patch.dict(frappe.conf, {"max_zip_extract_size": 1000}):
			self.assertRaisesRegex(ValidationError, "maximum allowed size", test_file.unzip)

		self.assertTrue(frappe.db.exists("File", test_file.name))
		self.assertEqual(frappe.db.count("File"), file_count_before)

	def test_file_unzip_requires_read_permission(self):
		file_path = frappe.get_app_path("frappe", "www/_test/assets/file.zip")
		with open(file_path, "rb") as f:
			zip_content = f.read()

		try:
			frappe.set_user("test@example.com")
			test_file = frappe.get_doc(
				{
					"doctype": "File",
					"file_name": "file.zip",
					"content": zip_content,
					"is_private": 1,
				}
			).insert()

			file_count_before = frappe.db.count("File")

			# block unzip
			frappe.set_user("test4@example.com")
			self.assertRaises(frappe.PermissionError, unzip_file, test_file.name)
			self.assertTrue(frappe.db.exists("File", test_file.name))
			self.assertEqual(frappe.db.count("File"), file_count_before)

			# allow unzip
			frappe.set_user("test@example.com")
			self.assertListEqual(
				[file.file_name for file in unzip_file(test_file.name)],
				["css_asset.css", "image.jpg", "js_asset.min.js"],
			)
		finally:
			frappe.set_user("Administrator")

	def test_file_unzip_rolls_back_children_on_mid_extraction_failure(self):
		fixture_dir = tempfile.mkdtemp()
		zip_path = os.path.join(fixture_dir, "corrupt.zip")
		with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_STORED) as zf:
			zf.writestr("a.txt", "hello-a")
			zf.writestr("b.txt", "hello-b")
			zf.writestr("c.txt", "hello-c")

		# flip a byte in the last member's stored (uncompressed) data so it fails
		# its CRC check on read, without touching the central directory metadata
		with open(zip_path, "rb") as f:
			data = bytearray(f.read())
		corrupt_offset = data.rfind(b"hello-c")
		self.assertNotEqual(corrupt_offset, -1)
		data[corrupt_offset] ^= 0xFF
		with open(zip_path, "wb") as f:
			f.write(data)

		public_file_path = frappe.get_site_path("public", "files")
		shutil.copy(zip_path, public_file_path)

		test_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_url": "/files/corrupt.zip",
			}
		).insert(ignore_permissions=True)
		self.addCleanup(test_file.delete)

		file_count_before = frappe.db.count("File")

		# a.txt and b.txt extract fine and get saved before c.txt fails its CRC check;
		# the whole call must still roll back to a clean no-op
		self.assertRaisesRegex(ValidationError, "not a valid zip file", test_file.unzip)

		self.assertTrue(frappe.db.exists("File", test_file.name))
		self.assertEqual(frappe.db.count("File"), file_count_before)
		self.assertFalse(frappe.db.exists("File", {"file_name": "a.txt"}))
		self.assertFalse(frappe.db.exists("File", {"file_name": "b.txt"}))

	def test_create_file_without_file_url(self):
		test_file = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "logo",
				"content": "frappe",
			}
		).insert()
		assert test_file is not None

	def test_symlinked_files_folder(self):
		files_dir = os.path.abspath(get_files_path())
		with convert_to_symlink(files_dir):
			file = frappe.get_doc(
				{
					"doctype": "File",
					"file_name": "symlinked_folder_test.txt",
					"content": "42",
				}
			)
			file.save()
			file.content = ""
			file._content = ""
			file.save().reload()
			self.assertIn("42", file.get_content())

	def test_guest_upload_to_non_allowed_doctype(self):
		"""Verify Guest cannot upload to a restricted DocType."""
		from werkzeug.test import EnvironBuilder
		from werkzeug.wrappers import Request

		from frappe.handler import upload_file

		old_allow_guests = frappe.db.get_single_value("System Settings", "allow_guests_to_upload_files")
		old_allowed_doctypes = frappe.db.get_single_value(
			"System Settings", "allowed_doctypes_for_guest_uploads"
		)

		frappe.db.set_single_value("System Settings", "allow_guests_to_upload_files", 1)
		frappe.db.set_single_value("System Settings", "allowed_doctypes_for_guest_uploads", "ToDo")

		builder = EnvironBuilder(path="/", base_url="http://localhost")
		frappe.local.request = Request(builder.get_environ())

		frappe.set_user("Guest")
		frappe.form_dict.doctype = "User"
		frappe.form_dict.docname = "Administrator"

		try:
			self.assertRaises(frappe.PermissionError, upload_file)
		finally:
			frappe.db.set_single_value("System Settings", "allow_guests_to_upload_files", old_allow_guests)
			frappe.db.set_single_value(
				"System Settings", "allowed_doctypes_for_guest_uploads", old_allowed_doctypes
			)

			frappe.set_user("Administrator")
			frappe.form_dict.pop("doctype", None)
			frappe.form_dict.pop("docname", None)
			if hasattr(frappe.local, "request"):
				del frappe.local.request

	def test_guest_upload_to_allowed_doctype(self):
		"""Verify Guest can upload to an explicitly whitelisted DocType."""
		from werkzeug.test import EnvironBuilder
		from werkzeug.wrappers import Request

		from frappe.handler import upload_file

		old_allow_guests = frappe.db.get_single_value("System Settings", "allow_guests_to_upload_files")
		old_allowed_doctypes = frappe.db.get_single_value(
			"System Settings", "allowed_doctypes_for_guest_uploads"
		)

		frappe.db.set_single_value("System Settings", "allow_guests_to_upload_files", 1)
		frappe.db.set_single_value("System Settings", "allowed_doctypes_for_guest_uploads", "User\nToDo")

		builder = EnvironBuilder(path="/", base_url="http://localhost")
		frappe.local.request = Request(builder.get_environ())

		frappe.set_user("Administrator")
		todo = frappe.get_doc({"doctype": "ToDo", "description": "Test Target"}).insert()

		frappe.set_user("Guest")
		frappe.form_dict.doctype = "ToDo"
		frappe.form_dict.docname = todo.name
		frappe.form_dict.file_url = "https://frappe.io/assets/img/logo.png"
		frappe.form_dict.file_name = "guest_logo.png"

		file_doc = None
		try:
			file_doc = upload_file()
			self.assertEqual(file_doc.attached_to_name, todo.name)
		finally:
			frappe.db.set_single_value("System Settings", "allow_guests_to_upload_files", old_allow_guests)
			frappe.db.set_single_value(
				"System Settings", "allowed_doctypes_for_guest_uploads", old_allowed_doctypes
			)

			frappe.set_user("Administrator")
			if file_doc:
				file_doc.delete()
			todo.delete()

			frappe.form_dict.pop("doctype", None)
			frappe.form_dict.pop("docname", None)
			frappe.form_dict.pop("file_url", None)
			frappe.form_dict.pop("file_name", None)

			if hasattr(frappe.local, "request"):
				del frappe.local.request

	def test_guest_upload_for_empty_whitelist(self):
		"""Verify Guest can upload anywhere if the configuration whitelist string is left completely empty."""
		from werkzeug.test import EnvironBuilder
		from werkzeug.wrappers import Request

		from frappe.handler import upload_file

		old_allow_guests = frappe.db.get_single_value("System Settings", "allow_guests_to_upload_files")
		old_allowed_doctypes = frappe.db.get_single_value(
			"System Settings", "allowed_doctypes_for_guest_uploads"
		)

		frappe.db.set_single_value("System Settings", "allow_guests_to_upload_files", 1)
		frappe.db.set_single_value("System Settings", "allowed_doctypes_for_guest_uploads", "")

		builder = EnvironBuilder(path="/", base_url="http://localhost")
		frappe.local.request = Request(builder.get_environ())

		frappe.set_user("Guest")
		frappe.form_dict.doctype = "User"
		frappe.form_dict.docname = "Administrator"
		frappe.form_dict.file_url = "https://frappe.io/assets/img/logo.png"
		frappe.form_dict.file_name = "guest_fallback.png"

		file_doc = None
		try:
			file_doc = upload_file()
			self.assertEqual(file_doc.attached_to_name, "Administrator")
		finally:
			frappe.db.set_single_value("System Settings", "allow_guests_to_upload_files", old_allow_guests)
			frappe.db.set_single_value(
				"System Settings", "allowed_doctypes_for_guest_uploads", old_allowed_doctypes
			)

			frappe.set_user("Administrator")
			if file_doc:
				file_doc.delete()

			frappe.form_dict.pop("doctype", None)
			frappe.form_dict.pop("docname", None)
			frappe.form_dict.pop("file_url", None)
			frappe.form_dict.pop("file_name", None)

			if hasattr(frappe.local, "request"):
				del frappe.local.request

	def test_remote_file_ignores_content_hash(self):
		existing = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": f"hash_{frappe.generate_hash(length=6)}.txt",
				"content": "private-content",
				"is_private": 1,
			}
		).insert()
		self.addCleanup(frappe.delete_doc, "File", existing.name, force=True)

		for file_url in ("https://example.com/remote.png", "/api/method/remote"):
			with self.subTest(file_url=file_url):
				frappe.set_user("test@example.com")
				try:
					remote = frappe.get_doc(
						{
							"doctype": "File",
							"file_name": "remote.png",
							"is_private": 1,
							"file_url": file_url,
							"content_hash": existing.content_hash,
						}
					).insert()
				finally:
					frappe.set_user("Administrator")
				self.addCleanup(frappe.delete_doc, "File", remote.name, force=True)

				self.assertEqual(remote.file_url, file_url)
				self.assertFalse(remote.content_hash)

				remote.content_hash = existing.content_hash
				remote.save()
				self.assertFalse(remote.content_hash)


@contextmanager
def convert_to_symlink(directory):
	"""Moves a directory to temp directory and symlinks original path for testing"""
	try:
		new_directory = shutil.move(directory, tempfile.mkdtemp())
		os.symlink(new_directory, directory)
		yield
	finally:
		os.unlink(directory)
		shutil.move(new_directory, directory)


class TestAttachment(FrappeTestCase):
	test_doctype = "Test For Attachment"

	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		frappe.get_doc(
			doctype="DocType",
			name=cls.test_doctype,
			module="Custom",
			custom=1,
			fields=[
				{"label": "Title", "fieldname": "title", "fieldtype": "Data"},
				{"label": "Attachment", "fieldname": "attachment", "fieldtype": "Attach"},
			],
		).insert(ignore_if_duplicate=True)

	@classmethod
	def tearDownClass(cls):
		frappe.db.rollback()
		frappe.delete_doc("DocType", cls.test_doctype)

	def test_file_attachment_on_update(self):
		doc = frappe.get_doc(doctype=self.test_doctype, title="test for attachment on update").insert()

		file = frappe.get_doc(
			{"doctype": "File", "file_name": "test_attach.txt", "content": "Test Content"}
		).save()

		doc.attachment = file.file_url
		doc.save()

		exists = frappe.db.exists(
			"File",
			{
				"file_name": "test_attach.txt",
				"file_url": file.file_url,
				"attached_to_doctype": self.test_doctype,
				"attached_to_name": doc.name,
				"attached_to_field": "attachment",
			},
		)

		self.assertTrue(exists)


class TestAttachmentsAccess(FrappeTestCase):
	def setUp(self) -> None:
		frappe.db.delete("File", {"is_folder": 0})

	def test_list_private_attachments(self):
		frappe.set_user("test4@example.com")
		self.attached_to_doctype, self.attached_to_docname = make_test_doc()

		frappe.new_doc(
			"File",
			file_name="test_user_attachment.txt",
			attached_to_doctype=self.attached_to_doctype,
			attached_to_name=self.attached_to_docname,
			content="Testing User",
			is_private=1,
		).insert()

		frappe.new_doc(
			"File",
			file_name="test_user_standalone.txt",
			content="User Home",
			is_private=1,
		).insert()

		frappe.set_user("test@example.com")

		frappe.new_doc(
			"File",
			file_name="test_sm_attachment.txt",
			attached_to_doctype=self.attached_to_doctype,
			attached_to_name=self.attached_to_docname,
			content="Testing System Manager",
			is_private=1,
		).insert()

		frappe.new_doc(
			"File",
			file_name="test_sm_standalone.txt",
			content="System Manager Home",
			is_private=1,
		).insert()

		system_manager_files = [file.file_name for file in get_files_in_folder("Home")["files"]]
		system_manager_attachments_files = [
			file.file_name for file in get_files_in_folder("Home/Attachments")["files"]
		]

		frappe.set_user("test4@example.com")
		user_files = [file.file_name for file in get_files_in_folder("Home")["files"]]
		user_attachments_files = [file.file_name for file in get_files_in_folder("Home/Attachments")["files"]]

		self.assertIn("test_sm_standalone.txt", system_manager_files)
		self.assertNotIn("test_sm_standalone.txt", user_files)

		self.assertIn("test_user_standalone.txt", user_files)
		self.assertNotIn("test_user_standalone.txt", system_manager_files)

		self.assertIn("test_sm_attachment.txt", system_manager_attachments_files)
		self.assertIn("test_user_attachment.txt", system_manager_attachments_files)
		self.assertIn("test_user_attachment.txt", user_attachments_files)

	def test_attach_to_doc_without_write_permission_is_blocked(self):
		frappe.set_user("test4@example.com")
		self.assertFalse(frappe.has_permission("User", "write", "test@example.com"))

		attack = frappe.new_doc(
			"File",
			file_name="poisoned.svg",
			attached_to_doctype="User",
			attached_to_name="test@example.com",
			content="<svg xmlns='http://www.w3.org/2000/svg'><script>alert(1)</script></svg>",
			is_private=1,
		)
		self.assertRaises(frappe.PermissionError, attack.insert)

		frappe.set_user("test@example.com")
		self.assertEqual(
			frappe.get_all(
				"File", filters={"attached_to_doctype": "User", "attached_to_name": "test@example.com"}
			),
			[],
		)

	def tearDown(self) -> None:
		frappe.set_user("Administrator")
		frappe.db.rollback()


class TestFileUtils(FrappeTestCase):
	def test_extract_images_from_doc(self):
		is_private = not frappe.get_meta("ToDo").make_attachments_public

		# with filename in data URI
		todo = frappe.get_doc(
			doctype="ToDo",
			description='Test <img src="data:image/png;filename=pix.png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">',
		).insert()
		self.assertTrue(frappe.db.exists("File", {"attached_to_name": todo.name, "is_private": is_private}))
		self.assertRegex(todo.description, r"<img src=\"(.*)/files/pix\.png(.*)\">")
		self.assertListEqual(get_attached_images("ToDo", [todo.name])[todo.name], ["/private/files/pix.png"])

		# without filename in data URI
		todo = frappe.get_doc(
			doctype="ToDo",
			description='Test <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">',
		).insert()
		filename = frappe.db.exists("File", {"attached_to_name": todo.name})
		self.assertIn(f'<img src="{frappe.get_doc("File", filename).file_url}', todo.description)

	def test_extract_images_from_comment(self):
		"""
		Ensure that images are extracted from comments and become private attachments.
		"""
		is_private = not frappe.get_meta("ToDo").make_attachments_public
		test_doc = frappe.get_doc(doctype="ToDo", description="comment test").insert()
		comment = add_comment(
			"ToDo",
			test_doc.name,
			'<div class="ql-editor read-mode"><img src="data:image/png;filename=pix.png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="></div>',
			frappe.session.user,
			frappe.session.user,
		)

		self.assertTrue(
			frappe.db.exists("File", {"attached_to_name": test_doc.name, "is_private": is_private})
		)
		self.assertRegex(comment.content, r"<img src=\"(.*)/files/pix\.png(.*)\">")

	def test_extract_images_from_communication(self):
		"""
		Ensure that images are extracted from communication and become public attachments.
		"""
		is_private = not frappe.get_meta("Communication").make_attachments_public
		communication = frappe.get_doc(
			doctype="Communication",
			communication_type="Communication",
			communication_medium="Email",
			content='<div class="ql-editor read-mode"><img src="data:image/png;filename=pix.png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="></div>',
			recipients="to <to@test.com>",
			cc=None,
			bcc=None,
			sender="sender@test.com",
		).insert(ignore_permissions=True)

		self.assertTrue(
			frappe.db.exists("File", {"attached_to_name": communication.name, "is_private": is_private})
		)
		self.assertRegex(communication.content, r"<img src=\"(.*)/files/pix\.png(.*)\">")

	def test_broken_image(self):
		"""Ensure that broken inline images don't cause errors."""
		is_private = not frappe.get_meta("Communication").make_attachments_public
		communication = frappe.get_doc(
			doctype="Communication",
			communication_type="Communication",
			communication_medium="Email",
			content='<div class="ql-editor read-mode"><img src="data:image/png;filename=pix.png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CY="></div>',
			recipients="to <to@test.com>",
			cc=None,
			bcc=None,
			sender="sender@test.com",
		).insert(ignore_permissions=True)

		self.assertFalse(
			frappe.db.exists("File", {"attached_to_name": communication.name, "is_private": is_private})
		)
		self.assertIn(f'<img src="#broken-image" alt="{get_corrupted_image_msg()}">', communication.content)

	def test_create_new_folder(self):
		folder = create_new_folder("test_folder", "Home")
		self.assertTrue(folder.is_folder)

	def test_resolved_file_path_stays_within_files_directory(self):
		from frappe.utils.file_manager import get_file_path

		normal = frappe.get_doc(
			{"doctype": "File", "file_name": "within_bounds.txt", "content": "ok"}
		).insert()
		original_file_url = normal.file_url
		try:
			self.assertTrue(get_file_path(normal.name).endswith("within_bounds.txt"))

			normal.db_set("file_url", "/private/files/../../../../outside_bounds.txt")
			self.assertRaisesRegex(ValidationError, "Cannot access file path", get_file_path, normal.name)

			normal.db_set("file_url", "/private/files/../../site_level_file.txt")
			self.assertRaisesRegex(ValidationError, "Cannot access file path", get_file_path, normal.name)
		finally:
			normal.db_set("file_url", original_file_url)
			normal.delete()

	def test_traversal_file_url_cannot_reach_other_private_file(self):
		victim = frappe.get_doc(
			{"doctype": "File", "file_name": "traversal_victim.txt", "content": "secret", "is_private": 1}
		).insert()
		try:
			for is_private in (0, 1):
				doc = frappe.get_doc(
					{
						"doctype": "File",
						"file_name": "traversal_copy.txt",
						"file_url": f"/files/../../private/files/{victim.file_name}",
						"is_private": is_private,
					}
				)
				self.assertRaisesRegex(ValidationError, "File URL", doc.insert)
		finally:
			victim.delete()

	def test_resolved_file_path_rejects_sibling_directory_prefix_match(self):
		from frappe.utils.file_manager import get_file_path

		sibling_dir = get_files_path(is_private=1) + "_lookalike"
		os.makedirs(sibling_dir, exist_ok=True)
		with open(os.path.join(sibling_dir, "neighbour.txt"), "w") as f:
			f.write("outside the intended directory")

		normal = frappe.get_doc(
			{"doctype": "File", "file_name": "sibling_check.txt", "content": "ok"}
		).insert()
		original_file_url = normal.file_url
		try:
			normal.db_set("file_url", "/private/files/../files_lookalike/neighbour.txt")
			self.assertRaisesRegex(ValidationError, "Cannot access file path", get_file_path, normal.name)
		finally:
			normal.db_set("file_url", original_file_url)
			normal.delete()
			shutil.rmtree(sibling_dir)


class TestFileOptimization(FrappeTestCase):
	def test_optimize_file(self):
		with make_test_image_file() as test_file:
			original_size = test_file.file_size
			original_content_hash = test_file.content_hash

			test_file.optimize_file()
			optimized_size = test_file.file_size
			updated_content_hash = test_file.content_hash

			self.assertLess(optimized_size, original_size)
			self.assertNotEqual(original_content_hash, updated_content_hash)

	def test_optimize_file_rejects_mismatched_file_url(self):
		"""optimize_file must not read/write through a file_url belonging to another File record."""
		with make_test_image_file(private=True) as first_file:
			original_content = first_file.get_content()

			# distinct content from the first file's, so this doesn't collide with it via
			# the File doctype's identical-content deduplication
			second_image_path = frappe.get_app_path("frappe", "tests/data/exif_sample_image.jpg")
			with open(second_image_path, "rb") as f:
				second_content = f.read()
			self.assertNotEqual(second_content, original_content)

			second_file = frappe.get_doc(
				{
					"doctype": "File",
					"file_name": "second_file.jpg",
					"content": second_content,
					"is_private": 1,
				}
			).insert()
			self.addCleanup(second_file.delete)

			# same identity (name/owner) as second_file, but file_url/file_name swapped
			# to point at first_file's path
			crafted = frappe.get_doc(
				{
					"doctype": "File",
					"name": second_file.name,
					"owner": second_file.owner,
					"file_name": first_file.file_name,
					"file_url": first_file.file_url,
					"is_private": 1,
					"file_size": first_file.file_size,
					"modified": second_file.modified,
					"creation": second_file.creation,
				}
			)

			self.assertRaises(frappe.PermissionError, crafted.optimize_file)

			# neither the read nor the write side of optimize_file executed
			self.assertEqual(first_file.get_content(), original_content)
			self.assertEqual(frappe.get_doc("File", second_file.name).file_url, second_file.file_url)

	def test_validate_file_url_matches_record_allows_own_url(self):
		with make_test_image_file() as test_file:
			test_file.validate_file_url_matches_record()

	def test_validate_file_url_matches_record_rejects_missing_name(self):
		"""A doc with no name at all must not bypass the check by short-circuiting on it -
		optimize_file never legitimately runs against a document with no backing record."""
		doc = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": "not_yet_saved.jpg",
				"file_url": "/private/files/not_yet_saved.jpg",
				"is_private": 1,
			}
		)
		self.assertIsNone(doc.name)
		self.assertRaises(frappe.PermissionError, doc.validate_file_url_matches_record)

	def test_optimize_file_rejects_doc_with_no_name(self):
		"""A crafted doc with owner set to the caller but name omitted must not bypass the
		guard: permission checks upstream may still pass (falling back to create-level
		permission), so this method must fail closed rather than skip validation."""
		with make_test_image_file(private=True) as target:
			original_content = target.get_content()

			crafted = frappe.get_doc(
				{
					"doctype": "File",
					"owner": frappe.session.user,
					"file_name": target.file_name,
					"file_url": target.file_url,
					"is_private": 1,
					"file_size": target.file_size,
				}
			)
			self.assertIsNone(crafted.name)

			self.assertRaises(frappe.PermissionError, crafted.optimize_file)
			self.assertEqual(target.get_content(), original_content)

	def test_validate_file_url_matches_record_allows_url_shared_by_multiple_files(self):
		"""Two File records may legitimately share one file_url (see create_attachment_copy);
		each one must still be able to operate on its own record using that shared url."""
		doctype, docname = make_test_doc()
		source = frappe.get_doc(
			{
				"doctype": "File",
				"file_name": f"shared-{frappe.generate_hash(length=8)}.jpg",
				"content": open(
					frappe.get_app_path("frappe", "tests/data/sample_image_for_optimization.jpg"), "rb"
				).read(),
				"is_private": 1,
			}
		).insert()
		self.addCleanup(source.delete)

		copy = source.create_attachment_copy(doctype, docname)
		self.assertEqual(copy.file_url, source.file_url)

		# both the original and the copy must pass, regardless of DB row ordering
		frappe.get_doc("File", source.name).validate_file_url_matches_record()
		frappe.get_doc("File", copy.name).validate_file_url_matches_record()

	def test_optimize_svg(self):
		file_path = frappe.get_app_path("frappe", "tests/data/sample_svg.svg")
		with open(file_path, "rb") as f:
			file_content = f.read()
		test_file = frappe.get_doc(
			{"doctype": "File", "file_name": "sample_svg.svg", "content": file_content}
		).insert()
		self.assertRaises(TypeError, test_file.optimize_file)
		test_file.delete()

	def test_optimize_textfile(self):
		test_file = frappe.get_doc(
			{"doctype": "File", "file_name": "sample_text.txt", "content": "Text files cannot be optimized"}
		).insert()
		self.assertRaises(NotImplementedError, test_file.optimize_file)
		test_file.delete()

	def test_optimize_folder(self):
		test_folder = frappe.get_doc("File", "Home/Attachments")
		self.assertRaises(TypeError, test_folder.optimize_file)

	def test_revert_optimized_file_on_rollback(self):
		with make_test_image_file() as test_file:
			image_path = test_file.get_full_path()
			size_before_optimization = os.stat(image_path).st_size
			test_file.optimize_file()
			frappe.db.rollback()
			size_after_rollback = os.stat(image_path).st_size

			self.assertEqual(size_before_optimization, size_after_rollback)

	def test_image_header_guessing(self):
		file_path = frappe.get_app_path("frappe", "tests/data/sample_image_for_optimization.jpg")
		with open(file_path, "rb") as f:
			file_content = f.read()

		self.assertEqual(get_extension("", None, file_content), "jpg")


class TestGuestFileAndAttachments(FrappeTestCase):
	def setUp(self) -> None:
		frappe.db.delete("File", {"is_folder": 0})
		frappe.get_doc(
			doctype="DocType",
			name="Test For Attachment",
			module="Custom",
			custom=1,
			fields=[
				{"label": "Title", "fieldname": "title", "fieldtype": "Data"},
				{"label": "Attachment", "fieldname": "attachment", "fieldtype": "Attach"},
			],
		).insert(ignore_if_duplicate=True)

	def tearDown(self) -> None:
		frappe.set_user("Administrator")
		frappe.db.rollback()
		frappe.delete_doc("DocType", "Test For Attachment")

	def test_attach_unattached_guest_file(self):
		"""Ensure that unattached files are attached on doc update."""
		f = frappe.new_doc(
			"File",
			file_name="test_private_guest_attachment.txt",
			content="Guest Home",
			is_private=1,
		).insert(ignore_permissions=True)

		d = frappe.new_doc("Test For Attachment")
		d.title = "Test for attachment on update"
		d.attachment = f.file_url
		d.assigned_by = frappe.session.user
		d.save()

		self.assertTrue(
			frappe.db.exists(
				"File",
				{
					"file_name": "test_private_guest_attachment.txt",
					"file_url": f.file_url,
					"attached_to_doctype": "Test For Attachment",
					"attached_to_name": d.name,
					"attached_to_field": "attachment",
				},
			)
		)

	def test_list_private_guest_single_file(self):
		"""Ensure that guests are not able to read private standalone guest files."""
		frappe.set_user("Guest")

		file = frappe.new_doc(
			"File",
			file_name="test_private_guest_single_txt",
			content="Private single File",
			is_private=1,
		).insert(ignore_permissions=True)

		self.assertFalse(file.is_downloadable())

	def test_list_private_guest_attachment(self):
		"""Ensure that guests are not able to read private guest attachments."""
		frappe.set_user("Guest")

		self.attached_to_doctype, self.attached_to_docname = make_test_doc(ignore_permissions=True)

		file = frappe.new_doc(
			"File",
			file_name="test_private_guest_attachment.txt",
			attached_to_doctype=self.attached_to_doctype,
			attached_to_name=self.attached_to_docname,
			content="Private Attachment",
			is_private=1,
		).insert(ignore_permissions=True)

		self.assertFalse(file.is_downloadable())

	def test_private_remains_private_even_if_same_hash(self):
		file_name = "test" + frappe.generate_hash()
		content = file_name.encode()

		doc_pub: File = frappe.new_doc("File")  # type: ignore
		doc_pub.file_url = f"/files/{file_name}.txt"
		doc_pub.content = content
		doc_pub.save()

		doc_pri: File = frappe.new_doc("File")  # type: ignore
		doc_pri.file_url = f"/private/files/{file_name}.txt"
		doc_pri.is_private = False
		doc_pri.content = content
		doc_pri.save()

		doc_pub.reload()
		doc_pri.reload()

		self.assertEqual(doc_pub.is_private, 0)
		self.assertEqual(doc_pri.is_private, 1)

		self.assertEqual(doc_pub.file_url, f"/files/{file_name}.txt")
		self.assertEqual(doc_pri.file_url, f"/private/files/{file_name}.txt")

		self.assertEqual(doc_pub.get_content(), content)
		self.assertEqual(doc_pri.get_content(), content)

		# Deleting a public File should not delete the private File's disk file
		doc_pub.delete()
		self.assertTrue(os.path.exists(doc_pri.get_full_path()))

		# TODO: Migrate existing Files that have a mismatch between `is_private` and `file_url` prefix?
		# self.assertFalse(os.path.exists(doc_pub.get_full_path()))

		self.assertEqual(doc_pri.get_content(), content)
		doc_pri.delete()
		self.assertFalse(os.path.exists(doc_pri.get_full_path()))


class TestFileListOwnerRestriction(FrappeTestCase):
	"""Test file list owner restriction."""

	OWNER = "test1@example.com"
	OTHER = "test2@example.com"

	def setUp(self):
		frappe.set_user("Administrator")
		other_user = frappe.get_doc("User", self.OTHER)
		if not any(r.role == "Blogger" for r in other_user.roles):
			other_user.append("roles", {"role": "Blogger"})
			other_user.save(ignore_permissions=True)

		frappe.set_user(self.OWNER)
		self.pddr = frappe.get_doc({"doctype": "Personal Data Download Request", "user": self.OWNER}).insert(
			ignore_permissions=True
		)
		self.file = frappe.new_doc(
			"File",
			file_name="secret_export.json",
			attached_to_doctype="Personal Data Download Request",
			attached_to_name=self.pddr.name,
			content="secret data",
			is_private=1,
		).insert(ignore_permissions=True)

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback()

	def test_other_user_file_count_excludes_owner_restricted_file(self):
		frappe.set_user(self.OTHER)
		files = frappe.get_list("File", filters={"name": self.file.name})
		self.assertEqual(len(files), 0)

	def test_owner_file_count_includes_owner_restricted_file(self):
		frappe.set_user(self.OWNER)
		files = frappe.get_list("File", filters={"name": self.file.name})
		self.assertEqual(len(files), 1)

	def test_shared_but_not_owned_document_still_shows_its_file(self):
		frappe.set_user("Administrator")
		frappe.share.add_docshare("Personal Data Download Request", self.pddr.name, self.OTHER, read=1)

		frappe.set_user(self.OTHER)
		files = frappe.get_list("File", filters={"name": self.file.name})
		self.assertEqual(len(files), 1)


class TestFileListUserPermissionRestriction(FrappeTestCase):
	"""A doctype can grant unconditional role-level read (no if_owner) while still being scoped
	per-user via User Permissions (e.g. multi-company setups). A File attached to a record
	outside that scope must not be listable either."""

	RESTRICTED = "test1@example.com"
	OTHER = "test2@example.com"
	DOCTYPE = "Test User Perm Attachment"

	@classmethod
	def setUpClass(cls):
		super().setUpClass()
		frappe.get_doc(
			doctype="DocType",
			name=cls.DOCTYPE,
			module="Custom",
			custom=1,
			fields=[
				{"label": "Linked Role", "fieldname": "linked_role", "fieldtype": "Link", "options": "Role"}
			],
			permissions=[{"role": "All", "read": 1, "create": 1}],
		).insert(ignore_if_duplicate=True)

	@classmethod
	def tearDownClass(cls):
		super().tearDownClass()
		frappe.delete_doc("DocType", cls.DOCTYPE, force=True, ignore_permissions=True)

	def setUp(self):
		frappe.set_user("Administrator")
		for user in (self.RESTRICTED, self.OTHER):
			user_doc = frappe.get_doc("User", user)
			if not any(r.role == "Blogger" for r in user_doc.roles):
				user_doc.append("roles", {"role": "Blogger"})
				user_doc.save(ignore_permissions=True)

		frappe.get_doc(
			{
				"doctype": "User Permission",
				"user": self.RESTRICTED,
				"allow": "Role",
				"for_value": "Blogger",
			}
		).insert(ignore_permissions=True)

		self.permitted_record = frappe.get_doc({"doctype": self.DOCTYPE, "linked_role": "Blogger"}).insert(
			ignore_permissions=True
		)
		self.out_of_scope_record = frappe.get_doc(
			{"doctype": self.DOCTYPE, "linked_role": "Website Manager"}
		).insert(ignore_permissions=True)

		self.permitted_file = frappe.new_doc(
			"File",
			file_name="permitted.txt",
			attached_to_doctype=self.DOCTYPE,
			attached_to_name=self.permitted_record.name,
			content="in scope",
			is_private=1,
		).insert(ignore_permissions=True)
		self.out_of_scope_file = frappe.new_doc(
			"File",
			file_name="out_of_scope.txt",
			attached_to_doctype=self.DOCTYPE,
			attached_to_name=self.out_of_scope_record.name,
			content="out of scope",
			is_private=1,
		).insert(ignore_permissions=True)

	def tearDown(self):
		frappe.set_user("Administrator")
		frappe.db.rollback()

	def test_restricted_user_excludes_out_of_scope_file(self):
		frappe.set_user(self.RESTRICTED)
		files = frappe.get_list("File", filters={"name": self.out_of_scope_file.name})
		self.assertEqual(len(files), 0)

	def test_restricted_user_includes_permitted_file(self):
		frappe.set_user(self.RESTRICTED)
		files = frappe.get_list("File", filters={"name": self.permitted_file.name})
		self.assertEqual(len(files), 1)

	def test_unrestricted_user_sees_both_files(self):
		frappe.set_user(self.OTHER)
		files = frappe.get_list(
			"File",
			filters={"name": ["in", [self.permitted_file.name, self.out_of_scope_file.name]]},
		)
		self.assertEqual(len(files), 2)


class TestFilePermissionQuery(FrappeTestCase):
	def test_ignores_stale_custom_docperm_doctype(self):
		"""A stale Custom DocPerm can reference a deleted DocType; must not crash the File list query."""
		from frappe.core.doctype.file.file import get_permission_query_conditions
		from frappe.permissions import SYSTEM_USER_ROLE

		with (
			patch(
				"frappe.core.doctype.file.file.get_doctypes_with_read",
				return_value=["Deleted Doctype XYZ"],
			),
			patch("frappe.get_roles", return_value=[SYSTEM_USER_ROLE]),
		):
			# should not raise frappe.exceptions.DoesNotExistError
			get_permission_query_conditions(user="test1@example.com")
