# Copyright (c) 2022, Frappe Technologies Pvt. Ltd. and Contributors
# License: MIT. See LICENSE

import io
import mimetypes
import os
import re
import shutil
import zipfile
from urllib.parse import quote, unquote

from PIL import Image, ImageFile, ImageOps

import frappe
from frappe import _
from frappe.database.schema import SPECIAL_CHAR_PATTERN
from frappe.exceptions import DoesNotExistError
from frappe.model.db_query import requires_owner_constraint
from frappe.model.document import Document
from frappe.permissions import SYSTEM_USER_ROLE, get_doctypes_with_read, get_role_permissions
from frappe.utils import (
	call_hook_method,
	cint,
	get_files_path,
	get_hook_method,
	get_table_name,
	get_url,
)
from frappe.utils.file_manager import is_safe_path
from frappe.utils.html_utils import escape_html
from frappe.utils.image import optimize_image, strip_exif_data
from frappe.utils.pdf import pdf_contains_js

from .exceptions import (
	AttachmentLimitReached,
	FileTypeNotAllowed,
	FolderNotEmpty,
	MaxFileSizeReachedError,
)
from .utils import *

exclude_from_linked_with = True
ImageFile.LOAD_TRUNCATED_IMAGES = True  # nosemgrep
URL_PREFIXES = ("http://", "https://", "/api/method/")


class File(Document):
	# begin: auto-generated types
	# This code is auto-generated. Do not modify anything in this block.

	from typing import TYPE_CHECKING

	if TYPE_CHECKING:
		from frappe.types import DF

		attached_to_doctype: DF.Link | None
		attached_to_field: DF.Data | None
		attached_to_name: DF.Data | None
		content_hash: DF.Data | None
		file_name: DF.Data | None
		file_size: DF.Int
		file_type: DF.Data | None
		file_url: DF.Code | None
		folder: DF.Link | None
		is_attachments_folder: DF.Check
		is_folder: DF.Check
		is_home_folder: DF.Check
		is_private: DF.Check
		old_parent: DF.Data | None
		thumbnail_url: DF.SmallText | None
		uploaded_to_dropbox: DF.Check
		uploaded_to_google_drive: DF.Check
	# end: auto-generated types
	no_feed_on_delete = True

	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)
		# if content is set, file_url will be generated
		# decode comes in the picture if content passed has to be decoded before writing to disk

		self.content = self.get("content") or b""
		self.decode = self.get("decode", False)

	@property
	def is_remote_file(self):
		if self.file_url:
			return self.file_url.startswith(URL_PREFIXES)
		return not self.content

	def autoname(self):
		"""Set name for folder"""
		if self.is_folder:
			if self.folder:
				self.name = self.get_name_based_on_parent_folder()
			else:
				# home
				self.name = self.file_name
		else:
			self.name = frappe.generate_hash(length=10)

	def before_insert(self):
		# Ensure correct formatting and type
		self.file_url = unquote(self.file_url) if self.file_url else ""

		self.set_folder_name()
		self.set_is_private()
		self.set_file_name()
		self.validate_attachment_limit()
		self.set_file_type()
		self.validate_file_extension()
		self.validate_private_file_access()

		if self.is_folder:
			if self.file_url:
				frappe.throw(_("A folder cannot have a File URL"))
			return

		if self.flags.copy_from_existing_file:
			# Preserve the normal insert lifecycle for hooks and validations, but skip
			# reprocessing an existing blob that is already referenced by `file_url`.
			if not self.file_url:
				frappe.throw(
					_("File URL is required when copying an existing attachment."),
					exc=frappe.MandatoryError,
				)
			return

		if self.is_remote_file:
			# a remote file has no local blob to hash
			self.content_hash = None
			self.validate_remote_file()
		else:
			self.save_file(content=self.get_content())
			self.flags.new_file = True
			frappe.db.after_rollback.add(self.on_rollback)

		if not self.is_remote_file:
			self.validate_duplicate_entry()  # Hash is generated in save_file

	def after_insert(self):
		if not self.is_folder:
			self.create_attachment_record()

	def create_attachment_copy(
		self,
		attached_to_doctype: str,
		attached_to_name: str,
		attached_to_field: str | None = None,
		ignore_permissions: bool = False,
	):
		"""Efficiently copy an attachment from one document to another by reusing `file_url`."""
		if self.is_folder:
			frappe.throw(_("Cannot attach a folder to a document"))

		attachment = frappe.copy_doc(self)
		attachment.update(
			{
				"attached_to_doctype": attached_to_doctype,
				"attached_to_name": attached_to_name,
				"attached_to_field": attached_to_field,
			}
		)
		attachment.folder = None
		attachment.flags.copy_from_existing_file = True
		return attachment.insert(ignore_permissions=ignore_permissions)

	def validate(self):
		if self.is_folder:
			if self.file_url:
				frappe.throw(_("A folder cannot have a File URL"))
			return

		if self.is_remote_file:
			self.content_hash = None

		self.validate_attachment_references()
		self.enforce_public_file_restrictions()

		# when dict is passed to get_doc for creation of new_doc, is_new returns None
		# this case is handled inside handle_is_private_changed
		if not self.is_new() and self.has_value_changed("is_private"):
			self.handle_is_private_changed()

		self.validate_file_path()
		self.validate_file_url()
		self.validate_file_on_disk()
		self.file_size = frappe.form_dict.file_size or self.file_size

	def enforce_public_file_restrictions(self):
		if not self.is_private and frappe.get_system_settings(
			"only_allow_system_managers_to_upload_public_files"
		):
			try:
				frappe.only_for("System Manager")
			except PermissionError:
				frappe.throw(_("Only System Managers can make this file public."))

	def validate_private_file_access(self):
		"""Validate that the user has permission to access an existing private file."""
		if not self.file_url:
			return

		existing_files = frappe.get_all(
			"File",
			filters={"file_url": self.file_url},
			fields=["name", "owner", "is_private"],
			limit=1,
		)

		if not existing_files:
			return

		existing_file = existing_files[0]

		if existing_file.is_private:
			user = frappe.session.user

			if user == existing_file.owner or user == "Administrator":
				return

			existing_doc = frappe.get_doc("File", existing_file.name)
			if not has_permission(existing_doc, "read", user=user):
				frappe.throw(
					_("You do not have permission to access this file"),
					frappe.PermissionError,
				)

	def validate_attachment_references(self):
		if not self.attached_to_doctype:
			return

		if not self.attached_to_name or not isinstance(self.attached_to_name, str | int):
			frappe.throw(_("Attached To Name must be a string or an integer"), frappe.ValidationError)

		if self.attached_to_field and SPECIAL_CHAR_PATTERN.search(self.attached_to_field):
			frappe.throw(_("The fieldname you've specified in Attached To Field is invalid"))

		if self.flags.ignore_permissions or frappe.flags.in_install:
			return

		from frappe.handler import check_write_permission

		check_write_permission(self.attached_to_doctype, self.attached_to_name)

	def after_rename(self, *args, **kwargs):
		for successor in self.get_successors():
			setup_folder_path(successor, self.name)

	def on_trash(self):
		if self.is_home_folder or self.is_attachments_folder:
			frappe.throw(_("Cannot delete Home and Attachments folders"))
		self.validate_empty_folder()
		self.validate_protected_file()
		self._delete_file_on_disk()
		if not self.is_folder:
			self.add_comment_in_reference_doc("Attachment Removed", self.file_name)

	def on_rollback(self):
		rollback_flags = ("new_file", "original_content", "original_path")

		def pop_rollback_flags():
			for flag in rollback_flags:
				self.flags.pop(flag, None)

		# following condition is only executed when an insert has been rolledback
		if self.flags.new_file:
			self._delete_file_on_disk()
			pop_rollback_flags()
			return

		# if original_content flag is set, this rollback should revert the file to its original state
		if self.flags.original_content:
			file_path = self.get_full_path()

			if isinstance(self.flags.original_content, bytes):
				mode = "wb+"
			elif isinstance(self.flags.original_content, str):
				mode = "w+"

			with open(file_path, mode) as f:
				f.write(self.flags.original_content)
				os.fsync(f.fileno())
				pop_rollback_flags()

		# used in case file path (File.file_url) has been changed
		if self.flags.original_path:
			target = self.flags.original_path["old"]
			source = self.flags.original_path["new"]
			shutil.move(source, target)
			pop_rollback_flags()

	def get_name_based_on_parent_folder(self) -> str | None:
		if self.folder:
			return os.path.join(self.folder, self.file_name)

	def get_successors(self):
		return frappe.get_all("File", filters={"folder": self.name}, pluck="name")

	def validate_file_path(self):
		if self.is_remote_file:
			return

		if self.file_url and ".." in self.file_url.split("/"):
			frappe.throw(_("The File URL you've entered is incorrect"), title=_("Invalid File URL"))

		base_path = os.path.realpath(get_files_path(is_private=self.is_private))
		file_path = os.path.realpath(self.get_full_path())
		if os.path.commonpath((base_path, file_path)) != base_path:
			frappe.throw(
				_("The File URL you've entered is incorrect"),
				title=_("Invalid File URL"),
			)

	def validate_file_url(self):
		if self.is_remote_file or not self.file_url:
			return

		if not self.file_url.startswith(("/files/", "/private/files/")):
			# Probably an invalid URL since it doesn't start with http either
			frappe.throw(
				_("URL must start with http:// or https://"),
				title=_("Invalid URL"),
			)

	def handle_is_private_changed(self):
		if self.is_remote_file:
			return

		from pathlib import Path

		old_file_url = self.file_url
		file_name = self.file_url.split("/")[-1]
		private_file_path = Path(frappe.get_site_path("private", "files", file_name))
		public_file_path = Path(frappe.get_site_path("public", "files", file_name))

		if cint(self.is_private):
			source = public_file_path
			target = private_file_path
			url_starts_with = "/private/files/"
		else:
			source = private_file_path
			target = public_file_path
			url_starts_with = "/files/"
		updated_file_url = f"{url_starts_with}{file_name}"

		# if a file document is created by passing dict throught get_doc and __local is not set,
		# handle_is_private_changed would be executed; we're checking if updated_file_url is same
		# as old_file_url to avoid a FileNotFoundError for this case.
		if updated_file_url == old_file_url:
			return

		if not source.exists():
			frappe.throw(
				_("Cannot find file {} on disk").format(source),
				exc=FileNotFoundError,
			)
		if target.exists():
			frappe.throw(
				_("A file with same name {} already exists").format(target),
				exc=FileExistsError,
			)

		# Uses os.rename which is an atomic operation
		shutil.move(source, target)
		self.flags.original_path = {"old": source, "new": target}
		frappe.db.after_rollback.add(self.on_rollback)

		self.file_url = updated_file_url
		update_existing_file_docs(self)

		if (
			not self.attached_to_doctype
			or not self.attached_to_name
			or not self.fetch_attached_to_field(old_file_url)
		):
			return

		if frappe.get_meta(self.attached_to_doctype).issingle:
			frappe.db.set_single_value(
				self.attached_to_doctype,
				self.attached_to_field,
				self.file_url,
			)
		else:
			frappe.db.set_value(
				self.attached_to_doctype,
				self.attached_to_name,
				self.attached_to_field,
				self.file_url,
			)

	def fetch_attached_to_field(self, old_file_url):
		if self.attached_to_field:
			return True

		reference_dict = frappe.get_doc(self.attached_to_doctype, self.attached_to_name).as_dict()

		for key, value in reference_dict.items():
			if value == old_file_url:
				self.attached_to_field = key
				return True

	def validate_attachment_limit(self):
		attachment_limit = 0
		if self.attached_to_doctype and self.attached_to_name:
			attachment_limit = cint(frappe.get_meta(self.attached_to_doctype).max_attachments)

		if attachment_limit:
			current_attachment_count = len(
				frappe.get_all(
					"File",
					filters={
						"attached_to_doctype": self.attached_to_doctype,
						"attached_to_name": self.attached_to_name,
					},
					limit=attachment_limit + 1,
				)
			)

			if current_attachment_count >= attachment_limit:
				frappe.throw(
					_("Maximum Attachment Limit of {0} has been reached for {1} {2}.").format(
						frappe.bold(attachment_limit), self.attached_to_doctype, self.attached_to_name
					),
					exc=AttachmentLimitReached,
					title=_("Attachment Limit Reached"),
				)

	def validate_remote_file(self):
		"""Validates if file uploaded using URL already exist"""
		site_url = get_url()
		if self.file_url and "/files/" in self.file_url and self.file_url.startswith(site_url):
			self.file_url = self.file_url.split(site_url, 1)[1]

	def set_folder_name(self):
		"""Make parent folders if not exists based on reference doctype and name"""
		if self.folder:
			return

		if self.attached_to_doctype:
			self.folder = frappe.db.get_value("File", {"is_attachments_folder": 1})

		elif not self.is_home_folder:
			self.folder = "Home"

	def set_file_type(self):
		if self.is_folder:
			return

		file_type = mimetypes.guess_type(self.file_name)[0]
		if not file_type:
			return

		file_extension = mimetypes.guess_extension(file_type)
		self.file_type = file_extension.lstrip(".").upper() if file_extension else None

	def validate_file_on_disk(self):
		"""Validates existence file"""
		full_path = self.get_full_path()

		if full_path.startswith(URL_PREFIXES):
			return True

		if not os.path.exists(full_path):
			frappe.throw(_("File {0} does not exist").format(self.file_url), IOError)

	def validate_file_extension(self):
		# Only validate uploaded files, not generated by code/integrations.
		if self.is_folder or not frappe.request:
			return

		allowed_extensions = frappe.get_system_settings("allowed_file_extensions")
		if not allowed_extensions:
			return

		file_extension = os.path.splitext(self.file_name)[1].lstrip(".").upper()
		if file_extension not in allowed_extensions.splitlines():
			frappe.throw(_("File type of {0} is not allowed").format(file_extension), exc=FileTypeNotAllowed)

	def check_content(self):
		if self.file_type == "PDF" and self._content and pdf_contains_js(self._content):
			frappe.throw(_("This PDF cannot be uploaded as it contains unsafe content."))

	def validate_duplicate_entry(self):
		if not self.flags.ignore_duplicate_entry_error and not self.is_folder:
			if not self.content_hash:
				self.generate_content_hash()

			# check duplicate name
			# check duplicate assignment
			filters = {
				"content_hash": self.content_hash,
				"is_private": self.is_private,
			}

			if self.name:
				filters.update({"name": ("!=", self.name)})

			if self.attached_to_doctype and self.attached_to_name:
				filters.update(
					{
						"attached_to_doctype": self.attached_to_doctype,
						"attached_to_name": self.attached_to_name,
					}
				)
			duplicate_file = frappe.db.get_value("File", filters, ["name", "file_url"], as_dict=1)

			if duplicate_file:
				duplicate_file_doc = frappe.get_cached_doc("File", duplicate_file.name)
				if duplicate_file_doc.exists_on_disk():
					# just use the url, to avoid uploading a duplicate
					self.file_url = duplicate_file.file_url

	def set_file_name(self):
		if not self.file_name and not self.file_url:
			frappe.throw(
				_("Fields `file_name` or `file_url` must be set for File"), exc=frappe.MandatoryError
			)
		elif not self.file_name and self.file_url:
			self.file_name = self.file_url.split("/")[-1].split("?")[0]
		else:
			self.file_name = re.sub(r"/", "", self.file_name)

	def generate_content_hash(self):
		if self.content_hash or not self.file_url or self.is_remote_file:
			return
		file_name = self.file_url.split("/")[-1]
		try:
			file_path = get_files_path(file_name, is_private=self.is_private)
			with open(file_path, "rb") as f:
				self.content_hash = get_content_hash(f.read())
		except OSError:
			frappe.throw(_("File {0} does not exist").format(file_path))

	def make_thumbnail(
		self,
		set_as_thumbnail: bool = True,
		width: int = 300,
		height: int = 300,
		suffix: str = "small",
		crop: bool = False,
	) -> str:
		from requests.exceptions import HTTPError, SSLError

		if not self.file_url:
			return

		try:
			if self.file_url.startswith(("/files", "/private/files")):
				image, filename, extn = get_local_image(self.file_url)
			else:
				image, filename, extn = get_web_image(self.file_url)
		except (HTTPError, SSLError, OSError, TypeError):
			return

		size = width, height
		if crop:
			image = ImageOps.fit(image, size, Image.Resampling.LANCZOS)
		else:
			image.thumbnail(size, Image.Resampling.LANCZOS)

		thumbnail_url = f"{filename}_{suffix}.{extn}"
		path = os.path.abspath(frappe.get_site_path("public", thumbnail_url.lstrip("/")))

		try:
			image.save(path)
			if set_as_thumbnail:
				self.db_set("thumbnail_url", thumbnail_url)

		except OSError:
			frappe.msgprint(_("Unable to write file format for {0}").format(path))
			return

		return thumbnail_url

	def validate_empty_folder(self):
		"""Throw exception if folder is not empty"""
		if self.is_folder and frappe.get_all("File", filters={"folder": self.name}, limit=1):
			frappe.throw(_("Folder {0} is not empty").format(self.name), FolderNotEmpty)

	def validate_protected_file(self):
		"""Throw an exception if this file is attached to a doctype that protects files.

		Allows deleting the attached file if the linked document is in draft. If submitted,
		deletion is not allowed. If canceled, requires delete permissions on the linked document.
		"""
		if not (self.attached_to_doctype and self.attached_to_name):
			return

		try:
			ref_doc = frappe.get_doc(self.attached_to_doctype, self.attached_to_name)
		except DoesNotExistError:
			return

		if ref_doc.docstatus == 0:
			# If the document is not submitted yet, users can correct wrong attachments
			return

		if not ref_doc.meta.protect_attached_files:
			return

		if ref_doc.docstatus == 2 and ref_doc.has_permission("delete"):
			# Deletion must still be possible if users have the permission to delete the linked document
			return

		frappe.throw(
			msg=_("This file is attached to a protected document and cannot be deleted."),
			title=_("Protected File"),
		)

	def _delete_file_on_disk(self):
		"""If file not attached to any other record, delete it"""
		on_disk_file_not_shared = self.content_hash and not frappe.get_all(
			"File",
			filters={
				"content_hash": self.content_hash,
				"name": ["!=", self.name],
				# NOTE: Some old Files might share file_urls while not sharing the is_private value
				# "is_private": self.is_private,
			},
			limit=1,
		)
		if on_disk_file_not_shared:
			self.delete_file_data_content()
		else:
			self.delete_file_data_content(only_thumbnail=True)

	def unzip(self) -> list["File"]:
		"""Unzip current file and replace it by its children"""
		from frappe.core.api.file import get_max_extract_size

		if not self.file_url.endswith(".zip"):
			frappe.throw(_("{0} is not a zip file").format(self.file_name))

		self.check_permission("read")

		zip_path = self.get_full_path()
		max_extracted_size = get_max_extract_size()

		files = []
		total_extracted_size = 0
		with zipfile.ZipFile(zip_path) as z:
			# skip directories, macos hidden directory & hidden files
			members = [
				file
				for file in z.filelist
				if not (file.is_dir() or file.filename.startswith("__MACOSX/"))
				and not os.path.basename(file.filename).startswith(".")
			]

			# Reject on declared (central directory) sizes before reading any member,
			# so a small, highly compressible archive can't force large reads/writes.
			declared_total_size = sum(file.file_size for file in members)
			if declared_total_size > max_extracted_size:
				frappe.throw(
					_("Zip file extracts to more than the maximum allowed size of {0} MB").format(
						max_extracted_size // 1048576
					)
				)

			try:
				for file in members:
					filename = os.path.basename(file.filename)

					file_doc = frappe.new_doc("File")
					try:
						content = z.read(file.filename)
					except zipfile.BadZipFile:
						frappe.throw(_("{0} is a not a valid zip file").format(self.file_name))

					total_extracted_size += len(content)
					if total_extracted_size > max_extracted_size:
						frappe.throw(
							_("Zip file extracts to more than the maximum allowed size of {0} MB").format(
								max_extracted_size // 1048576
							)
						)

					file_doc.content = content
					file_doc.file_name = filename
					file_doc.folder = self.folder
					file_doc.is_private = self.is_private
					file_doc.attached_to_doctype = self.attached_to_doctype
					file_doc.attached_to_name = self.attached_to_name
					file_doc.save()
					files.append(file_doc)
			except Exception:
				# roll back any children already persisted before the failure
				for file_doc in files:
					frappe.delete_doc("File", file_doc.name, ignore_permissions=True, force=True)
				raise

		frappe.delete_doc("File", self.name)
		return files

	def exists_on_disk(self):
		return os.path.exists(self.get_full_path())

	def get_content(self) -> bytes:
		if self.is_folder:
			frappe.throw(_("Cannot get file contents of a Folder"))

		self.validate_file_path()
		if self.get("content"):
			self._content = self.content
			if self.decode:
				self._content = decode_file_content(self._content)
				self.decode = False
			# self.content = None # TODO: This needs to happen; make it happen somehow
			return self._content

		if self.file_url:
			self.validate_file_url()
		file_path = self.get_full_path()

		# read the file
		with open(file_path, mode="rb") as f:
			self._content = f.read()
			try:
				# for plain text files
				self._content = self._content.decode()
			except UnicodeDecodeError:
				# for .png, .jpg, etc
				pass

		return self._content

	def get_full_path(self):
		"""Returns file path from given file name"""

		file_path = self.file_url or self.file_name

		site_url = get_url()
		if "/files/" in file_path and file_path.startswith(site_url):
			file_path = file_path.split(site_url, 1)[1]

		if "/" not in file_path:
			if self.is_private:
				file_path = f"/private/files/{file_path}"
			else:
				file_path = f"/files/{file_path}"

		if file_path.startswith("/private/files/"):
			file_path = get_files_path(*file_path.split("/private/files/", 1)[1].split("/"), is_private=1)

		elif file_path.startswith("/files/"):
			file_path = get_files_path(*file_path.split("/files/", 1)[1].split("/"))

		elif file_path.startswith(URL_PREFIXES):
			pass

		elif not self.file_url:
			frappe.throw(_("There is some problem with the file url: {0}").format(file_path))

		if not is_safe_path(file_path):
			frappe.throw(_("Cannot access file path {0}").format(file_path))

		if os.path.sep in self.file_name:
			frappe.throw(_("File name cannot have {0}").format(os.path.sep))

		return file_path

	def write_file(self):
		"""write file to disk with a random name (to compare)"""
		if self.is_remote_file:
			return

		file_path = self.get_full_path()

		if isinstance(self._content, str):
			self._content = self._content.encode()
		self.check_content()
		with open(file_path, "wb+") as f:
			f.write(self._content)
			os.fsync(f.fileno())

		frappe.db.after_rollback.add(self.on_rollback)

		return file_path

	def save_file(
		self,
		content: bytes | str | None = None,
		decode=False,
		ignore_existing_file_check=False,
		overwrite=False,
	):
		if self.is_remote_file:
			return

		if not self.flags.new_file:
			self.flags.original_content = self.get_content()

		if content:
			self.content = content
			self.decode = decode
			self.get_content()

		if not self._content:
			return

		file_exists = False
		duplicate_file = None

		self.is_private = cint(self.is_private)
		self.content_type = mimetypes.guess_type(self.file_name)[0]

		# transform file content based on site settings
		if (
			self.content_type
			and self.content_type == "image/jpeg"
			and frappe.get_system_settings("strip_exif_metadata_from_uploaded_images")
		):
			self._content = strip_exif_data(self._content, self.content_type)

		self.file_size = self.check_max_file_size()
		self.content_hash = get_content_hash(self._content)

		# check if a file exists with the same content hash and is also in the same folder (public or private)
		if not ignore_existing_file_check:
			duplicate_file = frappe.get_value(
				"File",
				{"content_hash": self.content_hash, "is_private": self.is_private},
				["file_url", "name"],
				as_dict=True,
			)

		if duplicate_file:
			file_doc: File = frappe.get_cached_doc("File", duplicate_file.name)
			if file_doc.exists_on_disk():
				if self.exists_on_disk():
					if not self.file_url:
						self.file_url = duplicate_file.file_url
				else:
					self.file_url = duplicate_file.file_url
				file_exists = True

		if not file_exists:
			if not overwrite:
				self.file_name = generate_file_name(
					name=self.file_name,
					suffix=self.content_hash[-6:],
					is_private=self.is_private,
				)
			call_hook_method("before_write_file", file_size=self.file_size)
			write_file_method = get_hook_method("write_file")
			if write_file_method:
				return write_file_method(self)
			return self.save_file_on_filesystem()

	def save_file_on_filesystem(self):
		safe_file_name = re.sub(r"[/\\%?#]", "_", self.file_name)
		if self.is_private:
			self.file_url = f"/private/files/{safe_file_name}"
		else:
			self.file_url = f"/files/{safe_file_name}"

		fpath = self.write_file()

		return {"file_name": os.path.basename(fpath), "file_url": self.file_url}

	def check_max_file_size(self):
		from frappe.core.api.file import get_max_file_size

		max_file_size = get_max_file_size()
		file_size = len(self._content or b"")

		if file_size > max_file_size:
			msg = _("File size exceeded the maximum allowed size of {0} MB").format(max_file_size / 1048576)
			if frappe.has_permission("System Settings", "write"):
				msg += ".<br>" + _("You can increase the limit from System Settings.")
			frappe.throw(msg, exc=MaxFileSizeReachedError)

		return file_size

	def delete_file_data_content(self, only_thumbnail=False):
		method = get_hook_method("delete_file_data_content")
		if method:
			method(self, only_thumbnail=only_thumbnail)
		else:
			self.delete_file_from_filesystem(only_thumbnail=only_thumbnail)

	def delete_file_from_filesystem(self, only_thumbnail=False):
		"""Delete file, thumbnail from File document"""
		if only_thumbnail:
			delete_file(self.thumbnail_url)
		else:
			delete_file(self.file_url)
			delete_file(self.thumbnail_url)

	def is_downloadable(self):
		return has_permission(self, "read")

	def get_extension(self):
		"""returns split filename and extension"""
		return os.path.splitext(self.file_name)

	def create_attachment_record(self):
		icon = ' <i class="fa fa-lock text-warning"></i>' if self.is_private else ""
		file_url = quote(frappe.safe_encode(self.file_url), safe="/:") if self.file_url else self.file_name
		file_name = escape_html(self.file_name or self.file_url)

		self.add_comment_in_reference_doc(
			"Attachment",
			f"<a href='{file_url}' target='_blank'>{file_name}</a>{icon}",
		)

	def add_comment_in_reference_doc(self, comment_type, text):
		if self.attached_to_doctype and self.attached_to_name:
			try:
				doc = frappe.get_doc(self.attached_to_doctype, self.attached_to_name)
				doc.add_comment(comment_type, text)
			except frappe.DoesNotExistError:
				frappe.clear_messages()

	def set_is_private(self):
		if self.file_url:
			self.is_private = cint(self.file_url.startswith("/private"))

	def validate_file_url_matches_record(self):
		"""Ensure file_url actually resolves back to an existing File record with this name."""
		if not self.file_url:
			return

		actual_file_url = frappe.db.get_value("File", self.name, "file_url") if self.name else None
		if actual_file_url != self.file_url:
			frappe.throw(_("The File URL does not belong to this File record"), frappe.PermissionError)

	@frappe.whitelist()
	def optimize_file(self):
		if self.is_folder:
			raise TypeError("Folders cannot be optimized")

		self.validate_file_url_matches_record()

		content_type = mimetypes.guess_type(self.file_name)[0]
		is_local_image = content_type.startswith("image/") and self.file_size > 0
		is_svg = content_type == "image/svg+xml"

		if not is_local_image:
			raise NotImplementedError("Only local image files can be optimized")

		if is_svg:
			raise TypeError("Optimization of SVG images is not supported")

		original_content = self.get_content()
		optimized_content = optimize_image(
			content=original_content,
			content_type=content_type,
		)

		if original_content == optimized_content:
			# optimization failed, don't resave it
			return

		self.save_file(content=optimized_content, overwrite=True)
		self.save()

	@property
	def unique_url(self) -> str:
		"""Unique URL contains file ID in URL to speed up permisison checks."""
		from urllib.parse import urlencode

		if self.is_private:
			return self.file_url + "?" + urlencode({"fid": self.name})
		else:
			return self.file_url

	@staticmethod
	def zip_files(files):
		zip_file = io.BytesIO()
		zf = zipfile.ZipFile(zip_file, "w", zipfile.ZIP_DEFLATED)
		for _file in files:
			if isinstance(_file, str):
				_file = frappe.get_doc("File", _file)
			if not isinstance(_file, File):
				continue
			if _file.is_folder:
				continue
			if not has_permission(_file, "read"):
				continue
			zf.writestr(_file.file_name, _file.get_content())
		zf.close()
		return zip_file.getvalue()


def on_doctype_update():
	frappe.db.add_index("File", ["attached_to_doctype", "attached_to_name"])
	frappe.db.add_index("File", ["file_url(100)"])


def has_permission(doc, ptype=None, user=None, debug=False):
	user = user or frappe.session.user

	if user == "Administrator":
		return True
	if ptype == "create":
		return frappe.has_permission("File", "create", user=user, debug=debug)

	if not doc.is_private and ptype in ("read", "select"):
		return True

	if user != "Guest" and doc.owner == user:
		return True
	if (
		user != "Guest"
		and ptype in ["read", "write", "share", "submit"]
		and frappe.share.get_shared(
			"File", filters=[["share_name", "=", doc.name]], rights=[ptype], user=user
		)
	):
		return True

	if doc.attached_to_doctype and doc.attached_to_name:
		attached_to_doctype = doc.attached_to_doctype
		attached_to_name = doc.attached_to_name

		try:
			ref_doc = frappe.get_doc(attached_to_doctype, attached_to_name)
		except (ModuleNotFoundError, ImportError):
			return False
		except frappe.DoesNotExistError:
			frappe.clear_last_message()
			return False

		if ptype in ["write", "create", "delete"]:
			return ref_doc.has_permission("write", debug=debug, user=user)
		else:
			return ref_doc.has_permission("read", debug=debug, user=user)

	return False


def get_permission_query_conditions(user: str | None = None) -> str:
	user = user or frappe.session.user
	if user == "Administrator":
		return ""

	if SYSTEM_USER_ROLE not in frappe.get_roles(user):
		return f""" `tabFile`.`owner` = {frappe.db.escape(user)} """

	# Custom DocPerm rows can outlive their DocType, drop those
	# before frappe.get_meta() below assumes the doctype still exists.
	candidate_doctypes = get_doctypes_with_read(user)
	existing_doctypes = set(
		frappe.get_all("DocType", filters={"name": ["in", candidate_doctypes]}, pluck="name")
	)
	readable_doctypes = [dt for dt in candidate_doctypes if dt in existing_doctypes]

	openly_readable_doctypes, owner_restricted_doctypes = _split_doctypes_by_owner_constraint(
		readable_doctypes, user
	)
	# a doctype that requires an owner constraint is never additionally scoped by User
	# Permissions here - same "if_owner takes priority, else check user permissions" rule
	# used for normal list queries (see database/query.py::get_permission_conditions)
	openly_readable_doctypes, user_perm_restricted_doctypes = _split_doctypes_by_user_permissions(
		openly_readable_doctypes, user
	)

	conditions = [
		"(`tabFile`.`is_private` = 0)",
		f"(`tabFile`.`attached_to_doctype` IS NULL AND `tabFile`.`owner` = {frappe.db.escape(user)})",
	]

	if openly_readable_doctypes:
		readable_doctypes = ", ".join(repr(dt) for dt in openly_readable_doctypes)
		conditions.append(f"(`tabFile`.`attached_to_doctype` IN ({readable_doctypes}))")

	# these doctypes only grant "read" to their owner (if_owner), so a File attached to one
	# of them may only be listed if the requesting user owns the referenced document or it
	# was individually shared with them.
	for doctype in owner_restricted_doctypes:
		table = get_table_name(doctype, wrap_in_backticks=True)
		conditions.append(
			_scoped_attachment_condition(doctype, user, f"{table}.`owner` = {frappe.db.escape(user)}")
		)

	# these doctypes grant unconditional role-level read, but this user is scoped by one or
	# more User Permissions (e.g. restricted to a specific Company) - only list a file if the
	# referenced record falls within that scope, or it was individually shared with them
	for doctype, field_conditions in user_perm_restricted_doctypes.items():
		conditions.append(_scoped_attachment_condition(doctype, user, " AND ".join(field_conditions)))

	return "(" + " OR ".join(conditions) + ")"


def _scoped_attachment_condition(doctype: str, user: str, exists_condition: str) -> str:
	"""Build `(attached_to_doctype = X AND (EXISTS(...) OR individually shared))`."""
	table = get_table_name(doctype, wrap_in_backticks=True)
	shared_names = frappe.share.get_shared(doctype, user)
	shared_condition = ""
	if shared_names:
		shared_list = ", ".join(frappe.db.escape(name, percent=False) for name in shared_names)
		shared_condition = f" OR `tabFile`.`attached_to_name` IN ({shared_list})"

	return f"""(`tabFile`.`attached_to_doctype` = {frappe.db.escape(doctype)}
		AND (
			EXISTS (
				SELECT 1 FROM {table}
				WHERE {table}.`name` = `tabFile`.`attached_to_name`
				AND {exists_condition}
			){shared_condition}
		))"""


def _split_doctypes_by_owner_constraint(doctypes, user):
	"""Split doctypes into those the user can read unconditionally vs. only as owner ("if_owner").

	Single doctypes have no per-record table (their fields live in `tabSingles`), so they can't
	be scoped with a `SELECT ... FROM tab<Doctype>` check and are always treated as openly readable.
	"""
	openly_readable, owner_restricted = [], []
	for doctype in doctypes:
		if frappe.get_meta(doctype).issingle:
			openly_readable.append(doctype)
			continue
		role_permissions = get_role_permissions(doctype, user=user)
		if requires_owner_constraint(role_permissions):
			owner_restricted.append(doctype)
		else:
			openly_readable.append(doctype)
	return openly_readable, owner_restricted


def _split_doctypes_by_user_permissions(doctypes, user):
	"""Split doctypes into those unaffected by User Permissions vs. those scoped by them.

	Mirrors the simplified, non-recursive semantics list queries already use for their own
	doctype (db_query.py::add_user_permissions / database/query.py::get_user_permission_conditions)
	- not the full has_user_permission() used for single-document checks, which additionally
	does tree traversal and isn't expressible as a flat SQL condition.
	"""
	user_permissions = frappe.permissions.get_user_permissions(user)
	if not user_permissions:
		return doctypes, {}

	strict_user_permissions = frappe.get_system_settings("apply_strict_user_permissions")

	unrestricted, restricted = [], {}
	for doctype in doctypes:
		if frappe.get_meta(doctype).issingle:
			unrestricted.append(doctype)
			continue
		field_conditions = _get_user_permission_field_conditions(
			doctype, user_permissions, strict_user_permissions
		)
		if field_conditions:
			restricted[doctype] = field_conditions
		else:
			unrestricted.append(doctype)
	return unrestricted, restricted


def _get_user_permission_field_conditions(doctype, user_permissions, strict_user_permissions) -> list[str]:
	"""SQL conditions (to be AND'd) restricting `doctype` rows to those permitted by `user_permissions`."""
	link_fields = [{"options": doctype, "fieldname": "name"}, *frappe.get_meta(doctype).get_link_fields()]
	table = get_table_name(doctype, wrap_in_backticks=True)

	conditions = []
	for df in link_fields:
		if df.get("ignore_user_permissions"):
			continue

		permitted = user_permissions.get(df.get("options"))
		if not permitted:
			continue

		docs = [
			p.get("doc")
			for p in permitted
			if not p.get("applicable_for") or p.get("applicable_for") == doctype
		]
		if not docs:
			continue

		field = f"{table}.`{df.get('fieldname')}`"
		docs_list = ", ".join(frappe.db.escape(doc, percent=False) for doc in docs)
		if strict_user_permissions:
			conditions.append(f"{field} IN ({docs_list})")
		else:
			conditions.append(f"(ifnull({field}, '') = '' OR {field} IN ({docs_list}))")

	return conditions


# Note: kept at the end to not cause circular, partial imports & maintain backwards compatibility
from frappe.core.api.file import *
