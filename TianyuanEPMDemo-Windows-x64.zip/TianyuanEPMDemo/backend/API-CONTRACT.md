# 本机演示后端接口契约

监听 127.0.0.1。Python 3.12 标准库，无外部运行依赖。CLI `python backend/server.py --data-dir PATH --port 0 --no-browser --static-dir PATH`；静态目录默认 `../frontend/dist`。

启动 stdout 单行 JSON `{ready:true,url:"http://127.0.0.1:PORT/#token=SECRET",port,token,instanceId}`。启动 token 只在进程有效；不要放入日志或公开报告。GET `/api/health` 返回 `{ready:true,instanceId,product:"SelfDevelopedEPM-Demo"}`。POST `/api/session` JSON `{token}` 换 HttpOnly、SameSite=Strict cookie，返回 `{csrfToken,sessionRole}`。后续同源 JSON 请求携带 cookie。写请求须 `X-CSRF-Token` 和同源 Origin。POST `/api/shutdown` 可用会话/CSRF，或启动器 `X-EPM-Token` 头；后者可省略 Origin。

GET `/api/bootstrap?group=group&month=9&currency=CNY&entity=all`。context group 为 group/mfg，month 为 1..12，currency 为 CNY/USD，entity 为 all 或法人 id。写操作 POST `/api/action`：`{action,payload,revision,context:{group,month,currency,entity}}`。成功返回完整 bootstrap；失败 JSON `{error:{code,message},message}`。409 代表版本冲突，请重新加载。

bootstrap：
- revision 全库递增整数；csrfToken 当前会话CSRF；companyName 主公司中文名；sessionRole 集团财务负责人/法人会计/审计只读；capabilities {canWrite,canApprove,canSignoff,canConfigure}。
- entities 原型结构：id/code/name/short/owner/currency/revenue/cost/expense/finance/tax/net，以及 opening/closing/cashflow。
- monthly 数值数组；accounts [{code,name,type,field,normalSide}]；rates [{currency,rate,name}]；journals [{id,title,kind,status,lines,effects}]。
- budget {version,status,spread,layers:[{label,amount}],versions:[{name,scenario,annual,status,layers,spread}],adjustments:[{id,version,layer,delta,reason,status,sourceAnnual,sourceLayers}],entityRatios,entityRevenueRatios,drivers,businessPlans}。
- periods 映射 `group:month` -> {submissionChecked,checksRun,icConfirmed,commentary,signed,icReason,commentaryText,checksFingerprint,signedAt}；period 为当前期间对象；checks 当前group/month全范围的人民币关账校验数组（不受entity钻取筛选影响）。
- statement {actual:{revenue,cost,expense,finance,tax,net},profit:[{key,label,value}],balance:[[label,value,key]],cash:[[label,value,key]],financial_checks:[{code,label,passed,difference}],currency,unit,period,scope}；report 同 statement。
- activities [{id,time,text,role,action}]；settings {companyName,fiscalYear,language,unit}；trialBalances [{id,entity,month,rowCount,importedAt,sourceName}]；ownership [{entityId,percent,method,note}]。

## 唯一动作名与payload

金额可传数字或十进制字符串；金额最多2位小数，汇率最多6位。所有写操作有服务器角色授权和SQLite事务。

|action|payload|规则|
|---|---|---|
|role_switch|{role}|三种演示角色；会话级切换，返回当前权限|
|budget_layer_save|{layer:0..3,amount}|仅编制中/已退回，非负|
|budget_spread|{spread:"even"或"seasonal"}|保存全年分摊；编制中可改|
|budget_driver|{volume,price}|保存量价模型；volume非负整数，price金额；调整最后一层|
|budget_submit|{}|编制中→审核中|
|budget_approve|{}|负责人，审核中→已审批|
|budget_lock|{}|负责人，已审批→已锁定|
|budget_copy|{name,scenario}|完整快照复制为新草稿并切换|
|budget_switch|{name}|切换已有完整版本|
|budget_adjust_create|{layer,delta,reason}|非零调整；记录原版快照|
|budget_adjust_approve|{id}|负责人；生成独立新版本，保留原版|
|budget_adjust_reject|{id,reason?}|负责人；退回|
|budget_plan_save|{type,rows:[{id,name,quantity,price,amount,note}]}|type:production/purchase/inventory/labor/expense/capital/cash；演示预算明细保存，金额必须等于数量×单价并保留2位；纯金额使用数量1|
|checks_run|{}|当前group/month真实勾稽与状态校验|
|submission_confirm|{}|当前期已校验报送确认；修改数据使旧确认失效|
|ic_confirm|{reason}|内部交易核对说明必填|
|commentary_save|{text}|经营分析说明必填|
|signoff|{}|负责人；报送、当前有效校验、内部交易、经营说明全满足|
|period_reopen|{reason}|负责人；解除当前期签核，并使校验失效|
|entity_save|{id,code,name,short,owner,currency}|新增/改法人主数据；不接受客户端任意财务字段|
|account_save|{code,name,type,field,normalSide}|type:资产/负债/权益/收入/成本/费用/税费；field须内置报表字段；normalSide:借/贷|
|rate_save|{currency:"USD",rate,name?}|正数；当前demo只有USD折算|
|journal_create|{title,kind,reason,lines:[{accountCode,debit,credit}],cashflowCategory?:"operating"/"investing"/"financing"}|含现金变动须选择现金流类别；借贷相等，不允许同一行双向；draft保存后需journal_approve|
|journal_approve|{id}|负责人；已平衡草稿→已审批，影响财务报表|
|tb_import|{csv,sourceName?}|标准模板见下，原子验证整批；当前context.month须与CSV期间一致|
|settings_save|{companyName?,fiscalYear?}|负责人；语言固定中文；会计年度固定2026且不得重标源数据；主公司名可改|

CSV模板（UTF-8，可有BOM）：`法人编码,期间,科目编码,借方余额,贷方余额`；期间形如 `2026-09`。每个法人整套余额必须借贷平衡；金额非负最多2位；相同法人/科目不得重复；法人和科目必须已存在。导入替换该法人当期的整套累计试算余额，只更新当前期间，不影响其他期间。系统派生当期三表并保留源批次。返回错误包含行号。导入现金流为演示估算，并在statement.source_entities标记cashflowEstimated；不构成正式现金流分类。不要直接传任意entities/state。

`statement/entityActuals/monthlyActuals`均为当前展示币种、万元单位（USD为万美元）；预算和源法人金额固定人民币万元。`entityActuals`包含全集团所有法人当前期独立损益，前端按scope筛选。初始actualThrough=9，10—12月未导入前沿用9月累计数。

GET `/api/runtime` 需要登录cookie，返回`{dataDir,logDir,platform}`。POST `/api/open-data-dir` 需要会话/CSRF/同源Origin，JSON `{}`，仅打开服务端固定dataDir；返回`{opened,dataDir,message}`。Linux不启动桌面程序，返回opened=false和路径。
