#!/usr/bin/env python3
"""Package complete Word/PDF documents and editable source; refuse incomplete releases."""
from pathlib import Path
import hashlib,json,shutil,zipfile
from verify_documents import run,ROOT

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 verification=run()
 meta=json.loads((ROOT/'release.json').read_text(encoding='utf-8'))
 stage=ROOT/'package/天元EPM_全模块交付文档_FOUNDATION-20261028_D1.0'
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir(parents=True)
 for spec in meta['documents']:
  for ext in ['docx','pdf']:
   dest=stage if ext=='docx' else stage/'PDF';dest.mkdir(exist_ok=True)
   shutil.copy2(ROOT/'output'/(spec['stem']+'.'+ext),dest/(spec['stem']+'.'+ext))
 guide_root=ROOT.parent/'guide-assets'
 guide_checked=json.loads((guide_root/'evidence/专项指南交付校验.json').read_text(encoding='utf-8'))
 assert guide_checked['passed'] is True and guide_checked['softwareBaseline']==meta['softwareBaseline']
 for ext,key in [('docx','word'),('pdf','pdf')]:
  source=guide_root/'output'/guide_checked['documents'][key]['file'];assert sha(source)==guide_checked['documents'][key]['sha256']
  dest=stage if ext=='docx' else stage/'PDF';dest.mkdir(exist_ok=True);shutil.copy2(source,dest/source.name)
 shutil.copytree(guide_root/'templates',stage/'templates')
 if (guide_root/'异常演示数据').exists():shutil.copytree(guide_root/'异常演示数据',stage/'异常演示数据')
 for folder in ['content','screenshots','evidence']:
  shutil.copytree(guide_root/folder,stage/'可编辑原稿/guide-assets'/folder,ignore=shutil.ignore_patterns('*.html','__pycache__','*.pyc'))
 for name in ['release.json','render_guide.py','verify_guide.py']:
  if (guide_root/name).exists():shutil.copy2(guide_root/name,stage/'可编辑原稿/guide-assets'/name)
 for folder in ['content','assets']:
  shutil.copytree(ROOT/folder,stage/'可编辑原稿'/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for name in ['release.json','render_documents.py','verify_documents.py','package_documents.py','README-文档使用说明.md','CHANGELOG.md']:
  shutil.copy2(ROOT/name,stage/'可编辑原稿'/name if name.endswith('.py') or name=='release.json' else stage/name)
 for p in (ROOT/'evidence').glob('*'):
  if p.suffix in {'.md','.json','.txt'}: 
   (stage/'校验与案例').mkdir(exist_ok=True);shutil.copy2(p,stage/'校验与案例'/p.name)
 contracts=stage/'接口与字段契约';contracts.mkdir()
 for path in (ROOT.parent/'backend').glob('*CONTRACT.md'):shutil.copy2(path,contracts/path.name)
 for name in ['AGENTS.md','DELIVERY-STANDARD.md']:shutil.copy2(ROOT.parent/name,stage/name)
 release_record=ROOT.parent/'dist/交付版本与校验.json'
 assert release_record.exists(),'先完成软件包和外部交付校验，避免自引用SHA。'
 shutil.copy2(release_record,stage/release_record.name)
 files=sorted(p for p in stage.rglob('*') if p.is_file())
 forbidden={'.db','.sqlite','.sqlite3','.log','.private','.pyc','.pdb'}
 assert not any(p.suffix in forbidden or p.name in {'instance.json','.env','launcher.lock'} for p in files)
 (stage/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(stage).as_posix()+'\n' for p in files),encoding='utf-8')
 output=ROOT/'TianyuanEPM-Foundation-Docs-CN-D1.0.zip'
 with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(stage.rglob('*')):
   if p.is_file():z.write(p,arcname=stage.name+'/'+p.relative_to(stage).as_posix())
 with zipfile.ZipFile(output) as z:assert z.testzip() is None
 output.with_suffix('.zip.sha256').write_text(sha(output)+'  '+output.name+'\n',encoding='utf-8')
 print(json.dumps({'path':str(output),'bytes':output.stat().st_size,'sha256':sha(output)},ensure_ascii=False))
if __name__=='__main__':main()
