#!/usr/bin/env python3
"""Validate the complete four-document release; semantic review is recorded separately."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def run():
 meta=json.loads((ROOT/'release.json').read_text(encoding='utf-8'))
 assert meta['status']=='已终验待发布', '文档仍为编制状态，不能发布。'
 assert meta['softwareBaseline']=='FOUNDATION-20261028'
 assert isinstance(meta['sourceSha256'],dict) and meta['sourceSha256']
 for name,digest in meta['sourceSha256'].items():assert sha(ROOT.parent/name)==digest,'运行源码已变更：'+name
 review_path=ROOT/'evidence/文档独立核对报告.json'
 review=json.loads(review_path.read_text(encoding='utf-8'))
 assert review.get('passed') is True and review.get('softwareBaseline')==meta['softwareBaseline']
 for name,digest in review.get('sourceMarkdownSha256',{}).items():assert sha(ROOT/name)==digest,'审查后文档已变更：'+name
 assert len(review.get('sourceMarkdownSha256',{}))>=5,'四主稿及字段附录必须绑定审查。'
 ids={d['id'] for d in meta['documents']};assert ids=={'PRD','SYS','PROD','USER'}
 records=[]
 for spec in meta['documents']:
  stem=spec['stem'];word=ROOT/'output'/(stem+'.docx');pdf=ROOT/'output'/(stem+'.pdf')
  with zipfile.ZipFile(word) as z:
   assert z.testzip() is None
   xml=ET.fromstring(z.read('word/document.xml'))
   text=''.join(xml.itertext())
   clean=''.join(t.text or '' for t in xml.iter(W+'t'))
   assert meta['softwareBaseline'] in clean and meta['documentationVersion'] in clean
   assert meta['companyName'] in clean
   missing=[m['name'] for m in meta['modules'] if m['name'] not in clean]
   assert not missing,(spec['id'],'缺少模块',missing)
   chars=len(re.findall('[\u4e00-\u9fff]',clean));assert chars>1000
   table_count=len(list(xml.iter(W+'tbl')))
   assert table_count>=2
  assert pdf.read_bytes().startswith(b'%PDF-')
  info=subprocess.check_output(['pdfinfo',str(pdf)],text=True)
  pages=int(re.search(r'^Pages:\s+(\d+)',info,re.M).group(1));assert pages>=3
  bbox=ROOT/'evidence'/(stem+'.bbox.html')
  subprocess.run(['pdftotext','-bbox-layout',str(pdf),str(bbox)],check=True)
  tree=ET.parse(bbox);issues=[]
  for i,page in enumerate(tree.findall('.//{http://www.w3.org/1999/xhtml}page'),1):
   width,height=float(page.attrib['width']),float(page.attrib['height'])
   for w in page.iter('{http://www.w3.org/1999/xhtml}word'):
    b=[float(w.attrib[k]) for k in ('xMin','yMin','xMax','yMax')]
    if b[0]<-.5 or b[1]<-.5 or b[2]>width+.5 or b[3]>height+.5:issues.append({'page':i,'word':w.text,'box':b})
  assert not issues,(spec['id'],'PDF文字超出页面',issues[:10])
  records.append({'id':spec['id'],'stem':stem,'source':spec['source'],'docx':{'file':word.name,'sha256':sha(word),'bytes':word.stat().st_size,'tables':table_count,'chineseCharacters':chars},'pdf':{'file':pdf.name,'sha256':sha(pdf),'bytes':pdf.stat().st_size,'pages':pages,'outOfPageWords':0},'moduleMentionsVerified':len(meta['modules'])})
 result={'passed':True,'softwareBaseline':meta['softwareBaseline'],'documentationVersion':meta['documentationVersion'],'releaseDate':meta['releaseDate'],'sourceSha256':meta['sourceSha256'],'documents':records,'independentReview':{'passed':True,'file':'文档独立核对报告.json','sha256':sha(review_path)},'note':'模块关键词校验只作机器覆盖核对，内容正确性由独立逐章审查记录承担；PDF文字边界检查另配代表页视检。'}
 out=ROOT/'evidence/文档交付校验.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'passed':True,'documents':len(records),'pdfPages':sum(r['pdf']['pages'] for r in records),'modules':len(meta['modules'])},ensure_ascii=False))
 return result
if __name__=='__main__':run()
