from pathlib import Path
import json,hashlib,zipfile,re,subprocess,sys,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent;PRODUCT=ROOT.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 sys.path.insert(0,str(PRODUCT/'acceptance'));from support import manifest
 current=manifest();review=json.loads((ROOT/'evidence/专项指南独立核对.json').read_text());assert review['passed'] and review['softwareBaseline']=='FOUNDATION-20261028' and review['sourceSha256']==current
 md=ROOT/'content/从零建档到凭证合并图文指南.md';assert review['guideSha256']==sha(md)
 for name,h in review['referencedImageSha256'].items():assert sha(PRODUCT/name)==h,name
 for name,h in review['inputSha256'].items():assert sha(PRODUCT/name)==h,name
 qa=json.loads((ROOT/'evidence/从零操作截图与验证.json').read_text());assert qa['passed'] and qa['candidate'] is False and qa['sourceUnchangedDuringRun'] and qa['inputFilesUnchangedDuringRun'] and not qa['javascriptErrors'] and qa['sourceSha256']==current
 for item in qa['files']:assert sha(ROOT/'screenshots'/item['file'])==item['sha256'],item['file']
 build=json.loads((ROOT/'evidence/word-build.json').read_text())[0];assert build['sourceSha256']==sha(md) and build['figures']==review['imageReferenceCount']==23
 word=ROOT/'output/从零建档到凭证合并图文指南.docx';pdf=word.with_suffix('.pdf');assert sha(word)==build['sha256']
 with zipfile.ZipFile(word) as z:
  assert z.testzip() is None;xml=ET.fromstring(z.read('word/document.xml'));ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';text=''.join(t.text or '' for t in xml.iter(ns+'t'))
  for value in ['FOUNDATION-20261028','杭州天元宠物用品有限公司','840','270','470','科目余额','原始凭证','集团本部']:assert value in text,value
  actual={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/')};expected=set(review['referencedImageSha256'].values());assert actual==expected
 assert pdf.read_bytes().startswith(b'%PDF-');info=subprocess.check_output(['pdfinfo',str(pdf)],text=True);pages=int(re.search(r'^Pages:\s+(\d+)',info,re.M).group(1));bbox=ROOT/'evidence/专项指南文字边界.html';subprocess.run(['pdftotext','-bbox-layout',str(pdf),str(bbox)],check=True);tree=ET.parse(bbox)
 for n,p in enumerate(tree.findall('.//{http://www.w3.org/1999/xhtml}page'),1):
  w,h=float(p.attrib['width']),float(p.attrib['height'])
  for item in p.iter('{http://www.w3.org/1999/xhtml}word'):
   b=[float(item.attrib[k]) for k in ['xMin','yMin','xMax','yMax']];assert b[0]>=-.5 and b[1]>=-.5 and b[2]<=w+.5 and b[3]<=h+.5,(n,item.text,b)
 result={'passed':True,'softwareBaseline':'FOUNDATION-20261028','sourceSha256':current,'guideSha256':sha(md),'figures':23,'documents':{'word':{'file':word.name,'sha256':sha(word),'bytes':word.stat().st_size},'pdf':{'file':pdf.name,'sha256':sha(pdf),'bytes':pdf.stat().st_size,'pages':pages,'outOfPageWords':0}},'independentReviewSha256':sha(ROOT/'evidence/专项指南独立核对.json'),'scope':'专项完整从零指南，23图实际文件及Word媒体字节核对；PDF文字边界另配代表页视检。'};(ROOT/'evidence/专项指南交付校验.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':True,'pages':pages,'figures':23},ensure_ascii=False));return result
if __name__=='__main__':main()
