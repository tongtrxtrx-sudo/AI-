"""ERP凭证纯处理：原币元精确账务、完整源三表及可追溯内部交易匹配。"""
from __future__ import annotations
from collections import defaultdict
from copy import deepcopy
import csv, hashlib, io, json, re, zipfile
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from xml.etree import ElementTree as ET
try:
 from .consolidation import BS,PL,CF,ASSETS,LIABILITIES,EQUITY,financial_checks,lowest_common_unit,collect_leaves,num as _report_num
except ImportError:
 from consolidation import BS,PL,CF,ASSETS,LIABILITIES,EQUITY,financial_checks,lowest_common_unit,collect_leaves,num as _report_num
ZERO=Decimal(0);CENT=Decimal('.01');WAN=Decimal(10000);SIX=Decimal('.000001')
MAPPING_HEADERS=['法人编码','科目编码','科目名称','报表字段','余额方向']
OPENING_HEADERS=['法人编码','会计年度','科目编码','币种','期初借方余额','期初贷方余额','内部往来对方','交易关联号','期初人民币留存收益']
VOUCHER_HEADERS=['法人编码','凭证日期','凭证类别','凭证号','分录序号','科目编码','借方金额','贷方金额','币种','摘要','内部往来对方','交易关联号','内部交易类型','现金流类别','凭证类型']
FIELD_NAMES={'cash':'货币资金','receivable':'应收账款','inventory':'存货','prepaid':'预付款及其他流动资产','investment':'长期股权投资','fixed':'固定资产净额','intangible':'无形及其他资产','deferred_asset':'递延所得税资产','payable':'应付账款','shortloan':'短期借款','taxpayable':'应交税费','otherliability':'其他流动负债','longloan':'长期借款','deferred_liability':'递延所得税负债','capital':'实收资本','retained':'未分配利润','nci':'少数股东权益','cta':'外币报表折算差额','revenue':'营业收入','cost':'营业成本','expense':'期间费用','finance':'财务费用','tax':'所得税费用'}
DEBIT_FIELDS=set(ASSETS)|set(PL[1:])
CF_NAMES={'经营':'operating','经营活动':'operating','经营活动现金流':'operating','operating':'operating','投资':'investing','投资活动':'investing','investing':'investing','筹资':'financing','筹资活动':'financing','financing':'financing','':'','不涉及':'','无':''}
IC_NAMES={'内部销售':'sales','销售':'sales','sales':'sales','内部采购':'cost','采购':'cost','内部成本':'cost','cost':'cost','应收':'receivable','内部应收':'receivable','receivable':'receivable','应付':'payable','内部应付':'payable','payable':'payable','':''}
ALIASES={
'entityId':['法人编码','法人','主体编码','公司编码','entityId'], 'accountCode':['科目编码','会计科目编码','科目代码','accountCode','code'],
'name':['科目名称','会计科目名称','name'],'field':['报表字段','集团报表字段','映射字段','field'],'normalSide':['余额方向','借贷方向','normalSide'],
'year':['会计年度','年度','year'],'currency':['币种','本位币','记账本位币','currency'],
'openingDebit':['期初借方余额','期初借方','openingDebit'],'openingCredit':['期初贷方余额','期初贷方','openingCredit'],
'counterpartyId':['内部往来对方','内部交易对方','对方法人','客商编码','counterpartyId'],'reference':['交易关联号','内部交易关联号','业务关联号','reference'],
'openingRetainedCny':['期初人民币留存收益','openingRetainedCny'],'date':['凭证日期','记账日期','制单日期','date'],
'category':['凭证类别','凭证类别编码','凭证字','category'],'voucherId':['凭证号','凭证编号','voucherId'],'lineNo':['分录序号','行号','分录号','lineNo'],
'debit':['借方金额','本币借方金额','借方','debit'],'credit':['贷方金额','本币贷方金额','贷方','credit'],'summary':['摘要','summary'],
'icType':['内部交易类型','交易类型','icType'],'cashflow':['现金流类别','现金流分类','cashflow'],'voucherKind':['凭证类型','业务凭证类型','voucherKind']}

def _text(v,label='',limit=300):
 if v is None:return ''
 s=str(v).strip()
 if len(s)>limit:raise ValueError(f'{label}超过{limit}字符。')
 return s

def _head(s):return re.sub(r'\s+','',str(s or '').lstrip('\ufeff').strip().lstrip('*').strip())
def _hash(obj):return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def _money(v,unit='元',label='金额'):
 if unit not in ('元','万元'):raise ValueError('金额单位只能为元或万元，不能猜测ERP导出单位。')
 if isinstance(v,bool):raise ValueError(f'{label}必须为金额。')
 s=str(v if v not in (None,'') else '0').strip().replace(',','')
 if s.startswith('(') and s.endswith(')'):s='-'+s[1:-1]
 try:d=Decimal(s)
 except InvalidOperation:raise ValueError(f'{label}不是有效金额。') from None
 if not d.is_finite() or abs(d)>Decimal('10000000000000000'):raise ValueError(f'{label}超出金额范围。')
 yuan=d*(WAN if unit=='万元' else 1)
 if yuan!=yuan.quantize(CENT):raise ValueError(f'{label}换算为元后最多两位小数。')
 return format(yuan.quantize(CENT),'f')
def _d(v):return Decimal(str(v or 0))
def _report(v):return _report_num((_d(v)/WAN).quantize(SIX,rounding=ROUND_HALF_UP))
def _balanced_pair(debit,credit,label,allow_zero=True):
 if _d(debit)!=0 and _d(credit)!=0:raise ValueError(label+'同一分录不能同时填借方和贷方金额。')
 if not allow_zero and _d(debit)==0 and _d(credit)==0:raise ValueError(label+'借贷金额不能同时为零。')

def _rows(text):
 if not isinstance(text,str) or len(text)>20_000_000:raise ValueError('导入CSV须为不超过20MB的文本。')
 reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
 if not reader.fieldnames:raise ValueError('CSV缺少表头。')
 heads=[_head(h) for h in reader.fieldnames]
 if len(set(heads))!=len(heads):raise ValueError('CSV存在重复表头，去除星号及空格后须唯一。')
 out=[]
 for n,raw in enumerate(reader,2):
  if n>100002:raise ValueError('本机Demo每批最多100000行。')
  if None in raw or any(v is None for v in raw.values()):raise ValueError(f'CSV第{n}行列数与表头不一致。')
  if all(not str(v).strip() for v in raw.values()):continue
  out.append((n,{_head(k):str(v).strip() for k,v in raw.items()}))
 if not out:raise ValueError('CSV没有数据行。')
 return heads,out

def _get(row,key,column_map=None,required=False):
 names=[column_map[key]] if column_map and key in column_map else ALIASES.get(key,[key])
 for name in names:
  if _head(name) in row:
   v=row[_head(name)]
   if required and not v:raise ValueError(f'{names[0]}不能为空。')
   return v
 if required:raise ValueError(f'缺少必填列：{names[0]}。')
 return ''

def _entity(data,value):
 value=_text(value,'法人',100)
 found=[e for e in data.get('entities',[]) if value in (e.get('id'),e.get('code'),e.get('name'))]
 if len(found)!=1:raise ValueError(f'法人编码未唯一匹配：{value or "（空）"}。请先维护法人档案。')
 return found[0]
def _counterparty(data,value):
 value=_text(value,'内部往来对方',100)
 if value in ('外部','EXTERNAL','external'):return {'counterpartyId':'','counterpartyCode':value,'counterpartyStatus':'external'}
 if not value:return {'counterpartyId':'','counterpartyCode':'','counterpartyStatus':'unspecified'}
 e=_entity(data,value);return {'counterpartyId':e['id'],'counterpartyCode':value,'counterpartyStatus':'internal'}
def _date(v):
 s=_text(v,'凭证日期',40).split(' ')[0].split('T')[0].replace('/','-').replace('.','-')
 try:d=date.fromisoformat(s)
 except ValueError:
  try:d=datetime.strptime(s,'%Y%m%d').date()
  except ValueError:raise ValueError('凭证日期须为2026年的YYYY-MM-DD。') from None
 if d.year!=2026:raise ValueError('当前演示账套仅接收2026年度凭证。')
 return d.isoformat()
def voucher_key(row):return '|'.join(str(row.get(k,'')) for k in ('entityId','bookCode','category'))+'|'+row['date'][:7]+'|'+str(row.get('rawVoucherNo',row['voucherId']))
def line_key(row):return voucher_key(row)+'|'+str(row['lineNo'])
def opening_key(row):return '|'.join(str(row.get(k,'')) for k in ('entityId','year','accountCode','counterpartyId','counterpartyCode','reference'))

def parse_mappings_csv(data,text,column_map=None):
 _,rows=_rows(text);out=[];seen=set();bylabel={v:k for k,v in FIELD_NAMES.items()}
 for n,row in rows:
  try:
   e=_entity(data,_get(row,'entityId',column_map,True));code=_text(_get(row,'accountCode',column_map,True),'科目编码',60)
   f=_get(row,'field',column_map,True);f=bylabel.get(f,f)
   side=_get(row,'normalSide',column_map,True);side={'debit':'借','credit':'贷','D':'借','C':'贷'}.get(side,side)
   if f not in BS+PL or side not in ('借','贷'):raise ValueError('报表字段须为模板内BS/PL技术键，余额方向为借/贷。')
   key=(e['id'],code)
   if key in seen:raise ValueError('同一法人科目重复映射。')
   seen.add(key);out.append({'entityId':e['id'],'code':code,'name':_text(_get(row,'name',column_map) or code,'科目名称',120),'field':f,'normalSide':side,'version':1,'sourceRow':n})
  except ValueError as ex:raise ValueError(f'科目CSV第{n}行：{ex}') from None
 return out

def parse_openings_csv(data,text,amount_unit='元',column_map=None):
 _,rows=_rows(text);out=[];seen=set();totals=defaultdict(lambda:[ZERO,ZERO])
 for n,row in rows:
  try:
   e=_entity(data,_get(row,'entityId',column_map,True));year=_get(row,'year',column_map,True)
   if year!='2026':raise ValueError('期初余额年度只能为2026。')
   currency=_get(row,'currency',column_map,True)
   if currency!=e['currency']:raise ValueError('期初币种须等于法人的记账本位币。')
   d=_money(_get(row,'openingDebit',column_map),amount_unit,'期初借方');c=_money(_get(row,'openingCredit',column_map),amount_unit,'期初贷方');_balanced_pair(d,c,'期初余额')
   r={'entityId':e['id'],'year':2026,'accountCode':_text(_get(row,'accountCode',column_map,True),'科目编码',60),'currency':currency,'debit':d,'credit':c,'reference':_text(_get(row,'reference',column_map),'交易关联号',120),'sourceRow':n,'rawFields':deepcopy(row),**_counterparty(data,_get(row,'counterpartyId',column_map))}
   retain=_get(row,'openingRetainedCny',column_map)
   if retain!='':r['openingRetainedCny']=_money(retain,amount_unit,'期初人民币留存收益')
   key=opening_key(r)
   if key in seen:raise ValueError('同法人/科目/对方/关联号的期初余额重复。')
   seen.add(key);r['id']='OPEN-'+_hash(key)[:20];out.append(r);totals[e['id']][0]+=_d(d);totals[e['id']][1]+=_d(c)
  except ValueError as ex:raise ValueError(f'期初CSV第{n}行：{ex}') from None
 for eid,(d,c) in totals.items():
  if d!=c:raise ValueError(f'期初CSV法人{eid}借贷不平衡，差额{d-c}元。')
 return out

def _finish_vouchers(out):
 groups=defaultdict(list);seen=set()
 for r in out:
  key=line_key(r)
  if key in seen:raise ValueError(f'凭证分录重复：{key}。')
  seen.add(key);r['id']='VLINE-'+_hash(key)[:20];r['voucherKey']=voucher_key(r);groups[r['voucherKey']].append(r)
 for key,rows in groups.items():
  if sum((_d(r['debit'])-_d(r['credit']) for r in rows),ZERO)!=ZERO:raise ValueError(f'凭证{key}借贷不平衡，必须整张凭证导入。')
  if len({(r['date'],r['currency']) for r in rows})!=1:raise ValueError(f'凭证{key}各分录的日期或本位币不一致。')
  closing=any(r['voucherKind']=='closing' for r in rows)
  for r in rows:r['voucherKind']='closing' if closing else 'business'
 return out

def parse_vouchers_csv(data,text,amount_unit='元',column_map=None):
 _,rows=_rows(text);out=[];counters=defaultdict(int)
 for n,row in rows:
  try:
   e=_entity(data,_get(row,'entityId',column_map,True));dt=_date(_get(row,'date',column_map,True));cat=_text(_get(row,'category',column_map) or '记','凭证类别',40);no=_text(_get(row,'voucherId',column_map,True),'凭证号',80)
   currency=_get(row,'currency',column_map,True)
   if currency!=e['currency']:raise ValueError('通用凭证币种须为法人记账本位币；NC交易币请使用NC适配器。')
   countkey=(e['id'],dt[:7],cat,no);counters[countkey]+=1;line=_get(row,'lineNo',column_map) or str(counters[countkey])
   if not re.fullmatch(r'[1-9][0-9]{0,5}',line):raise ValueError('分录序号须为1至999999的整数。')
   d=_money(_get(row,'debit',column_map),amount_unit,'借方金额');c=_money(_get(row,'credit',column_map),amount_unit,'贷方金额');_balanced_pair(d,c,'凭证',False)
   ic=_get(row,'icType',column_map);cf=_get(row,'cashflow',column_map);kind=_get(row,'voucherKind',column_map);summary=_text(_get(row,'summary',column_map),'摘要',500)
   if ic not in IC_NAMES or cf not in CF_NAMES:raise ValueError('内部交易类型或现金流类别不在模板枚举内。')
   if kind not in ('','业务','business','损益结转','closing'):raise ValueError('凭证类型仅支持业务或损益结转。')
   kind='closing' if kind in ('损益结转','closing') or re.search('结转(本年利润|本期损益|损益)',summary) else 'business'
   r={'entityId':e['id'],'date':dt,'bookCode':e['id'],'category':cat,'voucherId':cat+'-'+no,'rawVoucherNo':no,'lineNo':int(line),'accountCode':_text(_get(row,'accountCode',column_map,True),'科目编码',60),'currency':currency,'transactionCurrency':currency,'debit':d,'credit':c,'summary':summary,'reference':_text(_get(row,'reference',column_map),'交易关联号',120),'icType':IC_NAMES[ic],'cashflow':CF_NAMES[cf],'voucherKind':kind,'sourceRow':n,'rawFields':deepcopy(row),**_counterparty(data,_get(row,'counterpartyId',column_map))};out.append(r)
  except ValueError as ex:raise ValueError(f'凭证CSV第{n}行：{ex}') from None
 return _finish_vouchers(out)

def parse_nc_vouchers(data,erp,text,amount_unit='元',column_map=None):
 heads,rows=_rows(text);required=['核算账簿','凭证类别编码','凭证号','制单日期','摘要','科目编码','币种','本币借方金额','本币贷方金额']
 if any(h not in heads for h in required):raise ValueError('NC6.5文件缺少列：'+','.join(h for h in required if h not in heads))
 books={};cp={};opts=erp.get('importOptions',{})
 for b in erp.get('bookMappings',[]):
  key=_text(b.get('bookCode'),'核算账簿',120)
  if not key or key in books:raise ValueError('核算账簿映射须非空且唯一。')
  e=_entity(data,b.get('entityId'));curr=b.get('functionalCurrency',e['currency'])
  if curr!=e['currency']:raise ValueError('账簿本位币须等于法人档案本位币。')
  books[key]=e
 for c in erp.get('counterpartyMappings',[]):
  key=_text(c.get('code'),'客商编码',200)
  column=c.get('column','')
  if column and column not in [f'辅助核算{i}' for i in range(1,10)]:raise ValueError('客商映射的辅助核算列无效。')
  cpkey=(column,key)
  if not key or cpkey in cp:raise ValueError('辅助客商映射须按列及编码非空且唯一。')
  cp[cpkey]=c.get('entityId')
 auxes=opts.get('auxiliaryColumns') or [opts.get('auxiliaryColumn','辅助核算1')];ref=opts.get('referenceColumn','')
 if not isinstance(auxes,list) or not auxes or len(set(auxes))!=len(auxes) or any(a not in [f'辅助核算{i}' for i in range(1,10)] for a in auxes) or ref not in ('','结算号','核销号'):raise ValueError('NC辅助核算或交易关联列配置无效。')
 if any(a not in heads for a in auxes):raise ValueError('NC文件缺少选中的辅助核算列。')
 if ref and ref not in heads:raise ValueError('NC文件缺少配置的交易关联号列。')
 out=[];counters=defaultdict(int)
 for n,row in rows:
  try:
   book=row['核算账簿'];e=books.get(book)
   if e is None:raise ValueError(f'核算账簿{book}尚未映射到法人。')
   dt=_date(row['制单日期']);cat=_text(row['凭证类别编码'],'凭证类别',40);no=_text(row['凭证号'],'凭证号',80)
   if not cat or not no:raise ValueError('凭证类别与凭证号不能为空。')
   key=(book,cat,dt[:7],no);counters[key]+=1
   d=_money(row['本币借方金额'],amount_unit,'NC本币借方');c=_money(row['本币贷方金额'],amount_unit,'NC本币贷方');_balanced_pair(d,c,'凭证',False)
   auxiliary=[{'column':a,'code':row.get(a,'')} for a in auxes if row.get(a,'')]
   resolved=[cp.get((a['column'],a['code']),cp.get(('',a['code']))) for a in auxiliary]
   identities=set(v for v in resolved if v)
   rawcp=';'.join(a['column']+':'+a['code'] for a in auxiliary);status='unspecified' if not auxiliary else 'unresolved';cpid=''
   if len(identities)>1:status='conflict'
   elif any(v is None for v in resolved):status='unresolved'
   elif identities=={'EXTERNAL'}:status='external'
   elif identities:
    cpid=_entity(data,next(iter(identities)))['id'];status='internal'
   summary=_text(row['摘要'],'摘要',500)
   kind='closing' if re.search('结转(本年利润|本期损益|损益)',summary) else 'business'
   r={'entityId':e['id'],'date':dt,'bookCode':book,'category':cat,'voucherId':cat+'-'+no,'rawVoucherNo':no,'lineNo':counters[key],'accountCode':_text(row['科目编码'],'科目编码',60),'currency':e['currency'],'transactionCurrency':row.get('币种',''),'debit':d,'credit':c,'originalDebit':_money(row.get('原币借方金额','0'),amount_unit,'NC原币借方'),'originalCredit':_money(row.get('原币贷方金额','0'),amount_unit,'NC原币贷方'),'summary':summary,'counterpartyId':cpid,'counterpartyCode':rawcp,'counterpartyStatus':status,'unmappedCounterparty':status in ('unresolved','conflict'),'counterpartyAuxiliaries':auxiliary,'counterpartyConflict':status=='conflict','reference':_text(row.get(ref,'') if ref else '','关联号',120),'icType':'','cashflow':'','voucherKind':kind,'sourceRow':n,'rawFields':deepcopy(row),'adapter':'nc65'}
   out.append(r)
  except ValueError as ex:raise ValueError(f'NC第{n}行：{ex}') from None
 return _derive_nc_voucher_context(erp,_finish_vouchers(out))


def _derive_nc_voucher_context(erp,rows):
 """Only propagate unambiguous normalized voucher context; raw export cells stay intact."""
 maps=_mapping(erp);groups=defaultdict(list)
 for row in rows:groups[voucher_key(row)].append(row)
 relevant={'revenue','cost','receivable','payable'}
 for voucher_rows in groups.values():
  identities={('internal',r['counterpartyId']) for r in voucher_rows if r.get('counterpartyStatus')=='internal' and r.get('counterpartyId')}
  identities|={('external','EXTERNAL') for r in voucher_rows if r.get('counterpartyStatus')=='external'}
  unresolved=any(r.get('counterpartyStatus') in ('unresolved','conflict') or r.get('unmappedCounterparty') for r in voucher_rows)
  references={r['reference'] for r in voucher_rows if r.get('reference')}
  unique_cp=next(iter(identities)) if len(identities)==1 and not unresolved else None
  unique_ref=next(iter(references)) if len(references)==1 else None
  cp_sources=[r for r in voucher_rows if r.get('counterpartyStatus') in ('internal','external')]
  ref_sources=[r for r in voucher_rows if r.get('reference')]
  def origin(rs):return [{'id':r.get('id'),'lineNo':r['lineNo'],'sourceRow':r['sourceRow'],'accountCode':r['accountCode']} for r in rs]
  # Multiple explicit references mean multiple business transactions in this voucher.
  # No row is assigned another transaction's normalized context in that case.
  if len(references)>1:continue
  for row in voucher_rows:
   mapping=maps.get((row['entityId'],row['accountCode']))
   if not mapping or mapping['field'] not in relevant:continue
   if unique_cp and row.get('counterpartyStatus')=='unspecified' and not row.get('counterpartyCode') and not row.get('counterpartyId'):
    row['counterpartyId']='' if unique_cp[0]=='external' else unique_cp[1]
    row['counterpartyStatus']=unique_cp[0];row['unmappedCounterparty']=False
    row['counterpartyBasis']='同凭证唯一已解析客商推导'
    row['counterpartyDerivedFrom']=origin(cp_sources)
    row.setdefault('derivedFromVoucherRows',[]).extend(origin(cp_sources))
   if unique_cp and unique_ref and not row.get('reference') and row.get('counterpartyStatus') in ('internal','external'):
    row['reference']=unique_ref;row['referenceBasis']='同凭证唯一交易关联号推导'
    row['referenceDerivedFrom']=origin(ref_sources)
    row.setdefault('derivedFromVoucherRows',[]).extend(origin(ref_sources))
 return rows

def read_file_csv(file_bytes,file_name,sheet_name=None):
 if not isinstance(file_bytes,(bytes,bytearray)) or len(file_bytes)>25_000_000:raise ValueError('文件须不超过25MB。')
 name=str(file_name).lower()
 if name.endswith('.csv'):
  for encoding in ('utf-8-sig','gb18030'):
   try:return bytes(file_bytes).decode(encoding)
   except UnicodeDecodeError:pass
  raise ValueError('CSV编码无法读取，请另存UTF-8 CSV。')
 if name.endswith('.xls'):raise ValueError('旧版二进制xls暂不支持，请在Excel/WPS另存为xlsx或UTF-8 CSV。')
 if not name.endswith('.xlsx'):raise ValueError('仅支持CSV或原生xlsx文件。')
 try:
  with zipfile.ZipFile(io.BytesIO(file_bytes)) as z:
   if len(z.namelist())>20000 or sum(i.file_size for i in z.infolist())>100_000_000:raise ValueError('xlsx解压后超出本机导入限制。')
   ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
   wb=ET.fromstring(z.read('xl/workbook.xml'));rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'));relmap={r.attrib['Id']:r.attrib['Target'] for r in rels}
   sheets=wb.findall('m:sheets/m:sheet',ns)
   if not sheets:raise ValueError('xlsx没有工作表。')
   sheet=next((s for s in sheets if s.attrib.get('name')==sheet_name),None) if sheet_name else sheets[0]
   if sheet is None:raise ValueError('xlsx找不到指定工作表。')
   rid=sheet.attrib.get('{'+ns['r']+'}id');target=relmap[rid]
   path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
   if '..' in path.split('/'):raise ValueError('xlsx工作表引用路径无效。')
   shared=[]
   if 'xl/sharedStrings.xml' in z.namelist():
    st=ET.fromstring(z.read('xl/sharedStrings.xml'))
    shared=[''.join(n.itertext()) for n in st.findall('m:si',ns)]
   styles=[];custom={}
   if 'xl/styles.xml' in z.namelist():
    sx=ET.fromstring(z.read('xl/styles.xml'));custom={int(n.attrib['numFmtId']):n.attrib.get('formatCode','') for n in sx.findall('m:numFmts/m:numFmt',ns)}
    styles=[int(n.attrib.get('numFmtId','0')) for n in sx.findall('m:cellXfs/m:xf',ns)]
   doc=ET.fromstring(z.read(path));rows=[];maxcol=0
   for xr in doc.findall('m:sheetData/m:row',ns):
    cells={}
    for c in xr.findall('m:c',ns):
     address=c.attrib.get('r','');letters=re.match('[A-Z]+',address)
     if not letters:raise ValueError('xlsx缺少稳定单元格地址。')
     index=0
     for ch in letters.group():index=index*26+ord(ch)-64
     if index>300:raise ValueError('xlsx最多支持300列。')
     typ=c.attrib.get('t');v=c.find('m:v',ns);value=v.text if v is not None and v.text is not None else ''
     formula=c.find('m:f',ns)
     if formula is not None:raise ValueError(f'xlsx含公式单元格{address}，请粘贴为值后再导入。')
     if typ=='s':value=shared[int(value)] if value else ''
     elif typ=='inlineStr':value=''.join(c.find('m:is',ns).itertext()) if c.find('m:is',ns) is not None else ''
     elif typ=='b':value='TRUE' if value=='1' else 'FALSE'
     elif value and re.fullmatch(r'-?\d+(?:\.\d+)?',value):
      fmt=styles[int(c.attrib.get('s','0'))] if styles and int(c.attrib.get('s','0'))<len(styles) else 0
      fcode=custom.get(fmt,'')
      if fmt in set(range(14,23))|set(range(45,48)) or (fcode and re.search('[yd]',re.sub(r'"[^"]*"','',fcode),re.I)):
       epoch=date(1904,1,1) if wb.find('m:workbookPr',ns) is not None and wb.find('m:workbookPr',ns).attrib.get('date1904') in ('1','true') else date(1899,12,30)
       value=(epoch+timedelta(days=int(Decimal(value)))).isoformat()
      elif fcode and re.fullmatch('0+',fcode) and Decimal(value)==Decimal(value).to_integral_value():value=str(int(Decimal(value))).zfill(len(fcode))
     cells[index-1]=value;maxcol=max(maxcol,index)
    if cells:rows.append(cells)
    if len(rows)>100001:raise ValueError('xlsx最多100000条数据。')
   if not rows:raise ValueError('xlsx没有数据。')
   output=io.StringIO();writer=csv.writer(output)
   for row in rows:writer.writerow([row.get(i,'') for i in range(maxcol)])
   return output.getvalue()
 except (zipfile.BadZipFile,KeyError,ET.ParseError,IndexError,ValueError) as ex:
  if isinstance(ex,ValueError):raise
  raise ValueError('xlsx文件结构无效，请重新导出为标准xlsx。') from None

def _active_rows(erp,name):
 batches={b.get('id'):b for b in erp.get('batches',[]) if isinstance(b,dict)}
 return [r for r in erp.get(name,[]) if r.get('active',True) and batches.get(r.get('batchId'),{}).get('active',True)]
def _mapping(erp):
 out={}
 for m in _active_rows(erp,'mappings'):
  key=(m['entityId'],m.get('code',m.get('accountCode')))
  if key in out:raise ValueError('同一法人科目存在重复映射。')
  if m.get('field') not in BS+PL:raise ValueError('科目映射包含未知报表字段。')
  out[key]=m
 return out

def _ref(row,opening=False):
 keys=['id','batchId','entityId','date','bookCode','category','voucherId','rawVoucherNo','lineNo','accountCode','currency','transactionCurrency','debit','credit','summary','counterpartyId','counterpartyCode','counterpartyStatus','reference','sourceRow','voucherKey','adapter','counterpartyBasis','referenceBasis','counterpartyDerivedFrom','referenceDerivedFrom','derivedFromVoucherRows']
 out={k:deepcopy(row[k]) for k in keys if k in row};out['sourceType']='opening' if opening else 'voucher'
 if opening:out['voucherId']='2026期初余额';out['year']=row.get('year',2026)
 return out

def validate_erp(data,erp):
 issues=[]
 try:maps=_mapping(erp)
 except ValueError as ex:return [{'code':'mapping_duplicate','message':str(ex),'refs':[]}]
 seen=set()
 for kind in ('openings','vouchers'):
  for r in _active_rows(erp,kind):
   if (r.get('entityId'),r.get('accountCode')) not in maps:issues.append({'code':'unmapped_account','message':f'{r.get("entityId")}科目{r.get("accountCode")}尚未映射。','refs':[_ref(r,kind=='openings')]})
   key=(kind,opening_key(r) if kind=='openings' else line_key(r))
   if key in seen:issues.append({'code':'duplicate','message':'账务存在重复分录/期初明细。','refs':[_ref(r,kind=='openings')]})
   seen.add(key)
 return issues

def _closing_filter(rows,maps):
 groups=defaultdict(list)
 for r in rows:groups[voucher_key(r)].append(r)
 valid=[];excluded=[]
 for key,rs in groups.items():
  if sum((_d(r['debit'])-_d(r['credit']) for r in rs),ZERO)!=0:raise ValueError(f'凭证{key}借贷不平衡。')
  closing=any(r.get('voucherKind')=='closing' for r in rs)
  if closing:
   if any(maps[(r['entityId'],r['accountCode'])]['field'] not in PL+('retained',) for r in rs):raise ValueError(f'损益结转凭证{key}含资产/负债/资本科目，不能静默排除。请核对凭证类型。')
   excluded.append({'voucherKey':key,'reason':'损益结转仅从本期管理报表计算口径排除，保留原始凭证，避免损益清零或重复结转。','voucherRefs':[_ref(r) for r in rs]})
  else:valid.extend(rs)
 return valid,excluded

def _cash_classification(rows,maps):
 groups=defaultdict(list);classes={}
 for r in rows:groups[voucher_key(r)].append(r)
 for key,rs in groups.items():
  cash=[r for r in rs if maps[(r['entityId'],r['accountCode'])]['field']=='cash']
  noncash=[maps[(r['entityId'],r['accountCode'])]['field'] for r in rs if maps[(r['entityId'],r['accountCode'])]['field']!='cash' and _d(r['debit'])!=_d(r['credit'])]
  for r in rs:
   if r.get('cashflow') and maps[(r['entityId'],r['accountCode'])]['field']!='cash':raise ValueError(f'凭证{key}非现金科目行不能填写现金流类别。')
  if not cash:continue
  if not noncash:
   if sum((_d(r['debit'])-_d(r['credit']) for r in cash),ZERO)!=0:raise ValueError(f'现金账户内部转账凭证{key}不平衡。')
   for r in cash:classes[r['id']]=('','现金账户内部转账，不计重复现金流')
   continue
  inferred=set('investing' if f in ('investment','fixed','intangible') else 'financing' if f in ('capital','shortloan','longloan') else 'operating' for f in noncash)
  for r in cash:
   explicit=r.get('cashflow','')
   if explicit and explicit not in CF[:3]:raise ValueError(f'凭证{key}现金流类别不支持。')
   if explicit:classes[r['id']]=(explicit,'现金分录明确分类')
   elif len(inferred)==1:classes[r['id']]=(next(iter(inferred)),'同凭证对方科目无歧义分类')
   else:raise ValueError(f'凭证{key}现金分录{r["lineNo"]}存在多种经营/投资/筹资对方科目，须填写现金流类别，不能倒挤。')
 return classes

def generate_source(data,erp,entity_id,month):
 if isinstance(month,bool) or not isinstance(month,int) or not 1<=month<=12:raise ValueError('期间须为1至12月。')
 e=_entity(data,entity_id);maps=_mapping(erp);opening=[deepcopy(r) for r in _active_rows(erp,'openings') if r['entityId']==e['id']];posted=[deepcopy(r) for r in _active_rows(erp,'vouchers') if r['entityId']==e['id'] and int(r['date'][5:7])<=month]
 if not opening:raise ValueError(f'{e["name"]}缺少2026年期初科目余额，请先导入完整期初，零余额也需明确报送。')
 for r in opening+posted:
  if (e['id'],r['accountCode']) not in maps:raise ValueError(f'{e["name"]}科目{r["accountCode"]}未映射，原始行{r.get("sourceRow", "—")}。')
  if r['currency']!=e['currency']:raise ValueError('账务行本位币与法人不一致。')
 keys=[opening_key(r) for r in opening]
 if len(set(keys))!=len(keys):raise ValueError('期初科目/对方/关联号存在重复明细。')
 keys=[line_key(r) for r in posted]
 if len(set(keys))!=len(keys):raise ValueError('凭证账务存在重复分录。')
 if sum((_d(r['debit'])-_d(r['credit']) for r in opening),ZERO)!=0:raise ValueError('法人期初科目余额借贷不平衡。')
 valid,excluded=_closing_filter(posted,maps);cash_classes=_cash_classification(valid,maps)
 op={k:ZERO for k in BS};cl={k:ZERO for k in BS};profit={k:ZERO for k in PL};mp={str(m):{k:ZERO for k in PL} for m in range(1,month+1)};mc={str(m):{k:ZERO for k in CF} for m in range(1,month+1)};trace_refs=defaultdict(list);tb=defaultdict(lambda:{'openingNet':ZERO,'debit':ZERO,'credit':ZERO});retained_confirmed=ZERO;confirmed=False
 for r in opening:
  m=maps[(e['id'],r['accountCode'])];f=m['field'];raw=_d(r['debit'])-_d(r['credit']);tb[r['accountCode']]['openingNet']+=raw
  if f in PL:
   if raw!=0:raise ValueError('年度期初损益科目必须为零；中途启用账套需提供年初余额和1月起完整凭证。')
   continue
  amount=raw if f in DEBIT_FIELDS else -raw;op[f]+=amount;trace_refs[('opening',f,None)].append(_ref(r,True));trace_refs[('closing',f,None)].append(_ref(r,True))
  if f=='retained' and 'openingRetainedCny' in r:retained_confirmed+=_d(r['openingRetainedCny']);confirmed=True
 cl.update(op)
 for r in valid:
  f=maps[(e['id'],r['accountCode'])]['field'];raw=_d(r['debit'])-_d(r['credit']);amount=raw if f in DEBIT_FIELDS else -raw;mth=str(int(r['date'][5:7]));tb[r['accountCode']]['debit']+=_d(r['debit']);tb[r['accountCode']]['credit']+=_d(r['credit'])
  if f in PL:
   profit[f]+=amount;mp[mth][f]+=amount;trace_refs[('profit',f,None)].append(_ref(r));trace_refs[('monthlyProfit',f,mth)].append(_ref(r));trace_refs[('closing','retained',None)].append(_ref(r))
  else:cl[f]+=amount;trace_refs[('closing',f,None)].append(_ref(r))
  if f=='cash':
   cat,basis=cash_classes[r['id']]
   if cat:
    mc[mth][cat]+=raw;rr=_ref(r);rr['classificationBasis']=basis;trace_refs[('cashflow',cat,None)].append(rr);trace_refs[('monthlyCashflow',cat,mth)].append(rr)
 netprofit=profit['revenue']-sum((profit[k] for k in PL[1:]),ZERO);cl['retained']+=netprofit
 if cl['capital']!=op['capital']:raise ValueError('当前全资演示不支持期内资本变动，请核对资本凭证，不能以留存收益补平。')
 if cl['retained']-op['retained']!=netprofit:raise ValueError('业务凭证中有分红或其他留存收益变动，本轮需独立权益事件模型，不能重复结转。')
 if e['currency']=='USD' and op['retained'] and not confirmed:raise ValueError('美元期初留存收益非零，须在期初余额填写已确认人民币留存收益。')
 cf={k:sum((r[k] for r in mc.values()),ZERO) for k in CF}
 source={'version':int(erp.get('version',1)),'currency':e['currency'],'status':'已报送','sourceName':'ERP已记账凭证及年初余额生成','opening':{k:_report(v) for k,v in op.items()},'closing':{k:_report(v) for k,v in cl.items()},'profit':{k:_report(v) for k,v in profit.items()},'monthlyProfit':{m:{k:_report(v) for k,v in r.items()} for m,r in mp.items()},'cashflow':{k:_report(v) for k,v in cf.items()},'monthlyCashflow':{m:{k:_report(v) for k,v in r.items()} for m,r in mc.items()},'capitalMovement':0,'equityHistory':{'capitalByEntity':{e['id']:_report(op['capital'])},'openingRetainedCny':_report(retained_confirmed),'dividendsByMonth':{}}}
 checks=financial_checks(source,e['name'])
 if any(not c['passed'] for c in checks):raise ValueError('ERP生成报表未通过完整三表勾稽：'+'；'.join(c['label'] for c in checks if not c['passed']))
 trace=[]
 for (area,f,m),refs in trace_refs.items():
  val=source[area][m][f] if m else source[area][f]
  trace.append({'area':area,'field':f,'month':m,'amountYuan':format((_d(val)*WAN).quantize(CENT),'f'),'amount':val,'voucherRefs':refs})
 trial=[]
 for code,r in sorted(tb.items()):
  ending=r['openingNet']+r['debit']-r['credit'];m=maps[(e['id'],code)]
  trial.append({'accountCode':code,'accountName':m['name'],'field':m['field'],'normalSide':m.get('normalSide'),'currency':e['currency'],'openingDebit':format(max(r['openingNet'],ZERO),'.2f'),'openingCredit':format(max(-r['openingNet'],ZERO),'.2f'),'debit':format(r['debit'],'.2f'),'credit':format(r['credit'],'.2f'),'closingDebit':format(max(ending,ZERO),'.2f'),'closingCredit':format(max(-ending,ZERO),'.2f'),'unit':'元'})
 fingerprint=_hash({'entityId':e['id'],'month':month,'mappings':[m for m in maps.values() if m['entityId']==e['id']],'openings':opening,'vouchers':posted})
 return {'source':source,'trialBalance':trial,'trace':trace,'checks':checks,'ledgerFingerprint':fingerprint,'excludedClosingVouchers':excluded}

def match_ic(data,erp,unit_id,month):
 leaves=set(collect_leaves(data,unit_id));maps=_mapping(erp);issues=validate_erp(data,erp);differences=[];groups=defaultdict(lambda:{'sales':[],'cost':[],'receivable':[],'payable':[],'openingReceivable':[],'openingPayable':[]})
 def difference(code,message,rows,**extra):
  refs=[_ref(r,r.get('_opening',False)) for r in rows];differences.append({'id':'DIFF-'+_hash([code,[(r.get('id'),r.get('sourceRow')) for r in rows],extra])[:20],'code':code,'type':message,'message':message,'voucherRefs':refs,'status':'待处理',**extra})
 for issue in issues:
  refs=issue.get('refs',[])
  if not refs or any(r.get('entityId') in leaves for r in refs):differences.append({'id':'DIFF-'+_hash(issue)[:20],**issue,'type':issue['message'],'voucherRefs':refs,'status':'待处理'})
 openings=[{**r,'_opening':True} for r in _active_rows(erp,'openings')]
 posted=[r for r in _active_rows(erp,'vouchers') if int(r['date'][5:7])<=month]
 for r in openings+posted:
  eid=r.get('entityId')
  if eid not in leaves:continue
  m=maps.get((eid,r.get('accountCode')))
  if not m:continue
  f=m['field']
  if r.get('voucherKind')=='closing':continue
  if f not in ('revenue','cost','receivable','payable'):continue
  value=(_d(r['debit'])-_d(r['credit']))*(1 if f in ('cost','receivable') else -1)
  if not value:continue
  status=r.get('counterpartyStatus','internal' if r.get('counterpartyId') else 'unspecified');other=r.get('counterpartyId')
  if status=='external':continue
  if not other:
   difference('unmapped_counterparty' if r.get('unmappedCounterparty') or status=='unresolved' else 'counterparty_required','客商辅助核算未映射或未明确内外部，请配置后重新匹配。',[r],entityId=eid,counterpartyCode=r.get('counterpartyCode',''));continue
  if other not in leaves:continue
  if other==eid:difference('self_counterparty','内部交易不能以本法人作为对方。',[r]);continue
  target=lowest_common_unit(data, eid, other)
  if target!=unit_id:continue
  reference=r.get('reference','')
  if not reference:difference('reference_required','缺少双方共同交易关联号，不能仅按金额或摘要猜测配对。',[r],entityId=eid,counterpartyId=other);continue
  typ=r.get('icType') or {'revenue':'sales','cost':'cost','receivable':'receivable','payable':'payable'}[f]
  expected={'revenue':'sales','cost':'cost','receivable':'receivable','payable':'payable'}[f]
  if typ!=expected:difference('mapping_type','内部交易类型与报表科目映射不一致。',[r]);continue
  seller,buyer=(eid,other) if typ in ('sales','receivable') else (other,eid)
  target=lowest_common_unit(data,seller,buyer)
  transaction_month=0 if r.get('_opening') else int(r['date'][5:7])
  category='sales' if typ in ('sales','cost') else 'balances'
  # 损益逐月配对；余额按交易ref汇总期初和本期变化。
  key=(seller,buyer,reference,r['currency'],category,transaction_month if category=='sales' else 0,target)
  g=groups[key];entry={'row':r,'value':value}
  g[('openingReceivable' if typ=='receivable' else 'openingPayable') if r.get('_opening') and typ in ('receivable','payable') else typ].append(entry)
 matches=[]
 # 同一ref出现不同本位币必须作为币种差异，不能各自误报为简单缺另一方。
 currencies=defaultdict(set)
 for key in groups:currencies[(key[0],key[1],key[2],key[4],key[5])].add(key[3])
 for key,g in groups.items():
  seller,buyer,reference,currency,kind,tm,target=key
  rows=[x['row'] for values in g.values() for x in values]
  if len(currencies[(seller,buyer,reference,kind,tm)])>1:
   difference('currency_mismatch','双方记账本位币不一致，本轮不自动抵平跨币差异。',rows,sellerId=seller,buyerId=buyer,reference=reference,unitId=target);continue
  if kind=='sales':
   a=sum((x['value'] for x in g['sales']),ZERO);b=sum((x['value'] for x in g['cost']),ZERO);opening_a=opening_b=ZERO
   left=g['sales'];right=g['cost']
  else:
   opening_a=sum((x['value'] for x in g['openingReceivable']),ZERO);opening_b=sum((x['value'] for x in g['openingPayable']),ZERO)
   a=opening_a+sum((x['value'] for x in g['receivable']),ZERO);b=opening_b+sum((x['value'] for x in g['payable']),ZERO)
   left=g['openingReceivable']+g['receivable'];right=g['openingPayable']+g['payable']
  if not left or not right:
   difference('unpaired','缺少对方对应凭证或期初辅助余额。',rows,sellerId=seller,buyerId=buyer,reference=reference,currency=currency,unitId=target,sellerAmount=_report(a),buyerAmount=_report(b),difference=_report(a-b));continue
  if a!=b or opening_a!=opening_b:
   difference('amount_mismatch','双方金额或期初内部余额不一致，保留差异追溯，不生成补差凭证。',rows,sellerId=seller,buyerId=buyer,reference=reference,currency=currency,unitId=target,sellerAmount=_report(a),buyerAmount=_report(b),difference=_report(a-b),openingDifference=_report(opening_a-opening_b));continue
  if a<0 or opening_a<0:
   difference('negative_ic','内部交易净额为负或反向往来余额，本轮须人工审核红字/重分类，不擅自生成正向抵销。',rows,sellerId=seller,buyerId=buyer,reference=reference,unitId=target);continue
  if a==0 and opening_a==0:continue
  amount=_report(a);open_amount=_report(opening_a);matchid='MATCH-'+_hash([unit_id,month,key])[:20];refs=[_ref(r,r.get('_opening',False)) for r in rows]
  signature=_hash({'key':key,'month':month,'rows':rows,'mappings':[maps[(r['entityId'],r['accountCode'])] for r in rows]})
  item={'id':matchid,'matchId':matchid,'sourceId':'ERP-'+kind.upper()+'-'+_hash([month,key])[:24],'unitId':target,'month':month,'kind':kind,'sellerId':seller,'buyerId':buyer,'currency':currency,'amount':amount,'openingAmount':open_amount,'reference':reference,'voucherRefs':refs,'signature':signature,'status':'匹配通过','openingEffects':{}}
  if kind=='sales':
   schedule={str(m):amount if m==tm else 0 for m in range(1,month+1)};item.update(effects={'revenue':-amount,'cost':-amount},monthlyAmounts=schedule,monthlyEffects={m:{'revenue':-v,'cost':-v} for m,v in schedule.items()})
  else:item.update(effects={'receivable':-amount,'payable':-amount},openingEffects={'receivable':-open_amount,'payable':-open_amount})
  matches.append(item)
 return {'matches':matches,'differences':differences,'scopeId':unit_id,'month':month,'inputFingerprint':_hash({'mappings':_active_rows(erp,'mappings'),'openings':openings,'vouchers':posted,'unitId':unit_id,'month':month})}
