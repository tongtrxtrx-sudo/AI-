"""ERP科目余额外部核对基准；不产生分录、不重复入账。

All amounts in this module are functional-currency yuan with two decimals.
The reconciliation uses all posted voucher rows, including closing vouchers;
management financial statements separately exclude valid P&L closing vouchers.
"""
from collections import defaultdict
from copy import deepcopy
from decimal import Decimal
try:
 from . import ledger
except ImportError:
 import ledger

HEADERS=['法人编码','期间','科目编码','币种','年初借方余额','年初贷方余额','本年累计借方发生额','本年累计贷方发生额','期末借方余额','期末贷方余额']
FIELDS=('openingDebit','openingCredit','debit','credit','closingDebit','closingCredit')
LABELS=dict(zip(FIELDS,HEADERS[4:]))
ZERO=Decimal('0')
def money(v):return Decimal(str(v or 0))
def fmt(v):return format(v.quantize(Decimal('.01')),'f')

def parse(data,text,month,amount_unit='元'):
 heads,rows=ledger._rows(text)
 if heads!=HEADERS:raise ValueError('科目余额核对表头须按顺序为：'+','.join(HEADERS))
 maps=ledger._mapping(data.get('erp',{}));out=[];seen=set()
 for n,row in rows:
  try:
   entity=ledger._entity(data,row['法人编码']);eid=entity['id']
   if row['期间']!=f'2026-{month:02d}':raise ValueError('余额期间必须等于当前选择；发生额是年初至本期累计，不是单月。')
   code=ledger._text(row['科目编码'],'科目编码',60)
   if (eid,code) not in maps:raise ValueError('该法人科目尚未映射，请先导入科目映射。')
   if row['币种']!=entity['currency']:raise ValueError('余额表币种须等于法人记账本位币。')
   if (eid,code) in seen:raise ValueError('同一法人／科目的余额不能重复，辅助明细先汇总成科目级。')
   values={f:ledger._money(row[label],amount_unit,label) for f,label in LABELS.items()}
   ledger._balanced_pair(values['openingDebit'],values['openingCredit'],'年初科目余额')
   ledger._balanced_pair(values['closingDebit'],values['closingCredit'],'期末科目余额')
   seen.add((eid,code));out.append({'id':'BAL-'+ledger._hash([eid,month,code])[:20],'entityId':eid,'month':month,'period':row['期间'],'accountCode':code,'currency':entity['currency'],**values,'sourceRow':n,'rawFields':deepcopy(row)})
  except ValueError as ex:raise ValueError(f'余额核对CSV第{n}行：{ex}') from None
 return out

def raw_trial(data,erp,eid,month):
 """Legal ledger trial, including every active closing voucher row."""
 entity=ledger._entity(data,eid);maps=ledger._mapping(erp);acc=defaultdict(lambda:{'openingNet':ZERO,'debit':ZERO,'credit':ZERO,'voucherRefs':[],'openingRefs':[]})
 for kind in ('openings','vouchers'):
  for r in erp.get(kind,[]):
   if r.get('active',True) is False or r['entityId']!=entity['id'] or (kind=='vouchers' and int(r['date'][5:7])>month):continue
   code=r['accountCode'];record=acc[code]
   if (eid,code) not in maps:raise ValueError('科目余额核对发现尚未映射的实际账务科目：'+code)
   if kind=='openings':record['openingNet']+=money(r['debit'])-money(r['credit']);record['openingRefs'].append(ledger._ref(r,True))
   else:record['debit']+=money(r['debit']);record['credit']+=money(r['credit']);record['voucherRefs'].append(ledger._ref(r))
 out={}
 for code,row in acc.items():
  ending=row['openingNet']+row['debit']-row['credit'];mapping=maps[(eid,code)]
  out[code]={'accountCode':code,'accountName':mapping['name'],'field':mapping['field'],'currency':entity['currency'],'openingDebit':fmt(max(row['openingNet'],ZERO)),'openingCredit':fmt(max(-row['openingNet'],ZERO)),'debit':fmt(row['debit']),'credit':fmt(row['credit']),'closingDebit':fmt(max(ending,ZERO)),'closingCredit':fmt(max(-ending,ZERO)),'voucherRefs':row['voucherRefs'],'openingRefs':row['openingRefs']}
 return out

def reconcile(data,erp,eid,month):
 baseline=[r for r in erp.get('balanceRows',[]) if r.get('active',True) and r['entityId']==eid and r['month']==month]
 actual=raw_trial(data,erp,eid,month);expected={r['accountCode']:r for r in baseline};rows=[];missing=[];extra=[]
 # Unused, omitted zero accounts need not be exported; every used account must be present.
 for code in sorted(set(actual)|set(expected)):
  a=actual.get(code,dict.fromkeys(FIELDS,'0.00'));e=expected.get(code);diff=[]
  if e is None and not any(money(a[k]) for k in FIELDS):continue
  if e is None:
   missing.append(code);diff.append({'code':'missing_account','field':'account','message':'凭证／期初有该科目，但外部余额核对表缺少该科目。','expected':None,'actual':code,'difference':None})
   e=dict.fromkeys(FIELDS,'0.00')
  if code not in actual and any(money(e[k]) for k in FIELDS):extra.append(code)
  for field in FIELDS:
   delta=money(a[field])-money(e[field])
   if delta:diff.append({'code':'amount_mismatch','field':field,'label':LABELS[field],'expected':e[field],'actual':a[field],'difference':fmt(delta),'message':'原始凭证账务与外部科目余额表不一致。'})
  roll=money(e['openingDebit'])-money(e['openingCredit'])+money(e['debit'])-money(e['credit'])-money(e['closingDebit'])+money(e['closingCredit'])
  if roll:diff.append({'code':'external_rollforward','field':'rollforward','expected':'0.00','actual':fmt(roll),'difference':fmt(roll),'message':'外部余额表本身不满足年初余额＋累计借方－累计贷方＝期末余额。'})
  rows.append({'accountCode':code,'accountName':a.get('accountName') or ledger._mapping(erp).get((eid,code),{}).get('name',code),'passed':not diff,'differences':diff,'expected':{k:e[k] for k in FIELDS},'actual':{k:a[k] for k in FIELDS},'voucherRefs':deepcopy(a.get('voucherRefs',[])),'openingRefs':deepcopy(a.get('openingRefs',[])),'sourceRow':e.get('sourceRow'),'batchId':e.get('batchId'),'rawFields':deepcopy(e.get('rawFields',{}))})
 totals={side: {k:fmt(sum((money(row[side][k]) for row in rows),ZERO)) for k in FIELDS} for side in ('expected','actual')}
 return {'entityId':eid,'month':month,'period':f'2026-{month:02d}','amountUnit':'元','basis':'年初至本期累计，原账含损益结转；与管理损益报表排除结转的试算分开','passed':bool(baseline) and not any(not r['passed'] for r in rows),'rows':rows,'missingAccounts':missing,'extraAccounts':extra,'totals':totals,'externalRows':deepcopy(baseline)}
