# FOUNDATION-20261028 凭证账务与自动内部交易纯函数契约

纯模块`ledger.py`只读入参，无数据库、文件写入或进程副作用。账务金额canonical统一为**法人本位币元、两位小数字符串（含红字负借/负贷）**；保留NC原币、集团/全局本币原字段，但只使用本币借贷入账。报表源转换为本位币万元，保留六位。

## state.erp

- `mappings:[{entityId,code,name,field,normalSide,version?}]`：按法人/科目唯一。field为既有BS或PL，normalSide借/贷；余额合计按报表字段方向而非借贷正数粗加。
- `openings:[{entityId,year,accountCode,currency,debit,credit,counterpartyId,reference,openingRetainedCny?,sourceRow,batchId?,id?}]`：2026年年初余额，逐法人借贷平衡，损益期初为零；可按内部对方/业务ref拆余额。
- `vouchers:[{entityId,date,bookCode,category,voucherId,rawVoucherNo,lineNo,accountCode,currency,transactionCurrency,debit,credit,summary,counterpartyId,reference,icType,cashflow,voucherKind,sourceRow,batchId?,id?,rawFields}]`。currency始终法人本位币，NC的`*币种`只到transactionCurrency。
- `bookMappings:[{bookCode,entityId,functionalCurrency}]`，`counterpartyMappings:[{code,entityId}]`。
- `importOptions:{auxiliaryColumn:'辅助核算1'..'辅助核算9',referenceColumn:'结算号'|'核销号'|''}`。
- `batches:[{id,active?,...}]`、`version`由领域维护；行或批次active=false不参与生成。

## 函数

- `parse_mappings_csv(data,csv,column_map=None)` → mappings。
- `parse_openings_csv(data,csv,amount_unit='元',column_map=None)` → openings。
- `parse_vouchers_csv(data,csv,amount_unit='元',column_map=None)` → generic vouchers。
- `parse_nc_vouchers(data,erp,csv,amount_unit='元',column_map=None)` → NC6.5 vouchers。
- `read_file_csv(file_bytes,file_name,sheet_name=None)` → UTF-8 CSV文本。原生xlsx只读本地ZIP/XML，不执行公式/宏；xls请另存csv/xlsx。
- `generate_source(data,erp,entity_id,month)` → `{source,trialBalance,trace,checks,ledgerFingerprint,excludedClosingVouchers}`。source为可交给现有严格源校验的完整六区报表；trace为`[{area,field,month?,amountYuan,amount,voucherRefs:[...]}]`。元原始凭证/期初/映射应由领域一并存入source.ledgerSnapshot，历史结果只读此快照，不跳到新账务。
- `match_ic(data,erp,unit_id,month)` → `{matches,differences,scopeId,month,inputFingerprint}`。match每项含`id,matchId,sourceId,unitId,month,kind,sellerId,buyerId,currency,amount,openingAmount?,reference,monthlyAmounts?,effects,openingEffects,monthlyEffects?,voucherRefs,signature`。
- `validate_erp(data,erp)` → 结构/重复/缺映射问题列表（每项code,message,refs）。生成对缺映射、不平、现金流待分类等应明确拒绝。

## CSV模板

科目：`法人编码,科目编码,科目名称,报表字段,余额方向`。

期初：`法人编码,会计年度,科目编码,币种,期初借方余额,期初贷方余额,内部往来对方,交易关联号,期初人民币留存收益`。后三项可空，但USD期初留存非零需有确认人民币余额。

通用凭证：`法人编码,凭证日期,凭证类别,凭证号,分录序号,科目编码,借方金额,贷方金额,币种,摘要,内部往来对方,交易关联号,内部交易类型,现金流类别,凭证类型`。内部交易类型sales/cost/receivable/payable或中文；现金流经营/投资/筹资仅现金科目行可填。凭证类型业务/损益结转。

NC头见research-erp/NC65-HEADERS.json；去除BOM、前导星号及空格。账簿必须配置，科目按实际NC编码映射，辅助核算按指定列+客商映射，关联号只按指定结算号/核销号（空时列差异，禁止单凭金额擅配）。无分录序号时按同一凭证内源行序号生成；key包含账簿、凭证类别、年度月份、号、行。NC文件无记账状态，因此用户须导出已记账凭证，Demo不冒称已向ERP核验状态。

## 匹配范围与规则

收入/成本同一业务ref、双方、月份及同一本位币等额，形成sales草稿；逐月effects明确，不按累计倒分。应收/应付按ref累计期末和期初余额相符形成balances草稿，effects仅receivable/payable负同额。必须交易双方最低共同合并层。未配对、错期、币种差、金额差、缺对方/ref或未映射科目列差异，所有差异保留双方原凭证行，不倒挤。生成草稿不等于审批，领域执行去重、源版本检查、负责人审批和原分级签核依赖。

现金流使用明确现金行分类，或凭证对方科目无歧义规则；复合经营/投资/筹资混合必须补分类。损益结转凭证仅含损益和留存类且整凭证平衡时从管理报表口径排除（保留原始记录和排除证据），避免损益清零/重复计入；含其他资产负债的错误结转不能静默略过。

## 最终实现补充

NC辅助核算支持`importOptions.auxiliaryColumns`多选（单选`auxiliaryColumn`兼容），客商映射可带`column`限定列；`entityId:'EXTERNAL'`为明确外部客商。多列映出不同内部法人或内外部冲突时，行保存`counterpartyStatus:'conflict'`和原始辅助值，进入差异；未映射非空辅助值不默认为外部。期初AR/AP可按科目+对方+ref多行，非零余额缺辅助对方或关联号也进入差异。

红字负借/负贷金额保留并计入单体账务，凭证仍须借贷相等；若内部净交易/反向余额为负，本轮列待人工处理差异，不自动假生成正向抵销。`matches`与`differences`仅属于当前最低共同合并层；根层不再重复返回已在鸿旺层的事项。匹配金额及差异amount/sellerAmount/buyerAmount/difference/openingAmount均**万元六位**，原凭证和试算余额的debit/credit均**元两位**。

以下仅为保留的旧回归测试夹具，不是本版默认或用户可预载数据：完整虚构样例由`ledger_seed.sample_bundle(data,entity_ids=None)`给出三类CSV及NC配置；`seed_erp`在内存解析样例；`nc_sample_csv`提供用户NC48列同格式导出。七法人396条凭证分录生成鸿旺1400/450、海外USD100/20、集团2650/770/资产2370/负债576/CTA74/现金FX90。鸿旺100内部销售为未结算，同时有AR/AP100，自动产生9项月销售和9项余额抵销；集团层仅9项月销售合计50。

### NC典型辅助承接与运行包自包含

NC同一凭证内（账簿+年月+类别+号）若只有一个明确已映射内部或外部客商，且没有未映射/冲突辅助值，可向**原辅助值为空**的收入、成本、应收、应付行承接该唯一客商；若同凭证只有一个非空关联号，可向原关联号为空的这些行承接。多个不同客商、多个不同关联号均不任取，也不跨凭证、跨账簿、跨月份推断。明确外部客商可承接但不要求内部匹配关联号；缺关联号的内部交易仍列差异。`rawFields`原值不修改，标准化行保存`counterpartyBasis/referenceBasis`和`derivedFromVoucherRows`（含原行号及ID）作为推导证据。期初余额不适用此凭证承接。

`ledger_seed.NC65_HEADERS`在后端模块自包含完整48列表头；NC样例无需读取运行包之外的research目录。新增独立临时后端目录测试确认此行为。实际本版验证结果以最终验收报告和源摘要为准，不沿用历史测试通过数。

金额转换到JSON前使用财务内核同一万元六位round-trip校验。若极大额数字无法在现有JSON数值表示中无损保持原币分，明确拒绝生成；不先转float丢分再检查。原始凭证元两位字符串仍保留，不能将数值接收范围等同于保证任何巨额数均可无损发布。

本版默认空框架且只提供空表头；全部正式源须从用户期初和原凭证生成，并通过当前科目余额核对。余额外部基准及原账比较（包含结转凭证）见FOUNDATION-CONTRACT，不改变本模块管理三表排除有效损益结转的口径。
