# FOUNDATION-20261028 空框架与凭证合并合同

产品`SelfDevelopedEPM-Foundation-Demo`、schemaVersion=4；cookie `epm_foundation_session`。空业务初始化，默认2026年06期。旧产品目录只读拒绝，不自动迁入、覆盖。

## 初始化与创建

- `engine.seed()`无法人、科目、持股、财务源、期初/凭证、余额核对、交易、抵销、财务结果；ERP映射/账簿/客商也为空。
- 只保留技术容器`TY_GROUP`，名称“集团合并（待配置）”，CNY、`members:[]`、`isFramework:true`。该容器可以导航及建档，不能计算/签核零结果。空bootstrap `reportMode:'待建档'`、`frameworkOnly:true`、`dataReady:false`、`preconditions.scope_empty=false`。
- 预算保留零金额技术模板`V1 待编制`、4个0层、无实体分配/业务计划，无预装经营预算业务数字。用户自己编制。
- `entity_save:{id,code,name,short?,owner?,currency:'CNY'|'USD',parentId?:null|id,percent?:100}`。ID用户显式填写，大写字母起头，含大写/数字/_/-，≤40；业务code≤30且唯一。首建本部parent空；再建子法人选实际母公司，或用ownership_save后建100%持股；不自动把新法人挂TY。
- `ownership_save:{entityId,parentId,percent:100,method:'全额合并'}`，拒自持、循环、未知母子、少数股东。管理范围与真实持股分开。
- `unit_save:{id,name,currency,members:[{type:'entity'|'unit',id}]}`。用户保存的单位成员必须非空；仅初始技术容器是空例外。先建法人，再建小组合并成员，最后维护root本部+小组；重复叶子/循环/错误币种拒绝。
- 已有任何源、历史ERP期初/凭证/余额/账簿映射的法人不允许直接重标本位币。
- `erp_sample_load`在正常产品返回403 sample_disabled，前端不能预载旧7家或396条样例。旧`seed_demo`仅测试夹具，服务启动永不调用。

## 科目余额表：外部核对、不重复入账

新增动作`erp_balance_import`，非只读角色可用。payload与ERP其他文件相同：`{csv,sourceName,amountUnit:'元'|'万元'}`或`{fileBase64,fileName,sourceName,sheetName?,amountUnit}`，支持真实CSV/XLSX，无公式，导入需本期相关单位解锁。

固定10列，顺序不可变：

```
法人编码,期间,科目编码,币种,年初借方余额,年初贷方余额,本年累计借方发生额,本年累计贷方发生额,期末借方余额,期末贷方余额
```

- 法人ID/code/name唯一匹配；先建档与科目映射；币种是法人本位币。
- 期间2026-MM须等于当前month。发生额从1月到该月**累计**，不是单月。金额原单位由payload指定，规范化元两位字符串。
- 一法人一科目一行，辅助先汇总到科目级。年初和期末余额同一行不允许借贷同时非0；累计发生额允许借方/贷方同时非0，也保留真实红字符号。
- 文件只存外部核对基准，不写入凭证/期初、不改变金融源金额、不把余额重复计为收入或现金流。
- 同一法人本期新文件整体替换旧基准（旧行active=false保留）。因此部分文件不会靠残留旧行冒充完整。缺少实际有数科目会差异；完全未发生的零映射科目可省略。显式提供的零科目照样核对。
- 批次kind=balance，记录month/period及sourceName；余额行记录canonical id、entityId、accountCode、month、period、currency、六金额、batchId/sourceRow/rawFields/active。
- `erp_batch_cancel`支持balance，须在其实际期间操作；异期请求拒绝且零写。仅检查本期锁，停用不改原账金额；当前核对和依赖结果失效。

动作`erp_balance_check:{entityIds?:[id,...]}`，默认当前范围有账务的法人。显式ID需当前scope内，不重复。先用当前凭证生成单体三表，再核对；无账务、无当前source指纹时拒绝。

## 核对对象与追溯

`balance_domain.raw_trial`按全部有效原始期初和截至本月凭证计算原账，包括已确认损益结转凭证。它不同于管理三表为避免损益清零而排除结转的`trialBalance`。对真实NC已结转余额，PL期末可为0、累计含结转借贷，仍能与原账核对；管理利润保持业务口径。

每行六键`openingDebit/openingCredit/debit/credit/closingDebit/closingCredit`均元字符串；`expected`=导入外表，`actual`=原始账务，`difference=actual-expected`。对科目取实际有数科目与导入科目的并集，不能只挑几行相符就通过。外表本身滚算不符也列差异，不补差。

bootstrap.erp增加：

- `balanceTemplatesCsv`：纯表头。
- `balanceRows`：当前month外部余额行（含停用历史）；完整内部state保留所有期间。
- `balanceReports:{entityId:report}`：当前month检查投影；内部以`entityId:month`索引。
- report：`entityId,month,period,amountUnit:'元',basis,passed,valid,checkedAt,checkedBy,inputFingerprint,rows,missingAccounts,extraAccounts,totals,externalRows`。
- rows：`accountCode,accountName,passed,differences[],expected:{六键},actual:{六键},voucherRefs[],openingRefs[],sourceRow,batchId,rawFields`。
- difference：`code:'amount_mismatch'|'missing_account'|'external_rollforward',field,label?,expected,actual,difference,message`。缺科目等非数值项difference为null。

凭证refs保留id/batchId/sourceRow、法人/日期/凭证号/科目/借贷；前端可按来源身份跳原始行和NC原字段。无需新trace端点；财报字段仍用GET `/api/erp/trace`，历史结果使用已保存sourceSnapshots，不追最新账务。

## 版本与强制门禁

- 新产品`modelPolicy.requiresVoucherSources=true`、`requiresLedgerBalanceCheck=true`。所有正式合并叶子法人必须有当前有效ERP凭证来源；不接受无原账的手工源替代。每个法人须有当前fingerprint、valid且passed的余额报告，正式合并前置`erp_balance_<法人ID>`硬检查。
- inputFingerprint绑定实际ledger指纹和本法人本期外部基准。新凭证/期初/映射/补注/停批使受影响期间检查valid=false；外表换版/停用也使本期检查和相关结果失效。
- 差异保存为结果，不自动填平；修改原金额应回ERP核实、更正，停用旧批重导，重生、核对、匹配、草稿审批后再计算。
- 当前source.ledgerSnapshot.balanceCheck及对应ERP报告source保存当次核对证据。合并结果另有`balanceSnapshots:{entityId:report}`，包括外表原行和凭证refs；历史结果快照不被新余额基准回写。
- 空容器没有叶子法人，禁止正式计算/签核；不会生成“空零已完成”结果。

金额精度仍为原账元2位字符串、财务报表万元6位、预算万元2位。原NC48列、原币/集团币只保留核对，法人账仅使用本币借贷。匹配/差异/自动抵销审批与分级签核保持原正式事务和历史快照规则。

正常空框架产品在engine外部命令边界拒绝source_save/source_import/tb_import（403 voucher_source_required），手工三表模块仅供查看。外部elimination_save内部销售类型同样403 voucher_elimination_required，客户端伪造erpMatchId不放行；须真正erp_match_run生成相符事项→erp_elimination_generate→审批。投资权益仍允许按真实全资持股和当前期初源明确维护，正式计算同样需所有来源/余额核对通过。测试夹具seed_demo显式关闭该严格策略，不是可由客户端启用的业务模式。
