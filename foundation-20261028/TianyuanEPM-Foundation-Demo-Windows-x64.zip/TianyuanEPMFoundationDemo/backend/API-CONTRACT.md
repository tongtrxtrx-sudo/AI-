# FOUNDATION-20261028 本机空框架 API 合同

本合同与`FOUNDATION-CONTRACT.md`、`LEDGER-CONTRACT.md`、`CALCULATION-CONTRACT.md`共同描述当前版本；本版默认无任何业务示例。旧ERP-20261021仅作为回归测试来源，不是本版初始化行为。

## 身份、数据与会话

- product=`SelfDevelopedEPM-Foundation-Demo`，schemaVersion=4，cookie=`epm_foundation_session`。
- 新版独立数据目录，旧/未知产品先只读识别并拒绝改写。后端只监听127.0.0.1。启动凭据保留在私有进程管道/实例文件，不包含在可公开交付物。
- 默认06期，2026固定年度；只保留`TY_GROUP`空技术导航容器。法人、集团科目、股权、ERP映射/账簿/客商、期初/凭证/余额核对、财务源、抵销、结果均为空。预算只有零金额技术编制模板，无预置年度目标或业务计划。
- POST `/api/session` `{token}`建立本机cookie会话；响应csrfToken。角色切换用于本机体验，不是企业生产身份认证。

## 请求与事务

GET `/api/bootstrap?group=TY_GROUP&month=6&currency=CNY&entity=all`。

`group`为实际合并单元ID，month=1..12，entity=all或范围内法人ID；currency须等当前单元/法人本位币，不做展示币种随意换算。

POST `/api/action` `{action,payload,revision,context}`。同源Origin、cookie、`X-CSRF-Token`必须有效。所有业务动作进入SQLite单事务，错误整笔回滚、revision不增；成功返回最新bootstrap，只有revision_conflict 409需先刷新。

GET `/api/health`仅暴露ready/instanceId/product，供启动器核验；GET `/api/runtime`需会话，供本机环境面板显示路径。POST `/api/open-data-dir`、`/api/shutdown`需会话/CSRF；启动器有受控token停机方式。响应不输出启动token。

## 框架与主数据动作

|动作|payload|规则|
|---|---|---|
|role_switch|`{role}`|集团财务负责人／法人会计／审计只读，服务器会话角色，不写业务数据|
|settings_save|`{companyName,fiscalYear:2026}`|负责人，不能重标现有会计年度|
|entity_save|`{id,code,name,short?,owner?,currency,parentId?,percent?:100}`|负责人；先创建本部，parentId为null；再建真实子法人，不自动挂不存在的TY。ID/code唯一，本位币CNY/USD，已有源/账簿/历史账务后禁直接重标币种|
|ownership_save|`{entityId,parentId:null或法人ID,percent:100,method:'全额合并'}`|真实母子关系，与管理树独立；拒未知、自持、循环；可明确清母关系用于本部/纠错|
|unit_save|`{id,name,currency,members:[{type,id}]}`|先法人后成员；非空列表、每个底层法人仅一次，无环、无重叶；初始TY_GROUP技术空容器是唯一空结构例外，不能计算|
|account_save|`{code,name,type,field,normalSide}`|集团科目档案，field为内置BS/PL，方向借/贷；与法人ERP科目映射分别维护|
|rate_set_save|`{sourceCurrency:'USD',targetCurrency:'CNY',opening,closing,historicalCapital,averages,flowRates}`|1..month月均/流量率完整，正数6位；保留历史版本，当前支持USD到CNY|
|unit_reopen|`{unitId?,reason,cascade:true}`|负责人重开本层及依赖祖先，当前结果失效，历史金额/来源不改|

## ERP工作台动作

文件动作接受`{csv,sourceName,amountUnit:'元'|'万元',columnMap?}`或`{fileBase64,fileName,sourceName,sheetName?,amountUnit,columnMap?}`。真实CSV/XLSX；旧xls需另存；文件最大8MB，CSV正文UTF8最多9MB，HTTP整体最大12MB。XLSX本地ZIP/XML读取，不执行公式/宏；默认首工作表，或指定sheetName。

|动作|payload补充|实际效果|
|---|---|---|
|erp_adapter_save|`{adapter:'nc65'|'generic',bookMappings,counterpartyMappings,importOptions}`|负责人维护账簿→法人/本位币、辅助列原值→内部法人或EXTERNAL、结算号/核销号规则；仅影响后续导入|
|erp_mapping_save|文件或`{rows:[{entityId,code,name,field,normalSide}],sourceName}`|法人科目→报表字段，按法人科目保存新版本，旧行留存|
|erp_opening_import|期初文件|2026年初科目余额；逐法人借贷平衡，可按内部客商/共同号拆期初；不把期末当期初|
|erp_voucher_import|`format:'nc65'|'generic',postedConfirmed:true`|整张已记账凭证，逐凭证平衡/重复/映射校验；NC原48列保留，仅本币借贷入法人账|
|erp_balance_import|10列科目余额文件，详FOUNDATION-CONTRACT|本期年初至今累计外部核对基准，按法人本期整份替换；不产生分录、不重复入账|
|erp_report_generate|`{entityIds?:[],unitId?}`|当前scope内法人从期初＋原凭证生成管理三表、试算、字段归因和快照；不准跨当前范围明示生成|
|erp_balance_check|`{entityIds?:[]}`|当前scope，先生成当前ERP源，再以含损益结转的原账余额逐科目核对；差异保存，不倒挤|
|erp_match_run|`{unitId?}`|按最低共同合并层、双方、月份、同本位币与共同号匹配收入成本/ARAP，未知、缺号、金额/币种差保留凭证refs|
|erp_elimination_generate|`{unitId?,matchIds?:[]}`|从真实有效相符事项生成抵销草稿，当前版本重复生成幂等；不是外部伪erpMatchId放行|
|erp_eliminations_approve|`{unitId?,ids?:[],reason}`|负责人逐张正式校验，任一失败整批回滚，来源过期不能审批|
|erp_voucher_annotations_save|`{rowIds,counterpartyId?,reference?,cashflow?,reason}`|仅补规范化客商、共同号或现金行分类；原金额/日期/科目/raw不变，标注前后留痕；源/核对/匹配失效，须重做|
|erp_batch_cancel|`{batchId,reason}`|负责人停用保留原行/历史。余额batch须当前context为实际batch月，否则零写拒绝；不改变原账金额|
|erp_demo_eliminations_replace|`{unitId?,reason}`|兼容旧试验转换动作；新空框架本来没有预置抵销，不需此步骤|
|erp_sample_load|不可用|正常空框架返回403 sample_disabled；测试夹具可显式内部使用，不是API可启用的模式|

## 正式合并与操作边界

所有正式叶子须有当前有效原凭证ERP源，所有余额核对passed且指纹当前，内部交易匹配差异清零，相符事项已生成并审批；下级必须有效已签核。缺资料不使用旧手工样例填充。

- `consolidation_run:{unitId?}`生成当前层新版本，不能空范围计算、不能跨过下级签核；`result_approve:{resultId}`只签当前有效已计算版本，锁本层。
- `elimination_save:{id?,sourceId,unitId,sellerId,buyerId,kind:'投资权益',amount,currency}`仍允许真实全资投资与期初资本依据；`elimination_approve`、`elimination_cancel`负责人操作。金额须符合实际持股下子资本合计，最终还受原账余额与源校验。
- 对外`elimination_save kind sales/内部销售`403 voucher_elimination_required；须从ERP匹配生成，客户端传erpMatchId也不能绕过。
- 对外`source_save/source_import/tb_import`403 voucher_source_required。原手工源页仅查看；不能手填三表伪造凭证追溯。
- `commentary_save:{text}`保存本层经营解释。预算动作保留完整原流程且只在TY_GROUP/CNY/all，默认没有业务数值。

## bootstrap关键投影

- `frameworkOnly/dataReady/initialization/reportMode`明确当前是否待建档、待报送、预览、已计算、已签核或历史失效，零占位不是已完成财务结果。
- `entities/units/ownership/accounts/settings`当前主数据；`sources`仅当前月完整源；`unitStatus/unitStates/preconditions/currentResult/results`按真实依赖和历史版本投影。
- `erp.mappings/openings/vouchers/batches`保留active状态和历史行；balanceRows当前月，balanceReports按当前月法人索引，内部以eid:month保存；详细结构见FOUNDATION-CONTRACT。
- `erp.templates`仅空表头与配置结构，没有预装财务示例；`balanceTemplatesCsv`也仅表头。
- `erp.integration.onlineConnected:false`：当前是NC6.5 CSV/XLSX文件适配，没有企业NC在线自动同步和写回。

## 凭证、核对与历史追溯

GET `/api/erp/trace?entityId=HW&month=6&area=profit&field=revenue&resultId=...`。未传resultId读当前源；传则严格读历史结果sourceSnapshots。手工源无凭证血缘返回409，未知字段400。

返回entityId/month/area/field/sourceVersion/basis/resultId/currency/amount（报表万元）/contributingFields/traceRows/rows/openingRows/relatedVoucherRows/ledgerSnapshot。rows仅该字段归因；同凭证其他借贷在relatedVoucherRows另列，不能假称全属该字段。

原NC字段、账簿、类别、凭证号、分录、批次、原文件行保存。canonicalID在停用后重导可复用，界面来源定位需id+batchId+sourceRow；旧行只读，新有效行可补注。历史抵销来源只读。

当前ERP源ledgerSnapshot保存期初/凭证/映射、批次、解释规则、有效结转排除证据和余额核对证据；合并另冻结sourceSnapshots/balanceSnapshots/eliminationSnapshots/unitSnapshots/rateSnapshots/ownershipSnapshot。新数据不回写旧快照，依赖过期需自下而上重算签核。
