"""独立、虚构的全资分级合并账套。没有数据库或进程副作用。"""
from copy import deepcopy
from decimal import Decimal, ROUND_HALF_UP

BS = ('cash','receivable','inventory','prepaid','investment','fixed','intangible','deferred_asset','payable','shortloan','taxpayable','otherliability','longloan','deferred_liability','capital','retained','nci','cta')
PL = ('revenue','cost','expense','finance','tax')
CF = ('operating','investing','financing','fx')
def n(v): return float(Decimal(str(v)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP))
def cumulative(total,month): return n(Decimal(str(total))*Decimal(min(month,9))/9)
def monthly(total,month): return {str(m):n(Decimal(str(cumulative(total,m)))-Decimal(str(cumulative(total,m-1)))) for m in range(1,month+1)}

def seed_multilevel():
    specs=[
      ('TY','TY00','杭州天元宠物用品有限公司','天元本部','CNY',950,0,0,0,0),
      ('HW','HW00','鸿旺单体','鸿旺单体','CNY',100,1000,600,100,0),
      ('HW_CAT','HW01','鸿旺猫爬架生产事业部','鸿旺猫爬架','CNY',50,300,180,30,0),
      ('HW_ELEC','HW02','杭州鸿旺宠物用品有限公司电子工厂','鸿旺电子工厂','CNY',50,200,120,20,0),
      ('OTHER','OT01','集团其他境内公司（演示）','其他境内公司','CNY',100,600,360,60,0),
      ('OS_A','OS01','海外公司甲（演示）','海外公司甲','USD',50,50,0,40,40),
      ('OS_B','OS02','海外公司乙（演示）','海外公司乙','USD',50,50,0,40,40),
    ]
    entities=[{'id':s[0],'code':s[1],'name':s[2],'short':s[3],'currency':s[4],'currencyCode':s[4],'parentId':None if s[0]=='TY' else 'TY','ownershipPercent':100,'owner':'演示财务负责人','version':1,'enabled':True} for s in specs]
    units=[
      {'id':'HW_GROUP','name':'鸿旺小合并','currency':'CNY','version':1,'members':[{'type':'entity','id':i} for i in ('HW','HW_CAT','HW_ELEC')]},
      {'id':'OS_GROUP','name':'海外小合并','currency':'USD','version':1,'members':[{'type':'entity','id':i} for i in ('OS_A','OS_B')]},
      {'id':'TY_GROUP','name':'杭州天元集团合并','currency':'CNY','version':1,'members':[{'type':'entity','id':'TY'},{'type':'unit','id':'HW_GROUP'},{'type':'unit','id':'OS_GROUP'},{'type':'entity','id':'OTHER'}]},
    ]
    sources={};fx=[];eliminations=[]
    for month in range(1,13):
        period={}
        for eid,code,name,short,currency,capital,revenue,cost,expense,loan in specs:
            opening=dict.fromkeys(BS,0);opening['capital']=capital;opening['cash']=capital
            if eid=='TY':opening['cash']=0;opening['investment']=950
            closing=deepcopy(opening)
            profit={k:cumulative(v,month) for k,v in zip(PL,(revenue,cost,expense,0,0))}
            net=n(Decimal(str(profit['revenue']))-sum(Decimal(str(profit[k])) for k in PL[1:]))
            financing=cumulative(loan,month)
            closing.update(cash=n(Decimal(str(opening['cash']))+Decimal(str(net))+Decimal(str(financing))),longloan=financing,retained=net)
            mp={str(m):{k:monthly(v,month)[str(m)] for k,v in zip(PL,(revenue,cost,expense,0,0))} for m in range(1,month+1)}
            mc={str(m):{'operating':n(Decimal(str(mp[str(m)]['revenue']))-sum(Decimal(str(mp[str(m)][k])) for k in PL[1:])), 'investing':0,'financing':monthly(loan,month)[str(m)],'fx':0} for m in range(1,month+1)}
            period[eid]={'version':1,'currency':currency,'status':'已报送','sourceName':'系统初始化虚构演示报送','opening':opening,'closing':closing,'profit':profit,'cashflow':{'operating':net,'investing':0,'financing':financing,'fx':0},'monthlyProfit':mp,'monthlyCashflow':mc,'capitalMovement':0,'equityHistory':{'capitalByEntity':{eid:capital},'openingRetainedCny':0,'dividendsByMonth':{}}}
        sources[str(month)]=period
        fx.append({'id':f'FX-USD-CNY-2026-{month:02d}','month':month,'version':1,'sourceCurrency':'USD','targetCurrency':'CNY','opening':6.5,'closing':7.2,'historicalCapital':6.5,'averages':{str(m):7 for m in range(1,month+1)},'flowRates':{str(m):7 for m in range(1,month+1)},'status':'已审批','note':'报价1美元=若干人民币；本年度无资本变动、分红或少数股东。'})
        for prefix,unit,seller,buyer,amount in [('HW-SALES','HW_GROUP','HW','HW_CAT',100),('GROUP-SALES','TY_GROUP','HW','OTHER',50)]:
            monthly_amounts=monthly(amount,month);amount=cumulative(amount,month)
            eliminations.append({'id':f'{prefix}-{month:02d}','sourceId':f'IC-{prefix}-2026-{month:02d}','unitId':unit,'month':month,'kind':'sales','status':'已审批','version':1,'currency':'CNY','amount':amount,'sellerId':seller,'buyerId':buyer,'title':'鸿旺内部销售抵销' if unit=='HW_GROUP' else '集团跨小合并范围销售抵销','reason':'虚构已结算内部交易，收入与成本同时抵销，净利润及现金流影响为零。','effects':{'revenue':-amount,'cost':-amount},'openingEffects':{},'monthlyAmounts':monthly_amounts,'monthlyEffects':{m:{'revenue':-v,'cost':-v} for m,v in monthly_amounts.items()}})
        pairs=[{'parentId':'TY','childId':eid,'investment':capital if currency=='CNY' else n(Decimal(str(capital))*Decimal('6.5')),'capital':capital,'currency':currency} for eid,code,name,short,currency,capital,*_ in specs if eid!='TY']
        eliminations.append({'id':f'GROUP-INVESTMENT-{month:02d}','sourceId':f'INVESTMENT-TY-2026-{month:02d}','unitId':'TY_GROUP','month':month,'kind':'investment','status':'已审批','version':1,'currency':'CNY','amount':950,'title':'天元本部对子公司投资与期初资本抵销','reason':'真实持股按天元100%示例。管理归属不产生鸿旺对子公司的虚构投资；950=境内资本300+海外历史资本650。','effects':{'investment':-950,'capital':-950},'openingEffects':{'investment':-950,'capital':-950},'investmentPairs':pairs})
    return {'entities':entities,'units':units,'sources':sources,'fxRates':fx,'eliminations':eliminations,'ownership':[{'parent':'TY','child':e['id'],'percent':100,'method':'全额合并','effectiveFrom':'2026-01-01'} for e in entities if e['id']!='TY'],'modelPolicy':{'version':'20261020-multilevel-v1','year':2026,'actualThrough':9,'sourceUnit':'本位币万元','note':'全资普通境外经营、无税、无分红、无资本变动；1—9期虚构月度发生额，10—12期无新报送则沿用9期累计。'} }
