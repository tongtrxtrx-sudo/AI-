"""ERP领域真实业务、来源快照与事务保护回归。"""
import csv,hashlib,io,json,sqlite3,tempfile,unittest
from copy import deepcopy
from pathlib import Path
try:
 from .engine import seed_demo as seed,apply,bootstrap
 from . import erp_domain as erp
 from .ledger_seed import sample_bundle,nc_sample_csv
 from .store import Store,DomainError
except ImportError:
 from engine import seed_demo as seed,apply,bootstrap
 import erp_domain as erp
 from ledger_seed import sample_bundle,nc_sample_csv
 from store import Store,DomainError
ROLE='集团财务负责人'
CTX={'group':'TY_GROUP','month':9,'currency':'CNY','entity':'all'}
def context(data,uid):return {**CTX,'group':uid,'currency':next(u['currency'] for u in data['units'] if u['id']==uid)}
def act(data,a,p=None,uid='TY_GROUP',role=ROLE):return apply(data,role,a,p or {},context(data,uid))
def unlock(data):
 for uid in ('HW_GROUP','OS_GROUP','TY_GROUP'):act(data,'unit_reopen',{'reason':'ERP测试重新开启','cascade':True},uid)
def sample(data):
 act(data,'erp_sample_load',{'replace':True,'reason':'测试ERP完整来源'})
 act(data,'erp_report_generate',{'entityIds':[e['id'] for e in data['entities']]})
def consolidate(data,uid):
 act(data,'erp_match_run',{},uid);act(data,'erp_elimination_generate',{},uid)
 act(data,'erp_eliminations_approve',{'reason':'测试逐张校验审批'},uid)
 act(data,'consolidation_run',{},uid)
 rid=data['unitPeriods'][f'{uid}:9']['activeResultId'];act(data,'result_approve',{'resultId':rid},uid)
 return next(r for r in data['results'] if r['id']==rid)
def csv_text(heads,rows):
 s=io.StringIO();w=csv.writer(s);w.writerow(heads);w.writerows(rows);return s.getvalue()
def penny(data,cp='外部',ref=''):
 e=next(e for e in data['entities'] if e['id']=='HW')
 return csv_text(['法人编码','凭证日期','凭证类别','凭证号','分录序号','科目编码','借方金额','贷方金额','币种','摘要','内部往来对方','交易关联号','内部交易类型','现金流类别','凭证类型'],[[e['code'],'2026-09-29','记','PENNY-1',1,'100201','.01',0,'CNY','分位现金销售',cp,ref,'','经营','业务'],[e['code'],'2026-09-29','记','PENNY-1',2,'600101',0,'.01','CNY','分位现金销售',cp,ref,'sales' if cp!='外部' else '','','业务']])

class ERPDomainTests(unittest.TestCase):
 def test_sample_original_vouchers_to_all_three_tiers_and_journals(self):
  d=seed();sample(d)
  for uid in ('HW_GROUP','OS_GROUP','TY_GROUP'):result=consolidate(d,uid)
  a=result['snapshot']['statement']['actual'];self.assertEqual((a['revenue'],a['net'],a['assets'],a['cta'],a['cashFx']),(2650,770,2370,74,90))
  auto=[r for r in d['eliminations'] if r.get('erpMatchId')]
  self.assertEqual(len(auto),27)
  self.assertEqual(sum(r['amount'] for r in auto if r['unitId']=='HW_GROUP' and r['kind']=='sales'),100)
  self.assertEqual(sum(r['amount'] for r in auto if r['unitId']=='HW_GROUP' and r['kind']=='balances'),100)
  for row in auto:
   self.assertTrue(row['voucherRefs']);self.assertEqual(sum(x['debit'] for x in row['journalLines']),sum(x['credit'] for x in row['journalLines']))
  old=len(d['eliminations']);act(d,'unit_reopen',{'reason':'验证幂等','cascade':True},'TY_GROUP');act(d,'erp_match_run',{},'TY_GROUP');act(d,'erp_elimination_generate',{},'TY_GROUP');self.assertEqual(len(d['eliminations']),old)
 def test_nc_real_import_requires_mode_conversion_and_uses_only_functional_amount(self):
  d=seed();unlock(d);b=sample_bundle(d,['HW','HW_CAT','HW_ELEC']);act(d,'erp_adapter_save',{'adapter':'nc65','bookMappings':b['bookMappings'],'counterpartyMappings':sample_bundle(d)['counterpartyMappings'],'importOptions':b['importOptions']})
  act(d,'erp_mapping_save',{'csv':b['mappingCsv']});act(d,'erp_opening_import',{'csv':b['openingCsv']})
  raw=list(csv.DictReader(io.StringIO(nc_sample_csv(d,['HW','HW_CAT','HW_ELEC']))));heads=list(raw[0])
  for r in raw:r['币种']='USD';r['原币借方金额']='99999.01';r['原币贷方金额']='12345.12';r['集团本币借方金额']='87654.12';r['全局本币贷方金额']='987654.32'
  nc=csv_text(heads,[[r[h] for h in heads] for r in raw])
  with self.assertRaises(DomainError):act(d,'erp_voucher_import',{'csv':nc,'format':'nc65'})
  act(d,'erp_voucher_import',{'csv':nc,'format':'nc65','postedConfirmed':True})
  act(d,'erp_report_generate',{'entityIds':['HW','HW_CAT','HW_ELEC']})
  self.assertEqual(d['sources']['9']['HW']['profit']['revenue'],1000)
  self.assertEqual(d['sources']['9']['HW']['currency'],'CNY');self.assertEqual(d['erp']['vouchers'][0]['transactionCurrency'],'USD')
  act(d,'erp_match_run',{},'HW_GROUP')
  with self.assertRaises(DomainError) as error:act(d,'erp_elimination_generate',{},'HW_GROUP')
  self.assertEqual(error.exception.code,'erp_demo_elimination_conflict')
  act(d,'erp_demo_eliminations_replace',{'reason':'确认只转换本层旧示例'},'HW_GROUP')
  result=consolidate(d,'HW_GROUP');self.assertEqual(result['snapshot']['statement']['actual']['revenue'],1400)
  self.assertTrue(any(e['kind']=='investment' and e['status']=='已审批' for e in d['eliminations']))
 def test_one_cent_precision_and_duplicate_prevention(self):
  d=seed();sample(d);text=penny(d)
  act(d,'erp_voucher_import',{'csv':text,'amountUnit':'元'});count=len(d['erp']['vouchers'])
  with self.assertRaises(DomainError):act(d,'erp_voucher_import',{'csv':text,'amountUnit':'元'})
  self.assertEqual(len(d['erp']['vouchers']),count)
  act(d,'erp_report_generate',{'entityIds':['HW']})
  self.assertEqual(d['sources']['9']['HW']['profit']['revenue'],1000.000001)
  self.assertEqual(d['sources']['9']['HW']['closing']['cash'],300.000001)
 def test_changed_input_stales_auto_then_cancel_restore_can_regenerate(self):
  d=seed();sample(d);old=consolidate(d,'HW_GROUP');snapshot=deepcopy(old['snapshot'])
  act(d,'unit_reopen',{'reason':'变更原凭证','cascade':True},'HW_GROUP')
  act(d,'erp_voucher_import',{'csv':penny(d,'HW_CAT','PENNY-UNMATCH')})
  batch=d['erp']['batches'][-1]['id']
  self.assertTrue(any(e.get('erpMatchId') and e['status']=='来源失效' for e in d['eliminations']))
  with self.assertRaises(DomainError):act(d,'consolidation_run',{},'HW_GROUP')
  act(d,'erp_report_generate',{'entityIds':['HW']});act(d,'erp_match_run',{},'HW_GROUP')
  run=d['erp']['matchingByScope']['HW_GROUP:9'];self.assertTrue(run['differences']);self.assertTrue(run['differences'][0]['voucherRefs'])
  with self.assertRaises(DomainError):act(d,'consolidation_run',{},'HW_GROUP')
  act(d,'erp_batch_cancel',{'batchId':batch,'reason':'撤销分位测试批次'})
  act(d,'erp_report_generate',{'entityIds':['HW']});new=consolidate(d,'HW_GROUP')
  self.assertEqual(new['snapshot']['statement']['actual']['revenue'],1400)
  self.assertEqual(old['snapshot'],snapshot)
 def test_trace_exact_income_derived_and_old_snapshot(self):
  d=seed();sample(d);old=consolidate(d,'HW_GROUP');rid=old['id']
  income=erp.trace(d,'HW',9,'profit','revenue',rid)
  self.assertEqual(income['amount'],1000);self.assertTrue(income['rows']);self.assertEqual({r['accountCode'] for r in income['rows']},{'600101'})
  net=erp.trace(d,'HW',9,'profit','net',rid);self.assertEqual(net['amount'],300);self.assertEqual({r['accountCode'] for r in net['rows']},{'600101','640101','660201'})
  opening=erp.trace(d,'HW',9,'cashflow','openingcash',rid);self.assertFalse(opening['rows']);self.assertTrue(opening['openingRows'])
  with self.assertRaises(DomainError):erp.trace(d,'HW',9,'profit','unknown',rid)
  act(d,'unit_reopen',{'reason':'历史来源核对','cascade':True},'HW_GROUP');act(d,'erp_voucher_import',{'csv':penny(d)});act(d,'erp_report_generate',{'entityIds':['HW']})
  self.assertEqual(erp.trace(d,'HW',9,'profit','revenue')['amount'],1000.000001)
  self.assertEqual(erp.trace(d,'HW',9,'profit','revenue',rid)['amount'],1000)
 def test_roles_and_manual_source_cannot_fake_erp_lineage(self):
  d=seed();sample(d)
  for a,p in [('erp_mapping_save',{'rows':[]}),('erp_sample_load',{'replace':True,'reason':'拒绝'}),('erp_eliminations_approve',{'reason':'拒绝'})]:
   with self.assertRaises(DomainError) as error:act(d,a,p,role='法人会计')
   self.assertEqual(error.exception.status,403)
  with self.assertRaises(DomainError):act(d,'erp_voucher_import',{'csv':penny(d)},role='审计只读')
  with self.assertRaises(DomainError):act(d,'source_save',{'entityId':'HW','source':deepcopy(d['sources']['9']['HW'])})
 def test_annotations_resolve_reference_without_changing_raw_or_old_snapshot(self):
  d=seed();sample(d);old=consolidate(d,'HW_GROUP');snapshot=deepcopy(old['snapshot'])
  act(d,'unit_reopen',{'reason':'核对补注测试','cascade':True},'HW_GROUP')
  row=next(r for r in d['erp']['vouchers'] if r['entityId']=='HW_CAT' and r['icType']=='cost' and r['reference'])
  original=row['reference'];raw=deepcopy(row['rawFields'])
  act(d,'erp_voucher_annotations_save',{'rowIds':[row['id']],'reference':'TYPO','reason':'演示差异可追溯'},'HW_GROUP')
  act(d,'erp_report_generate',{'entityIds':['HW_CAT']},'HW_GROUP');act(d,'erp_match_run',{},'HW_GROUP')
  self.assertEqual(len(d['erp']['matchingByScope']['HW_GROUP:9']['differences']),2)
  act(d,'erp_voucher_annotations_save',{'rowIds':[row['id']],'reference':original,'reason':'核原单后确认共同编号'},'HW_GROUP')
  act(d,'erp_report_generate',{'entityIds':['HW_CAT']},'HW_GROUP');result=consolidate(d,'HW_GROUP')
  self.assertEqual(result['snapshot']['statement']['actual']['revenue'],1400);self.assertEqual(raw,row['rawFields']);self.assertEqual(len(row['annotations']),2);self.assertEqual(snapshot,old['snapshot'])
 def test_annotation_disallows_financial_changes_wrong_scope_non_cash_and_lock(self):
  d=seed();sample(d);row=next(r for r in d['erp']['vouchers'] if r['entityId']=='HW' and r['accountCode']=='600101')
  before=deepcopy(row)
  for extra in [{'debit':'999'},{'date':'2026-01-01'},{'accountCode':'999'}, {'cashflow':'operating'}]:
   with self.assertRaises(DomainError):act(d,'erp_voucher_annotations_save',{'rowIds':[row['id']],'reference':'REF','reason':'拒绝非法补注',**extra},'HW_GROUP')
  self.assertEqual(before,row)
  with self.assertRaises(DomainError):act(d,'erp_voucher_annotations_save',{'rowIds':[row['id']],'reference':'REF','reason':''},'HW_GROUP')
  with self.assertRaises(DomainError):act(d,'erp_voucher_annotations_save',{'rowIds':[row['id']],'reference':'REF','reason':'范围'},'OS_GROUP')
  consolidate(d,'HW_GROUP')
  with self.assertRaises(DomainError):act(d,'erp_voucher_annotations_save',{'rowIds':[row['id']],'reference':'REF','reason':'锁定'},'HW_GROUP')
 def test_future_voucher_and_its_cancellation_do_not_invalidate_signed_previous_period(self):
  d=seed();sample(d);old=consolidate(d,'HW_GROUP');fingerprint=d['erp']['matchingByScope']['HW_GROUP:9']['erpInputFingerprint']
  future=penny(d).replace('2026-09-29','2026-10-29')
  act(d,'erp_voucher_import',{'csv':future},'HW_GROUP')
  batch=d['erp']['batches'][-1]['id']
  self.assertTrue(d['resultValidity'][old['id']]['valid']);self.assertTrue(d['erp']['matchingByScope']['HW_GROUP:9']['valid'])
  self.assertEqual(fingerprint,erp.scope_fingerprint(d,'HW_GROUP',9));self.assertTrue(all(r['passed'] for r in erp.precondition_rows(d,'HW_GROUP',9)))
  act(d,'erp_batch_cancel',{'batchId':batch,'reason':'仅撤销未来10月凭证'},'HW_GROUP')
  self.assertTrue(d['resultValidity'][old['id']]['valid']);self.assertTrue(d['erp']['matchingByScope']['HW_GROUP:9']['valid'])
 def test_cancelling_all_ledger_inputs_cannot_reuse_old_erp_source(self):
  d=seed();unlock(d);b=sample_bundle(d,['HW','HW_CAT','HW_ELEC'])
  act(d,'erp_mapping_save',{'csv':b['mappingCsv']});act(d,'erp_opening_import',{'csv':b['openingCsv']})
  opening_batch=d['erp']['batches'][-1]['id'];act(d,'erp_voucher_import',{'csv':b['voucherCsv']});voucher_batch=d['erp']['batches'][-1]['id']
  act(d,'erp_report_generate',{'entityIds':['HW','HW_CAT','HW_ELEC']})
  self.assertEqual(d['sources']['9']['HW']['sourceType'],'erp')
  act(d,'erp_batch_cancel',{'batchId':voucher_batch,'reason':'停用凭证以更正'})
  act(d,'erp_batch_cancel',{'batchId':opening_batch,'reason':'停用期初以更正'})
  self.assertFalse(erp.has_ledger(d,'HW',9))
  checks=erp.precondition_rows(d,'HW_GROUP',9);self.assertTrue(any(r['code']=='erp_source_HW' and not r['passed'] for r in checks))
  with self.assertRaises(DomainError):act(d,'consolidation_run',{},'HW_GROUP')
 def test_unspecified_customer_cannot_bypass_required_matching(self):
  d=seed();sample(d)
  text=penny(d).replace('HW00','OS01').replace('CNY','USD').replace(',外部,',',,')
  act(d,'erp_voucher_import',{'csv':text},'OS_GROUP');act(d,'erp_report_generate',{'entityIds':['OS_A']},'OS_GROUP')
  checks=erp.precondition_rows(d,'OS_GROUP',9);self.assertTrue(any(r['code']=='erp_matching' and not r['passed'] for r in checks))
  act(d,'erp_match_run',{},'OS_GROUP');run=d['erp']['matchingByScope']['OS_GROUP:9'];self.assertTrue(any(r['code']=='counterparty_required' for r in run['differences']))
  with self.assertRaises(DomainError):act(d,'consolidation_run',{},'OS_GROUP')
 def test_store_failed_import_rollback_restart_and_old_product_refusal(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=Store(tmp,seed);revision,d,_=store.read();store.mutate(revision,ROLE,'erp_sample_load',{'replace':True,'reason':'持久测试'},CTX,apply)
   rev,d,_=store.read();before=json.dumps(d,sort_keys=True,ensure_ascii=False)
   bad=penny(d).replace(',0.01,',',0.02,')
   # 明确不平衡的完整凭证。
   rows=list(csv.reader(io.StringIO(penny(d))));rows[1][6]='0.02';bad=csv_text(rows[0],rows[1:])
   with self.assertRaises(DomainError):store.mutate(rev,ROLE,'erp_voucher_import',{'csv':bad},CTX,apply)
   rev2,after,_=store.read();self.assertEqual(rev,rev2);self.assertEqual(before,json.dumps(after,sort_keys=True,ensure_ascii=False))
   self.assertEqual(Store(tmp,seed).read()[1],after)
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'epm-demo.sqlite3';db=sqlite3.connect(path);db.execute('CREATE TABLE state(id INTEGER,document TEXT)');db.execute('INSERT INTO state VALUES(1,?)',(json.dumps({'schemaVersion':2,'product':'SelfDevelopedEPM-Multilevel-Demo'}),));db.commit();db.close();h=hashlib.sha256(path.read_bytes()).hexdigest()
   with self.assertRaises(DomainError):Store(tmp,seed)
   self.assertEqual(h,hashlib.sha256(path.read_bytes()).hexdigest())
if __name__=='__main__':unittest.main()
