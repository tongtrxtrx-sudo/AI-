"""演示用EPM领域模型；所有金额和工作流由服务端校验。"""
from __future__ import annotations
import csv
import hashlib
import io
import json
import re
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
try:
    from .store import DomainError
    from .finance import seed_finance, statement, validate_journal
except ImportError:
    from store import DomainError
    from finance import seed_finance, statement, validate_journal

ROLES=('集团财务负责人','法人会计','审计只读')
PLAN_TYPES=('production','purchase','inventory','labor','expense','capital','cash')
Q=Decimal('0.01')
def now(): return datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')
def money(value, label='金额', negative=False, places=2):
    if isinstance(value,bool) or value is None or isinstance(value,(dict,list)):
        raise DomainError(f'{label}必须是有效数字。')
    try:
        if len(str(value))>40: raise InvalidOperation
        v=Decimal(str(value))
        if not v.is_finite() or abs(v)>Decimal('1000000000000'): raise InvalidOperation
    except (InvalidOperation,ValueError): raise DomainError(f'{label}必须是有限数字，且不能超过一万亿元。')
    if v.as_tuple().exponent < -places: raise DomainError(f'{label}最多保留{places}位小数。')
    if not negative and v<0: raise DomainError(f'{label}不能为负数。')
    return v

def number(v): return float(v.quantize(Q,rounding=ROUND_HALF_UP))
def text(value,label='说明',limit=500,required=True):
    if not isinstance(value,str): raise DomainError(f'{label}必须是文字。')
    v=value.strip()
    if (required and not v) or len(v)>limit or any(ord(c)<32 and c not in '\n\t' for c in v):
        raise DomainError(f'{label}不能为空且最多{limit}字。')
    return v

def seed():
    data=seed_finance()
    ratios={'MFG':8600/13800,'TEC':4450/13800,'TRD':2750/13800}
    layers=[{'label':'基础层','amount':16000},{'label':'挑战层','amount':1066.67},{'label':'管理层','amount':800},{'label':'董事会层','amount':533.33}]
    data.update({'companyName':'杭州天元宠物用品有限公司','settings':{'companyName':'杭州天元宠物用品有限公司','fiscalYear':2026,'language':'简体中文','unit':'万元'},'periods':{},'trialBalances':[],'periodOverrides':{},'journalSequence':len(data.get('journals',[])),'budget':{'version':'V2 年度目标','status':'编制中','spread':'even','layers':layers,'versions':[],'adjustments':[],'entityRatios':ratios,'entityRevenueRatios':ratios,'drivers':{'volume':2000,'price':9.2},'businessPlans':{k:[] for k in PLAN_TYPES}}})
    b=data['budget']
    for name,annual in [('V1 基准预算',18000),('V2 年度目标',18400)]:
        ls=deepcopy(layers);ls[3]['amount']=number(Decimal(str(ls[3]['amount']))+Decimal(annual)-Decimal(18400))
        b['versions'].append({'name':name,'scenario':'年度预算','annual':annual,'layers':ls,'spread':'even','status':'编制中','drivers':deepcopy(b['drivers']),'businessPlans':deepcopy(b['businessPlans'])})
    return data

def context(raw=None):
    raw=raw or {}
    if not isinstance(raw,dict):raise DomainError('筛选条件必须为对象。')
    month=raw.get('month',9)
    try:
        if isinstance(month,bool) or str(int(month))!=str(month): raise ValueError
        month=int(month)
    except (ValueError,TypeError): raise DomainError('期间必须是1至12月。')
    if not 1<=month<=12: raise DomainError('期间必须是1至12月。')
    group=raw.get('group','group');currency=raw.get('currency','CNY');entity=raw.get('entity','all')
    if group not in ('group','mfg') or currency not in ('CNY','USD'): raise DomainError('集团或币种筛选无效。')
    return {'group':group,'month':month,'currency':currency,'entity':entity}

def period(data,c):
    key=f"{c['group']}:{c['month']}"
    return data['periods'].setdefault(key,{'submissionChecked':False,'checksRun':False,'icConfirmed':False,'commentary':False,'signed':False,'icReason':'','commentaryText':'','checksFingerprint':'','signedAt':None})

def source_fingerprint(data,c):
    raw={k:data.get(k) for k in ('entities','monthly','rates','accounts')}
    raw['periodOverrides']=data.get('periodOverrides',{}).get(str(c['month']),{})
    raw['journals']=[j for j in data.get('journals',[]) if j.get('month',c['month'])==c['month']]
    raw['context']={**c,'currency':'CNY','entity':'all'}
    return hashlib.sha256(json.dumps(raw,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def invalidate(data, c=None, all_periods=False):
    ps=data['periods'].values() if all_periods else [period(data,c)]
    for p in ps:
        p.update({'checksRun':False,'submissionChecked':False,'checksFingerprint':'','icConfirmed':False,'signed':False,'signedAt':None})

def ensure_open(data,c,all_periods=False):
    ps=data['periods'].values() if all_periods else [period(data,c)]
    if any(p.get('signed') for p in ps): raise DomainError('期间已签核，负责人先执行重新开启并说明原因，才能修改财务数据。','period_locked',409)

def ensure_month_open(data,c):
    for key,p in data['periods'].items():
        if key.endswith(':'+str(c['month'])) and p.get('signed'):
            raise DomainError('该月份有关联集团已签核，请先由负责人重新开启后修改数据。','period_locked',409)

def invalidate_month(data,c):
    for key,p in data['periods'].items():
        if key.endswith(':'+str(c['month'])):
            p.update({'checksRun':False,'submissionChecked':False,'checksFingerprint':'','icConfirmed':False,'signed':False,'signedAt':None})

def checks_for(data,c):
    result=statement(data,{**c,'entity':'all','currency':'CNY'})['financial_checks']
    return deepcopy(result)

def budget_sync(b):
    current=next(v for v in b['versions'] if v['name']==b['version'])
    for k in ('layers','spread','status','drivers','businessPlans'):
        current[k]=deepcopy(b[k])
    current['annual']=number(sum((Decimal(str(x['amount'])) for x in b['layers']),Decimal(0)))

def draft(b):
    if b['status'] not in ('编制中','已退回'): raise DomainError('此预算版本已提交、审批或锁定，请复制版本或发起独立调整。','budget_locked',409)

def layer_index(v):
    if isinstance(v,bool) or not isinstance(v,int) or not 0<=v<=3: raise DomainError('预算层级必须为0至3。')
    return v

def find(items,key,value,label):
    item=next((x for x in items if x.get(key)==value),None)
    if item is None: raise DomainError(f'未找到{label}。')
    return item

def _apply(data,role,action,p,c):
    if role not in ROLES or role=='审计只读': raise DomainError('当前为审计只读角色，不能修改数据。','forbidden',403)
    if not isinstance(p,dict): raise DomainError('操作参数必须为对象。')
    manager=role==ROLES[0]
    approved={'budget_approve','budget_lock','budget_adjust_approve','budget_adjust_reject','signoff','period_reopen','settings_save','journal_approve','account_save','rate_save','entity_save'}
    if action in approved and not manager: raise DomainError('此操作需要集团财务负责人权限。','forbidden',403)
    b=data['budget'];per=period(data,c)
    if action.startswith('budget_'):
        if action=='budget_layer_save':
            draft(b); i=layer_index(p.get('layer'));b['layers'][i]['amount']=number(money(p.get('amount')))
            detail=f"修改预算{b['layers'][i]['label']}"
        elif action=='budget_spread':
            draft(b);spread=p.get('spread')
            if spread not in ('even','seasonal'): raise DomainError('分摊方式无效。')
            b['spread']=spread;detail='保存预算全年分摊方式'
        elif action=='budget_driver':
            draft(b);volume=money(p.get('volume'),'数量');price=money(p.get('price'),'单价')
            if volume!=volume.to_integral_value(): raise DomainError('数量必须为整数。')
            total=(volume*price).quantize(Q,rounding=ROUND_HALF_UP)
            base=sum((Decimal(str(x['amount'])) for x in b['layers'][:3]),Decimal(0))
            if total<base: raise DomainError('量价目标不能小于前三层预算合计。')
            b['layers'][3]['amount']=number(total-base);b['drivers']={'volume':number(volume),'price':number(price)};detail='保存量价模型并更新董事会层预算'
        elif action=='budget_submit':
            draft(b);b['status']='审核中';detail='提交预算审核'
        elif action=='budget_approve':
            if b['status']!='审核中': raise DomainError('仅审核中的预算可审批。','invalid_state',409)
            b['status']='已审批';detail='审批预算'
        elif action=='budget_lock':
            if b['status']!='已审批': raise DomainError('仅已审批预算可锁定。','invalid_state',409)
            b['status']='已锁定';detail='锁定预算'
        elif action=='budget_copy':
            budget_sync(b);name=text(p.get('name'),'版本名称',40)
            if any(v['name']==name for v in b['versions']): raise DomainError('版本名称已存在。')
            scenario=text(p.get('scenario','年度预算'),'预算场景',30)
            v=deepcopy(next(v for v in b['versions'] if v['name']==b['version']));v.update(name=name,scenario=scenario,status='编制中');b['versions'].append(v);b['version']=name;b['status']='编制中';detail=f'复制预算版本：{name}'
        elif action=='budget_switch':
            budget_sync(b);v=find(b['versions'],'name',p.get('name'),'预算版本');b['version']=v['name']
            for k in ('layers','spread','status','drivers','businessPlans'): b[k]=deepcopy(v[k])
            detail=f"切换预算版本：{v['name']}"
        elif action=='budget_adjust_create':
            i=layer_index(p.get('layer'));delta=money(p.get('delta'),'调整金额',True);reason=text(p.get('reason'),'调整原因')
            if delta==0: raise DomainError('调整金额不能为零。')
            if Decimal(str(b['layers'][i]['amount']))+delta<0: raise DomainError('调整后层级金额不能为负数。')
            a={'id':f"ADJ-{len(b['adjustments'])+1:03d}",'version':b['version'],'layer':i,'delta':number(delta),'reason':reason,'status':'待审批','sourceAnnual':number(sum((Decimal(str(x['amount'])) for x in b['layers']),Decimal(0))),'sourceLayers':deepcopy(b['layers']),'sourceSpread':b['spread'],'sourceDrivers':deepcopy(b['drivers']),'sourcePlans':deepcopy(b['businessPlans']),'createdAt':now()}
            b['adjustments'].append(a);detail=f"提交独立预算调整{a['id']}"
        elif action in ('budget_adjust_approve','budget_adjust_reject'):
            a=find(b['adjustments'],'id',p.get('id'),'预算调整')
            if a['status']!='待审批': raise DomainError('此调整已处理，不能重复审批。','invalid_state',409)
            if action=='budget_adjust_reject':a['status']='已退回';a['reviewReason']=text(p.get('reason','退回修改'),'退回原因');detail=f"退回预算调整{a['id']}"
            else:
                budget_sync(b);name=f"V{len(b['versions'])+1} 调整批准";ls=deepcopy(a['sourceLayers']);i=a['layer'];ls[i]['amount']=number(Decimal(str(ls[i]['amount']))+Decimal(str(a['delta'])))
                v={'name':name,'scenario':'预算调整','annual':number(Decimal(str(a['sourceAnnual']))+Decimal(str(a['delta']))),'layers':ls,'spread':a['sourceSpread'],'status':'已审批','drivers':deepcopy(a['sourceDrivers']),'businessPlans':deepcopy(a['sourcePlans'])};b['versions'].append(v);b['version']=name
                for k in ('layers','spread','status','drivers','businessPlans'): b[k]=deepcopy(v[k])
                a['status']='已批准';a['newVersion']=name;detail=f"批准调整{a['id']}并生成独立版本{name}"
        elif action=='budget_plan_save':
            draft(b);kind=p.get('type');rows=p.get('rows')
            if kind not in PLAN_TYPES or not isinstance(rows,list) or len(rows)>200: raise DomainError('预算明细类型或行数无效。')
            clean=[];seen_plan_ids=set()
            for i,r in enumerate(rows):
                if not isinstance(r,dict): raise DomainError('预算明细行无效。')
                qty=money(r.get('quantity',0),'数量');price=money(r.get('price',0),'单价');calculated=(qty*price).quantize(Q,rounding=ROUND_HALF_UP);amount=money(r.get('amount',number(calculated)),'预算金额')
                if amount!=calculated:raise DomainError(f'第{i+1}行预算金额必须等于数量×单价（保留两位小数）。')
                plan_id=text(str(r.get('id',i+1)),'明细标识',40)
                if plan_id in seen_plan_ids:raise DomainError('预算明细标识重复。')
                seen_plan_ids.add(plan_id)
                clean.append({'id':plan_id,'name':text(r.get('name'),'预算项目',100),'quantity':number(qty),'price':number(price),'amount':number(amount),'note':text(r.get('note',''),'备注',300,False)})
            b['businessPlans'][kind]=clean;detail='保存业务预算明细'
        else: raise DomainError('不支持的预算操作。','unknown_action',404)
        budget_sync(b)
        return detail
    if action=='checks_run':
        ensure_open(data,c);checks=checks_for(data,c);per['checksRun']=all(x['passed'] for x in checks);per['checksFingerprint']=source_fingerprint(data,c);per['checks']=checks
        return f"运行{c['month']}月财务校验：{'通过' if per['checksRun'] else '存在差异'}"
    if action=='submission_confirm':
        ensure_open(data,c)
        if not all(x['passed'] for x in checks_for(data,c)): raise DomainError('财务勾稽存在差异，不能确认报送。')
        per['submissionChecked']=True;return f"确认{c['month']}月法人报送"
    if action=='ic_confirm':
        ensure_open(data,c);per['icReason']=text(p.get('reason'),'内部交易核对说明');per['icConfirmed']=True;return '保存内部交易核对说明'
    if action=='commentary_save':
        ensure_open(data,c);per['commentaryText']=text(p.get('text'),'经营分析说明',3000);per['commentary']=True;return '保存经营分析说明'
    if action=='signoff':
        ensure_open(data,c)
        if not (per['submissionChecked'] and per['checksRun'] and per['icConfirmed'] and per['commentary']): raise DomainError('签核前需完成法人报送确认、财务校验、内部交易说明和经营说明。','incomplete_workflow',409)
        if per['checksFingerprint']!=source_fingerprint(data,c) or not all(x['passed'] for x in checks_for(data,c)): raise DomainError('数据已变更，请重新校验后签核。','stale_checks',409)
        per['signed']=True;per['signedAt']=now();return f"完成{c['month']}月集团签核"
    if action=='period_reopen':
        reason=text(p.get('reason'),'重新开启原因');invalidate(data,c);return f"重新开启{c['month']}月：{reason}"
    if action=='entity_save':
        ensure_open(data,c,True);identifier=text(p.get('id'),'法人标识',20)
        if not re.fullmatch(r'[A-Z][A-Z0-9_-]{1,19}',identifier): raise DomainError('法人标识需为2至20位大写字母、数字、下划线或短横线。')
        existing=next((e for e in data['entities'] if e['id']==identifier),None)
        fields={k:text(p.get(k,existing.get(k,'') if existing else ''),{'code':'法人编码','name':'法人名称','short':'法人简称','owner':'报送负责人','currency':'币种'}.get(k,k),100) for k in ('code','name','short','owner','currency')}
        if fields['currency'] not in ('CNY','人民币'):raise DomainError('演示法人记账本位币为人民币。')
        if any(e['code']==fields['code'] and e['id']!=identifier for e in data['entities']): raise DomainError('法人编码重复。')
        if existing:existing.update(fields)
        else:
            e={'id':identifier,**fields,**{k:0 for k in ('revenue','cost','expense','finance','tax','net')},'opening':{k:0 for k in data['entities'][0]['opening']},'closing':{k:0 for k in data['entities'][0]['closing']},'cashflow':{'operating':0,'investing':0,'financing':0}};data['entities'].append(e);data['budget']['entityRatios'][identifier]=0;data['budget']['entityRevenueRatios'][identifier]=0
        invalidate(data,c,True);return f"保存法人：{fields['name']}"
    if action=='account_save':
        ensure_open(data,c,True);code=text(p.get('code'),'科目编码',20);name=text(p.get('name'),'科目名称',100)
        allowed={a['field'] for a in data['accounts']};typ=p.get('type');side=p.get('normalSide')
        if not re.fullmatch(r'[0-9A-Za-z_-]{1,20}',code) or p.get('field') not in allowed or side not in ('借','贷') or typ not in ('资产','负债','权益','收入','成本','费用','税费'): raise DomainError('科目编码、类别、报表字段或余额方向无效。')
        old=next((a for a in data['accounts'] if a['code']==code),None)
        if old:old.update(name=name,type=typ,field=p['field'],normalSide=side)
        else:data['accounts'].append({'code':code,'name':name,'type':typ,'field':p['field'],'normalSide':side})
        invalidate(data,c,True);return f'保存集团科目：{name}'
    if action=='rate_save':
        ensure_open(data,c,True)
        if p.get('currency')!='USD':raise DomainError('当前演示支持人民币和美元折算。')
        rate=money(p.get('rate'),'美元汇率',places=6)
        if rate<=0 or rate>Decimal('1000000'):raise DomainError('汇率必须大于零且不超过1000000。')
        if isinstance(data['rates'],dict):data['rates']['USD']=float(rate)
        else:
            r=next((r for r in data['rates'] if r['currency']=='USD'),None)
            if r:r['rate']=float(rate)
            else:data['rates'].append({'currency':'USD','rate':float(rate),'name':'美元'})
        invalidate(data,c,True);return '保存美元折算汇率'
    if action in ('journal_create','journal_save'):
        ensure_month_open(data,c);rows=p.get('lines')
        if not isinstance(rows,list) or not 2<=len(rows)<=100:raise DomainError('凭证需2至100行分录。')
        lines=[];debit=credit=Decimal(0);effects={}
        for i,r in enumerate(rows):
            if not isinstance(r,dict):raise DomainError('凭证明细无效。')
            account=find(data['accounts'],'code',r.get('accountCode'),'集团科目');d=money(r.get('debit',0),f'第{i+1}行借方');cr=money(r.get('credit',0),f'第{i+1}行贷方')
            if (d>0)==(cr>0):raise DomainError('每行需填写且仅填写一个方向的正金额。')
            debit+=d;credit+=cr;field=account['field'];effect=d-cr if account['normalSide']=='借' else cr-d;effects[field]=number(Decimal(str(effects.get(field,0)))+effect)
            lines.append({'accountCode':account['code'],'account':account['name'],'debit':number(d),'credit':number(cr),'direction':'借' if d else '贷','amount':number(d or cr)})
        if debit!=credit:raise DomainError(f'凭证借贷不平衡，借方{debit}，贷方{credit}。')
        if effects.get('cash',0):
            category=p.get('cashflowCategory')
            if category not in ('operating','investing','financing'):raise DomainError('包含现金科目的凭证必须选择经营、投资或筹资现金流类别。')
            effects[category]=effects['cash']
        data['journalSequence']+=1;j={'id':f"J-{data['journalSequence']:03d}",'title':text(p.get('title'),'凭证摘要',100),'kind':text(p.get('kind','合并调整'),'凭证类型',30),'reason':text(p.get('reason','演示合并调整'),'调整说明'),'status':'草稿','lines':lines,'effects':effects,'month':c['month'],'period':f"{data['settings']['fiscalYear']}-{c['month']:02d}",'group':c['group'],'createdAt':now()}
        try:validate_journal(j)
        except ValueError as ex:raise DomainError(str(ex)) from None
        data['journals'].append(j);return f"保存凭证草稿{j['id']}"
    if action=='journal_approve':
        j=find(data['journals'],'id',p.get('id'),'调整凭证');jc={**c,'month':j.get('month',c['month'])};ensure_month_open(data,jc)
        if j['status']!='草稿':raise DomainError('仅草稿凭证可以审批。','invalid_state',409)
        try:validate_journal(j)
        except ValueError as ex:raise DomainError(str(ex)) from None
        j['status']='已审批';invalidate_month(data,jc);return f"审批凭证{j['id']}"
    if action=='tb_import':
        ensure_month_open(data,c);return import_tb(data,p,c)
    if action=='settings_save':
        company=text(p.get('companyName',data['companyName']),'公司名称',100)
        year=p.get('fiscalYear',data['settings']['fiscalYear'])
        if isinstance(year,bool) or not isinstance(year,int) or year!=2026:raise DomainError('本演示只维护2026年独立账套；新会计年度需要正式研发支持，不能重标源财务数据。')
        if year!=data['settings']['fiscalYear'] and (data['trialBalances'] or any(x.get('signed') for x in data['periods'].values())):raise DomainError('已有报送或签核数据，不能直接切换会计年度。')
        data['companyName']=company;data['settings'].update(companyName=company,fiscalYear=year);return '保存集团系统设置'
    raise DomainError('未知业务操作。','unknown_action',404)


def import_tb(data,p,c):
    raw=p.get('csv')
    if not isinstance(raw,str) or len(raw)>2_000_000:raise DomainError('请提供小于2MB的UTF-8 CSV文本。')
    reader=csv.DictReader(io.StringIO(raw.lstrip('\ufeff')))
    expected=['法人编码','期间','科目编码','借方余额','贷方余额']
    if reader.fieldnames!=expected:raise DomainError('CSV表头须为：'+','.join(expected))
    groups={};seen=set();count=0;year=data['settings']['fiscalYear']
    for row in reader:
        count+=1
        if count>10000:raise DomainError('CSV最多10000行。')
        try:
            if None in row:raise DomainError('CSV列数超过模板，请检查多余逗号。')
            e=next((e for e in data['entities'] if e['code']==row['法人编码'] or e['id']==row['法人编码']),None)
            if not e:raise DomainError('法人编码不存在。')
            if row['期间']!=f'{year}-{c["month"]:02d}':raise DomainError('期间需与当前选择的会计期间一致。')
            a=find(data['accounts'],'code',row['科目编码'],'科目');key=(e['id'],a['code'])
            if key in seen:raise DomainError('同一法人科目重复。')
            seen.add(key);d=money(row['借方余额'],'借方余额');cr=money(row['贷方余额'],'贷方余额')
            if d>0 and cr>0:raise DomainError('同一科目不能同时填写借贷余额。')
            item=groups.setdefault(e['id'],{'entity':e,'rows':[],'debit':Decimal(0),'credit':Decimal(0),'fields':{}})
            item['rows'].append({'code':a['code'],'debit':number(d),'credit':number(cr)});item['debit']+=d;item['credit']+=cr
            value=d-cr if a['normalSide']=='借' else cr-d;f=a['field'];item['fields'][f]=item['fields'].get(f,Decimal(0))+value
        except DomainError as ex:raise DomainError(f'CSV第{count+1}行：{ex.message}')
    if not groups:raise DomainError('CSV没有数据行。')
    batch={'id':f"TB-{len(data['trialBalances'])+1:03d}",'month':c['month'],'rowCount':count,'importedAt':now(),'sourceName':text(p.get('sourceName','手工CSV报送'),'来源名称',150),'entities':list(groups),'rows':[]}
    for eid,item in groups.items():
        if item['debit']!=item['credit']:raise DomainError(f"法人{eid}试算不平衡：借方{item['debit']}，贷方{item['credit']}。整批未导入。")
        fields=item['fields'];original=item['entity'];bs={k:number(fields.get(k,Decimal(0))) for k in original['closing']}
        pl={k:number(fields.get(k,Decimal(0))) for k in ('revenue','cost','expense','finance','tax')};net=Decimal(str(pl['revenue']))-sum((Decimal(str(pl[k])) for k in ('cost','expense','finance','tax')),Decimal(0))
        # 试算中的未分配利润包含期初留存收益；当期损益在报表计算时结转。
        bs['retained']=number(Decimal(str(bs.get('retained',0)))+net)
        opening=deepcopy(original['opening']);invest=Decimal(str(original['cashflow'].get('investing',0)));financing=Decimal(str(original['cashflow'].get('financing',0)))
        cash_delta=Decimal(str(bs.get('cash',0)))-Decimal(str(opening.get('cash',0)))
        override={**pl,'net':number(net),'closing':bs,'opening':opening,'cashflow':{'operating':number(cash_delta-invest-financing),'investing':number(invest),'financing':number(financing)},'sourceBatch':batch['id'],'profitClosed':True,'cashflowEstimated':True}
        data['periodOverrides'].setdefault(str(c['month']),{})[eid]=override;batch['rows'].extend({'entity':eid,**r} for r in item['rows'])
    batch['entity']=','.join(groups);data['trialBalances'].append(batch);invalidate_month(data,c)
    return f"导入{count}行试算余额（{len(groups)}家法人），批次{batch['id']}"


def bootstrap(data,revision,activities,role,c):
    c=context(c)
    if c['entity']!='all' and not any(e['id']==c['entity'] for e in data['entities']):raise DomainError('法人筛选不存在。')
    try:report=statement(data,c)
    except ValueError as ex:raise DomainError(str(ex)) from None
    per=period(data,c);fingerprint=source_fingerprint(data,c)
    # 读接口也显式展示旧校验失效，绝不沿用客户端标志。
    if per['checksRun'] and per['checksFingerprint']!=fingerprint:per['checksRun']=False
    result={k:deepcopy(data.get(k)) for k in ('companyName','entities','monthly','budget','journals','periods','settings','accounts','rates','trialBalances','ownership')}
    if isinstance(result['rates'],dict):result['rates']=[{'currency':k,'rate':v,'name':'美元' if k=='USD' else k} for k,v in result['rates'].items()]
    result.update(revision=revision,sessionRole=role,activities=activities,statement=report,report=report,period=deepcopy(per),checks=checks_for(data,c),context=c,capabilities={'canWrite':role!='审计只读','canApprove':role==ROLES[0],'canSignoff':role==ROLES[0],'canConfigure':role==ROLES[0]})
    result['entityActuals']=[{'id':e['id'],**statement(data,{**c,'group':'group','entity':e['id']})['actual']} for e in data['entities']]
    # 每月金额用相邻累计口径相减，返回与报表相同币种和单位。
    cumulative=[statement(data,{**c,'month':m})['actual']['revenue'] for m in range(1,13)]
    result['monthlyActuals']=[round(v-(cumulative[i-1] if i else 0),2) for i,v in enumerate(cumulative)]
    return result


def apply(data,role,action,p,c):
    detail=_apply(data,role,action,p,c)
    if action in ('tb_import','journal_create','journal_save','journal_approve','rate_save','account_save','entity_save'):
        try:
            # 在SQLite提交前验证读取投影，不能先写坏账套再返回500。
            for month in range(1,13):
                statement(data,{**c,'month':month,'currency':'CNY','entity':'all'})
            statement(data,{**c,'currency':'USD','entity':'all'})
        except (ValueError,TypeError,KeyError) as ex:
            raise DomainError('财务数据无法生成报表：'+str(ex)) from None
    return detail
