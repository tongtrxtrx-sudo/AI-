# 天元EPM空框架后端

软件基线FOUNDATION-20261028，product=`SelfDevelopedEPM-Foundation-Demo`，schemaVersion=4，cookie=`epm_foundation_session`。默认无法人、科目、持股、账务、交易、抵销或合并结果；只有`TY_GROUP`空技术容器用于从零建档导航。旧版/未知数据目录先只读识别后拒绝，不迁入或覆盖。

用户从创建集团本部和子法人、维护真实全资持股、创建管理合并范围和集团科目开始，随后维护法人ERP科目映射、NC账簿与客商，导入年初余额、完整财务凭证及累计科目余额核对基准，生成单体三表、核对原账、匹配内部交易、审批自动抵销，再逐层计算签核。

本机标准库启动示例：

```sh
python -I backend/server.py --data-dir /tmp/foundation-private-data --port 0 --no-browser --static-dir frontend/dist
```

Windows交付包自带私有运行环境，用户无需安装Python。数据目录由启动器设为`%LOCALAPPDATA%\TianyuanEPMFoundationDemo`。不要公开启动输出中的凭据、instance.json、数据库或日志；公开证据只包含匿名业务断言和源摘要。

- `engine.py`：空初始化、API投影和外部动作边界。`seed_demo()`仅供保留的旧回归夹具，运行服务只用`seed()`；不能通过API载入旧7家演示数据。
- `multilevel_domain.py` / `consolidation.py`：主数据、全资管理树、汇率、分级结果、签核及不可变历史。
- `erp_domain.py` / `ledger.py`：NC6.5 CSV/XLSX及通用凭证、期初、真实分录三表、匹配差异、自动抵销与凭证追溯。
- `balance_domain.py`：外部科目余额表与原始账务逐科目比较，原账包括损益结转；核对资料不重复入账。
- `store.py`：SQLite单事务、revision、审计、旧数据保护。
- `server.py`：127.0.0.1、会话、Origin/CSRF、静态前端、启动/退出协议。

当前正式合并须所有叶子有最新ERP凭证源及当前余额核对；手工源写入、手工内部销售抵销被外部命令边界拒绝，不能绕过原凭证异常闭环。投资权益仍按真实持股及源余额明确维护。仅当前scope可生成指定法人报表。

契约见API-CONTRACT.md、FOUNDATION-CONTRACT.md、LEDGER-CONTRACT.md和CALCULATION-CONTRACT.md。会计范围为2026、100%全资全额、CNY/USD普通主体；线上NC同步、复杂权益、商誉、少数股东及未实现内部存货利润等须后续研发验收。

运行实际领域回归：`python -B -m unittest discover -s backend -v`。本版独立证据以`verification/foundation-domain-tests.json`及acceptance目录实际HTTP/浏览器记录为准，不能把旧测试夹具数字当作默认业务数据。
