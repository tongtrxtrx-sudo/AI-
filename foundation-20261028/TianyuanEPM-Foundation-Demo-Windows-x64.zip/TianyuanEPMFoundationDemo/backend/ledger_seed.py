"""完整虚构ERP导出样例，足以由凭证重建七法人及三层黄金报表。"""
from __future__ import annotations
from copy import deepcopy
from decimal import Decimal
import csv,io,json
from pathlib import Path
try:
 from .ledger import MAPPING_HEADERS,OPENING_HEADERS,VOUCHER_HEADERS,FIELD_NAMES,DEBIT_FIELDS,parse_mappings_csv,parse_openings_csv,parse_vouchers_csv,parse_nc_vouchers
 from .multilevel_seed import monthly
except ImportError:
 from ledger import MAPPING_HEADERS,OPENING_HEADERS,VOUCHER_HEADERS,FIELD_NAMES,DEBIT_FIELDS,parse_mappings_csv,parse_openings_csv,parse_vouchers_csv,parse_nc_vouchers
 from multilevel_seed import monthly
NC65_HEADERS=('核算账簿', '凭证类别编码', '凭证号', '附单据数', '制单人编码', '制单日期', '摘要', '科目编码', '币种', '原币借方金额', '本币借方金额', '集团本币借方金额', '全局本币借方金额', '业务单元编码', '单价', '借方数量', '贷方数量', '原币贷方金额', '本币贷方金额', '集团本币贷方金额', '全局本币贷方金额', '结算号', '结算日期', '核销号', '业务日期', '银行账户', '票据类型', '结算方式', '报税国家', '收货国', '交易代码', '客户VAT注册码', '供应商VAT注册码', '税码', 'VAT方向', '计税金额', '组织本币汇率', '集团本币汇率', '全局本币汇率', '辅助核算1', '辅助核算2', '辅助核算3', '辅助核算4', '辅助核算5', '辅助核算6', '辅助核算7', '辅助核算8', '辅助核算9')
CODES={'cash':'100201','receivable':'112201','inventory':'140501','prepaid':'112301','investment':'151101','fixed':'160101','intangible':'170101','deferred_asset':'181101','payable':'220201','shortloan':'200101','taxpayable':'222101','otherliability':'224101','longloan':'250101','deferred_liability':'290101','capital':'400101','retained':'410401','nci':'400201','cta':'400301','revenue':'600101','cost':'640101','expense':'660201','finance':'660301','tax':'680101'}
def _csv(headers,rows):
 out=io.StringIO();w=csv.writer(out);w.writerow(headers);w.writerows(rows);return out.getvalue()
def _yuan(wan):return format((Decimal(str(wan))*10000).quantize(Decimal('.01')),'f')
def sample_bundle(data,entity_ids=None):
 entities=[e for e in data['entities'] if entity_ids is None or e['id'] in entity_ids];ids={e['id'] for e in entities};byid={e['id']:e for e in data['entities']}
 specs={'TY':(950,0,0,0,0),'HW':(100,1000,600,100,0),'HW_CAT':(50,300,180,30,0),'HW_ELEC':(50,200,120,20,0),'OTHER':(100,600,360,60,0),'OS_A':(50,50,0,40,40),'OS_B':(50,50,0,40,40)}
 if any(e['id'] not in specs for e in entities):raise ValueError('完整种子样例仅适用于七家预置虚构法人；新建法人请用空模板维护。')
 mappings=[];openings=[];vouchers=[];bookmaps=[];counterparties=[{'code':'EXT','entityId':'EXTERNAL'}]
 for e in entities:
  eid=e['id'];bookmaps.append({'bookCode':'BOOK-'+eid,'entityId':eid,'functionalCurrency':e['currency']});counterparties.append({'code':'IC-'+eid,'entityId':eid})
  for field,code in CODES.items():mappings.append([e['code'],code,FIELD_NAMES[field],field,'借' if field in DEBIT_FIELDS else '贷'])
  cap=specs[eid][0];asset='investment' if eid=='TY' else 'cash'
  openings += [[e['code'],2026,CODES[asset],e['currency'],_yuan(cap),'0','外部','',''],[e['code'],2026,CODES['capital'],e['currency'],'0',_yuan(cap),'外部','','']]
 def voucher(eid,month,tag,legs,other='外部',reference=''):
  if eid not in ids:return
  e=byid[eid];number=f'{month:02d}-{tag}'
  for i,(field,debit,credit,ic,cf) in enumerate(legs,1):
   if Decimal(str(debit))==0 and Decimal(str(credit))==0:continue
   vouchers.append([e['code'],f'2026-{month:02d}-25','记',number,i,CODES[field],_yuan(debit),_yuan(credit),e['currency'],'虚构ERP演示：'+tag,other,reference,ic,cf,'业务'])
 def income(eid,m,amount,tag,other='外部',reference='',credit_sale=False):
  if not amount:return
  voucher(eid,m,tag,[('receivable' if credit_sale else 'cash',amount,0,'receivable' if credit_sale else '','' if credit_sale else '经营'),('revenue',0,amount,'sales' if other!='外部' else '','')],other,reference)
 def payment(eid,m,amount,field,tag,other='外部',reference='',credit_purchase=False):
  if not amount:return
  voucher(eid,m,tag,[(field,amount,0,'cost' if other!='外部' and field=='cost' else '',''),('payable' if credit_purchase else 'cash',0,amount,'payable' if credit_purchase else '','' if credit_purchase else '经营')],other,reference)
 for m in range(1,10):
  lower=Decimal(str(monthly(100,9)[str(m)]));upper=Decimal(str(monthly(50,9)[str(m)]))
  for eid,(cap,revenue,cost,expense,loan) in specs.items():
   if eid=='TY':continue
   rev=Decimal(str(monthly(revenue,9)[str(m)]));co=Decimal(str(monthly(cost,9)[str(m)]));ex=Decimal(str(monthly(expense,9)[str(m)]));ln=Decimal(str(monthly(loan,9)[str(m)]))
   if eid=='HW':
    income(eid,m,lower,'IC-CAT','HW_CAT',f'HW-CAT-2026-{m:02d}',True)
    income(eid,m,upper,'IC-OTHER','OTHER',f'HW-OTHER-2026-{m:02d}')
    rev-=lower+upper
   if eid=='HW_CAT':
    payment(eid,m,lower,'cost','IC-HW','HW',f'HW-CAT-2026-{m:02d}',True);co-=lower
   if eid=='OTHER':
    payment(eid,m,upper,'cost','IC-HW','HW',f'HW-OTHER-2026-{m:02d}');co-=upper
   income(eid,m,rev,'EXTERNAL-SALES');payment(eid,m,co,'cost','EXTERNAL-COST');payment(eid,m,ex,'expense','EXTERNAL-EXPENSE')
   if ln:voucher(eid,m,'BANK-LOAN',[('cash',ln,0,'','筹资'),('longloan',0,ln,'','')])
 mappingcsv=_csv(MAPPING_HEADERS,mappings);openingcsv=_csv(OPENING_HEADERS,openings);vouchercsv=_csv(VOUCHER_HEADERS,vouchers)
 return {'mappings':mappingcsv,'openings':openingcsv,'vouchers':vouchercsv,'mappingCsv':mappingcsv,'openingCsv':openingcsv,'voucherCsv':vouchercsv,'bookMappings':bookmaps,'counterpartyMappings':counterparties,'importOptions':{'auxiliaryColumn':'辅助核算1','auxiliaryColumns':['辅助核算1'],'referenceColumn':'核销号'},'entityIds':sorted(ids),'amountUnit':'元','note':'虚构已记账业务凭证；鸿旺内部100为未结算销售，同时生成应收/应付100。其他源及全集团金样保持2650/770/74/90。'}

def seed_erp(data,entity_ids=None):
 bundle=sample_bundle(data,entity_ids)
 erp={'mappings':parse_mappings_csv(data,bundle['mappings']),'openings':parse_openings_csv(data,bundle['openings']),'vouchers':parse_vouchers_csv(data,bundle['vouchers']),'batches':[],'version':1,'bookMappings':bundle['bookMappings'],'counterpartyMappings':bundle['counterpartyMappings'],'importOptions':bundle['importOptions']}
 return erp

def nc_sample_csv(data,entity_ids=None):
 bundle=sample_bundle(data,entity_ids);canonical=parse_vouchers_csv(data,bundle['vouchers'])
 headers=list(NC65_HEADERS)
 rows=[]
 for r in canonical:
  values=dict.fromkeys(headers,'');values.update({'核算账簿':'BOOK-'+r['entityId'],'凭证类别编码':r['category'],'凭证号':r['rawVoucherNo'],'附单据数':'0','制单人编码':'DEMO','制单日期':r['date'],'摘要':r['summary'],'科目编码':r['accountCode'],'币种':r['currency'],'原币借方金额':r['debit'],'本币借方金额':r['debit'],'原币贷方金额':r['credit'],'本币贷方金额':r['credit'],'集团本币借方金额':'0','全局本币借方金额':'0','集团本币贷方金额':'0','全局本币贷方金额':'0','辅助核算1':'IC-'+r['counterpartyId'] if r.get('counterpartyId') else 'EXT','核销号':r['reference']})
  rows.append([values[h] for h in headers])
 return _csv(headers,rows)
