import csv,io,json,sys,unittest,zipfile
from copy import deepcopy
from decimal import Decimal
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ledger import *
from ledger_seed import seed_erp,sample_bundle,nc_sample_csv,CODES
from multilevel_seed import seed_multilevel
from consolidation import calculate_unit

class LedgerTests(unittest.TestCase):
 def setUp(self):self.data=seed_multilevel();self.erp=seed_erp(self.data)
 def test_complete_seven_entity_vouchers_roll_up_golden(self):
  d=self.data;e=self.erp
  for entity in d['entities']:
   r=generate_source(d,e,entity['id'],9);self.assertTrue(all(c['passed'] for c in r['checks']));d['sources']['9'][entity['id']]=r['source']
  hw=match_ic(d,e,'HW_GROUP',9);root=match_ic(d,e,'TY_GROUP',9)
  self.assertEqual(len(hw['differences']),0);self.assertEqual(len(root['differences']),0)
  self.assertEqual(sum(m['amount'] for m in hw['matches'] if m['kind']=='sales'),100)
  self.assertEqual(sum(m['amount'] for m in hw['matches'] if m['kind']=='balances'),100)
  self.assertEqual(sum(m['amount'] for m in root['matches']),50)
  d['eliminations']=[x for x in d['eliminations'] if x['kind']=='investment']+[{**m,'status':'已审批','version':1} for m in hw['matches']+root['matches']]
  children={}
  for uid in ['HW_GROUP','OS_GROUP','TY_GROUP']:
   r=calculate_unit(d,uid,9,children);r.update(id='TEST-'+uid,resultVersion=1,approvalStatus='已签核',valid=True);children[uid]=r
  self.assertEqual({k:children['TY_GROUP']['statement']['actual'][k] for k in ['revenue','net','assets','liabilities','cta','cashFx']},{'revenue':2650,'net':770,'assets':2370,'liabilities':576,'cta':74,'cashFx':90})
 def test_nc48_roundtrip_uses_only_functional_amounts(self):
  nc=nc_sample_csv(self.data);parsed=parse_nc_vouchers(self.data,self.erp,nc)
  e={**self.erp,'vouchers':parsed}
  self.assertEqual(len(parsed),396)
  self.assertEqual(generate_source(self.data,e,'HW',9)['source']['profit']['revenue'],1000)
  inp=list(csv.DictReader(io.StringIO(nc)));pair=[r for r in inp if r['核算账簿']=='BOOK-HW'][:2]
  for row in pair:
   positive=Decimal(row['本币借方金额'])!=0
   row['币种']='USD';row['原币借方金额']='1' if positive else '0';row['原币贷方金额']='0' if positive else '1';row['本币借方金额']='7' if positive else '0';row['本币贷方金额']='0' if positive else '7';row['集团本币借方金额']='123';row['集团本币贷方金额']='456'
  text=_write(list(inp[0]),pair);rows=parse_nc_vouchers(self.data,self.erp,text)
  self.assertEqual(rows[0]['currency'],'CNY');self.assertEqual(rows[0]['transactionCurrency'],'USD')
  self.assertEqual(rows[0]['debit'],'7.00');self.assertEqual(rows[0]['originalDebit'],'1.00')
  r=generate_source(self.data,{**self.erp,'vouchers':rows},'HW',1)
  self.assertEqual(r['source']['profit']['revenue'],.0007)
 def test_nc_star_headers_and_zero_group_global_not_counted(self):
  text=nc_sample_csv(self.data);reader=csv.DictReader(io.StringIO(text));rows=list(reader)
  renamed=[' * '+h+' ' for h in reader.fieldnames];out=io.StringIO();w=csv.writer(out);w.writerow(renamed)
  for row in rows:w.writerow([row[h] for h in reader.fieldnames])
  self.assertEqual(len(parse_nc_vouchers(self.data,self.erp,'\ufeff'+out.getvalue())),396)
 def test_nc_multi_aux_conflict_and_external_are_explicit(self):
  rows=list(csv.DictReader(io.StringIO(nc_sample_csv(self.data))))
  selected=[r for r in rows if r['核算账簿']=='BOOK-HW'][:2]
  for r in selected:r['辅助核算1']='CUSTOMER';r['辅助核算2']='SUPPLIER'
  e=deepcopy(self.erp);e['importOptions']['auxiliaryColumns']=['辅助核算1','辅助核算2'];e['counterpartyMappings']=[{'column':'辅助核算1','code':'CUSTOMER','entityId':'HW_CAT'},{'column':'辅助核算2','code':'SUPPLIER','entityId':'HW_ELEC'}]
  v=parse_nc_vouchers(self.data,e,_write(list(rows[0]),selected));self.assertTrue(all(r['counterpartyConflict'] for r in v));e['vouchers']=v
  matches=match_ic(self.data,e,'HW_GROUP',1);self.assertFalse(matches['matches']);self.assertTrue(matches['differences'])
 def test_nc_unique_voucher_customer_and_reference_propagate_without_changing_raw(self):
  rows=list(csv.DictReader(io.StringIO(nc_sample_csv(self.data))))
  profit_codes={CODES['revenue'],CODES['cost']}
  for row in rows:
   if row['科目编码'] in profit_codes:row['辅助核算1']='';row['核销号']=''
  parsed=parse_nc_vouchers(self.data,self.erp,_write(list(rows[0]),rows))
  r=next(r for r in parsed if r['entityId']=='HW' and r['accountCode']==CODES['revenue'] and r['rawVoucherNo']=='01-IC-CAT')
  self.assertEqual(r['counterpartyId'],'HW_CAT');self.assertEqual(r['reference'],'HW-CAT-2026-01')
  self.assertEqual(r['rawFields']['辅助核算1'],'');self.assertEqual(r['rawFields']['核销号'],'')
  self.assertIn('同凭证',r['counterpartyBasis']);self.assertIn('同凭证',r['referenceBasis']);self.assertTrue(r['derivedFromVoucherRows'])
  out=match_ic(self.data,{**self.erp,'vouchers':parsed},'HW_GROUP',9)
  self.assertFalse(out['differences']);self.assertEqual(sum(m['amount'] for m in out['matches'] if m['kind']=='sales'),100)
  ext=next(r for r in parsed if r['entityId']=='HW' and r['accountCode']==CODES['revenue'] and r['rawVoucherNo']=='01-EXTERNAL-SALES')
  self.assertEqual(ext['counterpartyStatus'],'external');self.assertEqual(ext['reference'],'')
 def test_nc_multiple_customers_or_refs_do_not_propagate(self):
  original=list(csv.DictReader(io.StringIO(nc_sample_csv(self.data))));template=next(r for r in original if r['核算账簿']=='BOOK-HW')
  rows=[]
  for code,debit,credit,cp,ref in [(CODES['receivable'],'4','0','IC-HW_CAT','A'),(CODES['receivable'],'6','0','IC-HW_ELEC','B'),(CODES['revenue'],'0','10','','')]:
   r={**template,'凭证号':'MIX-CP','科目编码':code,'本币借方金额':debit,'本币贷方金额':credit,'辅助核算1':cp,'核销号':ref};rows.append(r)
  parsed=parse_nc_vouchers(self.data,self.erp,_write(list(template),rows));profit=parsed[-1]
  self.assertEqual(profit['counterpartyStatus'],'unspecified');self.assertEqual(profit['reference'],'');self.assertNotIn('counterpartyBasis',profit)
  # Even the same customer cannot identify one of two explicit business references.
  rows[1]['辅助核算1']='IC-HW_CAT';parsed=parse_nc_vouchers(self.data,self.erp,_write(list(template),rows));self.assertEqual(parsed[-1]['reference'],'');self.assertNotIn('referenceBasis',parsed[-1])
 def test_nc_context_is_not_propagated_across_vouchers(self):
  rows=list(csv.DictReader(io.StringIO(nc_sample_csv(self.data))))
  pair=[r for r in rows if r['核算账簿']=='BOOK-HW'][:2]
  other=[{**r,'凭证号':'NO-CONTEXT','辅助核算1':'','核销号':''} for r in pair]
  parsed=parse_nc_vouchers(self.data,self.erp,_write(list(rows[0]),pair+other))
  self.assertTrue(all(r['counterpartyStatus']=='unspecified' and not r['reference'] for r in parsed if r['rawVoucherNo']=='NO-CONTEXT'))
 def test_nc_sample_headers_self_contained_without_research_directory(self):
  import shutil,subprocess,tempfile
  with tempfile.TemporaryDirectory() as td:
   directory=Path(td)/'backend';directory.mkdir()
   for name in ['ledger.py','ledger_seed.py','consolidation.py','multilevel_seed.py']:shutil.copy2(Path(__file__).parent/name,directory/name)
   code='import sys,csv,io,json;sys.path.insert(0,'+repr(str(directory))+');from ledger_seed import nc_sample_csv;from multilevel_seed import seed_multilevel;print(json.dumps(next(csv.reader(io.StringIO(nc_sample_csv(seed_multilevel()))))),flush=True)'
   headers=json.loads(subprocess.check_output([sys.executable,'-I','-c',code],text=True))
   self.assertEqual(len(headers),48);self.assertEqual(headers[0],'核算账簿');self.assertEqual(headers[-1],'辅助核算9')
 def test_duplicate_line_and_unbalanced_voucher_atomic_parse(self):
  b=sample_bundle(self.data);rows=list(csv.DictReader(io.StringIO(b['voucherCsv'])))
  with self.assertRaisesRegex(ValueError,'重复'):parse_vouchers_csv(self.data,_write(VOUCHER_HEADERS,[rows[0],rows[0],rows[1]]))
  with self.assertRaisesRegex(ValueError,'不平衡'):parse_vouchers_csv(self.data,_write(VOUCHER_HEADERS,[rows[0]]))
 def test_zero_one_cent_is_not_lost(self):
  e=deepcopy(self.erp);r=deepcopy(next(v for v in e['vouchers'] if v['entityId']=='HW' and v['accountCode']==CODES['expense']))
  a={**r,'voucherId':'CENT','rawVoucherNo':'CENT','lineNo':1,'id':'CENT-1','accountCode':CODES['expense'],'debit':'.01','credit':'0','icType':'','counterpartyId':'','counterpartyStatus':'external','reference':''}
  b={**a,'lineNo':2,'id':'CENT-2','accountCode':CODES['cash'],'debit':'0','credit':'.01','cashflow':'operating'};e['vouchers'] += [a,b]
  result=generate_source(self.data,e,'HW',9)['source'];self.assertEqual(result['profit']['expense'],100.000001);self.assertEqual(result['closing']['cash'],299.999999)
 def test_large_amount_that_cannot_roundtrip_one_yuan_cent_is_rejected(self):
  from ledger import _report
  self.assertEqual(_report('100000000000000.00'),10000000000.0)
  with self.assertRaisesRegex(ValueError,'无损|原币分'):_report('100000000000000.01')
  erp=deepcopy(self.erp)
  for row in erp['openings']:
   if row['entityId']=='TY':
    if Decimal(row['debit']):row['debit']='100000000000000.01'
    if Decimal(row['credit']):row['credit']='100000000000000.01'
  with self.assertRaisesRegex(ValueError,'无损|原币分'):generate_source(self.data,erp,'TY',9)
 def test_red_letter_negative_debit_credit_are_preserved(self):
  e=deepcopy(self.erp);r=deepcopy(next(v for v in e['vouchers'] if v['entityId']=='HW' and v['accountCode']==CODES['revenue']))
  a={**r,'voucherId':'RED','rawVoucherNo':'RED','lineNo':1,'id':'RED-1','accountCode':CODES['cash'],'debit':'-1.00','credit':'0','icType':'','counterpartyId':'','counterpartyStatus':'external','reference':'','cashflow':'operating'}
  b={**a,'lineNo':2,'id':'RED-2','accountCode':CODES['revenue'],'debit':'0','credit':'-1.00','cashflow':''};e['vouchers'] += [a,b]
  result=generate_source(self.data,e,'HW',9)['source'];self.assertEqual(result['profit']['revenue'],999.9999);self.assertEqual(result['closing']['cash'],299.9999)
 def test_closing_is_explicitly_excluded_not_zeroed_or_counted_twice(self):
  e=deepcopy(self.erp);template=deepcopy(e['vouchers'][0]);rows=[]
  for i,(field,debit,credit) in enumerate([('revenue','10000000','0'),('cost','0','6000000'),('expense','0','1000000'),('retained','0','3000000')],1):
   rows.append({**template,'entityId':'HW','bookCode':'HW','date':'2026-09-30','voucherId':'CLOSE','rawVoucherNo':'CLOSE','lineNo':i,'id':'CLOSE-'+str(i),'accountCode':CODES[field],'debit':debit,'credit':credit,'cashflow':'','voucherKind':'closing'})
  e['vouchers']+=rows;r=generate_source(self.data,e,'HW',9);self.assertEqual(r['source']['profit']['revenue'],1000);self.assertEqual(r['source']['closing']['retained'],300);self.assertEqual(len(r['excludedClosingVouchers']),1)
  e['vouchers'][-1]['accountCode']=CODES['cash']
  with self.assertRaisesRegex(ValueError,'不能静默排除'):generate_source(self.data,e,'HW',9)
 def test_ambiguous_cashflow_is_blocked_instead_of_plugged(self):
  e=deepcopy(self.erp);base=deepcopy(e['vouchers'][0]);rs=[]
  for i,(f,d,c) in enumerate([('cash','20','0'),('cost','0','10'),('longloan','0','10')],1):rs.append({**base,'entityId':'HW','bookCode':'HW','date':'2026-09-20','voucherId':'MIX','rawVoucherNo':'MIX','lineNo':i,'id':'MIX'+str(i),'accountCode':CODES[f],'debit':d,'credit':c,'cashflow':'','voucherKind':'business'})
  e['vouchers']+=rs
  with self.assertRaisesRegex(ValueError,'多种'):generate_source(self.data,e,'HW',9)
 def test_opening_ar_ap_auxiliary_balances_roll_into_opening_elimination(self):
  e=deepcopy(self.erp)
  for r in e['openings']:
   if r['entityId']=='HW' and r['accountCode']==CODES['cash']:r['debit']='800000.00'
   if r['entityId']=='HW_CAT' and r['accountCode']==CODES['cash']:r['debit']='700000.00'
  a={'entityId':'HW','year':2026,'accountCode':CODES['receivable'],'currency':'CNY','debit':'200000.00','credit':'0','counterpartyId':'HW_CAT','counterpartyCode':'HW_CAT','counterpartyStatus':'internal','reference':'OPEN','sourceRow':99,'id':'OPENHW'}
  b={**a,'entityId':'HW_CAT','accountCode':CODES['payable'],'debit':'0','credit':'200000.00','counterpartyId':'HW','counterpartyCode':'HW','id':'OPENCAT'};e['openings'] += [a,b]
  for eid in ['HW','HW_CAT']:self.assertTrue(all(c['passed'] for c in generate_source(self.data,e,eid,9)['checks']))
  m=next(m for m in match_ic(self.data,e,'HW_GROUP',9)['matches'] if m['reference']=='OPEN')
  self.assertEqual(m['openingAmount'],20);self.assertEqual(m['amount'],20);self.assertEqual(m['openingEffects'],{'receivable':-20,'payable':-20})
 def test_opening_nonzero_ar_without_customer_is_difference(self):
  e=deepcopy(self.erp);e['openings'].append({'entityId':'HW','year':2026,'accountCode':CODES['receivable'],'currency':'CNY','debit':'100','credit':'0','counterpartyId':'','reference':'OPEN','sourceRow':99})
  d=match_ic(self.data,e,'HW_GROUP',9)['differences'];self.assertTrue(any(x['code']=='counterparty_required' for x in d))
 def test_mismatched_and_missing_reference_never_generate_difference_plug(self):
  e=deepcopy(self.erp);r=next(r for r in e['vouchers'] if r['entityId']=='HW_CAT' and r['icType']=='cost');r['debit']=str(Decimal(r['debit'])+1)
  out=match_ic(self.data,e,'HW_GROUP',9);self.assertTrue(any(d['code']=='amount_mismatch' for d in out['differences']));self.assertTrue(all(m['reference']!=r['reference'] or m['kind']!='sales' for m in out['matches']))
  r['reference']='';out=match_ic(self.data,e,'HW_GROUP',9);self.assertTrue(any(d['code']=='reference_required' for d in out['differences']))
 def test_root_matches_never_repeat_child_eliminations(self):
  r=match_ic(self.data,self.erp,'TY_GROUP',9);self.assertEqual(len(r['matches']),9);self.assertTrue(all(m['unitId']=='TY_GROUP' and m['buyerId']=='OTHER' for m in r['matches']))
 def test_trace_contains_exact_voucher_and_opening_ids(self):
  r=generate_source(self.data,self.erp,'HW',9);rev=next(t for t in r['trace'] if t['area']=='profit' and t['field']=='revenue');self.assertEqual(len(rev['voucherRefs']),27)
  self.assertTrue(all(v['voucherId'] and v['lineNo'] and v['sourceRow'] and v['entityId']=='HW' for v in rev['voucherRefs']))
 def test_unmapped_account_and_duplicate_opening_ref_rejected(self):
  e=deepcopy(self.erp);e['mappings']=[m for m in e['mappings'] if not(m['entityId']=='HW' and m['field']=='revenue')]
  with self.assertRaisesRegex(ValueError,'未映射'):generate_source(self.data,e,'HW',9)
  e=deepcopy(self.erp);e['openings'].append(deepcopy(e['openings'][0]))
  with self.assertRaisesRegex(ValueError,'重复'):generate_source(self.data,e,'TY',9)
 def test_xlsx_inline_shared_numeric_date_and_formula_policy(self):
  x=_xlsx([['法人编码','凭证日期','编码'],['HW',('46023','14'),('123','000000')]])
  text=read_file_csv(x,'test.xlsx');rows=list(csv.reader(io.StringIO(text)));self.assertEqual(rows[1][1],'2026-01-01');self.assertEqual(rows[1][2],'000123')
  with self.assertRaisesRegex(ValueError,'公式'):read_file_csv(_xlsx([['h'],[('1','FORMULA')]]),'test.xlsx')
  with self.assertRaisesRegex(ValueError,'另存'):read_file_csv(b'xls','test.xls')

def _write(headers,rows):
 out=io.StringIO();w=csv.DictWriter(out,fieldnames=headers);w.writeheader();w.writerows(rows);return out.getvalue()
def _xlsx(rows):
 import html
 buf=io.BytesIO();n='http://schemas.openxmlformats.org/spreadsheetml/2006/main';r='http://schemas.openxmlformats.org/officeDocument/2006/relationships';parts=[]
 for rowno,row in enumerate(rows,1):
  cs=[]
  for col,value in enumerate(row):
   address=chr(65+col)+str(rowno)
   if isinstance(value,tuple):
    v,fmt=value
    if fmt=='FORMULA':cs.append(f'<c r="{address}"><f>1+1</f><v>2</v></c>')
    else:cs.append(f'<c r="{address}" s="{1 if fmt=="14" else 2}"><v>{v}</v></c>')
   else:cs.append(f'<c r="{address}" t="inlineStr"><is><t>{html.escape(value)}</t></is></c>')
  parts.append('<row r="'+str(rowno)+'">'+''.join(cs)+'</row>')
 with zipfile.ZipFile(buf,'w') as z:
  z.writestr('xl/workbook.xml',f'<workbook xmlns="{n}" xmlns:r="{r}"><sheets><sheet name="数据" sheetId="1" r:id="rId1"/></sheets></workbook>')
  z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml" Type="x"/></Relationships>')
  z.writestr('xl/worksheets/sheet1.xml',f'<worksheet xmlns="{n}"><sheetData>'+''.join(parts)+'</sheetData></worksheet>')
  z.writestr('xl/styles.xml',f'<styleSheet xmlns="{n}"><numFmts><numFmt numFmtId="164" formatCode="000000"/></numFmts><cellXfs><xf numFmtId="0"/><xf numFmtId="14"/><xf numFmtId="164"/></cellXfs></styleSheet>')
 return buf.getvalue()

if __name__=='__main__':unittest.main()
