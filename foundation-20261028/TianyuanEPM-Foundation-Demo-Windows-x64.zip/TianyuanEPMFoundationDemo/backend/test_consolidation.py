"""实质财务/范围验收：三表金样、正式下级快照、分类折算和失败防线。"""
import unittest
from copy import deepcopy

from consolidation import (seed_multilevel, calculate_unit, translate_result,
    validate_tree, validate_source, lowest_common_unit, financial_checks, net)


def approved(result, number=1):
    out=deepcopy(result)
    out.update(id=f'{out["unitId"]}-{out["month"]}-v{number}',resultVersion=number,
               approvalStatus='已签核',status='已签核',valid=True)
    return out


class ConsolidationTests(unittest.TestCase):
    def setUp(self):
        self.data=seed_multilevel()

    def children(self,month=9):
        return {u:approved(calculate_unit(self.data,u,month)) for u in ('HW_GROUP','OS_GROUP')}

    def root(self,month=9,children=None):
        return calculate_unit(self.data,'TY_GROUP',month,self.children(month) if children is None else children)

    def journal(self,prefix,month=9):
        return next(e for e in self.data['eliminations'] if e['id']==f'{prefix}-{month:02d}')

    def rates(self,month=9):
        return next(r for r in self.data['fxRates'] if r['month']==month)

    def test_balanced_real_tiers_and_exact_foreign_component(self):
        children=self.children();r=self.root(children=children)
        self.assertEqual(children['HW_GROUP']['statement']['actual']['revenue'],1400)
        self.assertEqual(children['OS_GROUP']['statement']['actual']['revenue'],100)
        self.assertEqual(r['statement']['actual']['revenue'],2650)
        self.assertEqual(r['statement']['actual']['net'],770)
        self.assertEqual(r['statement']['actual']['assets'],2370)
        self.assertEqual(r['report']['closing']['investment'],0)
        self.assertEqual(r['report']['closing']['capital'],950)
        self.assertEqual(r['report']['closing']['retained'],770)
        self.assertEqual(r['report']['equityHistory']['capitalByEntity'],{'TY':950.0})
        self.assertTrue(r['passed'])
        fx=r['trace']['fx'][0];report=fx['translatedReport']
        self.assertEqual(fx['sourceUnitId'],'OS_GROUP')
        self.assertEqual(fx['rateId'],'FX-USD-CNY-2026-09')
        self.assertEqual(fx['rateVersion'],1)
        self.assertEqual(fx['sourceReport']['closing']['cash'],200)
        self.assertEqual(report['closing']['cash'],1440)
        self.assertEqual(report['closing']['longloan'],576)
        self.assertEqual(report['closing']['capital'],650)
        self.assertEqual(net(report['profit']),140)
        self.assertEqual(report['closing']['cta'],74)
        self.assertEqual(report['opening']['cash'],650)
        self.assertEqual(report['cashflow'],{'operating':140,'investing':0,'financing':560,'fx':90})
        self.assertTrue(all(x['passed'] for x in financial_checks(report)))
        self.assertEqual(len(r['leafIds']),7)
        self.assertEqual(len(r['eliminationIds']),3)
        inherited=[e for e in r['trace']['eliminations'] if e['inherited']]
        self.assertEqual([e['sourceId'] for e in inherited],['IC-HW-SALES-2026-09'])
        hw_input=next(i for i in r['inputs'] if i['id']=='HW_GROUP')
        self.assertEqual(hw_input['resultId'],children['HW_GROUP']['id'])
        self.assertEqual(hw_input['resultVersion'],1)

    def test_all_seed_periods_have_balanced_sources_and_consolidation(self):
        for m in range(1,13):
            with self.subTest(month=m):
                for eid,s in self.data['sources'][str(m)].items():validate_source(self.data,eid,m,s)
                self.assertTrue(self.root(m)['passed'])
        self.assertEqual(self.root(12)['statement']['actual']['revenue'],2650)

    def test_parent_cannot_silently_recalculate_missing_children(self):
        with self.assertRaisesRegex(ValueError,'先运行并签核'):self.root(children={})
        preview=calculate_unit(self.data,'TY_GROUP',9,preview=True)
        self.assertTrue(preview['preview'])

    def test_preview_unapproved_stale_wrong_context_and_currency_rejected(self):
        variants=[{'preview':True},{'approvalStatus':'待签核'},{'valid':False},
                  {'stale':True},{'month':8},{'unitId':'OS_GROUP'},{'currency':'USD'},{'passed':False}]
        for update in variants:
            with self.subTest(update=update):
                children=self.children();children['HW_GROUP'].update(update)
                with self.assertRaises(ValueError):self.root(children=children)

    def test_child_report_rechecked_even_if_passed_flag_forged(self):
        children=self.children();children['HW_GROUP']['report']['closing']['cash']+=1
        with self.assertRaisesRegex(ValueError,'三表'):self.root(children=children)

    def test_balanced_but_modified_snapshot_or_unidentified_result_rejected(self):
        children=self.children();s=children['HW_GROUP']['report']
        s['opening']['cash']+=1;s['closing']['cash']+=1
        s['opening']['retained']+=1;s['closing']['retained']+=1
        with self.assertRaisesRegex(ValueError,'内容校验'):self.root(children=children)
        for key in ('id','resultVersion','valid'):
            children=self.children();children['HW_GROUP'].pop(key)
            with self.subTest(key=key):
                with self.assertRaises(ValueError):self.root(children=children)

    def test_changed_source_invalidates_child_snapshot(self):
        children=self.children();self.data['sources']['9']['HW']['version']+=1
        with self.assertRaisesRegex(ValueError,'报送已变化'):self.root(children=children)
        self.data=seed_multilevel();children=self.children();del self.data['sources']['9']['HW']
        with self.assertRaisesRegex(ValueError,'报送已变化'):self.root(children=children)

    def test_new_approved_elimination_invalidates_child_snapshot(self):
        children=self.children();new=deepcopy(self.journal('HW-SALES'))
        new.update(id='new-hw-sale',sourceId='NEW-IC',amount=10,effects={'revenue':-10,'cost':-10})
        self.data['eliminations'].append(new)
        with self.assertRaisesRegex(ValueError,'新增或撤销'):self.root(children=children)

    def test_closing_sensitivity_affects_cta_and_cash_fx_not_profit(self):
        self.rates()['closing']=7.3;self.rates()['version']=2
        r=self.root();fx=r['trace']['fx'][0]
        self.assertEqual(r['statement']['actual']['revenue'],2650)
        self.assertEqual(r['statement']['actual']['net'],770)
        self.assertEqual(fx['translatedReport']['closing']['cta'],86)
        self.assertEqual(fx['translatedReport']['cashflow']['fx'],110)
        self.assertEqual(fx['rateVersion'],2)
        self.assertTrue(r['passed'])

    def test_monthly_average_not_period_end_or_single_cumulative_rate(self):
        os=self.children()['OS_GROUP'];self.rates()['averages']['1']=8
        translated=translate_result(self.data,os,'CNY',9)
        expected=sum(round(row['revenue']*(8 if m=='1' else 7),2) for m,row in os['report']['monthlyProfit'].items())
        self.assertAlmostEqual(translated['report']['profit']['revenue'],expected)
        self.assertNotEqual(translated['report']['profit']['revenue'],700)
        self.assertEqual(translated['report']['monthlyProfit']['1']['revenue'],88.96)
        self.assertEqual(translated['report']['cashflow']['operating'],140)
        self.assertTrue(translated['passed'])

    def test_usd_internal_sale_uses_actual_months_before_translation(self):
        self.rates()['averages'].update({'1':8,'2':6})
        baseline=self.root()['trace']['fx'][0]['translatedReport']
        # 两主体的已结算销售分别产生同额收款/付款，合并现金流净额为零。
        for eid,field,sign in [('OS_A','revenue',1),('OS_B','cost',-1)]:
            s=self.data['sources']['9'][eid]
            s['profit'][field]+=9;s['cashflow']['operating']+=sign*9
            s['closing']['retained']+=sign*9;s['closing']['cash']+=sign*9
            for month,amount in [('1',4),('2',5)]:
                s['monthlyProfit'][month][field]=round(s['monthlyProfit'][month][field]+amount,2)
                s['monthlyCashflow'][month]['operating']=round(s['monthlyCashflow'][month]['operating']+sign*amount,2)
        e={'id':'USD-IC','sourceId':'USD-IC-ORIGIN','month':9,'version':1,'unitId':'OS_GROUP',
           'currency':'USD','status':'已审批','kind':'sales','sellerId':'OS_A','buyerId':'OS_B',
           'amount':9,'effects':{'revenue':-9,'cost':-9},'openingEffects':{},
           'monthlyEffects':{str(m):{'revenue':-4 if m==1 else -5 if m==2 else 0,
                                      'cost':-4 if m==1 else -5 if m==2 else 0} for m in range(1,10)}}
        self.data['eliminations'].append(e)
        after=self.root()['trace']['fx'][0]['translatedReport']
        self.assertEqual(after,baseline)
        e.pop('monthlyEffects')
        with self.assertRaisesRegex(ValueError,'逐月发生额monthlyEffects'):self.root()
        e['monthlyEffects']={str(m):{'revenue':-1,'cost':-1} for m in range(1,10)}
        e['monthlyEffects']['1']['revenue']=-2
        with self.assertRaisesRegex(ValueError,'逐月发生额合计'):self.root()

    def test_inactive_rate_retained_but_current_version_selected(self):
        old=self.rates();old['active']=False
        new=deepcopy(old);new.update(id='FX-NEW-9',version=2,active=True,closing=7.3)
        self.data['fxRates'].append(new)
        r=self.root()
        self.assertEqual(r['trace']['fx'][0]['rateId'],'FX-NEW-9')
        self.assertEqual(r['statement']['actual']['cta'],86)

    def test_missing_duplicate_unapproved_or_invalid_rate_rejected(self):
        for mode in ('missing','duplicate','unapproved','negative','missing_month','precision'):
            with self.subTest(mode=mode):
                self.data=seed_multilevel();rate=self.rates()
                if mode=='missing':self.data['fxRates'].remove(rate)
                elif mode=='duplicate':self.data['fxRates'].append(deepcopy(rate))
                elif mode=='unapproved':rate['status']='草稿'
                elif mode=='negative':rate['closing']=-1
                elif mode=='missing_month':del rate['averages']['3']
                elif mode=='precision':rate['closing']='7.1234567'
                with self.assertRaises(ValueError):self.root()

    def test_historical_rate_change_cannot_manufacture_investment_difference(self):
        self.rates()['historicalCapital']=6.6
        with self.assertRaisesRegex(ValueError,'投资账面|历史资本'):self.root()

    def test_retained_earnings_use_confirmed_opening_cny_plus_translated_profit(self):
        source=self.data['sources']['9']['OS_A']
        source['opening']['cash']+=10;source['closing']['cash']+=10
        source['opening']['retained']=10;source['closing']['retained']+=10
        source['equityHistory']['openingRetainedCny']=60
        r=self.root();fx=r['trace']['fx'][0]['translatedReport']
        self.assertEqual(fx['opening']['retained'],60)
        self.assertEqual(fx['closing']['retained'],200)
        self.assertEqual(fx['opening']['cta'],5)
        self.assertEqual(fx['closing']['cta'],86)
        self.assertTrue(r['passed'])

    def test_source_history_and_unsupported_events_rejected(self):
        variants=[lambda s:s['equityHistory'].update(capitalByEntity={'OS_B':50}),
                  lambda s:s['equityHistory'].update(capitalByEntity={'OS_A':49}),
                  lambda s:s['equityHistory'].update(dividendsByMonth={'1':1}),
                  lambda s:s['closing'].update(cta=1),lambda s:s['cashflow'].update(fx=1)]
        for mutate in variants:
            with self.subTest(mutate=mutate):
                s=deepcopy(self.data['sources']['9']['OS_A']);mutate(s)
                with self.assertRaises(ValueError):validate_source(self.data,'OS_A',9,s)
        s=deepcopy(self.data['sources']['9']['OS_A'])
        s['opening']['cash']+=10;s['closing']['cash']+=10
        s['opening']['retained']=10;s['closing']['retained']+=10
        del s['equityHistory']['openingRetainedCny']
        with self.assertRaisesRegex(ValueError,'人民币留存'):validate_source(self.data,'OS_A',9,s)

    def test_monthly_sum_and_unbalanced_source_rejected(self):
        s=deepcopy(self.data['sources']['9']['HW']);s['monthlyProfit']['1']['revenue']+=1
        with self.assertRaisesRegex(ValueError,'月发生额'):validate_source(self.data,'HW',9,s)
        s=deepcopy(self.data['sources']['9']['HW']);s['closing']['cash']+=1
        with self.assertRaisesRegex(ValueError,'不平衡'):validate_source(self.data,'HW',9,s)

    def test_cycle_unknown_duplicate_leaf_and_unsupported_currency_rejected(self):
        for mode in ('cycle','unknown','duplicate','overlap','currency'):
            with self.subTest(mode=mode):
                d=deepcopy(self.data);units={u['id']:u for u in d['units']}
                if mode=='cycle':units['HW_GROUP']['members'].append({'type':'unit','id':'TY_GROUP'})
                if mode=='unknown':units['HW_GROUP']['members'].append({'type':'entity','id':'MISSING'})
                if mode=='duplicate':units['HW_GROUP']['members'].append({'type':'entity','id':'HW'})
                if mode=='overlap':units['TY_GROUP']['members'].append({'type':'entity','id':'HW'})
                if mode=='currency':units['OS_GROUP']['members'].append({'type':'entity','id':'HW'})
                with self.assertRaises(ValueError):validate_tree(d)
        d=deepcopy(self.data)
        d['units'].append({'id':'DETACHED','name':'独立重复范围','currency':'CNY','members':[{'type':'entity','id':'HW'}]})
        validate_tree(d)  # 允许先创建尚未接入现有根的新范围，供成员移动的中间态。
        root=next(u for u in d['units'] if u['id']=='TY_GROUP')
        root['members'].append({'type':'unit','id':'DETACHED'})
        with self.assertRaisesRegex(ValueError,'重复纳入底层法人'):validate_tree(d)

    def test_management_tree_does_not_invent_legal_ownership(self):
        self.assertTrue(all(o['parent']=='TY' for o in self.data['ownership']))
        self.assertEqual(lowest_common_unit(self.data,'HW','HW_CAT'),'HW_GROUP')
        self.assertEqual(lowest_common_unit(self.data,'HW','OTHER'),'TY_GROUP')

    def test_sales_at_wrong_level_and_duplicate_inherited_source_rejected(self):
        self.journal('HW-SALES')['unitId']='TY_GROUP'
        with self.assertRaisesRegex(ValueError,'最低共同'):self.root()
        self.data=seed_multilevel();self.journal('GROUP-SALES')['sourceId']=self.journal('HW-SALES')['sourceId']
        with self.assertRaisesRegex(ValueError,'再次抵销'):self.root()

    def test_investment_cannot_be_forged_by_balancing_effects(self):
        for mode in ('effect','pair_capital','parent_source','duplicate_pair','opening','pair_shift'):
            with self.subTest(mode=mode):
                self.data=seed_multilevel();e=self.journal('GROUP-INVESTMENT')
                if mode=='effect':e['effects']={'capital':-949,'investment':-949}
                if mode=='pair_capital':e['investmentPairs'][0]['capital']-=1
                if mode=='parent_source':e['investmentPairs'][0]['investment']-=1
                if mode=='duplicate_pair':e['investmentPairs'].append(deepcopy(e['investmentPairs'][0]))
                if mode=='opening':e['openingEffects']={}
                if mode=='pair_shift':e['investmentPairs'][0]['investment']-=1;e['investmentPairs'][1]['investment']+=1
                with self.assertRaises(ValueError):self.root()

    def test_unapproved_draft_has_no_financial_effect(self):
        before=self.root();new=deepcopy(self.journal('HW-SALES'));new.update(id='DRAFT',sourceId='DRAFT',status='草稿')
        self.data['eliminations'].append(new)
        after=self.root()
        self.assertEqual(before['report'],after['report'])
        self.assertEqual(before['fingerprint'],after['fingerprint'])


if __name__=='__main__':unittest.main()
