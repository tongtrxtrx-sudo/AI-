"""集团 EPM 演示账套的财务领域计算。

所有输入账面金额以人民币万元为单位，以十进制定点数计算。示例采用同一
本位币及累计数；美元展示是展示币种换算，不宣称实现外币报表折算准则。
本模块没有网络、文件系统或数据库副作用。
"""

from __future__ import annotations

from copy import deepcopy
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any


CENT = Decimal("0.01")
ZERO = Decimal("0.00")
PL_KEYS = ("revenue", "cost", "expense", "finance", "tax")
ASSET_KEYS = ("cash", "receivable", "inventory", "prepaid", "fixed", "intangible", "deferred_asset")
LIABILITY_KEYS = ("payable", "shortloan", "taxpayable", "otherliability", "longloan", "deferred_liability")
EQUITY_KEYS = ("capital", "retained", "nci")
BS_KEYS = ASSET_KEYS + LIABILITY_KEYS + EQUITY_KEYS
CF_KEYS = ("operating", "investing", "financing")
APPROVED = frozenset(("已批准", "已审批", "已过账", "approved", "posted"))
MAX_AMOUNT = Decimal("1000000000000")


def decimal_amount(value: Any, field: str = "金额", *, allow_negative: bool = True) -> Decimal:
    """验证业务金额；不允许 NaN、布尔值、超精度及静默四舍五入。"""
    if isinstance(value, bool) or value is None or isinstance(value, (dict, list, tuple)):
        raise ValueError(f"{field}必须填写数字")
    if isinstance(value, str):
        value = value.strip()
        if not value or len(value) > 48:
            raise ValueError(f"{field}必须填写有效数字")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(f"{field}必须填写有效数字") from None
    if not result.is_finite() or abs(result) > MAX_AMOUNT:
        raise ValueError(f"{field}超出允许的金额范围")
    if result != result.quantize(CENT, rounding=ROUND_HALF_UP):
        raise ValueError(f"{field}最多保留两位小数")
    if not allow_negative and result < ZERO:
        raise ValueError(f"{field}不能小于零")
    return result.quantize(CENT, rounding=ROUND_HALF_UP)


def decimal_rate(value: Any, field: str = "汇率") -> Decimal:
    if isinstance(value, bool) or value is None:
        raise ValueError(f"{field}必须填写大于零的数字")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(f"{field}必须填写有效数字") from None
    if not result.is_finite() or result <= 0 or result > Decimal("1000000"):
        raise ValueError(f"{field}必须大于零且不超过1000000")
    if result != result.quantize(Decimal("0.000001")):
        raise ValueError(f"{field}最多保留六位小数")
    return result


def _q(value: Decimal) -> Decimal:
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def _number(value: Decimal) -> float:
    return float(_q(value))


def _sum(mapping: dict[str, Any], keys: tuple[str, ...]) -> Decimal:
    return sum((decimal_amount(mapping.get(key, 0), key) for key in keys), ZERO)


def net_profit(entity: dict[str, Any]) -> Decimal:
    return decimal_amount(entity.get("revenue", 0), "营业收入") - sum(
        (decimal_amount(entity.get(key, 0), key) for key in PL_KEYS[1:]), ZERO
    )


def _net_effect(effects: dict[str, Any]) -> Decimal:
    return decimal_amount(effects.get("revenue", 0), "收入调整") - sum(
        (decimal_amount(effects.get(key, 0), key) for key in PL_KEYS[1:]), ZERO
    )


def _line_parts(line: Any) -> tuple[str, str, Decimal]:
    if isinstance(line, dict):
        account = str(line.get("account", line.get("label", "")))
        if "debit" in line or "credit" in line:
            debit = decimal_amount(line.get("debit", 0), "借方金额", allow_negative=False)
            credit = decimal_amount(line.get("credit", 0), "贷方金额", allow_negative=False)
            if (debit > 0) == (credit > 0):
                raise ValueError("凭证明细每行必须且只能填写一个方向的正数金额")
            return account, "借" if debit > 0 else "贷", debit or credit
        direction = str(line.get("direction", ""))
        amount = decimal_amount(line.get("amount", 0), "凭证金额", allow_negative=False)
    elif isinstance(line, (list, tuple)) and len(line) == 3:
        account, direction, raw_amount = line
        account, direction = str(account), str(direction)
        amount = decimal_amount(raw_amount, "凭证金额", allow_negative=False)
    else:
        raise ValueError("凭证明细格式不正确")
    if not account or len(account) > 100 or direction not in ("借", "贷") or amount <= 0:
        raise ValueError("凭证明细必须有科目、借贷方向及大于零的金额")
    return account, direction, amount


def validate_journal(journal: dict[str, Any]) -> None:
    """拒绝借贷或财务影响不平衡的合并调整。"""
    if not isinstance(journal, dict):
        raise ValueError("合并凭证格式不正确")
    if "capitalMovement" in journal:
        decimal_amount(journal["capitalMovement"], "凭证所有者投入及分配")
    lines = journal.get("lines", [])
    if not isinstance(lines, list) or not 2 <= len(lines) <= 200:
        raise ValueError("合并凭证需要2至200行明细")
    debit = credit = ZERO
    for line in lines:
        _, direction, amount = _line_parts(line)
        if direction == "借":
            debit += amount
        else:
            credit += amount
    if debit != credit:
        raise ValueError(f"合并凭证借贷不平衡，差额{_q(debit-credit):.2f}万元")
    effects = journal.get("effects", {})
    if not isinstance(effects, dict):
        raise ValueError("合并凭证财务影响格式不正确")
    allowed = set(PL_KEYS + BS_KEYS + CF_KEYS + ("noncash",))
    for key, value in effects.items():
        if key not in allowed:
            raise ValueError(f"合并凭证包含未支持的财务字段：{key}")
        decimal_amount(value, f"凭证影响{key}")
    if effects:
        balance_difference = _sum(effects, ASSET_KEYS) - _sum(effects, LIABILITY_KEYS) - _sum(effects, EQUITY_KEYS)
        # 无显式权益行时，损益自动结转至未分配利润；显式权益行不能重复结转。
        if "retained" not in effects:
            balance_difference -= _net_effect(effects)
        if balance_difference != 0:
            raise ValueError(f"合并凭证财务影响不平衡，差额{_q(balance_difference):.2f}万元")


def entity_checks(entity: dict[str, Any]) -> list[dict[str, Any]]:
    """返回法人校验；不会通过补数使错误账面自动平衡。"""
    label = str(entity.get("name", entity.get("id", "法人")))
    start, end = entity.get("opening", {}), entity.get("closing", {})
    cf = entity.get("cashflow", {})
    for stage, balances in (("期初", start), ("期末", end)):
        if not isinstance(balances, dict):
            raise ValueError(f"{label}{stage}余额格式不正确")
        for key in BS_KEYS:
            decimal_amount(balances.get(key, 0), f"{label}{stage}{key}")
    if not isinstance(cf, dict):
        raise ValueError(f"{label}现金流量格式不正确")
    for key in CF_KEYS:
        decimal_amount(cf.get(key, 0), f"{label}{key}")
    profit = net_profit(entity)
    beginning_equity, ending_equity = _sum(start, EQUITY_KEYS), _sum(end, EQUITY_KEYS)
    capital_movement = decimal_amount(entity.get("capitalMovement", 0), "所有者投入及分配")
    differences = [
        ("opening_balance", "期初资产负债平衡", _sum(start, ASSET_KEYS) - _sum(start, LIABILITY_KEYS) - beginning_equity),
        ("closing_balance", "期末资产负债平衡", _sum(end, ASSET_KEYS) - _sum(end, LIABILITY_KEYS) - ending_equity),
        ("cash_reconciliation", "现金流量与期末现金勾稽", decimal_amount(end.get("cash", 0)) - decimal_amount(start.get("cash", 0)) - _sum(cf, CF_KEYS)),
        ("equity_reconciliation", "权益变动与净利润勾稽", ending_equity - beginning_equity - profit - capital_movement),
    ]
    if "net" in entity:
        differences.append(("profit_reconciliation", "报送净利润与损益重算勾稽", decimal_amount(entity["net"], "报送净利润") - profit))
    return [{"code": f"{entity.get('id', 'entity')}_{code}", "label": f"{label} · {description}", "passed": difference == ZERO,
             "difference": _number(difference), "entityId": entity.get("id", "")} for code, description, difference in differences]


def validate_entity(entity: dict[str, Any]) -> None:
    if not isinstance(entity, dict) or not str(entity.get("id", "")).strip() or not str(entity.get("name", "")).strip():
        raise ValueError("法人必须填写编号和名称")
    for key in PL_KEYS:
        decimal_amount(entity.get(key, 0), key)
    for check in entity_checks(entity):
        if not check["passed"]:
            raise ValueError(f"{check['label']}不通过，差额{check['difference']:.2f}万元")


def validate_finance(data: dict[str, Any]) -> None:
    entities = data.get("entities", [])
    if not isinstance(entities, list) or not entities:
        raise ValueError("账套至少需要一个法人")
    seen = set()
    for entity in entities:
        validate_entity(entity)
        if entity["id"] in seen:
            raise ValueError("法人编号不能重复")
        seen.add(entity["id"])
    for journal in data.get("journals", []):
        validate_journal(journal)


def seed_finance() -> dict[str, Any]:
    """返回独立、可修改的演示账套。金额单位为万元，实际期间为2026年1至9月。"""
    opening = {"cash": 1680, "receivable": 1800, "inventory": 1500, "prepaid": 300, "fixed": 2200,
               "intangible": 400, "deferred_asset": 0, "payable": 1800, "shortloan": 1000,
               "taxpayable": 150, "otherliability": 300, "longloan": 1500, "deferred_liability": 0}
    closing = {"cash": 2050, "receivable": 2150, "inventory": 1920, "prepaid": 400, "fixed": 2700,
               "intangible": 470, "deferred_asset": 0, "payable": 2000, "shortloan": 800,
               "taxpayable": 100, "otherliability": 390, "longloan": 1440, "deferred_liability": 5}
    specifications = [
        ("MFG", "天元制造有限公司", "天元制造", "TY01", "0.60", (8000, 4800, 1600, 100, 375), (1092, 1542), (1100, -500, -150), "李会计"),
        ("TEC", "天元科技有限公司", "天元科技", "TY02", "0.25", (4200, 2300, 1050, 50, 200), (400, 330), (250, -250, -70), "陈会计"),
        ("TRD", "天元贸易有限公司", "天元贸易", "TY03", "0.15", (2600, 2200, 250, 20, 30), (188, 178), (100, -70, -40), "王会计"),
    ]
    entities = []
    for entity_id, name, short, code, weight, pl, cash, cf, owner in specifications:
        fraction = Decimal(weight)
        beginning = {key: _q(Decimal(str(value)) * fraction) for key, value in opening.items()}
        ending = {key: _q(Decimal(str(value)) * fraction) for key, value in closing.items()}
        beginning["cash"], ending["cash"] = map(Decimal, cash)
        pl_map = dict(zip(PL_KEYS, map(Decimal, pl)))
        net = pl_map["revenue"] - sum((pl_map[key] for key in PL_KEYS[1:]), ZERO)
        beginning["capital"] = Decimal("2000") * fraction
        beginning["nci"] = Decimal("100") if entity_id == "TEC" else ZERO
        beginning["retained"] = _sum(beginning, ASSET_KEYS) - _sum(beginning, LIABILITY_KEYS) - beginning["capital"] - beginning["nci"]
        ending["capital"] = beginning["capital"]
        # 示例少数股东分配为源报送数据，不对外宣称是完整持股链计算。
        minority_profit = Decimal("100") if entity_id == "TEC" else ZERO
        ending["nci"] = beginning["nci"] + minority_profit
        ending["retained"] = beginning["retained"] + net - minority_profit
        required_assets = _sum(ending, LIABILITY_KEYS) + _sum(ending, EQUITY_KEYS)
        ending["fixed"] += required_assets - _sum(ending, ASSET_KEYS)
        entity = {"id": entity_id, "name": name, "short": short, "code": code, "owner": owner, "currency": "人民币",
                  "currencyCode": "CNY", "enabled": True, "group": "manufacturing" if entity_id == "MFG" else "group",
                  **{key: _number(value) for key, value in pl_map.items()}, "net": _number(net),
                  "opening": {key: _number(value) for key, value in beginning.items()},
                  "closing": {key: _number(value) for key, value in ending.items()},
                  "cashflow": dict(zip(CF_KEYS, cf)), "capitalMovement": 0,
                  "minorityProfit": _number(minority_profit)}
        entities.append(entity)
    journals = [
        {"id": "DEMO-ELIM-001", "title": "内部销售抵销", "kind": "往来抵销", "status": "已审批", "period": "2026-09",
         "lines": [["营业收入", "借", 1800], ["营业成本", "贷", 1800]],
         "effects": {"revenue": -1800, "cost": -1800}, "effect": "收入与成本同时减少，净利润影响为零。"},
        {"id": "DEMO-ELIM-002", "title": "库存未实现利润及税项调整", "kind": "未实现利润", "status": "已审批", "period": "2026-09",
         "lines": [["营业成本", "借", 120], ["存货", "贷", 120], ["递延所得税资产", "借", 30], ["所得税费用", "贷", 30]],
         "effects": {"cost": 120, "tax": -30, "inventory": -120, "deferred_asset": 30},
         "effect": "抵销未实现利润120.00，确认税项影响30.00，净利润减少90.00。"},
        {"id": "DEMO-ADJ-003", "title": "购买价分摊后续折旧调整", "kind": "合并调整", "status": "已审批", "period": "2026-09",
         "lines": [["管理费用", "借", 20], ["累计折旧", "贷", 20], ["递延所得税负债", "借", 5], ["所得税费用", "贷", 5]],
         "effects": {"expense": 20, "tax": -5, "fixed": -20, "deferred_liability": -5},
         "effect": "费用增加20.00，税项减少5.00，净利润减少15.00。"},
    ]
    accounts = [
        {"code": "6001", "name": "营业收入", "field": "revenue", "type": "收入", "direction": "贷", "enabled": True},
        {"code": "6401", "name": "营业成本", "field": "cost", "type": "成本", "direction": "借", "enabled": True},
        {"code": "6602", "name": "期间费用", "field": "expense", "type": "费用", "direction": "借", "enabled": True},
        {"code": "6603", "name": "财务费用", "field": "finance", "type": "费用", "direction": "借", "enabled": True},
        {"code": "6801", "name": "所得税费用", "field": "tax", "type": "税费", "direction": "借", "enabled": True},
    ]
    labels = {"cash": ("1002", "货币资金"), "receivable": ("1122", "应收账款"), "inventory": ("1405", "存货"),
              "prepaid": ("1123", "预付款及其他流动资产"), "fixed": ("1601", "固定资产净额"),
              "intangible": ("1701", "无形及其他非流动资产"), "deferred_asset": ("1811", "递延所得税资产"),
              "payable": ("2202", "应付账款"), "shortloan": ("2001", "短期借款"), "taxpayable": ("2221", "应交税费"),
              "otherliability": ("2241", "其他流动负债"), "longloan": ("2501", "长期借款"),
              "deferred_liability": ("2901", "递延所得税负债"), "capital": ("4001", "实收资本"),
              "retained": ("4104", "未分配利润"), "nci": ("4002", "少数股东权益")}
    accounts += [{"code": code, "name": label, "field": key, "type": "资产" if key in ASSET_KEYS else "负债" if key in LIABILITY_KEYS else "权益",
                  "direction": "借" if key in ASSET_KEYS else "贷", "enabled": True} for key, (code, label) in labels.items()]
    for account in accounts:
        account["normalSide"] = account["direction"]
    result = {"entities": entities, "journals": journals, "monthly": [1180, 1260, 1390, 1410, 1480, 1520, 1570, 1600, 1590],
              "rates": {"CNY": 1, "USD": 7.1}, "accounts": accounts,
              "ownership": [{"entityId": entity["id"], "method": "全额合并", "percent": 80 if entity["id"] == "TEC" else 100,
                             "note": "示例权益分配采用报送少数股东利润；持股链和合并准则计算不在演示范围。"} for entity in entities],
              "financePolicy": {"year": 2026, "actualThrough": 9, "sourceUnit": "人民币万元",
                                "scopeNote": "同本位币累计演示账套；展示币换算，不含外币报表折算差额、持股链及准则判断。"}}
    validate_finance(result)
    return result


def _context(data: dict[str, Any], context: dict[str, Any] | None) -> dict[str, Any]:
    context = context or {}
    group = str(context.get("group", "group"))
    if group == "manufacturing":
        group = "mfg"
    entity_id = str(context.get("entity", "all"))
    currency = str(context.get("currency", "CNY")).upper()
    raw_month = context.get("month", 9)
    if isinstance(raw_month, bool):
        raise ValueError("期间必须为1至12月")
    try:
        month = int(str(raw_month))
    except (TypeError, ValueError):
        raise ValueError("期间必须为1至12月") from None
    if group not in ("group", "mfg"):
        raise ValueError("合并范围不正确")
    if currency not in ("CNY", "USD"):
        raise ValueError("展示币种仅支持人民币和美元")
    if not 1 <= month <= 12:
        raise ValueError("期间必须为1至12月")
    all_entities = data.get("entities", [])
    if not isinstance(all_entities, list) or not all_entities:
        raise ValueError("没有可用于计算的法人报送数据")
    active = [entity for entity in all_entities if entity.get("enabled", True)]
    if group == "mfg":
        active = [entity for entity in active if entity.get("id") == "MFG" or entity.get("group") in ("manufacturing", "mfg")]
    if entity_id != "all":
        active = [entity for entity in active if str(entity.get("id")) == entity_id]
    if not active:
        raise ValueError("所选法人不在当前合并范围内或已停用")
    return {"group": group, "entity": entity_id, "currency": currency, "month": month, "entities": active}


def _rate(data: dict[str, Any], currency: str) -> Decimal:
    if currency == "CNY":
        return Decimal(1)
    rates = data.get("rates", {})
    if isinstance(rates, dict):
        value = rates.get(currency)
        if isinstance(value, dict):
            value = value.get("rate", value.get("value"))
    elif isinstance(rates, list):
        row = next((row for row in rates if row.get("currency", row.get("code")) == currency), {})
        value = row.get("rate", row.get("value"))
    else:
        value = None
    if value is None:
        raise ValueError(f"尚未维护{currency}展示汇率")
    return decimal_rate(value)


def resolve_period_entity(data: dict[str, Any], entity: dict[str, Any], month: int) -> tuple[dict[str, Any], bool]:
    """解析某法人期间覆盖；返回实体与是否是该月独立累计报送。

    periodOverrides[月][法人] 的 PL/closing/cashflow 均为该月累计数。未覆盖的
    基础字段继承法人主档。CSV 未结转损益时传 profitClosed:false，自动结转
    当期净利润至 retained；这不消除任何源余额的借贷差额。
    """
    period_overrides = data.get("periodOverrides", {})
    if not isinstance(period_overrides, dict):
        raise ValueError("期间报送覆盖数据格式不正确")
    overrides = period_overrides.get(str(month), {})
    if not isinstance(overrides, dict):
        raise ValueError("期间报送覆盖数据格式不正确")
    override = overrides.get(entity["id"])
    if override is None:
        return entity, False
    if not isinstance(override, dict):
        raise ValueError("法人期间报送数据格式不正确")
    resolved = deepcopy(entity)
    resolved.update({key: deepcopy(value) for key, value in override.items() if key not in ("id", "name", "code", "enabled", "group")})
    if not override.get("profitClosed", False):
        ending = deepcopy(resolved.get("closing", {}))
        ending["retained"] = _number(decimal_amount(ending.get("retained", 0)) + net_profit(resolved))
        resolved["closing"] = ending
    if "net" not in override:
        resolved["net"] = _number(net_profit(resolved))
    return resolved, True


def statement(data: dict[str, Any], context: dict[str, Any] | None = None) -> dict[str, Any]:
    """从法人源余额及已审批分录重算三表、来源与勾稽结果。

    为便于前端沿用原型，profit 为对象行，balance/cash 为[label,value,key]行。
    所有展示值返回 number，输入源保持不变。校验采用换算前未被四舍五入掩盖的源数据。
    """
    selection = _context(data, context)
    entities = selection["entities"]
    month = selection["month"]
    weights = data.get("monthly", [])
    if not isinstance(weights, list) or len(weights) < 9:
        raise ValueError("月度实际数权重缺失，无法计算累计期间")
    decimal_weights = [decimal_amount(value, "月度实际数", allow_negative=False) for value in weights[:9]]
    total_weight = sum(decimal_weights, ZERO)
    if total_weight <= 0:
        raise ValueError("月度实际数合计必须大于零")
    factor = sum(decimal_weights[:month], ZERO) / total_weight
    period_sources = [resolve_period_entity(data, entity, month) for entity in entities]
    entities = [entity for entity, _ in period_sources]
    rate = _rate(data, selection["currency"])
    display = lambda value: _number(value / rate)
    begin = {key: sum((decimal_amount(entity.get("opening", {}).get(key, 0), key) for entity in entities), ZERO) for key in BS_KEYS}
    current = {key: sum((decimal_amount(entity.get("opening", {}).get(key, 0), key)
                       + (decimal_amount(entity.get("closing", {}).get(key, 0), key) - decimal_amount(entity.get("opening", {}).get(key, 0), key))
                       * (Decimal(1) if overridden else factor) for entity, overridden in period_sources), ZERO) for key in BS_KEYS}
    raw_pl = {key: sum((decimal_amount(entity.get(key, 0), key) * (Decimal(1) if overridden else factor)
                        for entity, overridden in period_sources), ZERO) for key in PL_KEYS}
    pl = dict(raw_pl)
    cf = {key: sum((decimal_amount(entity.get("cashflow", {}).get(key, 0), key) * (Decimal(1) if overridden else factor)
                   for entity, overridden in period_sources), ZERO) for key in CF_KEYS}
    approved_journals = []
    checks = []
    for entity in entities:
        checks.extend(entity_checks(entity))
    apply_group_journals = selection["entity"] == "all"
    journal_net = ZERO
    journal_capital_movement = ZERO
    if apply_group_journals:
        for journal in data.get("journals", []):
            if journal.get("status", "") not in APPROVED:
                continue
            journal_group = journal.get("group", "group")
            if journal_group == "manufacturing":
                journal_group = "mfg"
            if journal_group != selection["group"]:
                continue
            if "month" in journal and str(journal["month"]) != str(month):
                continue
            journal_factor = Decimal(1) if "month" in journal else factor
            try:
                validate_journal(journal)
            except ValueError as error:
                checks.append({"code": "journal_" + str(journal.get("id", "unknown")), "label": str(error), "passed": False, "difference": None})
                continue
            effects = journal.get("effects", {})
            for key in PL_KEYS:
                pl[key] += decimal_amount(effects.get(key, 0), key) * journal_factor
            for key in BS_KEYS:
                current[key] += decimal_amount(effects.get(key, 0), key) * journal_factor
            for key in CF_KEYS:
                cf[key] += decimal_amount(effects.get(key, 0), key) * journal_factor
            effect_net = _net_effect(effects) * journal_factor
            journal_net += effect_net
            # 实收资本及少数股东出资是明确的所有者投入，不能误当成本期利润。
            # 留存收益不能自动归入投入及分配，以免掩盖损益结转错误；股利或
            # 权益内部重分类需由凭证明示 capitalMovement（可为负数或零）。
            capital_movement = decimal_amount(journal.get("capitalMovement",
                _sum(effects, ("capital", "nci"))), "凭证所有者投入及分配") * journal_factor
            journal_capital_movement += capital_movement
            if "retained" not in effects:
                current["retained"] += effect_net
            approved_journals.append({"id": journal.get("id", ""), "title": journal.get("title", ""),
                                     "netEffect": display(effect_net),
                                     "capitalMovement": display(capital_movement),
                                     "effects": {key: display(decimal_amount(value) * journal_factor) for key, value in effects.items()}})
    net = pl["revenue"] - sum((pl[key] for key in PL_KEYS[1:]), ZERO)
    assets = sum((current[key] for key in ASSET_KEYS), ZERO)
    liabilities = sum((current[key] for key in LIABILITY_KEYS), ZERO)
    equity = sum((current[key] for key in EQUITY_KEYS), ZERO)
    change = sum(cf.values(), ZERO)
    financial_differences = [
        ("group_balance", "资产总额＝负债总额＋所有者权益", assets - liabilities - equity),
        ("group_cash", "期末现金＝期初现金＋现金净增加额", current["cash"] - begin["cash"] - change),
        ("group_equity", "权益变动＝累计净利润＋所有者投入及分配", equity - sum((begin[key] for key in EQUITY_KEYS), ZERO) - net
         - sum((decimal_amount(entity.get("capitalMovement", 0)) * (Decimal(1) if overridden else factor)
                for entity, overridden in period_sources), ZERO) - journal_capital_movement),
    ]
    checks.extend({"code": code, "label": label, "passed": abs(difference) < Decimal("0.0000001"),
                   "difference": display(difference)} for code, label, difference in financial_differences)
    gross = pl["revenue"] - pl["cost"]
    operating_profit = gross - pl["expense"]
    pretax = operating_profit - pl["finance"]
    actual = {key: display(value) for key, value in pl.items()}
    actual.update(net=display(net), gross=display(gross), operating=display(operating_profit), pretax=display(pretax),
                  grossMargin=float((gross / pl["revenue"] * 100).quantize(CENT)) if pl["revenue"] else 0,
                  netMargin=float((net / pl["revenue"] * 100).quantize(CENT)) if pl["revenue"] else 0,
                  assets=display(assets), liabilities=display(liabilities), equity=display(equity),
                  operatingCash=display(cf["operating"]), cash=display(current["cash"]))
    profit_lines = [("revenue", "营业收入", pl["revenue"]), ("cost", "营业成本", pl["cost"]), ("gross", "毛利", gross),
                    ("expense", "期间费用", pl["expense"]), ("operating", "营业利润（财务费用前）", operating_profit),
                    ("finance", "财务费用", pl["finance"]), ("pretax", "利润总额", pretax), ("tax", "所得税费用", pl["tax"]), ("net", "净利润", net)]
    profit = [{"key": key, "label": label, "value": display(value), "total": key in ("gross", "operating", "pretax", "net")}
              for key, label, value in profit_lines]
    bs_rows = [("货币资金", "cash"), ("应收账款", "receivable"), ("存货", "inventory"), ("预付款及其他流动资产", "prepaid"),
               ("固定资产净额", "fixed"), ("无形及其他非流动资产", "intangible"), ("递延所得税资产", "deferred_asset"),
               ("资产总计", "assets"), ("应付账款", "payable"), ("短期借款", "shortloan"), ("应交税费", "taxpayable"),
               ("其他流动负债", "otherliability"), ("长期借款", "longloan"), ("递延所得税负债", "deferred_liability"),
               ("负债合计", "liabilities"), ("实收资本", "capital"), ("未分配利润", "retained"), ("少数股东权益", "nci"),
               ("所有者权益合计", "equity"), ("负债及所有者权益总计", "balance")]
    totals = {"assets": assets, "liabilities": liabilities, "equity": equity, "balance": liabilities + equity}
    balance = [[label, display(totals.get(key, current.get(key, ZERO))), key] for label, key in bs_rows]
    # 间接法桥接中的非现金及其他调整由已报送现金流与源余额变动反推，并明确展示。
    # 该桥接只解释现金流，不修改资产负债数；现金勾稽仍可独立失败。
    working = {"receivable": -(current["receivable"] - begin["receivable"]),
               "inventory": -(current["inventory"] - begin["inventory"]),
               "prepaid": -(current["prepaid"] - begin["prepaid"]),
               "payable": current["payable"] - begin["payable"],
               "taxpayable": current["taxpayable"] - begin["taxpayable"],
               "otherliability": current["otherliability"] - begin["otherliability"]}
    noncash = cf["operating"] - net - sum(working.values(), ZERO)
    cash_rows = [("净利润", net, "net"), ("非现金及其他经营调整（报送桥接）", noncash, "noncash"),
                 ("应收账款减少（增加以负数列示）", working["receivable"], "receivable"),
                 ("存货减少（增加以负数列示）", working["inventory"], "inventory"),
                 ("预付款及其他流动资产减少", working["prepaid"], "prepaid"),
                 ("应付账款增加", working["payable"], "payable"),
                 ("应交税费增加", working["taxpayable"], "taxpayable"),
                 ("其他经营负债增加", working["otherliability"], "otherliability"),
                 ("经营活动产生的现金流量净额", cf["operating"], "operating"),
                 ("投资活动产生的现金流量净额", cf["investing"], "investing"),
                 ("筹资活动产生的现金流量净额", cf["financing"], "financing"),
                 ("现金及现金等价物净增加额", change, "change"), ("期初现金及现金等价物余额", begin["cash"], "openingcash"),
                 ("期末现金及现金等价物余额", current["cash"], "cash")]
    sources = [{"id": entity["id"], "name": entity.get("name", entity["id"]),
                **{key: display(decimal_amount(entity.get(key, 0)) * (Decimal(1) if overridden else factor)) for key in PL_KEYS},
                "net": display(net_profit(entity) * (Decimal(1) if overridden else factor)),
                "periodOverride": overridden,
                "cashflowEstimated": bool(entity.get("cashflowEstimated", False))} for entity, overridden in period_sources]
    year = data.get("settings", {}).get("fiscalYear", data.get("financePolicy", {}).get("year", 2026))
    return {"actual": actual, "profit": profit, "balance": balance,
            "cash": [[label, display(value), key] for label, value, key in cash_rows],
            "financial_checks": checks, "checks": checks, "passed": all(check["passed"] for check in checks),
            "currency": selection["currency"], "unit": "万美元" if selection["currency"] == "USD" else "万元",
            "rate": float(rate), "period": f"{year}年1—{month}月", "month": month,
            "scope": ("集团合并口径" if selection["group"] == "group" else "制造子集团") if selection["entity"] == "all" else entities[0].get("name", entities[0]["id"]),
            "context": {key: selection[key] for key in ("group", "entity", "currency", "month")},
            "source_entities": sources, "approved_journals": approved_journals,
            "rawNet": display(raw_pl["revenue"] - sum((raw_pl[key] for key in PL_KEYS[1:]), ZERO)),
            "journalNet": display(journal_net), "journalCapitalMovement": display(journal_capital_movement), "factor": float(factor),
            "actualThrough": data.get("financePolicy", {}).get("actualThrough", 9),
            "policyNote": "演示账套采用同本位币累计数；初始实际数截至9月，未报送的后续月份沿用累计数；非现金及其他经营调整为源报送现金流的解释桥接。"}
