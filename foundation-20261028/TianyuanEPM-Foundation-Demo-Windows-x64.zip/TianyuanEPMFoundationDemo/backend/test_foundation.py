"""Foundation-only invariants and original-ledger balance reconciliation."""
from copy import deepcopy
import json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'acceptance'))
import engine,erp_domain,foundation_fixtures as f
from store import DomainError,Store
ROLE='集团财务负责人'
class MemoryClient:
 def __init__(self):self.data=engine.seed();self.revision=0;self.context={'group':'TY_GROUP','month':6,'currency':'CNY','entity':'all'};self.bootstrap()
 def bootstrap(self,unit=None,month=6,currency='CNY'):
  if unit:self.context.update(group=unit,month=month,currency=currency,entity='all')
  self.state=engine.bootstrap(self.data,self.revision,[],ROLE,self.context);return self.state
 def act(self,action,payload=None):
  engine.apply(self.data,ROLE,action,payload or {},self.context);self.revision+=1;return self.bootstrap()
class FoundationTests(unittest.TestCase):
 def ready(self,closing=False):
  c=MemoryClient();f.create_masterdata(c);f.import_inputs(c,rows=f.with_closing() if closing else None);f.generate_and_check(c);return c
 def test_blank_never_preloads_or_signs(self):
  c=MemoryClient();d=c.data
  self.assertEqual((len(d['entities']),len(d['accounts']),len(d['ownership']),len(d['sources']),len(d['results']),len(d['eliminations'])),(0,0,0,0,0,0))
  self.assertFalse(c.state['dataReady']);self.assertEqual(c.state['reportMode'],'待建档');self.assertFalse(c.state['preconditions'][0]['passed'])
  self.assertEqual(len(c.state['erp']['templates']['nc65Csv'].splitlines()),1)
  with self.assertRaises(DomainError):c.act('consolidation_run')
  with self.assertRaises(DomainError) as error:c.act('erp_sample_load',{'replace':True,'reason':'不能预装'})
  self.assertEqual(error.exception.code,'sample_disabled')
 def test_first_custom_entity_has_no_fictional_parent(self):
  c=MemoryClient();c.act('entity_save',{'id':'OWNCO','code':'C001','name':'自建集团本部','currency':'CNY'})
  self.assertIsNone(c.data['entities'][0]['parentId']);self.assertEqual(c.data['ownership'],[])
  c.act('entity_save',{'id':'OWNCHILD','code':'C002','name':'自建子公司','currency':'CNY','parentId':'OWNCO'})
  c.act('ownership_save',{'entityId':'OWNCHILD','parentId':None,'percent':100,'method':'全额合并'})
  self.assertIsNone(next(e for e in c.data['entities'] if e['id']=='OWNCHILD')['parentId']);self.assertEqual(c.data['ownership'],[])
  c.act('unit_save',{'id':'TY_GROUP','name':'自建集团','currency':'CNY','members':[{'type':'entity','id':'OWNCO'}]})
  self.assertEqual(c.state['unitStatus']['status'],'待计算')
  with self.assertRaises(DomainError):c.act('consolidation_run')
 def test_balance_is_mandatory_and_not_double_booked(self):
  c=MemoryClient();f.create_masterdata(c);f.import_inputs(c,include_balance=False);c.act('erp_report_generate',{'entityIds':f.EIDS});before=deepcopy(c.data['sources']['6'])
  self.assertTrue(any(p['code']=='erp_balance_HW' and not p['passed'] for p in c.state['preconditions']))
  c.act('erp_balance_import',{'csv':f.balance_csv(),'amountUnit':'元'});self.assertEqual(c.data['sources']['6'],before)
  c.act('erp_balance_check',{'entityIds':f.EIDS});self.assertTrue(all(r['passed'] for r in c.state['erp']['balanceReports'].values()))
  results=f.consolidate(c);hw,root=results['HW_GROUP'],results['TY_GROUP']
  self.assertEqual((hw['statement']['actual']['revenue'],hw['statement']['actual']['net'],hw['statement']['actual']['assets']),(840,270,470))
  self.assertEqual((root['statement']['actual']['revenue'],root['statement']['actual']['assets']),(840,470))
  self.assertEqual(len(root['balanceSnapshots']),4)
  self.assertTrue(root['sourceSnapshots']['HW']['ledgerSnapshot']['balanceCheck']['passed'])
 def test_closing_vouchers_balance_in_original_ledger(self):
  c=self.ready(closing=True);report=c.state['erp']['balanceReports']['HW'];income=next(r for r in report['rows'] if r['accountCode']=='6001')
  self.assertTrue(report['passed']);self.assertEqual(income['actual']['closingCredit'],'0.00');self.assertEqual(income['actual']['debit'],'6000000.00')
  self.assertTrue(any('结转' in r['summary'] for r in income['voucherRefs']))
  self.assertEqual(c.data['sources']['6']['HW']['profit']['revenue'],600)
  results=f.consolidate(c);hw,root=results['HW_GROUP'],results['TY_GROUP'];self.assertEqual(root['statement']['actual']['net'],270)
 def test_one_cent_balance_difference_traces_without_plug(self):
  c=self.ready();before=deepcopy(c.data['sources']['6']);rows=f.balance_rows()
  for row in rows:
   if row[0]=='HW' and row[2]=='1001':row[6]='5800000.01';row[8]='2600000.01'
  c.act('erp_balance_import',{'csv':f.csv_text(f.BALANCE_HEADERS,rows),'amountUnit':'元'});c.act('erp_balance_check',{'entityIds':f.EIDS})
  bad=c.state['erp']['balanceReports']['HW'];self.assertFalse(bad['passed']);row=next(r for r in bad['rows'] if r['accountCode']=='1001')
  self.assertTrue(row['voucherRefs']);self.assertEqual(row['differences'][0]['difference'],'-0.01')
  self.assertEqual(c.data['sources']['6']['HW']['profit'],before['HW']['profit'])
  with self.assertRaises(DomainError):f.run_sign(c,'HW_GROUP')
 def test_missing_nonzero_account_and_changed_source_invalidate(self):
  c=self.ready();rows=[r for r in f.balance_rows() if not (r[0]=='HW' and r[2]=='1122')]
  c.act('erp_balance_import',{'csv':f.csv_text(f.BALANCE_HEADERS,rows)});c.act('erp_balance_check',{'entityIds':f.EIDS});self.assertIn('1122',c.state['erp']['balanceReports']['HW']['missingAccounts'])
  c.act('erp_balance_import',{'csv':f.balance_csv()});c.act('erp_balance_check',{'entityIds':f.EIDS})
  v=next(r for r in c.data['erp']['vouchers'] if r['entityId']=='HW' and r['accountCode']=='1001')
  c.act('erp_voucher_annotations_save',{'rowIds':[v['id']],'cashflow':'operating','reason':'据业务确认分类'})
  self.assertFalse(c.state['erp']['balanceReports']['HW']['valid'])
 def test_balance_cancel_wrong_period_is_zero_write(self):
  c=self.ready();batch=next(r for r in c.data['erp']['batches'] if r['kind']=='balance');c.bootstrap('TY_GROUP',month=7);before=deepcopy(c.data)
  with self.assertRaises(DomainError):c.act('erp_batch_cancel',{'batchId':batch['id'],'reason':'错期停用应被拒'})
  self.assertEqual(c.data,before)
  c.bootstrap('TY_GROUP',month=6);c.act('erp_batch_cancel',{'batchId':batch['id'],'reason':'重新取得余额表'})
  self.assertFalse(c.state['erp']['balanceReports']['HW']['valid'])
 def test_manual_sources_and_manual_sales_cannot_bypass_vouchers(self):
  c=MemoryClient();f.create_masterdata(c)
  with self.assertRaises(DomainError) as ex:c.act('source_import',{'csv':'法人编码,期间,数据区,项目编码,金额,月份\n'})
  self.assertEqual(ex.exception.code,'voucher_source_required')
  with self.assertRaises(DomainError) as ex:c.act('elimination_save',{'kind':'sales','erpMatchId':'伪造客户端标识','amount':60})
  self.assertEqual(ex.exception.code,'voucher_elimination_required')
  self.assertTrue(any(p['code']=='erp_source_HW' and not p['passed'] for p in c.state['preconditions']))
 def test_currency_cannot_relabel_imported_ledger_or_config(self):
  c=MemoryClient();f.create_masterdata(c)
  with self.assertRaises(DomainError):c.act('entity_save',{**f.ENTITIES[1],'currency':'USD'})
  c.act('erp_adapter_save',{'adapter':'nc65','bookMappings':[],'counterpartyMappings':[],'importOptions':{'auxiliaryColumns':['辅助核算1'],'referenceColumn':'结算号'}})
  c.act('erp_mapping_save',{'csv':f.mapping_csv()});c.act('erp_opening_import',{'csv':f.opening_csv()})
  with self.assertRaises(DomainError):c.act('entity_save',{**f.ENTITIES[1],'currency':'USD'})
if __name__=='__main__':unittest.main()
