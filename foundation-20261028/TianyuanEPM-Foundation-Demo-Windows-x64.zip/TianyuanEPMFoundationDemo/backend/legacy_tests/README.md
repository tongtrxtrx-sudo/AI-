旧版财务与工作流测试仅作历史参考。本目录不作为新版多层功能验收；新版仅运行 backend/test_consolidation.py 与 backend/test_multilevel_domain.py。旧display currency、少数股东、资本变动或分红不代表本版支持。
