"""财务领域金样与故障测试：python3 -m unittest backend.test_finance。"""

from copy import deepcopy
from decimal import Decimal
import unittest

try:
    from .finance import (BS_KEYS, decimal_amount, decimal_rate, entity_checks, net_profit,
                          seed_finance, statement, validate_entity, validate_finance, validate_journal)
except ImportError:
    from finance import (BS_KEYS, decimal_amount, decimal_rate, entity_checks, net_profit,
                         seed_finance, statement, validate_entity, validate_finance, validate_journal)


class FinanceTests(unittest.TestCase):
    def setUp(self):
        self.data = seed_finance()

    def test_group_golden_three_statements(self):
        report = statement(self.data)
        expected = dict(revenue=13000, cost=7620, expense=2920, finance=170, tax=570, net=1720,
                        assets=9580, liabilities=4730, equity=4850, operatingCash=1450, cash=2050)
        for key, value in expected.items():
            self.assertEqual(report['actual'][key], value, key)
        balance = {row[2]: row[1] for row in report['balance']}
        cash = {row[2]: row[1] for row in report['cash']}
        self.assertEqual(balance['retained'], 2650)
        self.assertEqual(balance['nci'], 200)
        self.assertEqual(cash['noncash'], 240)
        self.assertEqual(cash['change'], 370)
        self.assertEqual(cash['openingcash'], 1680)
        self.assertTrue(report['passed'])
        self.assertTrue(all(item['passed'] for item in report['financial_checks']))

    def test_each_entity_has_independently_balanced_sources(self):
        validate_finance(self.data)
        for entity, expected in zip(self.data['entities'], [1125, 600, 100]):
            self.assertEqual(net_profit(entity), expected)
            self.assertTrue(all(item['passed'] for item in entity_checks(entity)))
        self.assertEqual(statement(self.data, {'group': 'mfg'})['actual']['net'], 1125)
        self.assertEqual(statement(self.data, {'entity': 'MFG'})['actual']['net'], 1125)
        self.assertEqual(statement(self.data, {'group': 'manufacturing'})['context']['group'], 'mfg')

    def test_coherent_source_change_changes_all_relevant_values(self):
        entity = self.data['entities'][0]
        entity['revenue'] += 100
        entity['net'] += 100
        entity['closing']['cash'] += 100
        entity['closing']['retained'] += 100
        entity['cashflow']['operating'] += 100
        validate_entity(entity)
        actual = statement(self.data)['actual']
        self.assertEqual(actual['revenue'], 13100)
        self.assertEqual(actual['net'], 1820)
        self.assertEqual(actual['assets'], 9680)
        self.assertEqual(actual['equity'], 4950)
        self.assertEqual(actual['cash'], 2150)
        self.assertEqual(actual['operatingCash'], 1550)
        self.assertTrue(statement(self.data)['passed'])

    def test_incoherent_change_is_not_auto_balanced(self):
        self.data['entities'][0]['revenue'] += 1
        with self.assertRaisesRegex(ValueError, '勾稽不通过'):
            validate_entity(self.data['entities'][0])
        report = statement(self.data)
        self.assertEqual(report['actual']['net'], 1721)
        self.assertEqual(report['actual']['equity'], 4850)
        self.assertFalse(report['passed'])
        self.assertTrue(any(not check['passed'] for check in report['financial_checks']))

    def test_unapproved_journals_do_not_change_group(self):
        for journal in self.data['journals']:
            journal['status'] = '草稿'
        actual = statement(self.data)['actual']
        self.assertEqual(actual['revenue'], 14800)
        self.assertEqual(actual['net'], 1825)
        self.assertEqual(actual['assets'], 9690)
        self.assertEqual(actual['liabilities'], 4735)
        self.assertEqual(actual['equity'], 4955)

    def test_journal_amounts_change_results(self):
        journal = self.data['journals'][1]
        journal['lines'] = [[label, side, amount * 2] for label, side, amount in journal['lines']]
        journal['effects'] = {key: amount * 2 for key, amount in journal['effects'].items()}
        validate_journal(journal)
        report = statement(self.data)
        self.assertEqual(report['actual']['net'], 1630)
        self.assertEqual(report['actual']['assets'], 9490)
        self.assertEqual(report['actual']['equity'], 4760)
        self.assertTrue(report['passed'])

    def test_invalid_journal_is_rejected_and_report_blocks_close(self):
        journal = self.data['journals'][0]
        journal['lines'][0][2] = 1801
        with self.assertRaisesRegex(ValueError, '借贷不平衡'):
            validate_journal(journal)
        report = statement(self.data)
        self.assertFalse(report['passed'])
        self.assertTrue(any(check['code'] == 'journal_DEMO-ELIM-001' and not check['passed'] for check in report['checks']))

    def test_period_weights_preserve_financial_reconciliation(self):
        for month in range(1, 13):
            report = statement(self.data, {'month': month})
            self.assertTrue(report['passed'], month)
        self.assertEqual(statement(self.data, {'month': 12})['actual']['net'], 1720)
        self.assertLess(statement(self.data, {'month': 8})['actual']['revenue'], 13000)

    def test_foreign_display_currency_uses_rate_without_changing_sources(self):
        before = deepcopy(self.data)
        report = statement(self.data, {'currency': 'USD'})
        self.assertEqual(report['actual']['revenue'], 1830.99)
        self.assertEqual(report['actual']['net'], 242.25)
        self.assertEqual(report['unit'], '万美元')
        self.assertTrue(report['passed'])
        self.assertEqual(self.data, before)
        self.data['rates']['USD'] = 8
        self.assertEqual(statement(self.data, {'currency': 'USD'})['actual']['revenue'], 1625)

    def test_amount_and_rate_validation(self):
        self.assertEqual(decimal_amount('0.10') + decimal_amount('0.20'), Decimal('0.30'))
        self.assertEqual(decimal_rate('7.123456'), Decimal('7.123456'))
        for value in (True, None, '', 'NaN', 'Infinity', '-Infinity', '1.001', '1e100', [], {}):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    decimal_amount(value)
        for value in (0, -1, 'NaN', '7.1234567', True):
            with self.assertRaises(ValueError):
                decimal_rate(value)

    def test_selection_validation_and_scope(self):
        for context in ({'group': 'bad'}, {'group': 'mfg', 'entity': 'TEC'}, {'entity': 'unknown'},
                        {'month': 0}, {'month': 13}, {'month': True}, {'month': 1.5}, {'currency': 'EUR'}):
            with self.subTest(context=context):
                with self.assertRaises(ValueError):
                    statement(self.data, context)

    def test_period_override_is_current_cumulative_and_isolated(self):
        old_eight = statement(self.data, {'month': 8})
        zero = {key: 0 for key in BS_KEYS}
        closing = dict(zero, cash=123, retained=123)
        override = dict(revenue=123, cost=0, expense=0, finance=0, tax=0, net=123,
                        opening=zero, closing=closing, cashflow={'operating': 123, 'investing': 0, 'financing': 0},
                        profitClosed=True, cashflowEstimated=True)
        self.data['periodOverrides'] = {'7': {'MFG': override}}
        actual = statement(self.data, {'month': 7, 'entity': 'MFG'})
        self.assertEqual(actual['actual']['revenue'], 123)
        self.assertEqual(actual['actual']['net'], 123)
        self.assertEqual(actual['actual']['cash'], 123)
        self.assertEqual(actual['actual']['operatingCash'], 123)
        self.assertTrue(actual['passed'])
        self.assertTrue(actual['source_entities'][0]['cashflowEstimated'])
        self.assertEqual(statement(self.data, {'month': 8}), old_eight)

    def test_unclosed_override_profit_is_closed_exactly_once(self):
        zero = {key: 0 for key in BS_KEYS}
        self.data['periodOverrides'] = {'9': {'MFG': dict(revenue=10, cost=0, expense=0, finance=0, tax=0,
            opening=zero, closing=dict(zero, cash=10), cashflow={'operating': 10, 'investing': 0, 'financing': 0}, profitClosed=False)}}
        report = statement(self.data, {'entity': 'MFG'})
        self.assertEqual(report['actual']['net'], 10)
        self.assertEqual(report['actual']['equity'], 10)
        self.assertTrue(report['passed'])

    def test_explicit_journal_period_and_group_are_respected(self):
        new = {'id': 'J-TEST', 'title': '制造非现金调整', 'status': '已审批', 'group': 'mfg', 'month': 9,
               'lines': [['期间费用', '借', 10], ['固定资产净额', '贷', 10]], 'effects': {'expense': 10, 'fixed': -10}}
        self.data['journals'].append(new)
        self.assertEqual(statement(self.data)['actual']['net'], 1720)
        self.assertEqual(statement(self.data, {'group': 'mfg'})['actual']['net'], 1115)
        self.assertTrue(statement(self.data, {'group': 'mfg'})['passed'])
        self.assertFalse(any(j['id'] == 'J-TEST' for j in statement(self.data, {'group': 'mfg', 'month': 8})['approved_journals']))

    def test_cash_capital_contribution_has_no_profit_and_reconciles_equity(self):
        self.data['journals'].append({'id': 'J-CAPITAL', 'title': '股东现金增资', 'status': '已审批',
            'group': 'group', 'month': 9, 'lines': [['货币资金', '借', 100], ['实收资本', '贷', 100]],
            'effects': {'cash': 100, 'capital': 100, 'financing': 100}})
        report = statement(self.data)
        self.assertTrue(report['passed'])
        self.assertEqual(report['actual']['net'], 1720)
        self.assertEqual(report['actual']['cash'], 2150)
        self.assertEqual(report['actual']['equity'], 4950)
        self.assertEqual(report['journalCapitalMovement'], 100)
        self.assertEqual({row[2]: row[1] for row in report['cash']}['financing'], -160)

    def test_retained_profit_error_is_not_automatically_owner_contribution(self):
        self.data['journals'].append({'id': 'J-RETAINED', 'title': '未说明的留存收益变动', 'status': '已审批',
            'group': 'group', 'month': 9, 'lines': [['货币资金', '借', 100], ['未分配利润', '贷', 100]],
            'effects': {'cash': 100, 'retained': 100, 'financing': 100}})
        report = statement(self.data)
        self.assertFalse(report['passed'])
        self.assertEqual(report['journalCapitalMovement'], 0)
        self.assertFalse(next(check for check in report['checks'] if check['code'] == 'group_equity')['passed'])

    def test_explicit_owner_distribution_from_retained_earnings(self):
        self.data['journals'].append({'id': 'J-DIVIDEND', 'title': '现金股利分配', 'status': '已审批',
            'group': 'group', 'month': 9, 'capitalMovement': -100,
            'lines': [['未分配利润', '借', 100], ['货币资金', '贷', 100]],
            'effects': {'cash': -100, 'retained': -100, 'financing': -100}})
        report = statement(self.data)
        self.assertTrue(report['passed'])
        self.assertEqual(report['actual']['net'], 1720)
        self.assertEqual(report['actual']['equity'], 4750)
        self.assertEqual(report['journalCapitalMovement'], -100)


if __name__ == '__main__':
    unittest.main()
