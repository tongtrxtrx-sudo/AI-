import csv
import io
import tempfile
import threading
import unittest
from copy import deepcopy
from decimal import Decimal
from pathlib import Path
from engine import apply,bootstrap,context,seed
from store import DomainError,Store

ROLE='集团财务负责人'

def source_csv(data,month=9,entity='MFG',delta=0):
    out=io.StringIO();w=csv.writer(out);w.writerow(['法人编码','期间','科目编码','借方余额','贷方余额'])
    e=next(e for e in data['entities'] if e['id']==entity)
    for a in data['accounts']:
        f=a['field'];v=Decimal(str(e.get(f,e['closing'].get(f,0))))
        if f=='retained':v-=Decimal(str(e['net']))
        if f in ('cash','revenue'):v+=Decimal(str(delta))
        debit=v if a['normalSide']=='借' else -v
        w.writerow([e['code'],f'2026-{month:02d}',a['code'],str(max(debit,0)),str(max(-debit,0))])
    return out.getvalue()

class EngineTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name,seed);self.c=context()
    def tearDown(self):self.tmp.cleanup()
    def action(self,name,payload=None,c=None,role=ROLE,revision=None):
        r,_,_=self.store.read()
        return self.store.mutate(r if revision is None else revision,role,name,payload or {},c or self.c,apply)
    def view(self,c=None):
        r,d,a=self.store.read();return bootstrap(d,r,a,ROLE,c or self.c)
    def test_budget_snapshot_adjustment_and_switch(self):
        self.action('budget_submit');self.action('budget_approve');self.action('budget_lock')
        with self.assertRaises(DomainError):self.action('budget_layer_save',{'layer':0,'amount':1})
        original=self.view()['budget']['layers']
        self.action('budget_adjust_create',{'layer':0,'delta':'100.25','reason':'渠道扩张'})
        aid=self.view()['budget']['adjustments'][0]['id'];self.action('budget_adjust_approve',{'id':aid})
        self.assertEqual(self.view()['budget']['layers'][0]['amount'],16100.25)
        self.action('budget_switch',{'name':'V2 年度目标'})
        self.assertEqual(self.view()['budget']['layers'],original)
        self.assertEqual(self.view()['budget']['status'],'已锁定')
        with self.assertRaises(DomainError):self.action('budget_adjust_approve',{'id':aid})
    def test_rollback_precision_rate_and_invalid_action(self):
        for name,p in [('budget_layer_save',{'layer':0,'amount':'1.001'}),('rate_save',{'currency':'USD','rate':1000001}),('unknown',{})]:
            before=self.store.read()
            with self.assertRaises(DomainError):self.action(name,p)
            self.assertEqual(self.store.read(),before)
    def test_revision_race_one_commit(self):
        rev=self.store.read()[0];out=[]
        def write(amount):
            try:self.action('budget_layer_save',{'layer':0,'amount':amount},revision=rev);out.append('ok')
            except DomainError as e:out.append(e.code)
        threads=[threading.Thread(target=write,args=(x,)) for x in (16001,16002)]
        for t in threads:t.start()
        for t in threads:t.join()
        self.assertCountEqual(out,['ok','revision_conflict'])
        self.assertEqual(self.store.read()[0],1)
    def test_readonly_and_manager_actions(self):
        for role,action,p in [('审计只读','budget_layer_save',{'layer':0,'amount':1}),('法人会计','rate_save',{'currency':'USD','rate':7.2})]:
            with self.assertRaises(DomainError) as caught:self.action(action,p,role=role)
            self.assertEqual(caught.exception.status,403)
        self.assertEqual(self.store.read()[0],0)
    def test_csv_decimal_change_invalidation_and_restart(self):
        self.action('checks_run');self.action('ic_confirm',{'reason':'已核对往来'})
        data=self.store.read()[1]
        self.action('tb_import',{'csv':source_csv(data,delta='0.25'),'sourceName':'测试报送.csv'})
        v=self.view();self.assertEqual(v['statement']['actual']['revenue'],13000.25)
        self.assertEqual(v['statement']['actual']['net'],1720.25)
        self.assertFalse(v['period']['checksRun']);self.assertFalse(v['period']['icConfirmed'])
        self.assertTrue(v['statement']['passed'])
        second=Store(self.tmp.name,lambda: (_ for _ in ()).throw(AssertionError('不应重建账套')))
        r,d,a=second.read();self.assertEqual(bootstrap(d,r,a,ROLE,self.c)['statement']['actual']['revenue'],13000.25)
        self.assertEqual(len(a),3)
    def test_csv_whole_batch_rollback_and_month_isolation(self):
        c8=context({'month':8});self.action('checks_run',c=c8);self.action('ic_confirm',{'reason':'8月核对'},c=c8)
        d=self.store.read()[1];bad=source_csv(d)+'不存在,2026-09,1002,0,0\n';before=self.store.read()
        with self.assertRaises(DomainError):self.action('tb_import',{'csv':bad})
        self.assertEqual(self.store.read(),before)
        self.action('tb_import',{'csv':source_csv(d,delta=1)})
        self.assertTrue(self.view(c8)['period']['checksRun']);self.assertTrue(self.view(c8)['period']['icConfirmed'])
        self.assertFalse(self.view()['period']['checksRun'])
    def test_signoff_reopen_and_period_protection(self):
        with self.assertRaises(DomainError):self.action('signoff')
        self.action('submission_confirm');self.action('checks_run');self.action('ic_confirm',{'reason':'核对无误'});self.action('commentary_save',{'text':'收入达成目标，费用可控。'});self.action('signoff')
        self.assertTrue(self.view()['period']['signed'])
        with self.assertRaises(DomainError):self.action('tb_import',{'csv':source_csv(self.store.read()[1])})
        # 不同月份独立允许报送，不能解除9月签核。
        c8=context({'month':8});self.action('tb_import',{'csv':source_csv(self.store.read()[1],month=8)},c=c8)
        self.assertTrue(self.view()['period']['signed'])
        self.action('period_reopen',{'reason':'收到补充调整'});self.assertFalse(self.view()['period']['signed'])
        self.assertFalse(self.view()['period']['checksRun'])
    def test_journal_effect_is_month_specific_and_requires_approval(self):
        c8=context({'month':8});old8=self.view(c8)['statement']['actual']['assets']
        self.action('journal_create',{'title':'存货暂估','lines':[{'accountCode':'1405','debit':'10.25','credit':0},{'accountCode':'2202','debit':0,'credit':'10.25'}]})
        v=self.view();self.assertEqual(v['statement']['actual']['assets'],9580)
        j=v['journals'][-1];self.action('journal_approve',{'id':j['id']});v=self.view()
        self.assertEqual(v['statement']['actual']['assets'],9590.25);self.assertEqual(v['statement']['actual']['liabilities'],4740.25)
        self.assertTrue(v['statement']['passed']);self.assertEqual(self.view(c8)['statement']['actual']['assets'],old8)
    def test_cash_journal_requires_classification_and_reconciles(self):
        p={'title':'现金收入调整','lines':[{'accountCode':'1002','debit':100,'credit':0},{'accountCode':'6001','debit':0,'credit':100}]}
        with self.assertRaises(DomainError):self.action('journal_create',p)
        p['cashflowCategory']='operating';self.action('journal_create',p)
        self.action('journal_approve',{'id':self.view()['journals'][-1]['id']})
        v=self.view();self.assertEqual(v['statement']['actual']['cash'],2150);self.assertEqual(v['statement']['actual']['operatingCash'],1550);self.assertEqual(v['statement']['actual']['net'],1820);self.assertTrue(v['statement']['passed'])
    def test_budget_detail_price_is_validated_server_side(self):
        before=self.store.read()
        with self.assertRaises(DomainError):self.action('budget_plan_save',{'type':'purchase','rows':[{'id':'1','name':'采购预算','quantity':2,'price':3,'amount':999}]})
        self.assertEqual(self.store.read(),before)
        self.action('budget_plan_save',{'type':'purchase','rows':[{'id':'1','name':'采购预算','quantity':2,'price':3,'amount':6}]})
        self.assertEqual(self.view()['budget']['businessPlans']['purchase'][0]['amount'],6)
    def test_fiscal_year_cannot_relabel_financial_sources(self):
        before=self.store.read()
        with self.assertRaises(DomainError):self.action('settings_save',{'fiscalYear':2027})
        self.assertEqual(self.store.read(),before)
        self.action('settings_save',{'fiscalYear':2026,'companyName':'杭州天元宠物用品有限公司'})
        self.assertEqual(self.view()['settings']['fiscalYear'],2026)
    def test_all_contexts_render(self):
        for group in ['group','mfg']:
            for month in [1,8,9,10,12]:
                for currency in ['CNY','USD']:
                    v=self.view(context({'group':group,'month':month,'currency':currency}));self.assertTrue(v['statement']['passed'])

if __name__=='__main__':unittest.main()
