"""ERP functional currency cents survive source, FX, elimination and roll-up."""
import unittest
from copy import deepcopy
from decimal import Decimal
from consolidation import (BS,PL,CF,seed_multilevel,calculate_unit,translate_result,
    validate_source,dec,num,net,financial_checks)
from test_consolidation import approved

D=Decimal

def add(row,key,value):row[key]=num(D(str(row.get(key,0)))+D(str(value)))

def cash_sale(source,value,month=9):
    for area,key in [('profit','revenue'),('closing','cash'),('closing','retained'),('cashflow','operating')]:add(source[area],key,value)
    add(source['monthlyProfit'][str(month)],'revenue',value)
    add(source['monthlyCashflow'][str(month)],'operating',value)


def small_usd_source(month=2):
    o=dict.fromkeys(BS,0);c=deepcopy(o)
    c.update(cash=.000002,retained=.000002)
    p=dict.fromkeys(PL,0);p['revenue']=.000002
    f=dict.fromkeys(CF,0);f['operating']=.000002
    return {'version':1,'currency':'USD','opening':o,'closing':c,'profit':p,
            'cashflow':f,'monthlyProfit':{str(m):{**dict.fromkeys(PL,0),'revenue':.000001} for m in range(1,month+1)},
            'monthlyCashflow':{str(m):{**dict.fromkeys(CF,0),'operating':.000001} for m in range(1,month+1)},
            'capitalMovement':0,'equityHistory':{'capitalByEntity':{'SMALL':0},'openingRetainedCny':0,'dividendsByMonth':{}}}


class ERPCalculationTests(unittest.TestCase):
    def setUp(self):self.data=seed_multilevel()
    def children(self):return {u:approved(calculate_unit(self.data,u,9)) for u in ('HW_GROUP','OS_GROUP')}
    def root(self,children=None):return calculate_unit(self.data,'TY_GROUP',9,self.children() if children is None else children)

    def test_one_yuan_cent_survives_each_level(self):
        s=self.data['sources']['9']['HW_CAT'];cash_sale(s,'0.000001')
        validate_source(self.data,'HW_CAT',9,s)
        children=self.children();self.assertEqual(children['HW_GROUP']['statement']['actual']['net'],450.000001)
        r=self.root(children)
        self.assertEqual(r['statement']['actual']['revenue'],2650.000001)
        self.assertEqual(r['statement']['actual']['net'],770.000001)
        self.assertEqual(r['statement']['actual']['cash'],2370.000001)
        self.assertTrue(r['passed'])

    def test_decimal_repeated_cents_no_float_accumulation(self):
        s=self.data['sources']['9']['HW_CAT']
        for _ in range(1000):cash_sale(s,'0.000001')
        self.assertEqual(s['profit']['revenue'],300.001)
        r=self.root();self.assertEqual(r['statement']['actual']['net'],770.001)
        self.assertTrue(r['passed'])

    def test_half_cent_fx_rounds_at_target_currency_cent_per_month(self):
        source=small_usd_source()
        data={'entities':[{'id':'SMALL','name':'美元分位测试','currency':'USD'}],
              'units':[{'id':'SMALL_GROUP','name':'美元分位小合并','currency':'USD','members':[{'type':'entity','id':'SMALL'}]}],
              'sources':{'2':{'SMALL':source}},'eliminations':[],
              'fxRates':[{'id':'SMALL-FX','month':2,'version':1,'active':True,'sourceCurrency':'USD','targetCurrency':'CNY','status':'已审批','opening':7,'closing':7,'historicalCapital':7,'averages':{'1':6.5,'2':7.5},'flowRates':{'1':6.5,'2':7.5}}]}
        usd=calculate_unit(data,'SMALL_GROUP',2)
        cny=translate_result(data,usd,'CNY',2)
        # $0.01 at 6.5 -> CNY0.07; $0.01 at 7.5 -> CNY0.08.
        self.assertEqual(cny['report']['monthlyProfit']['1']['revenue'],.000007)
        self.assertEqual(cny['report']['monthlyProfit']['2']['revenue'],.000008)
        self.assertEqual(cny['report']['profit']['revenue'],.000015)
        self.assertEqual(cny['report']['closing']['cash'],.000014)
        self.assertEqual(cny['report']['closing']['cta'],-.000001)
        self.assertEqual(cny['report']['cashflow']['fx'],-.000001)
        self.assertTrue(cny['passed'])

    def test_no_more_than_currency_cents_or_lossy_json_amounts(self):
        self.assertEqual(dec('0.000001'),D('.000001'))
        with self.assertRaisesRegex(ValueError,'最多6'):dec('0.0000001')
        self.assertEqual(num(D('.0000005')),.000001)
        with self.assertRaisesRegex(ValueError,'无损保存'):num(D('1000000000000.000001'))
        s=deepcopy(self.data['sources']['9']['HW_CAT']);add(s['closing'],'cash','.000001')
        with self.assertRaisesRegex(ValueError,'0.000001万元'):validate_source(self.data,'HW_CAT',9,s)

    def add_credit_sale_and_opening_balance(self):
        seller=self.data['sources']['9']['HW'];buyer=self.data['sources']['9']['HW_CAT']
        for source,field,sign in [(seller,'receivable',1),(buyer,'payable',-1)]:
            add(source['opening'],field,5);add(source['closing'],field,15)
            add(source['opening'],'retained',sign*5);add(source['closing'],'retained',sign*15)
            pl='revenue' if sign==1 else 'cost'
            add(source['profit'],pl,10);add(source['monthlyProfit']['9'],pl,10)
            validate_source(self.data,'HW' if sign==1 else 'HW_CAT',9,source)
        sale={'id':'ERP-SALE','sourceId':'ERP-SALE-REF','unitId':'HW_GROUP','month':9,'kind':'sales','status':'已审批','version':1,'currency':'CNY','amount':10,'sellerId':'HW','buyerId':'HW_CAT','effects':{'revenue':-10,'cost':-10},'openingEffects':{},'monthlyEffects':{str(m):{'revenue':-10 if m==9 else 0,'cost':-10 if m==9 else 0} for m in range(1,10)},'voucherRefs':[{'entityId':'HW','voucherId':'NC-9-001','lineNo':1},{'entityId':'HW_CAT','voucherId':'NC-9-002','lineNo':2}],'matchSignature':'PAIR-V1'}
        balance={'id':'ERP-BAL','sourceId':'ERP-BAL-REF','unitId':'HW_GROUP','month':9,'kind':'balances','status':'已审批','version':1,'currency':'CNY','amount':15,'openingAmount':5,'sellerId':'HW','buyerId':'HW_CAT','effects':{'receivable':-15,'payable':-15},'openingEffects':{'receivable':-5,'payable':-5},'voucherRefs':deepcopy(sale['voucherRefs']),'matchSignature':'BAL-V1'}
        self.data['eliminations'] += [sale,balance]
        return sale,balance

    def test_receivable_payable_open_and_close_eliminate_without_profit_or_cf_plug(self):
        self.add_credit_sale_and_opening_balance();r=self.root()
        self.assertEqual(r['statement']['actual']['revenue'],2650)
        self.assertEqual(r['statement']['actual']['net'],770)
        self.assertEqual(r['statement']['actual']['assets'],2370)
        self.assertEqual(r['report']['opening']['receivable'],0)
        self.assertEqual(r['report']['closing']['receivable'],0)
        self.assertEqual(r['report']['closing']['payable'],0)
        self.assertEqual(r['report']['cashflow']['operating'],770)
        self.assertTrue(r['passed'])
        e=next(x for x in r['trace']['eliminations'] if x['id']=='ERP-BAL')
        self.assertTrue(e['inherited']);self.assertEqual(e['openingAmount'],5)
        self.assertEqual(e['voucherRefs'][0]['voucherId'],'NC-9-001')
        self.assertEqual(e['matchSignature'],'BAL-V1')

    def test_balances_wrong_layer_difference_or_hidden_effects_are_rejected(self):
        for mode in ('layer','difference','opening','profit','capital'):
            with self.subTest(mode=mode):
                self.data=seed_multilevel();_,e=self.add_credit_sale_and_opening_balance()
                if mode=='layer':e['unitId']='TY_GROUP'
                if mode=='difference':e['effects']['payable']=-14
                if mode=='opening':e['openingEffects']['payable']=-4
                if mode=='profit':e['effects']['revenue']=-1
                if mode=='capital':e['capitalMovement']=1
                with self.assertRaises(ValueError):self.root()

    def test_cent_internal_sale_elimination_survives_lineage_and_fx(self):
        for eid,field,sign in [('OS_A','revenue',1),('OS_B','cost',-1)]:
            s=self.data['sources']['9'][eid]
            add(s['profit'],field,'.000001');add(s['closing'],'retained',D('.000001')*sign)
            add(s['closing'],'cash',D('.000001')*sign);add(s['cashflow'],'operating',D('.000001')*sign)
            add(s['monthlyProfit']['9'],field,'.000001');add(s['monthlyCashflow']['9'],'operating',D('.000001')*sign)
        self.data['eliminations'].append({'id':'ERP-CENT','sourceId':'ERP-CENT','unitId':'OS_GROUP','month':9,'kind':'sales','status':'已审批','version':1,'currency':'USD','amount':.000001,'sellerId':'OS_A','buyerId':'OS_B','effects':{'revenue':-.000001,'cost':-.000001},'openingEffects':{},'monthlyEffects':{str(m):{'revenue':-.000001 if m==9 else 0,'cost':-.000001 if m==9 else 0} for m in range(1,10)},'voucherRefs':[{'voucherId':'NC-CENT-001','lineNo':2}]})
        r=self.root();self.assertEqual(r['statement']['actual']['revenue'],2650)
        self.assertEqual(r['statement']['actual']['net'],770);self.assertTrue(r['passed'])
        self.assertEqual(next(e for e in r['trace']['eliminations'] if e['id']=='ERP-CENT')['voucherRefs'][0]['voucherId'],'NC-CENT-001')

    def test_historical_ledger_provenance_inherited_and_hashed(self):
        s=self.data['sources']['9']['HW_CAT'];s['ledgerTrace']={'ledgerVersion':3,'voucherRefs':[{'voucherId':'NC-9-123','lineNo':1}]}
        children=self.children();r=self.root(children)
        trace=next(e for e in r['trace']['entities'] if e['entityId']=='HW_CAT')
        self.assertEqual(trace['ledgerTrace'],s['ledgerTrace'])
        children['HW_GROUP']['trace']['entities'][1]['ledgerTrace']['voucherRefs'][0]['voucherId']='forged'
        with self.assertRaisesRegex(ValueError,'内容校验'):self.root(children)


if __name__=='__main__':unittest.main()
