# 第三方归属与源码位置

本包供本机研发试用，将原有开源财务平台放入原生Linux客体，由Windows私有Python和QEMU启动。用户电脑不需要安装Docker；Docker镜像仅作为构建输入，不随之将Docker Desktop作为本机前提。包名“自研EPM”不改变上游版权、商标和许可证。

| 组件 | 固定版本/证据 | 许可文本与源码 |
|---|---|---|
| Konsolidat | 99d7c5a3b08c82034cc26eced1fbb95eaafec12b | MIT原文Konsolidat-MIT.txt；启动ZIP目标树source/konsolidat（构建输入build/input/konsolidat） |
| Konsol | d2d71efdb1f198610d711f656b8373ac0c9cd0c4 | hooks.py声明app_license=MIT，但此提交无仓库级LICENSE，也无pyproject.toml；不能把另一项目的MIT自动扩展给它。启动ZIP目标树source/konsol（构建输入build/input/konsol） |
| Frappe | d2efa79657ba5c1abf96098b3bfacc199517d57e | Frappe-MIT.txt；固定归档public_source_url见SOURCE-VERSIONS.json，不在启动ZIP；客体源码/home/frappe/frappe-bench/apps/frappe |
| CPython | Windows私有运行时3.12.10 | CPython-3.12.10.txt及python/LICENSE.txt，含附带第三方条款；来自已记录官方NuGet包 |
| QEMU | Windows11.1.0，20260811构建，实际revision e470268ff446ec56728215a987ed166d5ed8fb64 | qemu/内GPL2、LGPL2.1、EDK2及上游license说明；外置精确主仓源码归档public_source_url见SOURCE-VERSIONS.json，不在启动ZIP；15个gitlink子模块和DLL精确源/许可仍有缺口 |
| Node.js | 客体Frappe18.20.8、Cube20.17.0 | guest/Node-*-LICENSE.txt包含Node及附带组件许可，不能只留一行“MIT” |
| ClickHouse | 24.8.14.39官方构建 | guest/ClickHouse-24.8.14.39-LICENSE.txt，固定v24.8.14.39-lts源标签；二进制第三方NOTICE闭包仍需核对 |
| Cube | 实际官方镜像0.36.11 | guest/Cube-0.36.11-LICENSE.txt为Apache2原文；npm依赖各有许可，不能全部当Cube Apache2 |
| Debian及内核、MariaDB、Redis、nginx等 | Debian12.15，309包binary/source版本记录 | guest/Debian-package-copyrights.tar.gz含当前构建已安装copyright及通用许可；各包源码版本见TSV，源码归档并未全部随包 |
| Python/npm依赖 | 实际安装版本清单 | guest/下各pip/npm清单及Python-npm-installed-license-texts.tar.gz，收集2259份已安装许可文件；清单与文本不等于全部组件完整对应源码 |

QEMU的104个实际DLL逐文件Hash及候选来源保存在qemu/DLL-origin-license-inventory.json和.csv。8个GLib/GTK/OpenSSL DLL已与GPG校验及信任链通过的固定MSYS2包逐字节Hash匹配，实际包许可和metadata已留存于msys2-exact-packages；三组精确PKGBUILD已按固定提交取得并与BUILDINFO的SHA256匹配；上游源码tar及本地patch仍未下载。其余96个DLL的精确包/许可匹配仍pending。候选项目URL是进一步定位用的来源线索；根目录COPYING/COPYING.LIB不泛化覆盖这些DLL。固件许可也不能由QEMU主程序GPL一句概括。

本次研发试用如实记录以上覆盖范围。后续商业产品对外再分发涉及的具体事项：保留每个适用版权和许可；确认Konsol仓库级授权范围；为实际发出的GPL/LGPL等组件补齐匹配版本的源码、补丁、子模块及构建所需材料，采用适用许可允许的交付方式。当前源码链接、安装版本表和SHA记录用于追溯，不构成已履行完整对应源码义务的声明或书面源码提供承诺。

本目录不包含本机seed、运行密码或个人工作配置。上游许可证中的作者、版权方和联系信息属于应保留的公开归属，不是本次云环境个人凭据。基盘该版本全部检查通过，具体项目与无站点/seed/SSH主机密钥等清理证据见guest/pristine-rootfs-audit.json；这是指定构建rootfs的检查，实际调试overlay与发布基盘分开，不据此声明所有后续运行数据都可公开。

Frappe、Gunicorn、PyPika和QEMU主仓源码归档的公开下载固定于发布提交`1cf4b9911abf0fe13c0358c8f9ff548d56195fca`，完整URL、原始源码SHA与Hash见根目录SOURCE-VERSIONS.json；本目录不把外置归档写作启动ZIP的已含成员。两项目source目录的618/897个文件已由打包负责人对照构建输入逐Hash核验，最终ZIP由打包脚本逐成员核对；发布制品SHA256与验证结果见外置release-verification.json。
