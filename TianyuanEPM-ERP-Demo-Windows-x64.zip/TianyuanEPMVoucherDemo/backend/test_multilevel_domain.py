"""新版集成领域测试；每例独立内存/SQLite，不触碰用户已有数据。"""
import csv,io,json,sqlite3,sys,tempfile,unittest,hashlib
from copy import deepcopy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from engine import seed,bootstrap,context,apply
from store import Store,DomainError
import multilevel_domain as d

class DomainTests(unittest.TestCase):
    def setUp(self):self.data=seed();self.c=context({'group':'TY_GROUP','month':9,'currency':'CNY','entity':'all'})
    def act(self,name,p={},group=None,role='集团财务负责人'):
        c={**self.c,'group':group or self.c['group'],'currency':'USD' if group=='OS_GROUP' else 'CNY'}
        return apply(self.data,role,name,p,c)
    def reopen(self,unit):self.act('unit_reopen',{'unitId':unit,'reason':'独立验收','cascade':True},unit)
    def run_approve(self,unit):
        self.act('consolidation_run',{'unitId':unit},unit);r=d.current_result(self.data,unit,9);self.act('result_approve',{'resultId':r['id']},unit);return d.current_result(self.data,unit,9)
    def test_fresh_real_signed_golden_and_code_lineage(self):
        b=bootstrap(self.data,0,[],'集团财务负责人',self.c);a=b['statement']['actual']
        self.assertEqual((a['revenue'],a['net'],a['cta'],a['cashFx']),(2650,770,74,90));self.assertTrue(b['currentResult']['valid']);self.assertEqual(b['reportMode'],'已签核');self.assertEqual(len(b['results']),3)
        root=b['currentResult'];self.assertEqual(len([i for i in root['inputs'] if i['type']=='unit']),2);self.assertEqual(len(root['eliminationIds']),len(set(root['eliminationIds'])));self.assertEqual(len(root['sourceInfo']['codeDigest']),64)
        self.assertNotEqual(root['fingerprint'],root['inputFingerprint'])
    def test_reopen_source_cascade_recompute_and_immutable_history(self):
        historical=deepcopy([r['snapshot'] for r in self.data['results']]);self.reopen('HW_GROUP')
        self.assertFalse(d.current_result(self.data,'TY_GROUP',9)['valid']);self.assertTrue(d.current_result(self.data,'OS_GROUP',9)['valid'])
        with self.assertRaises(DomainError):self.act('consolidation_run',{})
        s=deepcopy(self.data['sources']['9']['HW_CAT']);s['profit']['expense']+=10;s['monthlyProfit']['9']['expense']+=10;s['closing']['cash']-=10;s['closing']['retained']-=10;s['cashflow']['operating']-=10;s['monthlyCashflow']['9']['operating']-=10
        self.act('source_save',{'entityId':'HW_CAT','source':s});hw=self.run_approve('HW_GROUP');root=self.run_approve('TY_GROUP')
        self.assertEqual(hw['statement']['actual']['net'],440);self.assertEqual(root['statement']['actual']['net'],760);self.assertEqual(historical,[r['snapshot'] for r in self.data['results'][:3]])
        self.assertEqual(root['inputs'][1]['resultId'],hw['id'])
    def test_rate_version_only_invalidates_translating_root(self):
        old=deepcopy(self.data['fxRates'][8]);payload={k:v for k,v in old.items() if k in ('sourceCurrency','targetCurrency','opening','closing','historicalCapital','averages','flowRates')};payload['closing']=7.3
        self.act('rate_set_save',payload);self.assertFalse(d.current_result(self.data,'TY_GROUP',9)['valid']);self.assertTrue(d.current_result(self.data,'OS_GROUP',9)['valid']);self.assertTrue(d.current_result(self.data,'HW_GROUP',9)['valid'])
        self.assertEqual(self.data['fxRates'][8]['closing'],old['closing']);self.assertFalse(self.data['fxRates'][8]['active']);new=self.run_approve('TY_GROUP');a=new['statement']['actual'];self.assertEqual((a['net'],a['cta'],a['cashFx']),(770,86,110))
    def test_roles_locks_currency_and_legacy_bypass(self):
        s=self.data['sources']['9']['HW_CAT']
        with self.assertRaises(DomainError):self.act('source_save',{'entityId':'HW_CAT','source':s})
        with self.assertRaises(DomainError):self.act('unit_reopen',{'reason':'xx'},role='法人会计')
        with self.assertRaises(DomainError):self.act('commentary_save',{'text':'xx'},role='审计只读')
        with self.assertRaises(DomainError):self.act('signoff',{})
        with self.assertRaises(DomainError):bootstrap(self.data,0,[],'集团财务负责人',{**self.c,'group':'OS_GROUP'})
        os=bootstrap(self.data,0,[],'集团财务负责人',{**self.c,'group':'OS_GROUP','currency':'USD'});self.assertEqual(os['statement']['actual']['revenue'],100);self.assertFalse(os['budgetComparable'])
        with self.assertRaises(DomainError):self.act('budget_layer_save',{'layer':0,'amount':1},'OS_GROUP')
    def test_dynamic_scope_configuration_rollup_and_no_ownership_fabrication(self):
        own=deepcopy(self.data['ownership']);self.reopen('TY_GROUP')
        self.act('unit_save',{'id':'ACCEPT_SCOPE','name':'新增实际可配置小合并','currency':'CNY','members':[{'type':'entity','id':'OTHER'}]})
        self.run_approve('ACCEPT_SCOPE');root=next(x for x in self.data['units'] if x['id']=='TY_GROUP')
        members=[{'type':'unit','id':'ACCEPT_SCOPE'} if m['id']=='OTHER' else m for m in root['members']]
        self.act('unit_save',{'id':'TY_GROUP','name':root['name'],'currency':'CNY','members':members});r=self.run_approve('TY_GROUP');self.assertEqual(r['statement']['actual']['revenue'],2650);self.assertEqual(self.data['ownership'],own)
        self.reopen('TY_GROUP')
        with self.assertRaises(DomainError):self.act('unit_save',{'id':'TY_GROUP','name':root['name'],'currency':'CNY','members':members+[{'type':'entity','id':'HW_CAT'}]})
    def test_internal_sale_wrong_level_and_duplicate_rejected(self):
        self.reopen('HW_GROUP')
        base={'sourceId':'NEW-IC','unitId':'HW_GROUP','sellerId':'HW','buyerId':'OTHER','kind':'内部销售','amount':1,'currency':'CNY'}
        with self.assertRaises(DomainError):self.act('elimination_save',base)
        base.update(unitId='TY_GROUP',sourceId='IC-HW-SALES-2026-09')
        with self.assertRaises(DomainError):self.act('elimination_save',base)
        base.update(sourceId='NEW-IC',sellerId='HW',buyerId='OTHER');self.act('elimination_save',base);e=self.data['eliminations'][-1]
        self.assertEqual(e['monthlyAmounts']['9'],1);self.assertEqual(e['status'],'草稿')
        with self.assertRaises(DomainError):self.act('consolidation_run',{})
    def csv_source(self,eid):
        s=self.data['sources']['9'][eid];stream=io.StringIO();w=csv.writer(stream);w.writerow(['法人编码','期间','数据区','项目编码','金额','月份'])
        for area in ('opening','closing','profit','cashflow','monthlyProfit','monthlyCashflow'):
            if area.startswith('monthly'):
                for m,row in s[area].items():
                    for k,v in row.items():w.writerow([eid,'2026-09',area,k,v,m])
            else:
                for k,v in s[area].items():w.writerow([eid,'2026-09',area,k,v,''])
        return stream.getvalue()
    def test_full_csv_roundtrip_duplicate_and_atomic_rejection(self):
        self.reopen('HW_GROUP');raw=self.csv_source('HW_CAT');self.act('source_import',{'csv':raw,'sourceName':'金样.csv'});self.assertEqual(self.data['sources']['9']['HW_CAT']['version'],2);self.assertEqual(self.run_approve('HW_GROUP')['statement']['actual']['revenue'],1400)
        self.reopen('HW_GROUP');old=deepcopy(self.data['sources']);bad=raw+raw.splitlines()[1]+'\r\n'
        with self.assertRaises(DomainError):self.act('source_import',{'csv':bad})
        self.assertEqual(self.data['sources'],old)
        bad=raw.replace('HW_CAT,2026-09,closing,cash,','HW_CAT,2026-09,closing,unknown,')
        with self.assertRaises(DomainError):self.act('source_import',{'csv':bad})
        self.assertEqual(self.data['sources'],old)
    def test_source_closing_profit_and_monthly_checks_not_bypassable(self):
        self.reopen('HW_GROUP');s=deepcopy(self.data['sources']['9']['HW_CAT']);s['closing']['retained']+=90
        with self.assertRaises(DomainError):self.act('source_save',{'entityId':'HW_CAT','source':s})
        s=deepcopy(self.data['sources']['9']['HW_CAT']);s['monthlyCashflow']['1']['operating']+=1
        with self.assertRaises(DomainError):self.act('source_save',{'entityId':'HW_CAT','source':s})
        self.assertEqual(self.data['sources']['9']['HW_CAT']['version'],1)
    def test_budget_still_has_independent_version_workflow(self):
        self.act('budget_layer_save',{'layer':0,'amount':3500});self.act('budget_submit');self.act('budget_approve');self.act('budget_lock');self.act('budget_copy',{'name':'V3 测试预算'})
        self.assertEqual(self.data['budget']['status'],'编制中');self.assertEqual(self.data['budget']['layers'][0]['amount'],3500);self.assertEqual(d.current_result(self.data,'TY_GROUP',9)['statement']['actual']['revenue'],2650)
    def test_store_transactions_revision_restart_and_old_db_byte_guard(self):
        with tempfile.TemporaryDirectory() as tmp:
            s=Store(tmp,seed);revision,data,activities=s.read();self.assertEqual(data['product'],d.PRODUCT);self.assertEqual(activities[0]['action'],'demo_initialize')
            s.mutate(0,'集团财务负责人','commentary_save',{'text':'重启保留'},self.c,apply)
            with self.assertRaises(DomainError):s.mutate(0,'集团财务负责人','commentary_save',{'text':'冲突'},self.c,apply)
            s2=Store(tmp,seed);self.assertEqual(s2.read()[0],1);self.assertEqual(s2.read()[1]['commentaries']['TY_GROUP:9']['text'],'重启保留')
            snapshot=s2.path.read_bytes();before=s2.read()[1]
            with self.assertRaises(DomainError):s2.mutate(1,'集团财务负责人','source_import',{'csv':'损坏'},self.c,apply)
            self.assertEqual(s2.read()[1],before)
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'epm-demo.sqlite3'
            with sqlite3.connect(p) as db:db.execute('CREATE TABLE state(id INTEGER,document TEXT)');db.execute('INSERT INTO state VALUES(1,?)',(json.dumps({'schemaVersion':1,'product':'old'}),));db.commit()
            digest=hashlib.sha256(p.read_bytes()).hexdigest()
            with self.assertRaises(DomainError):Store(tmp,seed)
            self.assertEqual(digest,hashlib.sha256(p.read_bytes()).hexdigest());self.assertFalse(Path(str(p)+'-wal').exists())
    def test_failed_seed_creates_no_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            def bad():raise ValueError('种子故障')
            with self.assertRaises(ValueError):Store(tmp,bad)
            self.assertFalse((Path(tmp)/'epm-demo.sqlite3').exists())

if __name__=='__main__':unittest.main()
