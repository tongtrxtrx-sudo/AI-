"""分级合并及USD→CNY报表折算：纯内存、Decimal、带来源血缘。"""
from __future__ import annotations
from copy import deepcopy
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import hashlib,json

# Financial reports use ten-thousand currency units.  Six decimal places in
# that unit are one cent in the functional/report currency, not one hundred
# currency units.  All arithmetic stays Decimal until the JSON boundary.
CENT=Decimal('.000001');ZERO=Decimal(0)
PL=('revenue','cost','expense','finance','tax')
ASSETS=('cash','receivable','inventory','prepaid','investment','fixed','intangible','deferred_asset')
LIABILITIES=('payable','shortloan','taxpayable','otherliability','longloan','deferred_liability')
EQUITY=('capital','retained','nci','cta')
BS=ASSETS+LIABILITIES+EQUITY
CF=('operating','investing','financing','fx')
APPROVED={'已审批','已批准','已签核','approved'}

def dec(v,label='金额',places=6):
    if isinstance(v,bool) or v is None or isinstance(v,(dict,list,tuple)):raise ValueError(f'{label}必须为有效数字。')
    try:x=Decimal(str(v))
    except (InvalidOperation,TypeError,ValueError):raise ValueError(f'{label}必须为有效数字。') from None
    if not x.is_finite() or abs(x)>Decimal('1000000000000'):raise ValueError(f'{label}超出允许范围。')
    if x!=x.quantize(Decimal(1).scaleb(-places),rounding=ROUND_HALF_UP):raise ValueError(f'{label}最多{places}位小数。')
    return x
def q(v):return v.quantize(CENT,rounding=ROUND_HALF_UP)
def num(v):
    value=q(v)
    # The public JSON shape remains numeric for the existing UI.  Refuse an
    # amount whose JSON float cannot round-trip to the same currency cent.
    # Silently losing a cent is worse than asking for a smaller supported book.
    encoded=float(value)
    if not Decimal(str(encoded)).is_finite() or q(Decimal(str(encoded)))!=value:
        raise ValueError('金额超出本机演示可无损保存的范围，无法保持到原币分。')
    return encoded
def _fingerprint(result):return hashlib.sha256(json.dumps({k:result[k] for k in ('dependencies','report','leafIds','eliminationIds','inputs','trace')},sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def total(m,keys):return sum((dec(m.get(k,0),k) for k in keys),ZERO)
def net(p):return dec(p.get('revenue',0))-total(p,PL[1:])
def rate(v,label='汇率'):
    x=dec(v,label,6)
    if x<=0 or x>1000000:raise ValueError(f'{label}必须大于零且不超过1000000。')
    return x
def by_id(rows,label):
    if not isinstance(rows,list):raise ValueError(f'{label}清单无效。')
    out={}
    for row in rows:
        if not isinstance(row,dict) or not isinstance(row.get('id'),str) or not row['id']:raise ValueError(f'{label}缺少编号。')
        if row['id'] in out:raise ValueError(f'{label}编号重复：{row["id"]}。')
        out[row['id']]=row
    return out

def seed_multilevel():
    try:from .multilevel_seed import seed_multilevel as seed
    except ImportError:from multilevel_seed import seed_multilevel as seed
    return seed()

def validate_tree(data):
    entities=by_id(data.get('entities',[]),'法人');units=by_id(data.get('units',[]),'合并单元');cache={};parents={}
    if not units:raise ValueError('至少需要一个合并单元。')
    for eid,e in entities.items():
        if e.get('currency') not in ('CNY','USD'):raise ValueError(f'法人{eid}本位币仅支持人民币或美元。')
    for uid,u in units.items():
        if u.get('currency') not in ('CNY','USD'):raise ValueError(f'合并单元{uid}报表币种无效。')
        members=u.get('members')
        if not isinstance(members,list) or not members:raise ValueError(f'合并单元{uid}至少需要一个成员。')
        seen=set()
        for m in members:
            if not isinstance(m,dict) or m.get('type') not in ('entity','unit'):raise ValueError(f'合并单元{uid}成员类型无效。')
            ref=m.get('id')
            if not isinstance(ref,str) or not ref:raise ValueError(f'合并单元{uid}成员编号无效。')
            key=(m['type'],ref)
            if key in seen:raise ValueError(f'合并单元{uid}存在重复成员：{ref}。')
            seen.add(key)
            if ref not in (entities if m['type']=='entity' else units):raise ValueError(f'合并单元{uid}引用不存在的成员：{ref}。')
            source_currency=(entities if m['type']=='entity' else units)[ref].get('currency')
            if source_currency!=u['currency'] and (source_currency,u['currency'])!=('USD','CNY'):raise ValueError(f'合并单元{uid}不支持{source_currency}→{u["currency"]}输入；本轮仅支持同币种或美元转人民币。')
            if m['type']=='unit':
                if ref in parents and parents[ref]!=uid:raise ValueError(f'合并单元{ref}不能同时挂在多个上级。')
                parents[ref]=uid
    def visit(uid,path):
        if uid in path:raise ValueError('合并范围存在循环引用：'+' → '.join(path+[uid]))
        if uid in cache:return cache[uid]
        leaves=[]
        for m in units[uid]['members']:
            new=[m['id']] if m['type']=='entity' else visit(m['id'],path+[uid])
            overlap=set(leaves)&set(new)
            if overlap:raise ValueError(f'合并单元{uid}重复纳入底层法人：'+','.join(sorted(overlap))+'。不能同时纳入小合并结果及其单体。')
            leaves+=new
        cache[uid]=leaves;return leaves
    for uid in units:visit(uid,[])
    return {'leafIdsByUnit':cache,'parentByUnit':parents}

def collect_leaves(data,unit_id):
    x=validate_tree(data)['leafIdsByUnit']
    if unit_id not in x:raise ValueError('合并单元不存在。')
    return list(x[unit_id])

def lowest_common_unit(data,seller,buyer):
    tree=validate_tree(data);candidates=[u for u,leaves in tree['leafIdsByUnit'].items() if seller in leaves and buyer in leaves]
    if seller==buyer or not candidates:raise ValueError('交易双方须是存在共同合并范围的不同法人。')
    def depth(u):
        n=0
        while u in tree['parentByUnit']:n+=1;u=tree['parentByUnit'][u]
        return n
    return sorted(candidates,key=lambda u:(len(tree['leafIdsByUnit'][u]),-depth(u),u))[0]

def normalize_report(source,month):
    if not isinstance(source,dict):raise ValueError('报送数据必须为对象。')
    out={}
    for name,keys in [('opening',BS),('closing',BS),('profit',PL),('cashflow',CF)]:
        raw=source.get(name)
        if not isinstance(raw,dict):raise ValueError(f'报送缺少{name}。')
        unknown=set(raw)-set(keys)-({'net'} if name=='profit' else set())
        if unknown:raise ValueError(f'{name}含未支持字段：'+','.join(sorted(unknown)))
        out[name]={k:num(dec(raw.get(k,0),k)) for k in keys}
        if name=='profit' and 'net' in raw and dec(raw['net'],'净利润')!=net(out[name]):raise ValueError('净利润为派生字段，报送值须与收入减成本费用税一致。')
    for name,keys in [('monthlyProfit',PL),('monthlyCashflow',CF)]:
        rows=source.get(name)
        if not isinstance(rows,dict):raise ValueError('必须提供逐月发生额，不能用单一汇率乘累计损益。')
        if set(rows)!={str(m) for m in range(1,month+1)}:raise ValueError('逐月报送须完整覆盖1至当前期间，不能含未来或无效月份。')
        out[name]={}
        for m in range(1,month+1):
            row=rows.get(str(m))
            if not isinstance(row,dict):raise ValueError(f'缺少{m}月发生额。')
            if set(row)-set(keys):raise ValueError(f'{m}月发生额含未支持字段。')
            out[name][str(m)]={k:num(dec(row.get(k,0),k)) for k in keys}
        target=out['profit' if name=='monthlyProfit' else 'cashflow']
        for k in keys:
            if sum((dec(r[k]) for r in out[name].values()),ZERO)!=dec(target[k]):raise ValueError(f'{k}逐月发生额合计与累计数不一致。')
    out['capitalMovement']=num(dec(source.get('capitalMovement',0),'所有者投入及分配'))
    out['equityHistory']=deepcopy(source.get('equityHistory',{}))
    if not isinstance(out['equityHistory'],dict):raise ValueError('历史权益资料无效。')
    return out

def financial_checks(report,label='合并报表'):
    o,c,p,f=(report[k] for k in ('opening','closing','profit','cashflow'))
    diffs=[('opening_balance','期初资产＝负债＋权益',total(o,ASSETS)-total(o,LIABILITIES)-total(o,EQUITY)),('closing_balance','期末资产＝负债＋权益',total(c,ASSETS)-total(c,LIABILITIES)-total(c,EQUITY)),('cash_reconciliation','期末现金＝期初现金＋经营/投资/筹资＋现金汇率影响',dec(c['cash'])-dec(o['cash'])-total(f,CF)),('equity_reconciliation','权益变动＝净利润＋资本变动＋折算差额变动',total(c,EQUITY)-total(o,EQUITY)-net(p)-dec(report.get('capitalMovement',0))-(dec(c['cta'])-dec(o['cta'])))]
    return [{'code':code,'label':label+' · '+title,'passed':d==0,'difference':num(d)} for code,title,d in diffs]

def validate_source(data,entity_id,month,source):
    if isinstance(month,bool) or not isinstance(month,int) or not 1<=month<=12:raise ValueError('期间必须为1至12期。')
    entities=by_id(data.get('entities',[]),'法人')
    if entity_id not in entities:raise ValueError('报送法人不存在。')
    if source.get('currency',entities[entity_id]['currency'])!=entities[entity_id]['currency']:raise ValueError('报送币种须与法人记账本位币一致。')
    r=normalize_report(source,month)
    for ch in financial_checks(r,entities[entity_id]['name']):
        if not ch['passed']:raise ValueError(ch['label']+f'不平衡，差额{ch["difference"]:.6f}万元。')
    if dec(r['closing']['nci']) or dec(r['opening']['nci']):raise ValueError('本轮演示仅支持全资，无少数股东报送。')
    if dec(r['closing']['capital'])!=dec(r['opening']['capital']) or dec(r['capitalMovement']):raise ValueError('本轮历史权益模型不支持期间资本变动，请使用期初已确认资本。')
    if dec(r['closing']['retained'])-dec(r['opening']['retained'])!=net(r['profit']):raise ValueError('留存收益须按期初加本期利润滚动；分红与其他权益调整不在本轮演示范围。')
    if any(dec(r[stage]['cta']) for stage in ('opening','closing')) or dec(r['cashflow']['fx']):raise ValueError('本轮法人源报告使用本位币，源折算差额和现金汇率影响必须为零；由上卷折算独立产生。')
    history=r['equityHistory'];capital_by=history.get('capitalByEntity')
    if not isinstance(capital_by,dict) or set(capital_by)!={entity_id} or dec(capital_by.get(entity_id,0))!=dec(r['closing']['capital']):raise ValueError('历史资本明细必须且只能属于本报送法人，金额须等于本位币实收资本。')
    dividends=history.get('dividendsByMonth',{})
    if not isinstance(dividends,dict) or dividends:raise ValueError('本轮不支持分红历史事件，请勿通过留存收益或补差绕过。')
    if entities[entity_id]['currency']=='USD' and dec(r['opening']['retained']) and 'openingRetainedCny' not in history:raise ValueError('美元法人期初留存收益非零时必须提供已确认的期初人民币留存收益。')
    if 'openingRetainedCny' in history:dec(history['openingRetainedCny'],'期初人民币留存收益')

def _rate_set(data,month):
    rows=[r for r in data.get('fxRates',[]) if r.get('month')==month and r.get('sourceCurrency')=='USD' and r.get('targetCurrency')=='CNY' and r.get('active',True)]
    if len(rows)!=1:raise ValueError(f'{month}期USD→CNY须有唯一已审批分类汇率表。')
    r=rows[0]
    if r.get('status','已审批') not in APPROVED:raise ValueError('分类汇率尚未审批。')
    for k in ('opening','closing','historicalCapital'):rate(r.get(k),k)
    for k in ('averages','flowRates'):
        if not isinstance(r.get(k),dict):raise ValueError('缺少逐月平均或现金流汇率。')
        for m in range(1,month+1):rate(r[k].get(str(m)),f'{m}月{k}')
    return r

def translate_result(data,result,target_currency,month):
    if result['currency']==target_currency:return deepcopy(result)
    if result['currency']!='USD' or target_currency!='CNY':raise ValueError('本轮正式折算仅支持美元结果到人民币，不能用展示换算替代其他币种。')
    rates=_rate_set(data,month);src=deepcopy(result['report']);dst=deepcopy(src);opening=rate(rates['opening']);closing=rate(rates['closing'])
    history=src.get('equityHistory',{});capital_by=history.get('capitalByEntity',{})
    if not isinstance(capital_by,dict) or total(src['opening'],('capital',))!=sum((dec(v) for v in capital_by.values()),ZERO):raise ValueError('缺少可追溯的法人历史资本明细。')
    if dec(src['closing']['capital'])!=dec(src['opening']['capital']):raise ValueError('资本变动尚需完整历史权益事件，本轮不能按期末汇率补差。')
    if dec(src['opening']['nci']) or dec(src['closing']['nci']):raise ValueError('本轮外币模型不支持少数股东。')
    for stage,fx in [('opening',opening),('closing',closing)]:
        for k in ASSETS+LIABILITIES:dst[stage][k]=num(dec(src[stage][k])*fx)
    for category,keys,rates_key in [('monthlyProfit',PL,'averages'),('monthlyCashflow',CF,'flowRates')]:
        dst[category]={}
        for m,row in src[category].items():
            rr=rate(rates[rates_key].get(m),m+'月汇率')
            dst[category][m]={k:num(dec(row.get(k,0))*rr) for k in keys}
        cumulative='profit' if category=='monthlyProfit' else 'cashflow'
        dst[cumulative]={k:num(sum((dec(r[k]) for r in dst[category].values()),ZERO)) for k in keys}
    capital=sum((q(dec(amount)*rate(rates.get('capitalRates',{}).get(eid,rates['historicalCapital']),eid+'历史资本率')) for eid,amount in capital_by.items()),ZERO)
    if dec(src['opening']['retained']) and 'openingRetainedCny' not in history:raise ValueError('期初留存收益必须提供已确认人民币余额，不能用期末汇率重算。')
    retained=dec(history.get('openingRetainedCny',0),'期初人民币留存收益')
    for stage in ('opening','closing'):
        dst[stage]['capital']=num(capital);dst[stage]['nci']=0
        dst[stage]['retained']=num(retained+(net(dst['profit']) if stage=='closing' else ZERO))
        dst[stage]['cta']=num(total(dst[stage],ASSETS)-total(dst[stage],LIABILITIES)-total(dst[stage],('capital','retained','nci')))
    fx_cash=dec(dst['closing']['cash'])-dec(dst['opening']['cash'])-total(dst['cashflow'],('operating','investing','financing'))
    dst['cashflow']['fx']=num(fx_cash)
    # 源报告累计现金汇率影响不作第二次换算；本轮是USD功能币，原币fx应为0。
    if dec(src['cashflow'].get('fx',0)):raise ValueError('不支持对已有外币现金汇率影响进行二次不透明换算。')
    for row in dst['monthlyCashflow'].values():row['fx']=0
    dst['monthlyCashflow'][str(month)]['fx']=num(fx_cash)
    dst['equityHistory']={'capitalByEntity':{eid:num(dec(amount)*rate(rates.get('capitalRates',{}).get(eid,rates['historicalCapital']))) for eid,amount in capital_by.items()},'openingRetainedCny':num(retained),'dividendsByMonth':{}}
    dst['capitalMovement']=0
    out=deepcopy(result);out['currency']='CNY';out['report']=dst
    fx_trace={'sourceId':result.get('id',result.get('unitId','')),'sourceUnitId':result.get('unitId'),'rateId':rates['id'],'rateVersion':rates.get('version',1),'sourceCurrency':'USD','targetCurrency':'CNY','quote':'1 USD = rate CNY','openingRate':float(opening),'closingRate':float(closing),'historicalCapitalRate':float(rate(rates['historicalCapital'])),'monthlyAverageRates':deepcopy(rates['averages']),'monthlyFlowRates':deepcopy(rates['flowRates']),'sourceReport':src,'translatedReport':deepcopy(dst),'cta':dst['closing']['cta'],'cashFx':dst['cashflow']['fx'],'rows':[{'field':k,'sourceValue':src['closing'][k],'rateType':'期末','rate':float(closing),'targetValue':dst['closing'][k]} for k in ASSETS+LIABILITIES]+[{'field':'capital','sourceValue':src['closing']['capital'],'rateType':'历史资本','rate':float(rate(rates['historicalCapital'])),'targetValue':dst['closing']['capital']},{'field':'retained','sourceValue':src['closing']['retained'],'rateType':'期初留存＋逐月折算利润','targetValue':dst['closing']['retained']},{'field':'cta','rateType':'资产负债与历史权益勾稽','targetValue':dst['closing']['cta']}]}
    capital_details=[{'entityId':eid,'sourceValue':amount,'rate':float(rate(rates.get('capitalRates',{}).get(eid,rates['historicalCapital']))),'targetValue':dst['equityHistory']['capitalByEntity'][eid]} for eid,amount in capital_by.items()]
    fx_trace['capitalRateDetails']=capital_details
    capital_row=next(row for row in fx_trace['rows'] if row['field']=='capital')
    used_capital_rates={detail['rate'] for detail in capital_details}
    if len(used_capital_rates)==1:capital_row['rate']=next(iter(used_capital_rates))
    elif len(used_capital_rates)>1:
        capital_row.pop('rate',None);capital_row['rateType']='逐法人历史资本明细'
    out.setdefault('trace',{}).setdefault('fx',[]).append(fx_trace)
    out.setdefault('dependencies',{}).setdefault('rates',{})[rates['id']]=rates.get('version',1)
    out['checks']=financial_checks(dst,'海外结果折算');out['passed']=all(c['passed'] for c in out['checks']);out['statement']=make_statement(out)
    return out

def _empty_report(month):
    return {'opening':dict.fromkeys(BS,0),'closing':dict.fromkeys(BS,0),'profit':dict.fromkeys(PL,0),'cashflow':dict.fromkeys(CF,0),'monthlyProfit':{str(m):dict.fromkeys(PL,0) for m in range(1,month+1)},'monthlyCashflow':{str(m):dict.fromkeys(CF,0) for m in range(1,month+1)},'capitalMovement':0,'equityHistory':{'capitalByEntity':{},'openingRetainedCny':0,'dividendsByMonth':{}}}
def _merge(a,b):
    for name,keys in [('opening',BS),('closing',BS),('profit',PL),('cashflow',CF)]:
        for k in keys:a[name][k]=num(dec(a[name][k])+dec(b[name][k]))
    for name,keys in [('monthlyProfit',PL),('monthlyCashflow',CF)]:
        for m in a[name]:
            for k in keys:a[name][m][k]=num(dec(a[name][m][k])+dec(b[name][m][k]))
    a['capitalMovement']=num(dec(a['capitalMovement'])+dec(b.get('capitalMovement',0)))
    h=a['equityHistory'];bh=b.get('equityHistory',{})
    for eid,value in bh.get('capitalByEntity',{}).items():h['capitalByEntity'][eid]=num(dec(h['capitalByEntity'].get(eid,0))+dec(value))
    h['openingRetainedCny']=num(dec(h['openingRetainedCny'])+dec(bh.get('openingRetainedCny',0)))

def _dependency_current(data,result,month):
    dep=result.get('dependencies',{})
    for eid,v in dep.get('sources',{}).items():
        source=data.get('sources',{}).get(str(month),{}).get(eid)
        if not source or source.get('version',1)!=v:raise ValueError('下级结果依赖的法人报送已变化，请先重新计算并签核下级。')
        validate_source(data,eid,month,source)
    units=by_id(data['units'],'合并单元')
    for uid,v in dep.get('units',{}).items():
        if uid not in units or units[uid].get('version',1)!=v:raise ValueError('下级合并范围版本已变化，请先重新计算下级。')
    for field,key in [('fxRates','rates'),('eliminations','eliminations')]:
        rows=by_id(data.get(field,[]),field)
        for rid,v in dep.get(key,{}).items():
            if rid not in rows or rows[rid].get('version',1)!=v or not rows[rid].get('active',True) or rows[rid].get('status','已审批') not in APPROVED:raise ValueError('下级结果依赖的汇率或抵销版本已变化。')
    # 新增已审批抵销同样会使旧快照过期，不能只检查旧快照里已有的记录。
    scopes=set(dep.get('units',{}))
    current_elims={e['id'] for e in data.get('eliminations',[]) if e.get('unitId') in scopes and e.get('month')==month and e.get('status') in APPROVED and e.get('active',True)}
    if current_elims!=set(dep.get('eliminations',{})):raise ValueError('下级范围已新增或撤销已审批抵销，请先重新计算并签核下级。')

def _elimination_monthly(e,month,currency):
    """抵销发生额独立留痕；USD累计损益不能全部用期末月平均率折算。"""
    schedule=e.get('monthlyEffects');effects=e.get('effects',{});flow_keys=PL+CF
    if schedule is None:
        if currency=='USD' and any(dec(effects.get(k,0)) for k in flow_keys):raise ValueError('美元损益或现金流抵销须提供逐月发生额monthlyEffects，不能将累计事项隐含记入期末月。')
        return {str(m):{k:num(dec(effects.get(k,0))) if m==month else 0 for k in flow_keys} for m in range(1,month+1)}
    if not isinstance(schedule,dict) or set(schedule)!={str(m) for m in range(1,month+1)}:raise ValueError('抵销逐月发生额须完整覆盖1至当前期间，不能含未来月份。')
    normalized={}
    for m,row in schedule.items():
        if not isinstance(row,dict) or set(row)-set(flow_keys):raise ValueError('抵销月度字段仅支持损益和现金流项目。')
        normalized[m]={k:num(dec(row.get(k,0),'抵销逐月发生额')) for k in flow_keys}
    for k in flow_keys:
        if sum((dec(row[k]) for row in normalized.values()),ZERO)!=dec(effects.get(k,0)):raise ValueError(f'抵销{k}逐月发生额合计与累计抵销效果不一致。')
    return normalized

def calculate_unit(data,unit_id,month,child_results=None,preview=False):
    if isinstance(month,bool) or not isinstance(month,int) or not 1<=month<=12:raise ValueError('期间必须为1至12期。')
    tree=validate_tree(data);units=by_id(data['units'],'合并单元');entities=by_id(data['entities'],'法人')
    if unit_id not in units:raise ValueError('合并单元不存在。')
    unit=units[unit_id];report=_empty_report(month);inputs=[];leaf_ids=[];elim_ids=[];trace={'entities':[],'eliminations':[],'fx':[]};dep={'sources':{},'units':{unit_id:unit.get('version',1)},'rates':{},'eliminations':{},'childResults':{}}
    for member in unit['members']:
        mid=member['id'];typ=member['type']
        if typ=='entity':
            source=data.get('sources',{}).get(str(month),{}).get(mid)
            if source is None:raise ValueError(f'{entities[mid]["name"]}缺少本期报送。')
            validate_source(data,mid,month,source)
            sr=normalize_report(source,month)
            if 'capitalByEntity' not in sr['equityHistory']:sr['equityHistory']['capitalByEntity']={mid:sr['opening']['capital']}
            entity_trace={'entityId':mid,'name':entities[mid]['name'],'sourceVersion':source.get('version',1),'currency':entities[mid]['currency']}
            if 'ledgerTrace' in source:entity_trace['ledgerTrace']=deepcopy(source['ledgerTrace'])
            child={'unitId':mid,'currency':entities[mid]['currency'],'month':month,'report':sr,'leafIds':[mid],'eliminationIds':[],'trace':{'entities':[entity_trace],'eliminations':[],'fx':[]},'dependencies':{'sources':{mid:source.get('version',1)},'units':{},'rates':{},'eliminations':{}}}
            inputs.append({'type':'entity','id':mid,'name':entities[mid]['name'],'currency':child['currency'],'sourceVersion':source.get('version',1),'leafIds':[mid]})
        else:
            if preview:child=calculate_unit(data,mid,month,child_results,True)
            else:
                child=deepcopy((child_results or {}).get(mid))
                if not child:raise ValueError(f'请先运行并签核下级合并单元：{units[mid]["name"]}。')
                if child.get('unitId')!=mid or child.get('month')!=month:raise ValueError('下级结果的单元或期间不符。')
                if child.get('currency')!=units[mid]['currency']:raise ValueError('下级结果报表币种与该单元配置不符，不能再次折算或混用结果。')
                if child.get('preview') or child.get('valid') is not True or child.get('stale') or child.get('approvalStatus',child.get('status')) not in APPROVED:raise ValueError('上级只能引用当前有效、已签核的下级结果，不能引用预览或失效结果。')
                if not child.get('id') or not isinstance(child.get('resultVersion'),int) or isinstance(child.get('resultVersion'),bool) or child['resultVersion']<1:raise ValueError('下级已签核结果必须有可追溯快照编号及正整数版本。')
                if child.get('passed') is not True or not all(c['passed'] for c in financial_checks(child['report'],'下级签核结果')):raise ValueError('下级签核结果三表未通过校验，不能上卷。')
                if child.get('fingerprint')!=_fingerprint(child):raise ValueError('下级签核快照内容校验不符，请重新计算并签核。')
                if set(child.get('leafIds',[]))!=set(tree['leafIdsByUnit'][mid]):raise ValueError('下级结果成员与当前配置不同，请重新签核下级。')
                _dependency_current(data,child,month)
            inputs.append({'type':'unit','id':mid,'name':units[mid]['name'],'currency':child['currency'],'resultId':child.get('id'),'resultVersion':child.get('resultVersion',child.get('version')),'approvalStatus':child.get('approvalStatus',child.get('status','预览')),'leafIds':child['leafIds']})
            dep['childResults'][mid]={'id':child.get('id'),'version':child.get('resultVersion',child.get('version'))}
        if child['currency']!=unit['currency']:child=translate_result(data,child,unit['currency'],month)
        overlap=set(leaf_ids)&set(child['leafIds'])
        if overlap:raise ValueError('重复纳入底层法人：'+','.join(sorted(overlap)))
        leaf_ids+=child['leafIds']
        if set(elim_ids)&set(child.get('eliminationIds',[])):raise ValueError('同一抵销事项不能通过两个输入重复继承。')
        elim_ids+=child.get('eliminationIds',[])
        _merge(report,child['report'])
        for k in ('entities','fx'):trace[k]+=deepcopy(child.get('trace',{}).get(k,[]))
        for row in child.get('trace',{}).get('eliminations',[]):
            r=deepcopy(row);r['inherited']=True;trace['eliminations'].append(r)
        for key in ('sources','units','rates','eliminations'):dep[key].update(child.get('dependencies',{}).get(key,{}))
    approved=[e for e in data.get('eliminations',[]) if e.get('unitId')==unit_id and e.get('month')==month and e.get('status') in APPROVED and e.get('active',True)]
    for e in approved:
        if e.get('kind') not in ('sales','balances','investment','manual'):raise ValueError('抵销类型仅支持内部销售、内部应收应付、期初全资投资或明确手工凭证。')
        if not isinstance(e.get('effects'),dict) or set(e['effects'])-set(BS+PL+CF):raise ValueError('抵销包含未支持的财务字段。')
        source_id=e.get('sourceId')
        if not isinstance(source_id,str) or not source_id.strip():raise ValueError('抵销事项必须有唯一来源编号。')
        if source_id in elim_ids:raise ValueError('该抵销事项已在下级处理，不能再次抵销。')
        if e.get('currency')!=unit['currency']:raise ValueError('抵销凭证币种必须与本层报表币种一致。')
        if e.get('kind')=='sales':
            if lowest_common_unit(data,e.get('sellerId'),e.get('buyerId'))!=unit_id:raise ValueError('内部销售必须在交易双方最低共同合并层处理，不能跨层重复抵销。')
            amount=dec(e.get('amount',0),'抵销金额')
            if amount<0:raise ValueError('销售抵销金额不能为负。')
            effects=e.get('effects',{})
            if set(effects)-{'revenue','cost'} or dec(effects.get('revenue',0))!=-amount or dec(effects.get('cost',0))!=-amount:raise ValueError('内部销售须只等额减少收入和成本，不能夹带其他财务调整。')
            if e.get('openingEffects'):raise ValueError('内部销售发生额抵销不能改变期初资产负债。')
        if e.get('kind')=='balances':
            if lowest_common_unit(data,e.get('sellerId'),e.get('buyerId'))!=unit_id:raise ValueError('内部应收应付必须在双方最低共同合并层处理。')
            amount=dec(e.get('amount',0),'期末往来抵销金额')
            opening_amount=dec(e.get('openingAmount',0),'期初往来抵销金额')
            if amount<0 or opening_amount<0:raise ValueError('内部往来抵销金额不能为负；反向余额须先按真实应收应付方向核对。')
            effects=e.get('effects',{});opening_effects=e.get('openingEffects',{})
            if set(effects)!={'receivable','payable'} or any(dec(effects[k])!=-amount for k in ('receivable','payable')):raise ValueError('内部应收应付须只等额抵销期末应收与应付，不能抵平金额差异或夹带损益。')
            if set(opening_effects)-{'receivable','payable'} or any(dec(opening_effects.get(k,0))!=-opening_amount for k in ('receivable','payable')):raise ValueError('期初内部应收应付须按核对一致的期初金额等额抵销。')
            if dec(e.get('capitalMovement',0)):raise ValueError('内部应收应付抵销不能改变所有者投入及分配。')
        if e.get('kind')=='investment':
            pairs=e.get('investmentPairs',[])
            if not pairs:raise ValueError('投资抵销必须保留真实母子公司与投资金额明细。')
            expected_capital=ZERO;expected_investment=ZERO;seen_children=set();parent_investments={}
            for pair in pairs:
                if pair.get('parentId') not in leaf_ids or pair.get('childId') not in leaf_ids:raise ValueError('投资抵销的母子法人必须在当前合并范围。')
                if pair['childId'] in seen_children:raise ValueError('同一子公司资本不能重复纳入投资抵销明细。')
                seen_children.add(pair['childId'])
                own=next((o for o in data.get('ownership',[]) if o.get('parent')==pair['parentId'] and o.get('child')==pair['childId']),None)
                if not own or dec(own.get('percent',0))!=100:raise ValueError('本轮投资抵销仅支持已维护的真实全资关系。')
                cap=dec(pair.get('capital',0));inv=dec(pair.get('investment',0))
                child_source=data['sources'][str(month)][pair['childId']]
                if pair.get('currency')!=entities[pair['childId']]['currency'] or cap!=dec(child_source['opening']['capital']) or cap!=dec(child_source['closing']['capital']):raise ValueError('投资抵销的子公司币种或资本金额与实报来源不一致。')
                if entities[pair['parentId']]['currency']!=unit['currency']:raise ValueError('本轮投资抵销母公司投资账面须以当前层报表币种报送。')
                if cap<0 or inv<0:raise ValueError('投资抵销资本与投资金额不能为负。')
                parent_investments[pair['parentId']]=parent_investments.get(pair['parentId'],ZERO)+inv
                if pair.get('currency')!=unit['currency']:
                    rr=_rate_set(data,month);cap*=rate(rr.get('capitalRates',{}).get(pair['childId'],rr['historicalCapital']))
                if q(cap)!=inv:raise ValueError('各子公司投资账面须与其历史资本逐项相符；差额不能在不同公司之间相互抵消。')
                expected_capital+=q(cap);expected_investment+=inv
            for parent_id,amount in parent_investments.items():
                parent_source=data['sources'][str(month)][parent_id]
                if amount!=dec(parent_source['opening']['investment']) or amount!=dec(parent_source['closing']['investment']):raise ValueError('投资抵销明细合计与母公司期初及期末实报投资账面不符；本轮须完整列示该母公司全部投资，不能虚构金额。')
            if expected_capital!=expected_investment:raise ValueError('投资账面与历史资本抵销存在差额，需按真实历史权益调整，不能用净利润或CTA补平。')
            if -dec(e.get('effects',{}).get('capital',0))!=expected_capital or -dec(e.get('effects',{}).get('investment',0))!=expected_investment:raise ValueError('投资资本抵销金额与来源明细不一致。')
            if set(e.get('effects',{}))-{'capital','investment'} or set(e.get('openingEffects',{}))-{'capital','investment'} or e.get('openingEffects')!=e.get('effects') or dec(e.get('amount',0))!=expected_investment:raise ValueError('本轮期初全资投资抵销须在期初期末等额消除投资与资本，不得夹带其他调整。')
        effects=e.get('effects',{})
        if not isinstance(effects,dict) or set(effects)-set(BS+PL+CF):raise ValueError('抵销包含未支持的财务字段。')
        opening_effects=e.get('openingEffects',{})
        if not isinstance(opening_effects,dict) or set(opening_effects)-set(BS):raise ValueError('期初抵销字段无效。')
        monthly_effects=_elimination_monthly(e,month,unit['currency'])
        for k,v in opening_effects.items():report['opening'][k]=num(dec(report['opening'][k])+dec(v))
        p_effect={k:dec(effects.get(k,0)) for k in PL};net_effect=net(p_effect)
        for k,v in effects.items():
            name='profit' if k in PL else 'cashflow' if k in CF and k not in BS else 'closing'
            report[name][k]=num(dec(report[name][k])+dec(v))
            if name in ('profit','cashflow'):
                monthly_name='monthlyProfit' if name=='profit' else 'monthlyCashflow'
                for m,row in monthly_effects.items():report[monthly_name][m][k]=num(dec(report[monthly_name][m][k])+dec(row[k]))
        if 'retained' not in effects:report['closing']['retained']=num(dec(report['closing']['retained'])+net_effect)
        report['capitalMovement']=num(dec(report['capitalMovement'])+dec(e.get('capitalMovement',0)))
        if e.get('kind')=='investment':
            for pair in e['investmentPairs']:report['equityHistory']['capitalByEntity'].pop(pair['childId'],None)
        elim_ids.append(source_id);dep['eliminations'][e['id']]=e.get('version',1)
        elimination_trace={'id':e['id'],'sourceId':source_id,'unitId':unit_id,'title':e.get('title','合并抵销'),'kind':e.get('kind'),'inherited':False,'effects':deepcopy(effects),'openingEffects':deepcopy(opening_effects),'monthlyEffects':monthly_effects,'investmentPairs':deepcopy(e.get('investmentPairs',[]))}
        for key in ('openingAmount','voucherRefs','sourceRefs','ledgerTrace','matchId','matchKey','matchSignature','sourceSignature','ledgerVersion','generationMode','automation','origin','erp'):
            if key in e:elimination_trace[key]=deepcopy(e[key])
        trace['eliminations'].append(elimination_trace)
    checks=financial_checks(report,unit['name'])
    result={'unitId':unit_id,'unitName':unit['name'],'month':month,'currency':unit['currency'],'preview':preview,'report':report,'checks':checks,'passed':all(c['passed'] for c in checks),'leafIds':leaf_ids,'eliminationIds':elim_ids,'inputs':inputs,'dependencies':dep,'trace':trace}
    result['fingerprint']=_fingerprint(result)
    result['statement']=make_statement(result)
    return result

def make_statement(result):
    r=result['report'];p=r['profit'];o=r['opening'];c=r['closing'];f=r['cashflow'];n=net(p);gross=dec(p['revenue'])-dec(p['cost']);operating=gross-dec(p['expense']);pretax=operating-dec(p['finance'])
    actual={k:num(dec(p[k])) for k in PL};actual.update(net=num(n),gross=num(gross),operating=num(operating),pretax=num(pretax),assets=num(total(c,ASSETS)),liabilities=num(total(c,LIABILITIES)),equity=num(total(c,EQUITY)),cash=c['cash'],operatingCash=f['operating'],cta=c['cta'],cashFx=f['fx'],grossMargin=float(q(gross/dec(p['revenue'])*100)) if dec(p['revenue']) else 0,netMargin=float(q(n/dec(p['revenue'])*100)) if dec(p['revenue']) else 0)
    profit=[{'key':k,'label':label,'value':num(v),'total':k in ('gross','operating','pretax','net')} for k,label,v in [('revenue','营业收入',dec(p['revenue'])),('cost','营业成本',dec(p['cost'])),('gross','毛利',gross),('expense','期间费用',dec(p['expense'])),('operating','营业利润（财务费用前）',operating),('finance','财务费用',dec(p['finance'])),('pretax','利润总额',pretax),('tax','所得税费用',dec(p['tax'])),('net','净利润',n)]]
    labels={'cash':'货币资金','receivable':'应收账款','inventory':'存货','prepaid':'预付款及其他流动资产','investment':'长期股权投资','fixed':'固定资产净额','intangible':'无形及其他资产','deferred_asset':'递延所得税资产','payable':'应付账款','shortloan':'短期借款','taxpayable':'应交税费','otherliability':'其他流动负债','longloan':'长期借款','deferred_liability':'递延所得税负债','capital':'实收资本','retained':'未分配利润','nci':'少数股东权益','cta':'其他综合收益—外币报表折算差额'}
    balance=[[labels[k],c[k],k] for k in ASSETS]+[['资产总计',actual['assets'],'assets']]+[[labels[k],c[k],k] for k in LIABILITIES]+[['负债合计',actual['liabilities'],'liabilities']]+[[labels[k],c[k],k] for k in EQUITY]+[['所有者权益合计',actual['equity'],'equity'],['负债及所有者权益总计',num(total(c,LIABILITIES+EQUITY)),'balance']]
    cash=[['经营活动产生的现金流量净额',f['operating'],'operating'],['投资活动产生的现金流量净额',f['investing'],'investing'],['筹资活动产生的现金流量净额',f['financing'],'financing'],['汇率变动对现金及现金等价物的影响',f['fx'],'fx'],['现金及现金等价物净增加额',num(total(f,CF)),'change'],['期初现金及现金等价物余额',o['cash'],'openingcash'],['期末现金及现金等价物余额',c['cash'],'cash']]
    checks=result.get('checks',financial_checks(r));return {'actual':actual,'profit':profit,'balance':balance,'cash':cash,'financial_checks':checks,'checks':checks,'passed':all(c['passed'] for c in checks),'currency':result['currency'],'unit':'万美元' if result['currency']=='USD' else '人民币万元','period':f'2026年1—{result["month"]}月','month':result['month'],'scope':result.get('unitName',result.get('unitId','法人报送')),'source_entities':deepcopy(result.get('trace',{}).get('entities',[])),'approved_journals':deepcopy(result.get('trace',{}).get('eliminations',[])),'policyNote':'本机全资分级合并演示；输入与下级签核结果留痕，USD→CNY按月损益/期末余额/历史权益分别折算；初始实际截至9期。'}
