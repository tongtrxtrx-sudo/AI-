"""真实本机HTTP回归：配置改变当前范围币种后，提交响应和后续动作一致。"""
import http.cookiejar,json,sys,tempfile,threading,unittest
from pathlib import Path
from urllib.request import Request,build_opener,HTTPCookieProcessor,ProxyHandler
sys.path.insert(0,str(Path(__file__).resolve().parent))
from server import Server

class CurrencyContextHTTPTests(unittest.TestCase):
    def test_edit_current_unit_currency_returns_new_context_then_can_sign(self):
        with tempfile.TemporaryDirectory() as tmp:
            server=Server(0,tmp,Path(__file__).resolve().parent.parent/'frontend'/'dist')
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            opener=build_opener(ProxyHandler({}),HTTPCookieProcessor(http.cookiejar.CookieJar()))
            origin=server.origin
            def post(path,body,csrf=None):
                headers={'Content-Type':'application/json','Origin':origin}
                if csrf:headers['X-CSRF-Token']=csrf
                request=Request(origin+path,json.dumps(body).encode(),headers,method='POST')
                with opener.open(request,timeout=10) as response:return response.status,json.load(response)
            try:
                _,session=post('/api/session',{'token':server.token});csrf=session['csrfToken']
                with opener.open(origin+'/api/bootstrap?group=OS_GROUP&month=9&currency=USD&entity=all',timeout=10) as response:state=json.load(response)
                def action(name,payload):
                    nonlocal state
                    status,state=post('/api/action',{'action':name,'payload':payload,'revision':state['revision'],'context':state['context']},csrf)
                    self.assertEqual(status,200)
                    return state
                action('unit_reopen',{'unitId':'OS_GROUP','reason':'当前范围币种回归','cascade':True})
                os=next(u for u in state['units'] if u['id']=='OS_GROUP')
                action('unit_save',{'id':'OS_GROUP','name':os['name'],'currency':'CNY','members':os['members']})
                self.assertEqual(state['context']['group'],'OS_GROUP');self.assertEqual(state['context']['currency'],'CNY')
                self.assertEqual(state['revision'],2)
                self.assertEqual(state['reportMode'],'历史失效结果')
                self.assertEqual(state['statement']['currency'],'USD') # 历史报表保留原币种
                action('consolidation_run',{'unitId':'OS_GROUP'})
                self.assertEqual(state['statement']['currency'],'CNY');self.assertEqual(state['statement']['actual']['revenue'],700)
                action('result_approve',{'resultId':state['currentResult']['id']})
                self.assertTrue(state['currentResult']['valid']);self.assertEqual(state['reportMode'],'已签核')
                with opener.open(origin+'/api/bootstrap?group=TY_GROUP&month=9&currency=CNY&entity=all',timeout=10) as response:state=json.load(response)
                action('consolidation_run',{'unitId':'TY_GROUP'});action('result_approve',{'resultId':state['currentResult']['id']})
                actual=state['statement']['actual'];self.assertEqual((actual['revenue'],actual['net'],actual['cta'],actual['cashFx']),(2650,770,74,90))
                os_input=next(i for i in state['currentResult']['inputs'] if i['id']=='OS_GROUP');self.assertEqual(os_input['currency'],'CNY')
                # 配置保存也可移出当前法人筛选；响应回单元总览，不能已提交后报错。
                action('unit_save',{'id':'CONTEXT_SCOPE','name':'上下文成员回归','currency':'CNY','members':[{'type':'entity','id':'TY'},{'type':'entity','id':'OTHER'}]})
                with opener.open(origin+'/api/bootstrap?group=CONTEXT_SCOPE&month=9&currency=CNY&entity=TY',timeout=10) as response:state=json.load(response)
                self.assertEqual(state['context']['entity'],'TY')
                action('unit_save',{'id':'CONTEXT_SCOPE','name':'上下文成员回归','currency':'CNY','members':[{'type':'entity','id':'OTHER'}]})
                self.assertEqual(state['context']['entity'],'all');self.assertEqual(state['context']['group'],'CONTEXT_SCOPE')
                action('consolidation_run',{'unitId':'CONTEXT_SCOPE'});action('result_approve',{'resultId':state['currentResult']['id']})
                self.assertEqual(state['statement']['actual']['revenue'],600)
            finally:
                server.shutdown();server.server_close();thread.join(timeout=5)

if __name__=='__main__':unittest.main()
