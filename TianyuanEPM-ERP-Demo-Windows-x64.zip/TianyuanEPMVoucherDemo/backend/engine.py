"""多层EPM API投影与命令入口；SQLite是唯一持久化状态。"""
from __future__ import annotations
from copy import deepcopy
import re
try:
    from . import legacy_engine as legacy
    from . import multilevel_domain as domain
    from . import erp_domain as erp
    from .store import DomainError
    from .consolidation import seed_multilevel, calculate_unit, collect_leaves, normalize_report, financial_checks, make_statement, translate_result
except ImportError:
    import legacy_engine as legacy
    import multilevel_domain as domain
    import erp_domain as erp
    from store import DomainError
    from consolidation import seed_multilevel, calculate_unit, collect_leaves, normalize_report, financial_checks, make_statement, translate_result
ROLES=domain.ROLES

def seed():
    old=legacy.seed();data=seed_multilevel()
    data.update(schemaVersion=3,product=domain.PRODUCT,companyName='杭州天元宠物用品有限公司',settings={'companyName':'杭州天元宠物用品有限公司','fiscalYear':2026,'language':'简体中文','unit':'本位币万元'},periods={},trialBalances=[],results=[],resultValidity={},unitPeriods={},commentaries={},accounts=deepcopy(old['accounts']))
    data['accounts'] += [{'code':'1511','name':'长期股权投资','field':'investment','type':'资产','normalSide':'借','direction':'借','enabled':True},{'code':'4003','name':'其他综合收益—外币报表折算差额','field':'cta','type':'权益','normalSide':'贷','direction':'贷','enabled':True}]
    b=deepcopy(old['budget']);ratios={'TY':0,'HW':.5,'HW_CAT':.15,'HW_ELEC':.1,'OTHER':.25,'OS_A':0,'OS_B':0};layers=[{'label':'基础层','amount':3400},{'label':'挑战层','amount':300},{'label':'管理层','amount':200},{'label':'董事会层','amount':100}]
    b.update(version='V2 年度目标',status='编制中',layers=layers,entityRatios=ratios,entityRevenueRatios=deepcopy(ratios),drivers={'volume':1000,'price':4},versions=[],businessPlans={k:[] for k in legacy.PLAN_TYPES},comparisonAnnual={'revenue':4000,'cost':2600,'expense':200,'finance':0,'tax':0},scope='TY_GROUP',currency='CNY')
    for name,total in [('V1 基准预算',3800),('V2 年度目标',4000)]:
        ls=deepcopy(layers);ls[0]['amount']+=total-4000
        b['versions'].append({'name':name,'scenario':'年度预算','annual':total,'layers':ls,'spread':'even','status':'编制中','drivers':deepcopy(b['drivers']),'businessPlans':deepcopy(b['businessPlans'])})
    data['budget']=b
    data['erp']=erp.empty()
    data['modelPolicy'].update(version='ERP-20261021',sourceUnit='本位币万元（六位小数，保留到分）',erpSourceUnit='法人本位币元（两位小数）')
    for r in data['fxRates']:r['active']=True
    for e in data['entities']:e['percent']=100
    for e in data['eliminations']:
        if e.get('kind')=='sales' and str(e.get('id','')).startswith(('HW-SALES-','GROUP-SALES-')):e['seedOrigin']='ML初始化示例'
    # 首屏真实演示签核使用与用户完全相同的计算/审批函数。
    for uid in ('HW_GROUP','OS_GROUP','TY_GROUP'):
        rid=domain.run(data,uid,9,'系统初始化演示');domain.approve(data,rid,'系统初始化')
    return data

def context(raw=None):
    raw=raw or {}
    if not isinstance(raw,dict):raise DomainError('筛选条件必须为对象。')
    m=raw.get('month',9)
    try:
        if isinstance(m,bool) or str(int(m))!=str(m):raise ValueError
        m=int(m)
    except (ValueError,TypeError,OverflowError):raise DomainError('期间须为1至12月。') from None
    if not 1<=m<=12:raise DomainError('期间须为1至12月。')
    group={'group':'TY_GROUP','mfg':'HW_GROUP'}.get(raw.get('group'),raw.get('group','TY_GROUP'))
    if not isinstance(group,str) or not re.fullmatch('[A-Z][A-Z0-9_-]{0,39}',group):raise DomainError('合并单元编号无效。')
    currency=raw.get('currency')
    if currency not in (None,'','CNY','USD'):raise DomainError('报表币种只支持人民币或美元。')
    entity=raw.get('entity','all')
    if not isinstance(entity,str):raise DomainError('法人筛选编号无效。')
    return {'group':group,'month':m,'currency':currency,'entity':entity}

def resolve_context(data,raw):
    c=context(raw);u=domain.find(data['units'],c['group'],'合并单元');currency=u['currency']
    if c['entity']!='all':
        if c['entity'] not in domain.calc(collect_leaves,data,c['group']):raise DomainError('所选法人不属于当前合并单元。')
        currency=domain.find(data['entities'],c['entity'],'法人')['currency']
    if c['currency'] and c['currency']!=currency:raise DomainError('报表币种应与当前单元或法人本位币一致；请选择对应单元，不能用单一汇率换算整张报表。')
    return {**c,'currency':currency}

def entity_result(data,eid,month):
    e=domain.find(data['entities'],eid,'法人');source=data.get('sources',{}).get(str(month),{}).get(eid)
    if source is None:raise DomainError('该法人缺少所选月份完整三表报送。')
    report=domain.calc(normalize_report,source,month);checks=financial_checks(report,e['name'])
    result={'unitId':eid,'unitName':e['name'],'month':month,'currency':e['currency'],'report':report,'checks':checks,'passed':all(c['passed'] for c in checks),'leafIds':[eid],'inputs':[],'eliminationIds':[],'dependencies':{'sources':{eid:source.get('version',1)}},'trace':{'entities':[{'entityId':eid,'sourceVersion':source.get('version',1),'name':e['name'],'currency':e['currency']}],'eliminations':[],'fx':[]},'preview':True}
    result['statement']=make_statement(result);return result

def bootstrap(data,revision,activities,role,c):
    c=resolve_context(data,c);uid=c['group'];month=c['month'];active=domain.current_result(data,uid,month);report_error=''
    if c['entity']!='all':result=entity_result(data,c['entity'],month);mode='法人报送'
    elif active:result=active;mode=active['approvalStatus'] if active['valid'] else '历史失效结果'
    else:
        mode='预览'
        try:result=domain.calc(calculate_unit,data,uid,month,None,True)
        except DomainError as ex:
            report_error=ex.message
            empty={'opening':dict.fromkeys(domain.BS,0),'closing':dict.fromkeys(domain.BS,0),'profit':dict.fromkeys(domain.PL,0),'cashflow':dict.fromkeys(domain.CF,0),'monthlyProfit':{str(m):dict.fromkeys(domain.PL,0) for m in range(1,month+1)},'monthlyCashflow':{str(m):dict.fromkeys(domain.CF,0) for m in range(1,month+1)},'capitalMovement':0,'equityHistory':{}}
            result={'unitId':uid,'unitName':domain.find(data['units'],uid,'单元')['name'],'month':month,'currency':c['currency'],'report':empty,'checks':[{'code':'report_error','label':'报表前置未满足','passed':False,'message':report_error}],'passed':False,'trace':{'entities':[],'eliminations':[],'fx':[]},'inputs':[],'leafIds':[],'eliminationIds':[],'preview':True};result['statement']=make_statement(result)
    statuses={}
    for u in data['units']:
        r=domain.current_result(data,u['id'],month);p=domain.unit_period(data,u['id'],month)
        statuses[u['id']]={'unitId':u['id'],'locked':p.get('locked',False),'activeResultId':p.get('activeResultId'),'valid':bool(r and r['valid']),'status':r['status'] if r else '待计算','staleReason':r['staleReason'] if r else p.get('staleReason','')}
    report=result['statement'];comment=data.get('commentaries',{}).get(f'{uid}:{month}',{})
    out={k:deepcopy(data.get(k)) for k in ('companyName','settings','budget','accounts','units','entities','ownership','trialBalances','modelPolicy')}
    # 前端只接本期数据；完整历史快照保留在服务端。
    out.update(revision=revision,sessionRole=role,activities=activities,statement=deepcopy(report),report=deepcopy(report),canonicalReport=deepcopy(result['report']),checks=deepcopy(result['checks']),context=c,sources=deepcopy(data.get('sources',{}).get(str(month),{})),rateSets=deepcopy([r for r in data.get('fxRates',[]) if r['month']==month]),eliminations=deepcopy([e for e in data.get('eliminations',[]) if e['month']==month]),results=[domain.project_result(data,r) for r in data['results'] if r['month']==month],currentResult=active,unitStates=statuses,unitStatus=statuses[uid],preconditions=domain.preconditions(data,uid,month),reportMode=mode,reportError=report_error,budgetComparable=uid=='TY_GROUP' and c['currency']=='CNY' and c['entity']=='all',capabilities={'canWrite':role!='审计只读','canApprove':role==ROLES[0],'canSignoff':role==ROLES[0],'canConfigure':role==ROLES[0]},commentary=comment,period={'signed':bool(active and active['valid'] and active['approvalStatus']=='已签核'),'checksRun':bool(result['passed']),'submissionChecked':all(x['passed'] for x in domain.preconditions(data,uid,month)),'icConfirmed':not any(e['status']=='草稿' for e in data['eliminations'] if e['month']==month and e['unitId']==uid),'commentary':bool(comment),'commentaryText':comment.get('text','')},journals=[])
    # 法人贡献按所展示结果的同一来源快照和报表币种投影；明确尚未分摊合并抵销。
    leaves=result.get('leafIds',[]);out['entityActuals']=[]
    input_data=data
    if active and c['entity']=='all' and active.get('sourceSnapshots'):
        input_data=deepcopy(data);input_data['sources'][str(month)]=deepcopy(active['sourceSnapshots']);input_data['fxRates']=deepcopy(active.get('rateSnapshots',data['fxRates']))
    for eid in leaves:
        e=domain.find(data['entities'],eid,'法人')
        if eid in input_data.get('sources',{}).get(str(month),{}):
            er=entity_result(input_data,eid,month)
            if er['currency']!=result['currency']:
                er=domain.calc(translate_result,input_data,er,result['currency'],month)
            out['entityActuals'].append({'id':eid,'name':e['name'],'currency':result['currency'],'sourceCurrency':e['currency'],'sourceVersion':input_data['sources'][str(month)][eid].get('version',1),'basis':'法人贡献（合并抵销前）',**er['statement']['actual']})
    # 明确选中报表币种的月度发生额，不将USD法人的原币金额与CNY直接相加。
    out['monthlyActuals']=[result['report']['monthlyProfit'].get(str(m),{}).get('revenue',0) for m in range(1,13)]
    out['rates']=deepcopy(out['rateSets']);out['erp']=erp.bootstrap(data,uid,month);return out

def apply(data,role,action,p,c):
    if not isinstance(p,dict):raise DomainError('操作参数必须为对象。')
    c=resolve_context(data,c)
    if action in erp.ERP_ACTIONS:return erp.apply(data,role,action,p,c)
    if action.startswith('budget_'):
        if c['group']!='TY_GROUP' or c['currency']!='CNY' or c['entity']!='all':raise DomainError('预算仅在集团人民币口径编制，请切换杭州天元集团合并、全部法人、人民币。')
        return legacy._apply(data,role,action,p,c)
    return domain.apply(data,role,action,p,c)
