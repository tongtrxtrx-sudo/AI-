# ERP-20261021 后端与数据契约

本目录运行新“天元EPM 凭证合并Demo”，产品标识`SelfDevelopedEPM-ERP-Demo`、schemaVersion=3，与旧ML产品和数据库分开。默认数据目录由Windows启动器设为`%LOCALAPPDATA%\TianyuanEPMVoucherDemo`；服务对旧版或未知数据库先只读识别并拒绝改写。

## 研发运行

使用Python 3.12标准库，前端先从项目根执行`python frontend-build.py`。然后执行：

```sh
python -I backend/server.py --data-dir /tmp/tianyuan-epm-voucher --port 0 --no-browser
```

启动管道包含本机私有凭据，不能公开。EXE用户无需另装Python、Docker、WSL或虚拟机。

## 业务结构

- `ledger.py`：通用/NC6.5 CSV及XLSX、科目与期初、逐凭证借贷校验、单体试算/三表、现金分类、原凭证行血缘、按最低共同层匹配内部销售和应收应付。
- `ledger_seed.py`：七家完全虚构法人ERP样例及48列NC模板，能由原凭证重建鸿旺及集团金样。
- `erp_domain.py`：文件批次/映射版本、明确停用示例防双扣、规范化补注、源生成、匹配与差异、自动抵销草稿和事务批审、历史字段精确追溯。
- `consolidation.py`：动态管理树、严格引用已签核子快照、分层抵销、分类汇率、期初期末三表及权益校验。
- `multilevel_domain.py`：计算版本、快照、签核保护、重开与依赖失效；ERP输入版本也是正式计算前置。
- `engine.py`：中文页面投影与命令路由，预算保留集团人民币的独立编制/审批/调整流程。
- `server.py`、`store.py`：回环HTTP、会话/Origin/CSRF、revision和SQLite事务；真实SQL表仅state、audit，业务对象位于state.document JSON。

原始账务金额按法人本位币元两位十进制字符串；报表及合并金额按本位币万元六位，一分不会在万元两位中丢失；极大到无法JSON无损表达分位的金额明确拒绝。NC原币、集团/全局本币只保留核对，不重复生成法人账。

## 当前工作流

真实NC路径：配置账簿/法人本位币、客商辅助列及编码映射、共同结算/核销关联号 → 重开相关层级 → 导入科目映射与年初余额 → 导入已确认已记账的NC凭证 → 生成法人三表 → 本层匹配/查差异 → 明确转换旧预置销售抵销 → 自动生成抵销草稿 → 负责人逐张或事务批审 → 小合并计算签核 → 上层相同流程。

一键虚构样例只载入输入并保留旧历史，不替用户签核。内置鸿旺示例内部销售100万元全部未结，另有应收/应付100万元抵销；匹配18项（9个月销售+9个月往来），集团另有跨范围销售50万元9项。样例合并收入1400万元，集团2650万元、净利770万元、CTA74万元、现金汇率影响90万元。

参考`API-CONTRACT.md`、`LEDGER-CONTRACT.md`、`CALCULATION-CONTRACT.md`。普通手工源没有ERP血缘，不能伪装凭证来源；ERP原金额/日期/科目不可通过补注修改，错误金额应停用错误批次后更正重导。

## 验证

```sh
python -B -m unittest discover -s backend -v
```

独立HTTP/Chromium及Windows EXE链路证据由`acceptance`、`windows/evidence`记录。旧ML证据不能替代新ERP功能测试；Wine不等同实体Windows验收。在线NC API、写回ERP、复杂收购/少数股东/未实现利润税项、自动排除所有历史开账与未知现金分配仍属后续研发范围。
