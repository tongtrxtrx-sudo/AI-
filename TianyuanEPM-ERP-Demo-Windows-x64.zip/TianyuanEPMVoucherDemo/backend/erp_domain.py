"""ERP文件导入、凭证派生三表、内部交易匹配及原凭证历史追溯。"""
from __future__ import annotations
import base64,csv,hashlib,io,json,re
from copy import deepcopy
from decimal import Decimal
try:
    from . import multilevel_domain as domain
    from .consolidation import BS,PL,CF,ASSETS,LIABILITIES,EQUITY,make_statement,financial_checks,collect_leaves,num
    from .store import DomainError
except ImportError:
    import multilevel_domain as domain
    from consolidation import BS,PL,CF,ASSETS,LIABILITIES,EQUITY,make_statement,financial_checks,collect_leaves,num
    from store import DomainError

ERP_ACTIONS={'erp_adapter_save','erp_mapping_save','erp_opening_import','erp_voucher_import','erp_batch_cancel','erp_report_generate','erp_match_run','erp_elimination_generate','erp_sample_load','erp_demo_eliminations_replace','erp_eliminations_approve','erp_voucher_annotations_save'}
MANAGER_ACTIONS={'erp_adapter_save','erp_mapping_save','erp_batch_cancel','erp_sample_load','erp_demo_eliminations_replace','erp_eliminations_approve'}

def empty():
    return {'version':1,'adapter':'generic','mappings':[],'openings':[],'vouchers':[],'batches':[],'annotations':[],'reports':{},'matchingByScope':{},'bookMappings':[],'counterpartyMappings':[],'importOptions':{'auxiliaryColumn':'辅助核算1','referenceColumn':'结算号'}}

def state(data):
    value=data.setdefault('erp',empty())
    for k,v in empty().items():value.setdefault(k,deepcopy(v))
    return value

def _pure():
    try:from . import ledger
    except ImportError:import ledger
    return ledger

def _sample_module():
    try:from . import ledger_seed
    except ImportError:import ledger_seed
    return ledger_seed

def _call(fn,*args,**kwargs):
    try:return fn(*args,**kwargs)
    except DomainError:raise
    except (ValueError,TypeError,KeyError) as ex:raise DomainError(str(ex),'erp_validation',400) from None

def _id(prefix,rows):return f'{prefix}-{len(rows)+1:05d}'
def _entity(data,eid):return domain.find(data['entities'],eid,'法人')
def _affected(data,eids):return set().union(*(domain.entity_units(data,eid) for eid in eids)) if eids else set()
def _active_rows(erp,key):return [r for r in erp.get(key,[]) if r.get('active',True)]

def effective_erp(data):
    e=deepcopy(state(data))
    for k in ('mappings','openings','vouchers'):e[k]=_active_rows(e,k)
    return e

def ledger_fingerprint(data,eid,month):
    e=effective_erp(data)
    rows={k:[r for r in e[k] if r.get('entityId')==eid and (k!='vouchers' or int(str(r.get('date','2026-12-31'))[5:7])<=month)] for k in ('mappings','openings','vouchers')}
    # 账簿/客商映射属于导入时解释规则，已固定在凭证行中；源只依赖其实际规范化输入。
    return hashlib.sha256(json.dumps(rows,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def scope_fingerprint(data,uid,month):
    leaves=_call(collect_leaves,data,uid)
    value={'unit':next(u for u in data['units'] if u['id']==uid),'entities':{eid:ledger_fingerprint(data,eid,month) for eid in leaves}}
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def has_ledger(data,eid,month=12):
    e=state(data)
    return any(r.get('entityId')==eid and r.get('active',True) and (k!='vouchers' or int(r['date'][5:7])<=month) for k in ('openings','vouchers') for r in e.get(k,[]))

def _changed(data,eids,reason,start_month=1):
    erp=state(data);erp['version']+=1
    uids=_affected(data,eids)
    for month in range(start_month,13):domain.invalidate(data,uids,month,reason)
    for key,run in erp.get('matchingByScope',{}).items():
        if run.get('month',1)>=start_month and set(run.get('leafIds',[]))&set(eids):run['valid']=False;run['staleReason']=reason
    for e in data.get('eliminations',[]):
        if e.get('erpMatchId') and e.get('unitId') in uids and e.get('month',1)>=start_month and e.get('status')!='已停用':
            e.update(status='来源失效',version=e.get('version',1)+1,staleReason=reason)
    for report in erp.get('reports',{}).values():
        if report.get('entityId') in eids and report.get('month',1)>=start_month:report['valid']=False


def _assert_inputs_open(data,eids,start_month=1):
    for m in range(start_month,13):domain.assert_open(data,_affected(data,eids),m)


def precondition_rows(data,uid,month):
    if not data.get('erp'):return []
    leaves=_call(collect_leaves,data,uid);rows=[]
    for eid in leaves:
        source=data.get('sources',{}).get(str(month),{}).get(eid,{})
        if not has_ledger(data,eid,month) and source.get('sourceType')!='erp':continue
        ok=source.get('sourceType')=='erp' and source.get('ledgerFingerprint')==ledger_fingerprint(data,eid,month)
        rows.append({'code':'erp_source_'+eid,'label':_entity(data,eid)['name']+'凭证三表版本','passed':ok,'message':'当前凭证及期初已生成完整三表。' if ok else '凭证、科目映射或期初已变化，须重新生成法人三表，不能沿用旧报送。'})
    # 只有存在ERP内部交易相关行才要求本层匹配；跨范围交易由其最低共同上层处理。
    relevant=False
    maps={(r['entityId'],r['code']):r for r in _active_rows(state(data),'mappings')}
    for kind in ('openings','vouchers'):
        for r in _active_rows(state(data),kind):
            if kind=='vouchers' and int(r['date'][5:7])>month:continue
            if r.get('entityId') not in leaves:continue
            if maps.get((r.get('entityId'),r.get('accountCode')),{}).get('field') not in ('revenue','cost','receivable','payable'):continue
            if Decimal(str(r.get('debit',0)))==Decimal(str(r.get('credit',0))):continue
            status=r.get('counterpartyStatus','internal' if r.get('counterpartyId') else 'unspecified')
            if status=='external':continue
            if r.get('counterpartyId') in leaves or r.get('unmappedCounterparty') or status in ('unspecified','unresolved','conflict') or not r.get('counterpartyId'):relevant=True
    if relevant:
        conflict=[e for e in data.get('eliminations',[]) if e.get('seedOrigin')=='ML初始化示例' and e.get('kind')=='sales' and e.get('unitId')==uid and e.get('month')==month and e.get('status')!='已停用']
        rows.append({'code':'erp_demo_elimination_conflict','label':'预置示例抵销已明确转换','passed':not conflict,'message':'本层不再重复使用旧示例销售抵销。' if not conflict else '本层仍有预置手工示例销售抵销，请由负责人确认转入凭证合并模式，保留历史并停用示例，避免双扣。'})
        run=state(data)['matchingByScope'].get(f'{uid}:{month}')
        current=bool(run and run.get('valid') and run.get('erpInputFingerprint')==scope_fingerprint(data,uid,month))
        rows.append({'code':'erp_matching','label':'本层ERP内部交易匹配版本','passed':current,'message':'匹配使用当前原凭证版本。' if current else '请先运行本层内部交易匹配，查看差异并生成抵销草稿。'})
        if current:
            differences=run.get('differences',[])
            rows.append({'code':'erp_differences','label':'内部交易差异已核清','passed':not differences,'message':'无未解决差异。' if not differences else f'有{len(differences)}项差异，请追溯原凭证、修正后重新匹配；系统不会倒挤。'})
            missing=[m for m in run.get('matches',[]) if not any(e.get('erpMatchId')==m['id'] and e.get('erpInputFingerprint')==run['erpInputFingerprint'] and e.get('status') in ('已审批','已签核') for e in data.get('eliminations',[]) if e.get('month')==month and e.get('unitId')==uid)]
            rows.append({'code':'erp_generated','label':'匹配抵销已生成并审批','passed':not missing,'message':'相符项目已审批并纳入本层抵销。' if not missing else f'{len(missing)}项相符交易尚未生成并审批抵销。'})
    return rows


def _input_text(p):
    raw=p.get('csv')
    if isinstance(raw,str):
        if len(raw.encode('utf-8'))>9_000_000:raise DomainError('导入文本不能超过9MB。')
        return raw
    encoded=p.get('fileBase64')
    if not isinstance(encoded,str):raise DomainError('请提供CSV文本或XLSX文件。')
    try:binary=base64.b64decode(encoded,validate=True)
    except (ValueError,TypeError):raise DomainError('上传文件编码无效。') from None
    if len(binary)>8_000_000:raise DomainError('上传文件不能超过8MB。')
    name=p.get('fileName',p.get('sourceName',''))
    parser=_pure()
    if hasattr(parser,'read_file_csv'):return _call(parser.read_file_csv,binary,name,p.get('sheetName'))
    if hasattr(parser,'file_to_csv'):return _call(parser.file_to_csv,binary,name,p.get('sheetName'))
    if str(name).lower().endswith('.xlsx'):
        if hasattr(parser,'read_xlsx_csv'):return _call(parser.read_xlsx_csv,binary,p.get('sheetName'))
        raise DomainError('XLSX解析器尚未完整安装，请使用CSV。')
    if str(name).lower().endswith('.xls'):raise DomainError('旧版.xls暂不支持，请在Excel/WPS另存为.xlsx或UTF-8 CSV。')
    for encoding in ('utf-8-sig','gb18030'):
        try:return binary.decode(encoding)
        except UnicodeDecodeError:pass
    raise DomainError('无法读取文件，请另存为UTF-8 CSV。')


def _batch(data,kind,source_name,rows):
    erp=state(data);bid=_id('ERP-BATCH',erp['batches'])
    entry={'id':bid,'kind':kind,'sourceName':domain.text(source_name,'来源文件',180),'createdAt':domain.now(),'status':'已导入','active':True,'rowCount':len(rows),'entityIds':sorted({r['entityId'] for r in rows}),'adapter':erp.get('adapter','generic')}
    for i,row in enumerate(rows,1):row.update(batchId=bid,active=True,id=row.get('id') or f'{bid}-L{i:05d}',sourceRow=row.get('sourceRow',i+1))
    erp['batches'].append(entry)
    return entry


def _mapping_rows(data,p):
    rows=p.get('rows')
    if rows is not None:
        if not isinstance(rows,list) or not rows:raise DomainError('科目映射必须为非空列表。')
        out=[]
        for row in rows:
            if not isinstance(row,dict):raise DomainError('科目映射行无效。')
            e=_entity(data,row.get('entityId'));field=row.get('field');side=row.get('normalSide')
            if field not in BS+PL or side not in ('借','贷'):raise DomainError('科目映射字段或余额方向无效。')
            out.append({'entityId':e['id'],'code':domain.text(row.get('code'),'科目编码',60),'name':domain.text(row.get('name'),'科目名称',100),'field':field,'normalSide':side,'version':1})
        return out
    return _call(_pure().parse_mappings_csv,data,_input_text(p),p.get('columnMap'))


def _report(data,eid,month):
    erp=effective_erp(data);out=_call(_pure().generate_source,data,erp,eid,month)
    source=deepcopy(out['source']);clean=domain.sanitize_source(data,eid,month,source)
    snapshot={'mappings':[r for r in erp['mappings'] if r['entityId']==eid],'openings':[r for r in erp['openings'] if r['entityId']==eid],'vouchers':[r for r in erp['vouchers'] if r['entityId']==eid and int(r['date'][5:7])<=month], 'batches':[b for b in erp['batches'] if eid in b.get('entityIds',[])], 'excludedClosingVouchers':deepcopy(out.get('excludedClosingVouchers',[])), 'adapter':erp.get('adapter','generic'),'bookMappings':[r for r in erp['bookMappings'] if r['entityId']==eid],'counterpartyMappings':deepcopy(erp['counterpartyMappings']),'importOptions':deepcopy(erp['importOptions'])}
    clean.update(sourceType='erp',ledgerFingerprint=ledger_fingerprint(data,eid,month),ledgerTrace=deepcopy(out.get('trace',{})),ledgerSnapshot=snapshot,sourceName='ERP凭证与期初派生三表')
    result={'unitId':eid,'unitName':_entity(data,eid)['name'],'currency':clean['currency'],'month':month,'report':clean,'checks':financial_checks(clean),'passed':True,'trace':{'entities':[],'eliminations':[],'fx':[]}}
    statement=make_statement(result)
    return clean,{'entityId':eid,'month':month,'currency':clean['currency'],'sourceVersion':clean['version'],'source':deepcopy(clean),'statement':statement,'trialBalance':deepcopy(out.get('trialBalance',[])),'trace':deepcopy(out.get('trace',{})),'checks':deepcopy(out.get('checks',financial_checks(clean))),'ledgerFingerprint':clean['ledgerFingerprint'],'valid':True,'generatedAt':domain.now(),'excludedClosingVouchers':deepcopy(out.get('excludedClosingVouchers',[]))}


def _templates(data):
    module=_sample_module()
    if hasattr(module,'sample_bundle'):
        known=[e['id'] for e in data['entities'] if e['id'] in ('TY','HW','HW_CAT','HW_ELEC','OTHER','OS_A','OS_B')]
        value=_call(module.sample_bundle,data,known)
        value['nc65Csv']=_call(module.nc_sample_csv,data,known)
        return value
    if hasattr(module,'sample_files'):
        value=_call(module.sample_files,data)
        if isinstance(value,dict):return value
    if hasattr(module,'templates'):
        value=_call(module.templates,data)
        if isinstance(value,dict):return value
    return {}


def bootstrap(data,uid,month):
    e=deepcopy(state(data));e['reports']={}
    for eid in [a['id'] for a in data['entities']]:
        report=state(data)['reports'].get(f'{eid}:{month}')
        if report:e['reports'][eid]=deepcopy(report)
    e['matching']=deepcopy(state(data)['matchingByScope'].get(f'{uid}:{month}',{'matches':[],'differences':[],'scopeId':uid,'month':month,'valid':False}))
    e['templates']=_templates(data)
    e['demoEliminationConflicts']=[deepcopy(row) for row in data['eliminations'] if row.get('seedOrigin')=='ML初始化示例' and row.get('kind')=='sales' and row['unitId']==uid and row['month']==month and row.get('status')!='已停用']
    e['integration']={'adapter':e['adapter'],'mode':'NC6.5文件导入' if e['adapter']=='nc65' else '通用凭证文件导入','onlineConnected':False,'note':'文件导入不是NC在线接口；导出必须由用户确认只含已记账业务凭证。','amountUnit':'元','reportUnit':'本位币万元（最多6位小数，保留到分）'}
    e.pop('matchingByScope',None)
    return e


def apply(data,role,action,p,c):
    if role not in domain.ROLES or role=='审计只读':raise DomainError('审计只读角色不能导入或修改ERP数据。','forbidden',403)
    if action in MANAGER_ACTIONS and role!=domain.ROLES[0]:raise DomainError('此操作需要集团财务负责人权限。','forbidden',403)
    erp=state(data);month=c['month'];uid=p.get('unitId',c['group'])
    if action=='erp_adapter_save':
        if p.get('adapter','generic') not in ('generic','nc65'):raise DomainError('适配器仅支持generic或nc65文件导入。')
        books=p.get('bookMappings',[]);counter=p.get('counterpartyMappings',[]);options=p.get('importOptions',{})
        if not isinstance(books,list) or not isinstance(counter,list) or not isinstance(options,dict) or any(not isinstance(r,dict) for r in books+counter):raise DomainError('账簿、客商及导入选项格式无效。')
        cleaned=[];seen=set()
        for r in books:
            eid=r.get('entityId');e=_entity(data,eid);code=domain.text(r.get('bookCode'),'账簿编码',80)
            if code in seen or r.get('functionalCurrency',e['currency'])!=e['currency']:raise DomainError('账簿编码重复或本位币与法人档案不符。')
            seen.add(code);cleaned.append({'bookCode':code,'entityId':eid,'functionalCurrency':e['currency']})
        cc=[];seen=set()
        for r in counter:
            code=domain.text(r.get('code'),'客商编码',80);eid=r.get('entityId');column=r.get('column','')
            if column and column not in [f'辅助核算{i}' for i in range(1,10)]:raise DomainError('客商映射辅助列无效。')
            key=(column,code)
            if key in seen:raise DomainError('相同辅助列客商编码重复。')
            if eid!='EXTERNAL':_entity(data,eid)
            seen.add(key);cc.append({'code':code,'entityId':eid,**({'column':column} if column else {})})
        auxiliary=options.get('auxiliaryColumn','辅助核算1');reference=options.get('referenceColumn','结算号')
        columns=options.get('auxiliaryColumns',[auxiliary])
        if not isinstance(columns,list) or not columns or any(not isinstance(v,str) for v in columns) or len(columns)!=len(set(columns)) or any(x not in [f'辅助核算{i}' for i in range(1,10)] for x in columns) or auxiliary not in [f'辅助核算{i}' for i in range(1,10)] or reference not in ('结算号','核销号',''):raise DomainError('辅助核算列或关联号字段选择无效。')
        erp.update(adapter=p.get('adapter','generic'),bookMappings=cleaned,counterpartyMappings=cc,importOptions={'auxiliaryColumn':auxiliary,'auxiliaryColumns':columns,'referenceColumn':reference},version=erp['version']+1)
        return '保存ERP文件适配规则；只影响后续导入。旧NC批次须先停用后按新规则重新导入才生效，已导入原凭证与历史快照不改写。'
    if action=='erp_mapping_save':
        rows=_mapping_rows(data,p);eids={r['entityId'] for r in rows};_assert_inputs_open(data,eids)
        keys=[(r['entityId'],r['code']) for r in rows]
        if len(keys)!=len(set(keys)):raise DomainError('同法人科目映射重复。')
        for r in rows:
            previous=[m for m in erp['mappings'] if (m['entityId'],m['code'])==(r['entityId'],r['code'])]
            r['version']=max((m.get('version',1) for m in previous),default=0)+1
            for old in previous:old['active']=False
        batch=_batch(data,'mapping',p.get('sourceName','科目映射'),rows);erp['mappings'].extend(rows)
        _changed(data,eids,'ERP科目映射已更新，请重新生成法人三表及内部匹配。')
        return f'导入科目映射{len(rows)}行，批次{batch["id"]}。'
    if action in ('erp_opening_import','erp_voucher_import'):
        unit=p.get('amountUnit','元')
        if unit not in ('元','万元'):raise DomainError('金额单位须为元或万元。')
        raw=_input_text(p);module=_pure()
        if action=='erp_opening_import':rows=_call(module.parse_openings_csv,data,raw,unit,p.get('columnMap'));key='openings';kind='opening'
        elif p.get('format',erp.get('adapter','generic'))=='nc65':
            if p.get('postedConfirmed') is not True:raise DomainError('NC导出没有记账状态列，请确认文件仅包含已记账业务凭证后再导入。')
            rows=_call(module.parse_nc_vouchers,data,effective_erp(data),raw,unit,p.get('columnMap'));key='vouchers';kind='voucher'
        else:rows=_call(module.parse_vouchers_csv,data,raw,unit,p.get('columnMap'));key='vouchers';kind='voucher'
        eids={r['entityId'] for r in rows};start=min((int(r['date'][5:7]) for r in rows),default=1) if key=='vouchers' else 1
        _assert_inputs_open(data,eids,start)
        if key=='vouchers':
            def rowkey(r):return (r['entityId'],r.get('bookCode',''),r['date'][:7],r.get('category',''),r['voucherId'],str(r['lineNo']))
        else:
            def rowkey(r):return (r['entityId'],r['accountCode'],r.get('counterpartyId',''),r.get('reference',''))
        existing={rowkey(r) for r in _active_rows(erp,key)};incoming=[rowkey(r) for r in rows]
        if len(incoming)!=len(set(incoming)) or existing&set(incoming):raise DomainError('发现重复凭证分录或期初余额；整批未导入，请先停用错误批次后更正，不能重复入账。','erp_duplicate',409)
        batch=_batch(data,kind,p.get('sourceName',p.get('fileName','ERP导入')),rows);batch['postedConfirmed']=p.get('postedConfirmed',False);erp[key].extend(rows)
        issues=_call(module.validate_erp,data,effective_erp(data))
        blocking=[x for x in (issues or []) if not isinstance(x,dict) or x.get('blocking',True)]
        if blocking:raise DomainError('ERP数据校验失败：'+'；'.join(str(x.get('message',x)) if isinstance(x,dict) else str(x) for x in blocking[:10]))
        _changed(data,eids,'ERP期初或凭证已更新，请重新生成法人三表与内部交易匹配。',start)
        return f'导入{len(rows)}行，批次{batch["id"]}；原凭证与文件行号已保存。'
    if action=='erp_batch_cancel':
        batch=domain.find(erp['batches'],p.get('batchId'),'ERP批次');reason=domain.text(p.get('reason'),'停用原因',500)
        if not batch.get('active',True):raise DomainError('此批次已停用。')
        eids=set(batch.get('entityIds',[]))
        dated=[int(r['date'][5:7]) for r in erp['vouchers'] if r.get('batchId')==batch['id']]
        start=min(dated) if dated and batch.get('kind')=='voucher' else 1
        _assert_inputs_open(data,eids,start)
        batch.update(active=False,status='已停用',cancelReason=reason,cancelledAt=domain.now())
        for key in ('mappings','openings','vouchers'):
            for r in erp[key]:
                if r.get('batchId')==batch['id']:r['active']=False
        _changed(data,eids,'ERP批次已停用，需重新生成三表和匹配。',start)
        return '已停用ERP批次，原始行与历史报表仍保留。'
    if action=='erp_voucher_annotations_save':
        allowed={'rowIds','counterpartyId','reference','cashflow','reason'}
        if set(p)-allowed:raise DomainError('核对补注只允许客商、共同关联号和现金分类；不能修改原金额、日期、科目或原始字段。')
        ids=p.get('rowIds');fields=set(p)&{'counterpartyId','reference','cashflow'}
        if not isinstance(ids,list) or not ids or any(not isinstance(v,str) for v in ids) or len(ids)!=len(set(ids)) or not fields:raise DomainError('请选择不重复的原凭证行并填写至少一项核对信息。')
        reason=domain.text(p.get('reason'),'核对补注原因',500)
        rows=[r for r in _active_rows(erp,'vouchers') if r['id'] in ids]
        if {r['id'] for r in rows}!=set(ids):raise DomainError('存在不存在或已停用的原凭证行，不能补注。')
        leaves=set(_call(collect_leaves,data,uid));eids={r['entityId'] for r in rows}
        if not eids<=leaves or any(int(r['date'][5:7])>month for r in rows):raise DomainError('只能补注当前合并范围、截至当前期间的原凭证行。')
        _assert_inputs_open(data,eids,min(int(r['date'][5:7]) for r in rows))
        changes={}
        if 'counterpartyId' in fields:
            cp=p['counterpartyId']
            if cp!='EXTERNAL':_entity(data,cp)
            if any(cp==r['entityId'] for r in rows):raise DomainError('内部交易对方不能为本法人。')
            changes.update(counterpartyId='' if cp=='EXTERNAL' else cp,counterpartyStatus='external' if cp=='EXTERNAL' else 'internal',unmappedCounterparty=False)
        if 'reference' in fields:changes['reference']=domain.text(p['reference'],'共同交易关联号',120,False)
        if 'cashflow' in fields:
            cf=p['cashflow']
            if cf not in ('','operating','investing','financing'):raise DomainError('现金分类只能为经营、投资、筹资或清除。')
            maps={(r['entityId'],r['code']):r for r in _active_rows(erp,'mappings')}
            if any(maps.get((r['entityId'],r['accountCode']),{}).get('field')!='cash' for r in rows):raise DomainError('现金流类别只能补充在货币资金科目分录；非现金行混入时整批未保存。')
            changes['cashflow']=cf
        for row in rows:
            before={k:deepcopy(row.get(k)) for k in changes};annotation={'id':_id('ERP-NOTE',erp['annotations']),'at':domain.now(),'by':role,'reason':reason,'rowId':row['id'],'before':before,'after':deepcopy(changes)}
            row.update(deepcopy(changes));row.setdefault('annotations',[]).append(deepcopy(annotation));erp['annotations'].append(annotation)
        _changed(data,eids,'原凭证规范化核对信息已补充，请重生法人三表与重新匹配。',min(int(r['date'][5:7]) for r in rows))
        return f'已补充{len(rows)}行核对信息；原金额、日期、科目和NC原始字段保留，历史快照不变。'
    if action=='erp_report_generate':
        eids=p.get('entityIds') or _call(collect_leaves,data,uid)
        if not isinstance(eids,list) or not eids or any(not isinstance(v,str) for v in eids) or len(eids)!=len(set(eids)):raise DomainError('生成法人清单无效或重复。')
        for eid in eids:_entity(data,eid)
        _assert_inputs_open(data,eids,month)
        prepared={eid:_report(data,eid,month) for eid in eids}
        for eid,(source,report) in prepared.items():
            data['sources'].setdefault(str(month),{})[eid]=source;erp['reports'][f'{eid}:{month}']=report
        domain.invalidate(data,_affected(data,eids),month,'ERP凭证已生成新法人三表，请逐层计算和签核。')
        return f'已由凭证与期初生成{len(eids)}家法人完整三表，保存来源行与快照。'
    if action=='erp_match_run':
        leaves=_call(collect_leaves,data,uid)
        run=_call(_pure().match_ic,data,effective_erp(data),uid,month)
        run.update(valid=True,leafIds=leaves,erpInputFingerprint=scope_fingerprint(data,uid,month),runAt=domain.now())
        for old in data.get('eliminations',[]):
            if old.get('erpMatchId') and old.get('unitId')==uid and old.get('month')==month and old.get('erpInputFingerprint')!=run['erpInputFingerprint'] and old.get('status')!='已停用':old.update(status='已停用',version=old.get('version',1)+1,cancelReason='原始凭证版本变化，已重新匹配。')
        for i,m in enumerate(run.get('matches',[]),1):m.setdefault('id',f'MATCH-{uid}-{month:02d}-{i:04d}')
        for i,d in enumerate(run.get('differences',[]),1):d.setdefault('id',f'DIFF-{uid}-{month:02d}-{i:04d}')
        erp['matchingByScope'][f'{uid}:{month}']=run
        return f'匹配完成：相符{len(run.get("matches",[]))}项，差异{len(run.get("differences",[]))}项；金额差异未自动抵平。'
    if action=='erp_demo_eliminations_replace':
        domain.find(data['units'],uid,'合并单元');reason=domain.text(p.get('reason'),'模式切换原因',500)
        domain.assert_open(data,domain.ancestors(data,uid),month)
        matches=[e for e in data['eliminations'] if e.get('seedOrigin')=='ML初始化示例' and e.get('kind')=='sales' and e.get('unitId')==uid and e.get('month')==month and e.get('status')!='已停用']
        for old in matches:old.update(status='已停用',version=old.get('version',1)+1,cancelReason='明确转入ERP凭证模式：'+reason,cancelledAt=domain.now())
        if matches:domain.invalidate(data,domain.ancestors(data,uid),month,'明确停用本层旧示例销售抵销，请生成ERP抵销并审批。')
        return f'停用本层{len(matches)}项预置示例销售抵销；用户自建事项、投资权益及历史快照保留。'
    if action=='erp_elimination_generate':
        conflict=[e for e in data['eliminations'] if e.get('seedOrigin')=='ML初始化示例' and e.get('kind')=='sales' and e.get('unitId')==uid and e.get('month')==month and e.get('status')!='已停用']
        if conflict:raise DomainError('本层仍有预置手工销售抵销，请先由负责人确认“转入凭证合并模式”，避免与ERP自动抵销双扣。','erp_demo_elimination_conflict',409)
        domain.assert_open(data,domain.ancestors(data,uid),month)
        run=erp['matchingByScope'].get(f'{uid}:{month}')
        if not run or not run.get('valid') or run.get('erpInputFingerprint')!=scope_fingerprint(data,uid,month):raise DomainError('匹配已失效，请先重新匹配当前凭证。','erp_stale_match',409)
        ids=p.get('matchIds');selected=[m for m in run.get('matches',[]) if ids is None or m['id'] in ids]
        if ids is not None and (not isinstance(ids,list) or any(not isinstance(v,str) for v in ids) or set(ids)!={m['id'] for m in selected}):raise DomainError('选择的匹配项目不存在。')
        count=0
        for m in selected:
            previous=[e for e in data['eliminations'] if e.get('erpMatchId')==m['id'] and e.get('unitId')==uid and e.get('month')==month and e.get('status')!='已停用']
            if any(e.get('erpInputFingerprint')==run['erpInputFingerprint'] and e.get('status') in ('草稿','已审批','已签核') for e in previous):continue
            for old in previous:old.update(status='已停用',cancelReason='原凭证变更后重新生成',version=old.get('version',1)+1)
            amount=num(Decimal(str(m['amount'])));kind=m.get('kind','sales')
            if m['currency']!=domain.find(data['units'],uid,'合并单元')['currency']:raise DomainError('本层报表币种与匹配原币不一致，请在同币小合并层处理；本轮不自动倒挤跨币抵销。')
            if kind not in ('sales','balances'):raise DomainError('自动抵销类型尚不支持。')
            if m.get('unitId',uid)!=uid or domain.calc(domain.lowest_common_unit,data,m['sellerId'],m['buyerId'])!=uid:raise DomainError('自动抵销不在交易双方最低共同合并层。')
            effects=deepcopy(m.get('effects') or ({'revenue':-amount,'cost':-amount} if kind=='sales' else {'receivable':-amount,'payable':-amount}))
            row={'id':_id('AUTO-ELIM',data['eliminations']),'sourceId':'ERP-'+str(m.get('sourceId',m['id']))+'-'+run['erpInputFingerprint'][:10],'unitId':uid,'month':month,'kind':kind,'status':'草稿','version':1,'currency':m['currency'],'amount':amount,'sellerId':m['sellerId'],'buyerId':m['buyerId'],'effects':effects,'openingEffects':deepcopy(m.get('openingEffects',{})),'title':'ERP自动内部销售抵销' if kind=='sales' else 'ERP自动内部往来余额抵销','reason':'按双方原凭证及关联号匹配生成，须负责人审批。','erpMatchId':m['id'],'matchId':m['id'],'matchSignature':run['erpInputFingerprint'],'sourceSignature':m.get('signature'),'automation':'ERP原凭证匹配','erpInputFingerprint':run['erpInputFingerprint'],'voucherRefs':deepcopy(m.get('voucherRefs',[])),'sourceRows':deepcopy(m.get('sourceRows',m.get('voucherRefs',[])))}
            fields=('revenue','cost') if kind=='sales' else ('payable','receivable')
            labels=('营业收入','营业成本') if kind=='sales' else ('应付账款','应收账款')
            row['journalLines']=[{'accountField':fields[0],'accountName':labels[0],'debit':amount,'credit':0,'currency':m['currency'],'amountUnit':'万元'},{'accountField':fields[1],'accountName':labels[1],'debit':0,'credit':amount,'currency':m['currency'],'amountUnit':'万元'}]
            if kind=='sales':
                schedule=m.get('monthlyAmounts') or {str(i):amount if i==month else 0 for i in range(1,month+1)}
                row['monthlyAmounts']=deepcopy(schedule);row['monthlyEffects']={str(i):{'revenue':-num(Decimal(str(schedule.get(str(i),0)))),'cost':-num(Decimal(str(schedule.get(str(i),0))))} for i in range(1,month+1)}
            else:row['openingAmount']=m.get('openingAmount',0)
            data['eliminations'].append(row);count+=1
        if count:domain.invalidate(data,domain.ancestors(data,uid),month,'ERP匹配已生成抵销草稿，请审批后重算。')
        return f'生成{count}张自动抵销草稿；已生成的同版本项目不重复生成。'
    if action=='erp_eliminations_approve':
        reason=domain.text(p.get('reason'),'批量审批原因',500)
        domain.assert_open(data,domain.ancestors(data,uid),month)
        run=erp['matchingByScope'].get(f'{uid}:{month}')
        if not run or not run.get('valid') or run.get('erpInputFingerprint')!=scope_fingerprint(data,uid,month):raise DomainError('匹配来源已变化，请重新匹配并生成。','erp_stale_match',409)
        ids=p.get('ids');selected=[e for e in data['eliminations'] if e.get('unitId')==uid and e.get('month')==month and e.get('erpMatchId') and e.get('status')=='草稿' and (ids is None or e['id'] in ids)]
        if ids is not None and (not isinstance(ids,list) or any(not isinstance(v,str) for v in ids) or set(ids)!={e['id'] for e in selected}):raise DomainError('批量审批只能选择本层本期待审批的ERP自动草稿。')
        for row in selected:
            if row.get('erpInputFingerprint')!=run['erpInputFingerprint']:raise DomainError('自动抵销来源版本已失效，请重新生成。','erp_stale_match',409)
            domain.apply(data,role,'elimination_approve',{'id':row['id']},c)
            row.update(approvedBy=role,approvedAt=domain.now(),approvalReason=reason)
        return f'已逐张校验并审批{len(selected)}张ERP自动抵销；整批事务保存，手工事项未修改。'
    if action=='erp_sample_load':
        if p.get('replace') is not True:raise DomainError('载入演示样例需明确replace=true；现ERP输入会归档，历史报表保留。')
        reason=domain.text(p.get('reason'),'载入样例原因',500)
        sample=_call(_sample_module().seed_erp,data)
        if any(erp.get(k) for k in ('mappings','openings','vouchers')):data.setdefault('erpArchives',[]).append({'archivedAt':domain.now(),'reason':reason,'erp':deepcopy(erp)})
        for old in data.get('eliminations',[]):
            if old.get('erpMatchId') and old.get('status')!='已停用':old.update(status='来源失效',version=old.get('version',1)+1,staleReason='明确重新载入ERP演示输入。')
        fresh=empty();fresh.update(deepcopy(sample));data['erp']=fresh
        for k in ('mappings','openings','vouchers'):fresh.setdefault(k,[])
        eids={r['entityId'] for k in ('openings','vouchers') for r in fresh[k]}
        affected=_affected(data,eids)
        for m in range(1,13):domain.invalidate(data,affected,m,'明确载入ERP样例：'+reason,True)
        # 原演示已含手工100/50销售抵销，改用同源凭证匹配后不能再扣一次。
        for e in data['eliminations']:
            if e.get('kind')=='sales' and str(e.get('id','')).startswith(('HW-SALES-','GROUP-SALES-')):e.update(status='已停用',version=e.get('version',1)+1,cancelReason='切换ERP样例，防止与自动来源重复抵销。')
        return '已载入完整虚构ERP映射、期初及原凭证；旧ERP输入已归档、旧签核结果保留。请先生成单体三表，再匹配和审批抵销。'
    raise DomainError('ERP操作不存在。','not_found',404)


def trace(data,eid,month,area,field,result_id=None):
    _entity(data,eid);source=None;basis='当前法人源'
    if result_id:
        result=domain.find(data['results'],result_id,'历史结果')
        if result['month']!=month:raise DomainError('结果期间与追溯期间不符。')
        source=result['snapshot'].get('sourceSnapshots',{}).get(eid);basis='历史签核输入快照'
    else:source=data.get('sources',{}).get(str(month),{}).get(eid)
    if not source:raise DomainError('该结果或期间没有所选法人的源报送。','not_found',404)
    if source.get('sourceType')!='erp':raise DomainError('此报送是手工三表源，没有ERP原凭证血缘。','no_erp_lineage',409)
    actual_area=area;fields=[];signs={}
    if area in ('opening','closing'):
        derived={'assets':ASSETS,'liabilities':LIABILITIES,'equity':EQUITY,'balance':LIABILITIES+EQUITY}
        if field in BS:fields=[field]
        elif field in derived:fields=list(derived[field])
    elif area in ('profit','monthlyProfit'):
        derived={'gross':PL[:2],'operating':PL[:3],'pretax':PL[:4],'net':PL}
        if field in PL:fields=[field]
        elif field in derived:fields=list(derived[field]);signs={k:1 if k=='revenue' else -1 for k in fields}
    elif area in ('cashflow','monthlyCashflow'):
        if field in CF:fields=[field]
        elif field=='change':fields=list(CF)
        elif field=='openingcash':actual_area='opening';fields=['cash']
        elif field=='cash':actual_area='closing';fields=['cash']
    if not fields:raise DomainError('追溯数据区或报表项目无效。','invalid_trace_field',400)
    snapshot=deepcopy(source.get('ledgerSnapshot',{}));all_trace=deepcopy(source.get('ledgerTrace',[]))
    if isinstance(all_trace,dict):
        # 兼容明确按区/字段分组的历史结构，不能回退为全部凭证。
        trace_rows=[]
        for a,content in all_trace.items():
            if isinstance(content,dict):
                for k,refs in content.items():trace_rows.append({'area':a,'field':k,'voucherRefs':refs if isinstance(refs,list) else []})
    else:trace_rows=all_trace
    selected=[r for r in trace_rows if isinstance(r,dict) and r.get('area')==actual_area and r.get('field') in fields]
    refs=[ref for r in selected for ref in r.get('voucherRefs',[]) if isinstance(ref,dict)]
    def key(r):
        return ('id',r['id']) if r.get('id') else ('row',r.get('entityId',eid),r.get('batchId',''),r.get('date',''),r.get('voucherId',''),str(r.get('lineNo','')),r.get('accountCode',''),r.get('sourceRow'))
    wanted={key(r) for r in refs}
    rows=[r for r in snapshot.get('vouchers',[]) if key(r) in wanted]
    openings=[r for r in snapshot.get('openings',[]) if key(r) in wanted]
    # 某些trace保留完整原行而snapshot按标准行存储，完整原行也是冻结输入。
    for ref in refs:
        if ref.get('accountCode') and ('debit' in ref or 'credit' in ref) and key(ref) not in {key(r) for r in rows+openings}:
            (rows if ref.get('voucherId') else openings).append(ref)
    vouchers={(r.get('bookCode',''),r.get('date','')[:7],r.get('category',''),r.get('voucherId')) for r in rows}
    related=[r for r in snapshot.get('vouchers',[]) if (r.get('bookCode',''),r.get('date','')[:7],r.get('category',''),r.get('voucherId')) in vouchers]
    values=source.get(actual_area,{})
    if actual_area.startswith('monthly'):
        amount=sum((Decimal(str(row.get(k,0)))*signs.get(k,1) for row in values.values() for k in fields),Decimal(0))
    else:amount=sum((Decimal(str(values.get(k,0)))*signs.get(k,1) for k in fields),Decimal(0))
    return {'entityId':eid,'month':month,'area':area,'field':field,'sourceVersion':source.get('version'),'basis':basis,'resultId':result_id,'currency':source['currency'],'amount':num(amount),'amountUnit':'万元','contributingFields':fields,'traceRows':selected,'rows':rows,'openingRows':openings,'relatedVoucherRows':related,'ledgerSnapshot':snapshot,'source':deepcopy(source),'trace':selected}
