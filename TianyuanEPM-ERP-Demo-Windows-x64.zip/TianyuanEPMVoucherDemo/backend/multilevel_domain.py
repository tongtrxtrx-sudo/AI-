"""多层合并事务领域：来源版本、签核快照、依赖失效与中文校验。"""
from __future__ import annotations
import csv, hashlib, io, json, re
from pathlib import Path
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
try:
    from .store import DomainError
    from .legacy_engine import money, number, text
    from .consolidation import (BS, PL, CF, ASSETS, LIABILITIES, EQUITY, calculate_unit,
        validate_tree, collect_leaves, lowest_common_unit, validate_source, normalize_report, make_statement, num)
except ImportError:
    from store import DomainError
    from legacy_engine import money, number, text
    from consolidation import (BS, PL, CF, ASSETS, LIABILITIES, EQUITY, calculate_unit,
        validate_tree, collect_leaves, lowest_common_unit, validate_source, normalize_report, make_statement, num)

PRODUCT='SelfDevelopedEPM-ERP-Demo'
_legacy_money=money
def money(value,label='金额',negative=False,places=6):return _legacy_money(value,label,negative,places)
def number(value):return num(value)
ROLES=('集团财务负责人','法人会计','审计只读')
def now():return datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')
def calc(fn,*args,**kwargs):
    try:return fn(*args,**kwargs)
    except (ValueError,TypeError,KeyError) as ex:raise DomainError(str(ex)) from None

def find(rows,identifier,label):
    r=next((r for r in rows if r['id']==identifier),None)
    if r is None:raise DomainError(f'未找到{label}。')
    return r

def ident(v,label='编号'):
    v=text(v,label,40)
    if not re.fullmatch('[A-Z][A-Z0-9_-]{0,39}',v):raise DomainError(f'{label}须以大写字母开头，只含大写字母、数字、下划线和短横线。')
    return v

def unit_period(data,uid,month):
    return data.setdefault('unitPeriods',{}).setdefault(f'{uid}:{month}',{'activeResultId':None,'locked':False,'staleReason':''})

def ancestors(data,uid):
    tree=calc(validate_tree,data);parents=tree['parentByUnit'];out=[uid]
    while out[-1] in parents:out.append(parents[out[-1]])
    return out

def entity_units(data,eid):
    return {u for u,leaves in calc(validate_tree,data)['leafIdsByUnit'].items() if eid in leaves}

def assert_open(data,uids,month=None):
    names={u['id']:u['name'] for u in data['units']}
    for key,state in data.get('unitPeriods',{}).items():
        uid,period=key.rsplit(':',1)
        if uid in uids and (month is None or int(period)==month) and state.get('locked'):
            raise DomainError(f'{names.get(uid,uid)}{period}月已签核，请先由负责人在受影响的小合并单元执行“重新开启（含上级）”，再修改。','period_locked',409)

def invalidate(data,uids,month,reason,unlock=False):
    uids=set(uids)
    for r in data.get('results',[]):
        if r['unitId'] in uids and (month is None or r['month']==month):
            data.setdefault('resultValidity',{})[r['id']]={'valid':False,'reason':reason,'invalidatedAt':now()}
    for key,s in data.get('unitPeriods',{}).items():
        uid,period=key.rsplit(':',1)
        if uid in uids and (month is None or int(period)==month):
            s['staleReason']=reason
            if unlock:s['locked']=False


def project_result(data,row):
    if row is None:return None
    result=deepcopy(row['snapshot'])
    for k in ('id','unitId','month','version','createdAt','origin','approvalStatus','approvedAt','approvedBy','inputFingerprint','snapshotHash'):
        if k in row:result[k]=row[k]
    valid=data.get('resultValidity',{}).get(row['id'],{'valid':True})
    result.update(valid=valid.get('valid',True),staleReason=valid.get('reason',''),resultVersion=row['version'])
    result['status']=row['approvalStatus'] if result['valid'] else '已失效'
    return result


def current_result(data,uid,month):
    rid=unit_period(data,uid,month).get('activeResultId')
    row=next((r for r in data.get('results',[]) if r['id']==rid),None)
    return project_result(data,row)


def fingerprint(data,uid,month):
    tree=calc(validate_tree,data);leaves=set(tree['leafIdsByUnit'][uid]);scope={u for u in tree['leafIdsByUnit'] if u==uid or (set(tree['leafIdsByUnit'][u])<=leaves and uid in ancestors(data,u))}
    units={u['id']:u for u in data['units']};entities={e['id']:e for e in data['entities']}
    foreign=False
    for unit_id in scope:
        u=units[unit_id]
        if any((entities if m['type']=='entity' else units)[m['id']]['currency']!=u['currency'] for m in u['members']):foreign=True
    raw={'units':[units[x] for x in sorted(scope)],'entities':[entities[x] for x in sorted(leaves)],'sources':{x:data.get('sources',{}).get(str(month),{}).get(x) for x in sorted(leaves)},'eliminations':[e for e in data.get('eliminations',[]) if e['month']==month and e['unitId'] in scope],'ownership':[o for o in data.get('ownership',[]) if o.get('parent') in leaves and o.get('child') in leaves]}
    if foreign:raw['rates']=[r for r in data.get('fxRates',[]) if r['month']==month and r.get('active',True)]
    children={}
    for m in units[uid]['members']:
        if m['type']=='unit':
            r=current_result(data,m['id'],month)
            children[m['id']]={'id':r['id'],'version':r['version'],'valid':r['valid'],'status':r['approvalStatus']} if r else None
    raw['children']=children
    return hashlib.sha256(json.dumps(raw,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


def preconditions(data,uid,month):
    u=find(data['units'],uid,'合并单元');rows=[]
    try:validate_tree(data);rows.append({'code':'tree','label':'合并范围无重复和循环','passed':True,'message':'每个底层法人只纳入一次。'})
    except ValueError as ex:rows.append({'code':'tree','label':'合并范围','passed':False,'message':str(ex)});return rows
    for m in u['members']:
        if m['type']=='unit':
            r=current_result(data,m['id'],month);ok=bool(r and r['valid'] and r['approvalStatus']=='已签核')
            name=find(data['units'],m['id'],'下级单元')['name']
            rows.append({'code':'child_'+m['id'],'label':name+'已签核结果','passed':ok,'message':f'引用{r["id"]}版本{r["version"]}。' if ok else '须先计算并签核有效下级结果；预览和失效结果不能引用。'})
        else:
            e=find(data['entities'],m['id'],'法人');s=data.get('sources',{}).get(str(month),{}).get(m['id'])
            try:
                if not s:raise ValueError('缺少本期完整三表报送。')
                validate_source(data,m['id'],month,s);ok=True;message=f'本位币{e["currency"]}报送版本{s.get("version",1)}，三表勾稽通过。'
            except (ValueError,TypeError,KeyError) as ex:ok=False;message=str(ex)
            rows.append({'code':'source_'+m['id'],'label':e['name']+'报送','passed':ok,'message':message})
    draft=[e for e in data.get('eliminations',[]) if e['month']==month and e['unitId']==uid and e.get('status') not in ('已审批','已签核','已停用')]
    rows.append({'code':'eliminations','label':'本层抵销已审批','passed':not draft,'message':'所有本层抵销事项已审批。' if not draft else '存在草稿或来源失效抵销，请重新匹配、生成并审批后再计算。'})
    if data.get('erp'):
        try:from . import erp_domain
        except ImportError:import erp_domain
        rows.extend(erp_domain.precondition_rows(data,uid,month))
    return rows


def run(data,uid,month,origin='用户计算'):
    assert_open(data,{uid},month)
    bad=[r for r in preconditions(data,uid,month) if not r['passed']]
    if bad:raise DomainError('计算前置未通过：'+'；'.join(r['label']+'：'+r['message'] for r in bad),'incomplete_workflow',409)
    unit=find(data['units'],uid,'合并单元');children={m['id']:current_result(data,m['id'],month) for m in unit['members'] if m['type']=='unit'}
    snapshot=calc(calculate_unit,data,uid,month,children,False)
    snapshot['sourceSnapshots']={eid:deepcopy(data.get('sources',{}).get(str(month),{}).get(eid)) for eid in snapshot['leafIds']}
    snapshot['rateSnapshots']=deepcopy([r for r in data.get('fxRates',[]) if r['month']==month and r.get('active',True)])
    snapshot['unitSnapshots']=deepcopy([u for u in data['units'] if u['id'] in snapshot['dependencies'].get('units',{})])
    snapshot['eliminationSnapshots']=deepcopy([e for e in data['eliminations'] if e['id'] in snapshot['dependencies'].get('eliminations',{})])
    snapshot['ownershipSnapshot']=deepcopy(data.get('ownership',[]))
    snapshot['sourceInfo']={'product':PRODUCT,'schemaVersion':3,'engineVersion':'ERP-20261021','modelPolicyVersion':data.get('modelPolicy',{}).get('version'),'codeDigest':hashlib.sha256(b''.join((Path(__file__).resolve().parent/f).read_bytes() for f in ('engine.py','multilevel_domain.py','consolidation.py','multilevel_seed.py','erp_domain.py','ledger.py') if (Path(__file__).resolve().parent/f).is_file())).hexdigest()}
    if not snapshot['passed']:raise DomainError('合并三表勾稽未通过，请检查源报送与抵销。','financial_check',409)
    existing=[r for r in data.setdefault('results',[]) if r['unitId']==uid and r['month']==month];version=max((r['version'] for r in existing),default=0)+1
    rid=f'RES-{uid}-2026{month:02d}-V{version}'
    row={'id':rid,'unitId':uid,'month':month,'version':version,'origin':origin,'createdAt':now(),'approvalStatus':'已计算','approvedAt':None,'inputFingerprint':fingerprint(data,uid,month),'snapshot':deepcopy(snapshot),'snapshotHash':hashlib.sha256(json.dumps(snapshot,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()}
    # 新计算替换active指针，旧结果保留原快照，旧版不再作为有效引用。
    invalidate(data,ancestors(data,uid),month,'已生成新的结果版本，原引用需重新计算。')
    data['results'].append(row);data.setdefault('resultValidity',{})[rid]={'valid':True,'reason':''}
    unit_period(data,uid,month).update(activeResultId=rid,locked=False,staleReason='')
    return rid


def approve(data,rid,role='集团财务负责人'):
    row=find(data['results'],rid,'合并结果');uid=row['unitId'];month=row['month'];active=current_result(data,uid,month)
    if not active or active['id']!=rid or not active['valid']:raise DomainError('只能签核当前有效结果，请重新计算。','stale_result',409)
    if row['approvalStatus']!='已计算':raise DomainError('此结果已签核，不能重复签核。','invalid_state',409)
    if row['inputFingerprint']!=fingerprint(data,uid,month):raise DomainError('结果依赖已变化，请重新计算后签核。','stale_result',409)
    if not row['snapshot']['passed'] or any(not r['passed'] for r in preconditions(data,uid,month)):raise DomainError('校验或下级签核未通过，不能签核。','incomplete_workflow',409)
    row.update(approvalStatus='已签核',approvedAt=now(),approvedBy=role)
    unit_period(data,uid,month).update(locked=True,staleReason='')
    return f'签核结果{rid}，财务报表快照及依赖版本已保留。'


def sanitize_source(data,eid,month,raw):
    if not isinstance(raw,dict):raise DomainError('源报送必须为完整三表对象。')
    e=find(data['entities'],eid,'报送法人');old=data.get('sources',{}).get(str(month),{}).get(eid,{})
    allowed={'version','currency','status','sourceName','opening','closing','profit','cashflow','monthlyProfit','monthlyCashflow','capitalMovement','equityHistory'}
    if set(raw)-allowed:raise DomainError('源报送包含未支持的数据区。')
    out={'currency':e['currency'],'version':old.get('version',0)+1,'status':'已报送','sourceName':text(raw.get('sourceName','手工三表报送'),'报送来源',150)}
    if raw.get('currency',e['currency'])!=e['currency']:raise DomainError('报送币种必须与法人记账本位币一致。')
    for area,keys in [('opening',BS),('closing',BS),('profit',PL),('cashflow',CF)]:
        row=raw.get(area)
        if not isinstance(row,dict) or set(row)-set(keys) or set(keys)-set(row):raise DomainError(f'{area}必须包含模板全部项目，不能出现未知字段。')
        out[area]={k:number(money(row[k],area+' '+k,True)) for k in keys}
    for area,keys in [('monthlyProfit',PL),('monthlyCashflow',CF)]:
        rows=raw.get(area)
        if not isinstance(rows,dict) or set(rows)!={str(m) for m in range(1,month+1)}:raise DomainError(f'{area}必须完整填写1至{month}月发生额。')
        out[area]={}
        for m,row in rows.items():
            if not isinstance(row,dict) or set(row)!=set(keys):raise DomainError(f'{area}的{m}月项目与模板不符。')
            out[area][m]={k:number(money(row[k],m+'月'+k,True)) for k in keys}
    out['capitalMovement']=number(money(raw.get('capitalMovement',0),'资本变动',True))
    history=deepcopy(raw.get('equityHistory',old.get('equityHistory',{})))
    if not isinstance(history,dict) or set(history)-{'capitalByEntity','openingRetainedCny','dividendsByMonth'}:raise DomainError('历史权益资料格式无效。')
    cap=history.get('capitalByEntity',{eid:out['opening']['capital']})
    if not isinstance(cap,dict) or set(cap)!={eid} or money(cap[eid],'历史资本',True)!=Decimal(str(out['opening']['capital'])):raise DomainError('历史资本明细必须且仅属于当前法人，并等于其期初实收资本。')
    history['capitalByEntity']={eid:number(money(cap[eid],'历史资本',True))}
    if 'openingRetainedCny' in history:history['openingRetainedCny']=number(money(history['openingRetainedCny'],'已确认期初人民币留存收益',True))
    elif not out['opening']['retained']:history['openingRetainedCny']=0
    elif e['currency']=='USD':raise DomainError('美元法人期初留存收益非零，须填写已确认的期初人民币留存收益。')
    if history.get('dividendsByMonth',{}):raise DomainError('本轮全资演示暂不支持分红，请保持分红明细为空。')
    history['dividendsByMonth']={};out['equityHistory']=history
    calc(validate_source,data,eid,month,out)
    return out


def save_sources(data,month,raws):
    affected=set().union(*(entity_units(data,eid) for eid in raws))
    assert_open(data,affected,month)
    cleaned={eid:sanitize_source(data,eid,month,raw) for eid,raw in raws.items()}
    data.setdefault('sources',{}).setdefault(str(month),{}).update(cleaned)
    invalidate(data,affected,month,'法人报送已更新，需逐层重算并签核。')
    return f'保存{len(cleaned)}家法人本期完整三表源报送，关联合并结果已失效。'


def import_sources(data,p,c):
    raw=p.get('csv')
    if not isinstance(raw,str) or len(raw)>2_000_000:raise DomainError('CSV应为小于2MB的UTF-8文本。')
    reader=csv.DictReader(io.StringIO(raw.lstrip('\ufeff')));header=['法人编码','期间','数据区','项目编码','金额','月份']
    if reader.fieldnames!=header:raise DomainError('完整源CSV表头须为：'+','.join(header))
    fields={'opening':BS,'closing':BS,'profit':PL,'cashflow':CF,'monthlyProfit':PL,'monthlyCashflow':CF};groups={};seen=set()
    for n,row in enumerate(reader,2):
        if n>10002:raise DomainError('完整源CSV最多10000行。')
        if None in row or any(v is None for v in row.values()):raise DomainError(f'CSV第{n}行列数不符。')
        eid=next((e['id'] for e in data['entities'] if row['法人编码'] in (e['id'],e['code'])),None)
        if not eid:raise DomainError(f'CSV第{n}行法人编码不存在。')
        if row['期间']!=f'2026-{c["month"]:02d}':raise DomainError(f'CSV第{n}行期间与当前选择不一致。')
        area=row['数据区'];key=row['项目编码'];m=row['月份']
        if area not in fields or key not in fields[area]:raise DomainError(f'CSV第{n}行数据区或项目编码无效。')
        if area.startswith('monthly'):
            if m not in {str(x) for x in range(1,c['month']+1)}:raise DomainError(f'CSV第{n}行发生月份无效。')
        elif m!='':raise DomainError(f'CSV第{n}行累计数据区的月份应留空。')
        unique=(eid,area,key,m)
        if unique in seen:raise DomainError(f'CSV第{n}行法人/数据区/项目/月份重复。')
        seen.add(unique);s=groups.setdefault(eid,{a:{} for a in fields})
        target=s[area].setdefault(m,{}) if area.startswith('monthly') else s[area]
        target[key]=number(money(row['金额'],f'CSV第{n}行金额',True))
    if not groups:raise DomainError('CSV没有财务数据。')
    for s in groups.values():s['sourceName']=text(p.get('sourceName','完整财务源CSV'),'文件名称',150)
    detail=save_sources(data,c['month'],groups)
    data.setdefault('trialBalances',[]).append({'id':f'SRC-{len(data.get("trialBalances",[]))+1:03d}','month':c['month'],'importedAt':now(),'sourceName':p.get('sourceName','完整财务源CSV'),'entities':list(groups),'rowCount':len(seen)})
    return detail


def import_tb(data,p,c):
    raw=p.get('csv')
    if not isinstance(raw,str) or len(raw)>2_000_000:raise DomainError('CSV应为小于2MB的UTF-8文本。')
    reader=csv.DictReader(io.StringIO(raw.lstrip('\ufeff')))
    if reader.fieldnames!=['法人编码','期间','科目编码','借方余额','贷方余额']:raise DomainError('试算CSV表头须为：法人编码,期间,科目编码,借方余额,贷方余额；完整三表请用完整财务源CSV。')
    groups={};seen=set()
    for n,r in enumerate(reader,2):
        if n>10002:raise DomainError('试算CSV最多10000行。')
        if None in r or any(v is None for v in r.values()):raise DomainError(f'CSV第{n}行列数无效。')
        eid=next((e['id'] for e in data['entities'] if r['法人编码'] in (e['id'],e['code'])),None)
        if not eid:raise DomainError(f'CSV第{n}行法人不存在。')
        if r['期间']!=f'2026-{c["month"]:02d}':raise DomainError('试算期间与当前选择不一致。')
        a=next((a for a in data['accounts'] if a['code']==r['科目编码']),None)
        if not a:raise DomainError(f'CSV第{n}行科目未映射。')
        if (eid,a['code']) in seen:raise DomainError('同一法人科目不能重复。')
        seen.add((eid,a['code']));d=money(r['借方余额'],'借方余额');cr=money(r['贷方余额'],'贷方余额')
        if d and cr:raise DomainError('一行科目不能同时填写借贷余额。')
        g=groups.setdefault(eid,{'debit':Decimal(0),'credit':Decimal(0),'fields':{}});g['debit']+=d;g['credit']+=cr
        value=d-cr if a['normalSide']=='借' else cr-d;g['fields'][a['field']]=g['fields'].get(a['field'],Decimal(0))+value
    if not groups:raise DomainError('试算CSV没有数据。')
    sources={}
    for eid,g in groups.items():
        if g['debit']!=g['credit']:raise DomainError(f'{eid}试算借贷不平衡，整批未导入。')
        s=deepcopy(data.get('sources',{}).get(str(c['month']),{}).get(eid))
        if not s:raise DomainError('须先填写本期明确的期初数及现金流报送，或使用完整财务源CSV模板；不能从现金差额估算经营现金流。')
        s['profit']={k:number(g['fields'].get(k,Decimal(0))) for k in PL};s['closing']={k:number(g['fields'].get(k,Decimal(0))) for k in BS}
        net=Decimal(str(s['profit']['revenue']))-sum((Decimal(str(s['profit'][k])) for k in PL[1:]),Decimal(0))
        s['closing']['retained']=number(Decimal(str(s['closing']['retained']))+net)
        s['monthlyProfit'][str(c['month'])]={k:number(Decimal(str(s['profit'][k]))-sum((Decimal(str(row[k])) for m,row in s['monthlyProfit'].items() if int(m)<c['month']),Decimal(0))) for k in PL}
        s['sourceName']=text(p.get('sourceName','试算CSV'),'文件名称',150);sources[eid]=s
    try:detail=save_sources(data,c['month'],sources)
    except DomainError as ex:raise DomainError(ex.message+' 试算导入保留明确现金流源，不自动倒挤；请改用完整财务源模板同步现金流。') from None
    data.setdefault('trialBalances',[]).append({'id':f'TB-{len(data.get("trialBalances",[]))+1:03d}','month':c['month'],'rowCount':len(seen),'entities':list(sources),'sourceName':p.get('sourceName','试算CSV'),'importedAt':now()})
    return detail


def validate_ownership(data):
    entities={e['id']:e for e in data['entities']};edges={}
    for o in data.get('ownership',[]):
        p=o.get('parent');ch=o.get('child')
        if p not in entities or ch not in entities or p==ch:raise DomainError('持股母子法人无效。')
        if money(o.get('percent'),'持股比例')!=100:raise DomainError('本轮仅支持100%全资全额合并。')
        if ch in edges:raise DomainError('本轮一个法人只能有一个直接母公司。')
        edges[ch]=p
    for ch in edges:
        path=set();node=ch
        while node in edges:
            if node in path:raise DomainError('实际持股关系存在循环。')
            path.add(node);node=edges[node]


def apply(data,role,action,p,c):
    if role not in ROLES or role=='审计只读':raise DomainError('当前为审计只读角色，不能修改数据。','forbidden',403)
    manager=role==ROLES[0]
    manager_actions={'entity_save','ownership_save','unit_save','rate_set_save','elimination_approve','elimination_cancel','result_approve','unit_reopen','settings_save','account_save'}
    if action in manager_actions and not manager:raise DomainError('此操作需要集团财务负责人权限。','forbidden',403)
    uid=p.get('unitId',c['group']);month=c['month']
    if action=='consolidation_run':
        rid=run(data,uid,month);return f'计算完成，生成不可覆盖的新结果{rid}。'
    if action=='result_approve':return approve(data,p.get('resultId'),role)
    if action=='unit_reopen':
        find(data['units'],uid,'合并单元');reason=text(p.get('reason'),'重新开启原因',500)
        if p.get('cascade',True) is not True:raise DomainError('多层重开须同时使依赖祖先失效，请设置cascade=true。')
        affected=ancestors(data,uid);invalidate(data,affected,month,'重新开启：'+reason,True)
        for x in affected:unit_period(data,x,month).update(locked=False,reopenedAt=now(),reopenReason=reason)
        return '重新开启并保留历史版本：'+' → '.join(find(data['units'],x,'单元')['name'] for x in affected)+'；原因：'+reason
    if action=='source_save':return save_sources(data,month,{p.get('entityId'):p.get('source')})
    if action=='source_import':return import_sources(data,p,c)
    if action=='tb_import':return import_tb(data,p,c)
    if action=='unit_save':
        uid=ident(p.get('id'),'合并单元编号');old=next((u for u in data['units'] if u['id']==uid),None);affected=set(ancestors(data,uid)) if old else set()
        assert_open(data,affected)
        currency=p.get('currency');members=p.get('members')
        if currency not in ('CNY','USD') or not isinstance(members,list) or not members or len(members)>200:raise DomainError('单元币种须为CNY/USD，成员须为非空清单。')
        clean=[]
        for m in members:
            if not isinstance(m,dict) or set(m)!={'type','id'} or m['type'] not in ('entity','unit'):raise DomainError('成员格式应为type、id，类型为entity或unit。')
            clean.append({'type':m['type'],'id':ident(m['id'],'成员编号')})
        new={'id':uid,'name':text(p.get('name'),'单元名称',100),'currency':currency,'members':clean,'version':old.get('version',1)+1 if old else 1}
        temp=deepcopy(data);temp['units']=[new if u['id']==uid else u for u in temp['units']] if old else temp['units']+[new];calc(validate_tree,temp)
        # 改动范围不能使已有抵销落在错误层级。
        for e in temp.get('eliminations',[]):
            if e['kind']=='sales' and e.get('status')!='已停用' and calc(lowest_common_unit,temp,e['sellerId'],e['buyerId'])!=e['unitId']:raise DomainError('成员变更使已有内部销售抵销不在最低共同层；请先调整相关抵销事项。')
        affected|=set(ancestors(temp,uid));assert_open(data,affected);data['units']=temp['units'];invalidate(data,affected,None,'合并单元成员或币种配置已变更。')
        return f'保存合并单元{new["name"]}；管理范围与实际持股关系独立。'
    if action in ('entity_save','ownership_save'):
        if action=='entity_save':
            eid=ident(p.get('id'),'法人编号');old=next((e for e in data['entities'] if e['id']==eid),None);affected=entity_units(data,eid) if old else set();assert_open(data,affected)
            currency=p.get('currency',old.get('currency') if old else None)
            if currency not in ('CNY','USD'):raise DomainError('法人记账本位币仅支持CNY或USD。')
            if old and currency!=old['currency'] and any(eid in rows for rows in data['sources'].values()):raise DomainError('已有财务报送的法人不能直接更改本位币；请新建法人，避免历史数据被重标币种。')
            new={'id':eid,'code':text(p.get('code',old.get('code') if old else ''),'法人编码',30),'name':text(p.get('name'),'法人名称',100),'short':text(p.get('short',p.get('name')),'法人简称',100),'owner':text(p.get('owner','演示财务负责人'),'报送负责人',100),'currency':currency,'currencyCode':currency,'parentId':p.get('parentId',old.get('parentId') if old else None),'ownershipPercent':100,'version':old.get('version',1)+1 if old else 1,'enabled':True}
            if any(e['code']==new['code'] and e['id']!=eid for e in data['entities']):raise DomainError('法人编码重复。')
            temp=deepcopy(data);temp['entities']=[new if e['id']==eid else e for e in temp['entities']] if old else temp['entities']+[new]
        else:
            eid=p.get('entityId');old=find(data['entities'],eid,'法人');affected=entity_units(data,eid);assert_open(data,affected);temp=deepcopy(data)
            new=find(temp['entities'],eid,'法人');new['parentId']=p.get('parentId');new['ownershipPercent']=100;new['version']+=1
        percent=p.get('percent',100)
        if money(percent,'持股比例')!=100 or p.get('method','全额合并')!='全额合并':raise DomainError('本轮仅支持100%全资全额合并。')
        temp['ownership']=[o for o in temp.get('ownership',[]) if o['child']!=eid]
        if new['parentId']:temp['ownership'].append({'parent':new['parentId'],'child':eid,'percent':100,'method':'全额合并','effectiveFrom':'2026-01-01'})
        validate_ownership(temp);calc(validate_tree,temp);data['entities']=temp['entities'];data['ownership']=temp['ownership'];invalidate(data,affected,None,'法人或实际持股关系已变更。')
        data['budget']['entityRatios'].setdefault(eid,0);data['budget']['entityRevenueRatios'].setdefault(eid,0)
        return f'保存法人及真实持股关系：{new["name"]}。'
    if action=='rate_set_save':
        if p.get('sourceCurrency','USD')!='USD' or p.get('targetCurrency','CNY')!='CNY':raise DomainError('本轮分类折算仅支持USD→CNY。')
        row={'month':month,'sourceCurrency':'USD','targetCurrency':'CNY','status':'已审批','active':True}
        for k in ('opening','closing','historicalCapital'):
            v=money(p.get(k),'分类汇率',places=6)
            if v<=0 or v>1000000:raise DomainError('汇率须大于零且不超过1000000。')
            row[k]=float(v)
        for k in ('averages','flowRates'):
            raw=p.get(k)
            if not isinstance(raw,dict) or set(raw)!={str(m) for m in range(1,month+1)}:raise DomainError(f'须完整填写1至{month}月的损益平均和现金流汇率。')
            row[k]={}
            for m,v in raw.items():
                r=money(v,m+'月汇率',places=6)
                if r<=0 or r>1000000:raise DomainError('逐月汇率须大于零且不超过1000000。')
                row[k][m]=float(r)
        old=[r for r in data['fxRates'] if r['month']==month];version=max((r.get('version',1) for r in old),default=0)+1;row.update(id=f'FX-USD-CNY-2026-{month:02d}-V{version}',version=version,createdAt=now())
        # 历史汇率金额永不覆盖，仅切换激活标记；只有实际使用外币转换的结果失效。
        affected=set()
        for r in data['results']:
            if r['month']==month and r['snapshot'].get('trace',{}).get('fx'):affected.update(ancestors(data,r['unitId']))
        for r in old:r['active']=False
        data['fxRates'].append(row);invalidate(data,affected,month,'分类汇率启用新版本，需重新计算受影响层级。',True)
        return f'启用分类汇率版本{version}，历史汇率及结果保留；美元原币小合并不受影响。'
    if action=='elimination_save':
        uid=p.get('unitId',c['group']);unit=find(data['units'],uid,'合并单元');affected=ancestors(data,uid);old=next((e for e in data['eliminations'] if e['id']==p.get('id')),None)
        if old and (old['month']!=month or old['unitId']!=uid):raise DomainError('不能将已有抵销跨期间或跨单元移动。')
        assert_open(data,affected,month);kind={'内部销售':'sales','投资权益':'investment','sales':'sales','investment':'investment'}.get(p.get('kind'))
        if kind not in ('sales','investment'):raise DomainError('本轮仅支持已结算内部销售、期初全资投资权益抵销。')
        source_id=text(p.get('sourceId'),'抵销来源编号',100)
        if any(e['month']==month and e['sourceId']==source_id and e is not old for e in data['eliminations']):raise DomainError('同一抵销来源不能重复配置或跨层二次抵销。')
        amount=number(money(p.get('amount'),'抵销金额'))
        if amount<=0:raise DomainError('抵销金额须大于零。')
        if p.get('currency')!=unit['currency']:raise DomainError('抵销币种须与本层合并报表币种一致。')
        row={'id':old['id'] if old else f'ELIM-{len(data["eliminations"])+1:04d}','sourceId':source_id,'unitId':uid,'month':month,'kind':kind,'status':'草稿','version':old.get('version',1)+1 if old else 1,'currency':unit['currency'],'amount':amount,'sellerId':p.get('sellerId'),'buyerId':p.get('buyerId'),'title':'内部销售抵销' if kind=='sales' else '期初全资投资权益抵销','reason':text(p.get('reason','用户维护的演示抵销'),'抵销说明',500),'openingEffects':{},'effects':{}}
        if kind=='sales':
            if calc(lowest_common_unit,data,row['sellerId'],row['buyerId'])!=uid:raise DomainError('内部销售必须在交易双方最低共同合并层处理。')
            row['effects']={'revenue':-amount,'cost':-amount}
            schedule=p.get('monthlyAmounts')
            if schedule is None:schedule={str(m):amount if m==month else 0 for m in range(1,month+1)}
            if not isinstance(schedule,dict) or set(schedule)!={str(m) for m in range(1,month+1)}:raise DomainError('内部销售须完整填写1至当前月的发生金额分配。')
            schedule={m:number(money(v,m+'月内部销售抵销金额')) for m,v in schedule.items()}
            if sum((Decimal(str(v)) for v in schedule.values()),Decimal(0))!=Decimal(str(amount)):raise DomainError('逐月抵销金额合计必须等于本事项累计金额。')
            row['monthlyAmounts']=schedule;row['monthlyEffects']={m:{'revenue':-v,'cost':-v} for m,v in schedule.items()}
            row['reason'] += '；发生口径：逐月明细分配。' if p.get('monthlyAmounts') is not None else '；发生口径：本事项全部发生在当前月。'
        else:
            leaves=set(calc(collect_leaves,data,uid));pairs=[];rates=[r for r in data['fxRates'] if r['month']==month and r.get('active',True)]
            for o in data['ownership']:
                if o['parent'] in leaves and o['child'] in leaves:
                    s=data['sources'].get(str(month),{}).get(o['child'])
                    if not s:raise DomainError('投资抵销子法人缺少本期报送。')
                    currency=find(data['entities'],o['child'],'法人')['currency'];cap=Decimal(str(s['opening']['capital']));rr=Decimal(1)
                    if currency!=unit['currency']:
                        if currency!='USD' or unit['currency']!='CNY' or len(rates)!=1:raise DomainError('投资抵销缺少适用的历史资本汇率。')
                        rr=Decimal(str(rates[0].get('capitalRates',{}).get(o['child'],rates[0]['historicalCapital'])))
                    pairs.append({'parentId':o['parent'],'childId':o['child'],'investment':number(cap*rr),'capital':number(cap),'currency':currency})
            if not pairs or sum((Decimal(str(x['investment'])) for x in pairs),Decimal(0))!=Decimal(str(amount)):raise DomainError('投资抵销金额必须等于本层真实全资子公司的期初历史资本合计；本轮不支持商誉或收购差额。')
            row['investmentPairs']=pairs;row['effects']={'investment':-amount,'capital':-amount};row['openingEffects']=dict(row['effects'])
        data['eliminations']=[row if e is old else e for e in data['eliminations']] if old else data['eliminations']+[row];invalidate(data,affected,month,'抵销配置已变更，需审批并重算。')
        return f'保存抵销草稿{row["id"]}。'
    if action=='elimination_cancel':
        row=find(data['eliminations'],p.get('id'),'抵销事项')
        if row['month']!=month:raise DomainError('抵销期间与当前选择不一致。')
        affected=ancestors(data,row['unitId']);assert_open(data,affected,month)
        if row['status']=='已停用':raise DomainError('此事项已停用。','invalid_state',409)
        row.update(status='已停用',version=row.get('version',1)+1,cancelReason=text(p.get('reason'),'停用原因',500),cancelledAt=now())
        invalidate(data,affected,month,'抵销已停用，需重新计算。');return f'停用抵销{row["id"]}，历史结果仍保留原抵销快照。'
    if action=='elimination_approve':
        row=find(data['eliminations'],p.get('id'),'抵销事项')
        if row['month']!=month:raise DomainError('抵销期间与当前选择不一致。')
        affected=ancestors(data,row['unitId']);assert_open(data,affected,month)
        if row['status']!='草稿':raise DomainError('仅草稿抵销可审批。','invalid_state',409)
        row['status']='已审批';row['version']=row.get('version',1)+1
        check=calc(calculate_unit,data,row['unitId'],month,None,True)
        if not check['passed']:raise DomainError('该抵销导致三表勾稽不平衡，不能审批。')
        invalidate(data,affected,month,'抵销已审批，需重新计算。');return f'审批抵销{row["id"]}。'
    if action=='commentary_save':
        find(data['units'],uid,'合并单元');data.setdefault('commentaries',{})[f'{uid}:{month}']={'text':text(p.get('text'),'经营分析说明',3000),'updatedAt':now(),'role':role};return '保存本单元经营分析说明。'
    if action=='settings_save':
        year=p.get('fiscalYear',2026)
        if isinstance(year,bool) or year!=2026:raise DomainError('本演示账套固定2026年度，不能重标历史报表。')
        name=text(p.get('companyName',data['companyName']),'公司名称',100);data['companyName']=name;data['settings']['companyName']=name;return '保存集团系统设置。'
    if action=='account_save':
        assert_open(data,{u['id'] for u in data['units']});code=text(p.get('code'),'科目编码',20);field=p.get('field');typ=p.get('type');side=p.get('normalSide')
        if not re.fullmatch('[0-9A-Za-z_-]{1,20}',code) or field not in BS+PL or typ not in ('资产','负债','权益','收入','成本','费用','税费') or side not in ('借','贷'):raise DomainError('科目编码、报表字段、类别或借贷方向无效。')
        row={'code':code,'name':text(p.get('name'),'科目名称',100),'field':field,'type':typ,'normalSide':side};old=next((a for a in data['accounts'] if a['code']==code),None)
        if old:old.update(row)
        else:data['accounts'].append(row)
        invalidate(data,{u['id'] for u in data['units']},None,'科目映射已变更。');return '保存集团科目映射。'
    raise DomainError('此旧版财务操作不适用于多层结果版本体系，请使用报送、抵销审批、逐层计算、结果签核或重新开启。','unsupported_action',404)
