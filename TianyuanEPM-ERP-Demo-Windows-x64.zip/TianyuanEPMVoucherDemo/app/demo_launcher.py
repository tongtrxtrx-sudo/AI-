"""Private, dependency-free process manager for Tianyuan EPM Demo.

Only binds to an existing backend via its random process identity and creation
time, never by PID alone. Credentials are kept in the user's data directory;
no token is printed in console output, diagnostics, or release evidence.
"""
from __future__ import annotations

import argparse
import ctypes
import json
import logging
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit
import webbrowser


PRODUCT = "SelfDevelopedEPM-ERP-Demo"
ROOT = Path(__file__).resolve().parents[1]
LOG = logging.getLogger("天元EPM启动器")


class ChineseParser(argparse.ArgumentParser):
    def error(self, message):
        raise RuntimeError("启动参数无效，请使用 --help 查看可用参数。")

    def format_help(self):
        return super().format_help().replace("usage:", "用法：")


def process_identity(pid: int) -> str | None:
    """Get a process creation identity without terminating or signaling it."""
    if not isinstance(pid, int) or pid <= 0:
        return None
    if os.name == "nt":
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        kernel.GetProcessTimes.restype = wintypes.BOOL
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.GetExitCodeProcess.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return None
        try:
            code = wintypes.DWORD()
            if not kernel.GetExitCodeProcess(handle, ctypes.byref(code)) or code.value != 259:
                return None
            created, exited, system, user = (wintypes.FILETIME() for _ in range(4))
            if not kernel.GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(exited),
                                          ctypes.byref(system), ctypes.byref(user)):
                return None
            return str((created.dwHighDateTime << 32) | created.dwLowDateTime)
        finally:
            kernel.CloseHandle(handle)
    try:
        # Linux development is supported, with the same PID reuse protection.
        return Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
    except (OSError, IndexError):
        return None


class DataLock:
    def __init__(self, path: Path):
        self.file = path.open("a+b")
        self.file.seek(0, os.SEEK_END)
        if self.file.tell() == 0:
            self.file.write(b"0")
            self.file.flush()
        self.file.seek(0)
        self.held = False

    def acquire(self) -> bool:
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.held = True
            return True
        except OSError:
            return False

    def close(self):
        if self.held:
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_UN)
        self.file.close()


def request_json(url: str, *, token: str | None = None) -> dict:
    headers = {"Accept": "application/json"}
    if token is not None:
        headers["X-EPM-Token"] = token
    request = urllib.request.Request(url, data=b"{}" if token is not None else None,
                                     headers=headers, method="POST" if token is not None else "GET")
    # System proxy configuration must never receive a local startup credential.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request, timeout=2) as response:
        result = json.load(response)
        if not isinstance(result, dict):
            raise ValueError("无效的本机响应")
        return result


def verify_live(data: dict) -> bool:
    try:
        port = data["port"]
        if not isinstance(port, int) or not 1 <= port <= 65535:
            return False
        if process_identity(data["backendPid"]) != data["backendCreated"]:
            return False
        health = request_json(f"http://127.0.0.1:{port}/api/health")
        if (health.get("ready") is True and health.get("product") == PRODUCT
                and health.get("instanceId") == data["instanceId"]
                and isinstance(data.get("token"), str) and len(data["token"]) >= 24):
            return True
    except (OSError, ValueError, TypeError, KeyError, urllib.error.URLError):
        pass
    return False


def load_live(path: Path) -> dict | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if verify_live(data):
            return data
    except (OSError, ValueError, TypeError):
        pass
    return None


def atomic_json(path: Path, data: dict):
    temp = path.with_suffix(".tmp")
    with temp.open("w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False)
        file.flush()
        os.fsync(file.fileno())
    try:
        temp.chmod(0o600)
    except OSError:
        pass
    temp.replace(path)


def open_browser(instance: dict):
    url = f"http://127.0.0.1:{instance['port']}/#token={instance['token']}"
    if not webbrowser.open(url):
        raise RuntimeError("浏览器未能自动打开。请再次双击“天元EPM 凭证合并Demo.exe”打开平台。")


def show_error(message: str, gui: bool):
    if gui and os.name == "nt":
        ctypes.windll.user32.MessageBoxW(None, message, "天元 EPM 凭证合并 · 启动提示", 0x10)
    elif sys.stderr is not None:
        print(message, file=sys.stderr)


def emit(**data):
    if sys.stdout is not None:
        print(json.dumps(data, ensure_ascii=False), flush=True)


def stop_instance(instance: dict):
    request_json(f"http://127.0.0.1:{instance['port']}/api/shutdown", token=instance["token"])
    for _ in range(100):
        if process_identity(instance["backendPid"]) != instance["backendCreated"]:
            return
        time.sleep(0.1)
    raise RuntimeError("平台正在保存并退出，请稍后重试。未强制终止数据进程。")


def main() -> int:
    parser = ChineseParser(description="天元 EPM 凭证合并演示平台：无需另行安装运行环境。", add_help=False)
    parser.add_argument("-h", "--help", action="help", help="显示参数帮助并退出")
    parser._optionals.title = "可选参数"
    parser.add_argument("--data-dir", type=Path, help="独立的数据目录，默认使用当前用户的本地应用数据文件夹")
    parser.add_argument("--port", type=int, default=0, help="本机端口，默认自动选择空闲端口")
    parser.add_argument("--no-browser", action="store_true", help="启动服务但不自动打开浏览器")
    parser.add_argument("--status", action="store_true", help="输出不含登录凭据的运行状态")
    parser.add_argument("--stop", action="store_true", help="保存数据并安全停止当前演示平台")
    parser.add_argument("--open-data", action="store_true", help="打开数据和日志所在文件夹")
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        raise RuntimeError("端口必须在 0 至 65535 之间。")
    base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local" / "share")))
    data_dir = (args.data_dir or base / "TianyuanEPMVoucherDemo").resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    logs = data_dir / "logs"
    logs.mkdir(exist_ok=True)
    logging.basicConfig(filename=logs / "launcher.log", encoding="utf-8", level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    instance_file = data_dir / "instance.json"
    if args.open_data:
        if os.name == "nt":
            os.startfile(str(data_dir))
        emit(成功=True, 数据目录=str(data_dir), 日志目录=str(logs))
        return 0
    if args.status or args.stop:
        current = load_live(instance_file)
        if current and args.stop:
            stop_instance(current)
        emit(成功=True, 运行中=bool(current and not args.stop),
             端口=current["port"] if current else None, 数据目录=str(data_dir), 日志目录=str(logs))
        return 0

    lock = DataLock(data_dir / "launcher.lock")
    acquired = lock.acquire()
    try:
        for _ in range(150 if not acquired else 1):
            current = load_live(instance_file)
            if current:
                if not args.no_browser:
                    open_browser(current)
                emit(成功=True, 已复用=True, 端口=current["port"], 数据目录=str(data_dir))
                return 0
            if not acquired:
                time.sleep(0.2)
        if not acquired:
            raise RuntimeError("平台仍在启动，请稍后再次双击。若持续未完成，请查看日志。")
        server = ROOT / "backend" / "server.py"
        web = ROOT / "frontend"
        if not server.is_file() or not (web / "index.html").is_file():
            raise RuntimeError("运行包缺少平台文件。请完整解压后，再从解压目录启动。")
        interpreter = ROOT / "python" / ("python.exe" if os.name == "nt" else "python3")
        if not interpreter.is_file() and os.name != "nt":
            interpreter = Path(sys.executable)
        command = [str(interpreter), "-I", "-X", "utf8", str(server),
                   "--data-dir", str(data_dir), "--port", str(args.port), "--no-browser",
                   "--static-dir", str(web)]
        LOG.info("正在启动本机平台；数据目录：%s", data_dir)
        with (logs / "backend.log").open("a", encoding="utf-8") as error_log:
            child = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                                     stdout=subprocess.PIPE, stderr=error_log,
                                     encoding="utf-8", errors="replace",
                                     creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            events = queue.Queue()
            def read_output():
                for line in child.stdout:
                    try:
                        event = json.loads(line)
                        if isinstance(event, dict) and event.get("ready") is True:
                            events.put(event)
                    except ValueError:
                        pass  # Never log raw output that may contain credentials.
                events.put(None)
            threading.Thread(target=read_output, daemon=True).start()
            try:
                ready = events.get(timeout=60)
            except queue.Empty:
                raise RuntimeError("平台启动超过一分钟。请查看 logs\\backend.log；未强制关闭数据进程。")
            if ready is None or child.poll() is not None:
                raise RuntimeError("平台启动失败，请查看数据目录中的 logs\\backend.log。")
            split = urlsplit(ready.get("url", ""))
            if split.hostname != "127.0.0.1" or split.scheme != "http" or split.port != ready.get("port"):
                raise RuntimeError("本机平台返回了无效的启动地址。")
            identity = process_identity(child.pid)
            if not identity:
                raise RuntimeError("无法校验本机服务的进程身份，请查看日志。")
            record = {"version": 1, "port": ready["port"], "token": ready["token"],
                      "instanceId": ready["instanceId"], "backendPid": child.pid,
                      "backendCreated": identity, "launcherPid": os.getpid()}
            for _ in range(30):
                if verify_live(record):
                    break
                if child.poll() is not None:
                    break
                time.sleep(.1)
            else:
                raise RuntimeError("本机服务身份检查未通过，请查看日志。")
            if child.poll() is not None:
                raise RuntimeError("平台在准备就绪前已退出，请查看日志。")
            # Publish only after self-verification. A client may immediately
            # request safe shutdown as soon as this file becomes visible.
            atomic_json(instance_file, record)
            LOG.info("平台启动完成；本机端口：%s；关闭浏览器不会停止服务。", ready["port"])
            emit(成功=True, 已复用=False, 端口=ready["port"], 数据目录=str(data_dir), 日志目录=str(logs))
            if not args.no_browser:
                def launch_browser():
                    try:
                        open_browser(record)
                    except RuntimeError as exc:
                        show_error(str(exc), gui=True)
                threading.Thread(target=launch_browser, daemon=True).start()
            code = child.wait()
            try:
                saved = json.loads(instance_file.read_text(encoding="utf-8"))
                if saved.get("instanceId") == record["instanceId"]:
                    instance_file.unlink(missing_ok=True)
            except (OSError, ValueError):
                pass
            LOG.info("平台已退出；数据已保留；进程退出码：%s。", code)
            return code
    finally:
        lock.close()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, OSError, KeyError, ValueError, urllib.error.URLError) as exc:
        # Keep OS exception details out of the UI; data paths are in the log.
        message = str(exc) if isinstance(exc, RuntimeError) else "本机平台未能完成操作，请查看数据目录内的日志。"
        LOG.error("启动器未完成操作：%s", message)
        show_error(message, gui=len(sys.argv) == 1)
        raise SystemExit(1)
