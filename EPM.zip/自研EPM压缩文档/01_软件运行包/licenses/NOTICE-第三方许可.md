# 第三方归属与授权边界

- Konsolidat: https://github.com/grynn-in/konsolidat ，MIT 原文见 Konsolidat-MIT.txt。
- Konsol: https://github.com/grynn-in/konsol ，本包固定提交未发现仓库级 LICENSE。仅公开源码不自动等同于许可商业再分发；商业二次开发/分发前应向原权利人确认授权。源码作者信息原样保留。
- Frappe Framework: https://github.com/frappe/frappe ，MIT 原文见 Frappe-MIT.txt；完整源码归档保留其所有内含第三方版权/授权文件。
- CPython 3.12.10: 官方 NuGet 包 python；PSF 与附带第三方许可见 CPython-3.12.10.txt 与 python/LICENSE.txt。
- 本包的启动器和部署适配代码为交付中新增；公开源组件不因压缩包命名为“自研”而改变其原归属。
- Docker Desktop 需要用户单独安装，是否符合免费使用条件由 Docker 许可决定。本包未重新分发 Docker Desktop。
- MariaDB、Redis、ClickHouse、Cube、Caddy、Node 等镜像在首次启动联网下载，受各自许可证约束；构建时的 Python/npm 依赖亦保留各自授权。
