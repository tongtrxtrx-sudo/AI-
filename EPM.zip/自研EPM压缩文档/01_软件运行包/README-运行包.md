# 自研 EPM 运行包

本包以固定版本的 Konsolidat/Konsol 为研发底座，提供 Windows x64 EXE 启动入口。EXE 调用包内私有 CPython 控制 Docker；电脑不需要另装 Python。完整 EPM 在 Docker Linux 容器中运行，浏览器打开操作界面。它不是一个脱离 Docker 的单文件财务软件，也不等同于已完成中国会计准则适配和集团正式验收的自研成品。

## 使用前提

- Windows 10/11 64 位，启用硬件虚拟化、WSL2。
- 安装并启动 Docker Desktop，选择 Linux containers。Docker Desktop 自身许可按 Docker 官方条款执行。
- Docker 可用资源至少 4 CPU、8 GB 内存，建议 16 GB；Docker 数据磁盘至少留 30 GB。
- 首次构建须联网访问 Docker Hub、Debian、PyPI、npm/Yarn 与 GitHub；Office 插件功能还会访问 Microsoft Office.js。
- 将压缩包完整解压，建议路径 `C:\EPM`。不要从压缩包预览中运行 EXE，不要只移动 EXE；保留 python、app、platform 等配套目录。

## 双击操作

双击 `自研EPM.exe`，依次选择 `1 前提检查`、`2 初始化/启动`。首次会下载依赖并构建镜像，不是双击后立即离线可用。构建中出现错误会停止该流程，不会提示平台已全部就绪。

菜单 `4` 打开 http://localhost:18080/login ，用户为 `Administrator`。密码在首次启动时本机随机生成，由菜单 `6` 打开 `data/login-info.txt` 查看。完整密钥位于 `data/.env`，交付压缩包不包含任何预置真实密码。

菜单 `5` 停止服务并保留数据；菜单 `0` 只退出启动器，后台 Docker 服务继续运行。菜单 `7` 暂停应用写入后导出 MariaDB、ClickHouse 结构/数据与 Frappe sites 文件至 `data/backups`，再恢复此前运行的应用服务；不自动删除旧备份。没有 `BACKUP_COMPLETE.txt` 的目录视为未成功备份。恢复必须先在隔离环境演练，不提供覆盖现有财务数据库的一键恢复。

命令行也可运行：

```powershell
.\自研EPM.exe check
.\自研EPM.exe start
.\自研EPM.exe status
.\自研EPM.exe backup
.\自研EPM.exe stop
```

## 本机资源与目录

| 内容 | 路径或地址 |
|---|---|
| 网页入口 | http://localhost:18080/login |
| Frappe 直连 | http://localhost:18069 |
| Cube.js | http://localhost:14000，默认关闭开发模式 |
| ClickHouse HTTP/native | 127.0.0.1:18123 / 19000 |
| Excel ODBC | 127.0.0.1:15432 |
| Docker 项目 | epmdev，停止操作只影响本项目 |
| 运行日志 | data/logs |
| 本机配置/登录信息 | data/.env 与 data/login-info.txt |
| 本机备份 | data/backups |
| MariaDB、ClickHouse、Frappe 数据 | Docker 管理的 epmdev_* 数据卷；不在 EXE 旁的数据文件夹里 |
| 原始源码 | source/konsolidat、source/konsol |
| 部署副本 | platform，Dockerfile 等部署适配见 build/deployment-changes.patch |
| 固定版本与依赖来源 | SOURCE-VERSIONS.json |

所有公开端口只绑定 127.0.0.1，用于本机开发。对外生产部署需要单独设计域名、HTTPS、网络、身份认证、备份恢复和权限方案。不要执行 `docker compose down -v`、Docker 工厂重置或删除 `epmdev_*` 卷来排查启动问题，这些操作会丢失数据。

## 上游部署适配说明

原始源码保持原样。部署副本消除固定容器/网络名冲突，以项目名管理容器；对外端口改为本机回环；固定 Frappe 源码与 Bench/Node/Yarn/dbt 版本；将已有源码在镜像内初始化为本地 Git 仓库，电脑不需安装 Git；不打印密码到日志；严格执行基础设施、镜像、迁移、应用、汇率校验、dbt 构建顺序。EXE/本地启动器代码和构建源码也包含在包内。

上游 Dockerfile 通过外部 wkhtmltopdf 安装包构建；本部署副本使用 Debian Cairo/Pango 依赖和 Frappe 自带 WeasyPrint 依赖，未安装 wkhtmltopdf。需要 wkhtmltopdf 的特定 PDF 模板或打印流程应另行安装受信任版本并验收，不能假设所有 PDF 导出功能已验证。

本机可选 `data/compose.extra.json` 为企业代理、证书等提供 Compose 叠加配置；它不随本交付包提供。请勿将企业代理凭据写入 source 或提交版本库。TLS、包签名与锁文件完整性检查不应关闭。

## 开源与验收边界

Konsolidat 的 MIT 授权原文保存在 licenses；Frappe 与 CPython 授权亦保留。固定版本 Konsol 仓库未发现仓库级 LICENSE，不能将 Konsolidat 的 MIT 自动视为覆盖 Konsol。自有商业产品或对外再分发前须向该权利人确认授权，并保留所有上游归属和第三方许可。

真实验证状态以同包《运行验证说明》为准。Windows EXE 已交叉编译为原生 PE x64，当前云机不能替代 Windows 实机验证；业务计算正确性、中文界面完整性、Excel 插件、ERP 接口与中国会计准则均需专项验收。

请使用本包 EXE/`app/desktop_launcher.py` 作为本机部署入口。`source` 和 `platform` 中保留的上游 `deploy.sh` 用于阅读溯源；它假设原端口和固定容器名称，且会在部分步骤输出密码，不能代替本交付入口直接运行。不要在已有财务数据上混用上游脚本与本机运行包。

Frappe 与 dbt 使用独立 Python 虚拟环境以防依赖冲突；应用调用的 `env/bin/dbt` 链接到专用 dbt 环境。构建会执行两个环境的 `pip check`，任一失败即停止。Konsol 安装阶段对 requests 的无上限升级会被恢复到固定 Frappe 的原始依赖声明 `~=2.33.0`，不修改原仓库依赖声明。

同一台电脑上的运行包副本共用 epmdev 项目；启动器会核对 Docker 项目的创建目录，不允许另一个解压位置直接接管现有实例。请保留首次运行的目录，移动目录、迁移数据或建立第二套实例要先按运维方案处理，不要通过修改项目名来猜测连接旧数据。状态菜单展示本机容器以及带时间的最近启动记录；历史 Passed 不能证明当前健康。

当前验证存在明确的云端 HTTPS 上游 503 阻塞，完整镜像/登录/dbt 尚未验收，详细事实见《运行验证说明.md》。本包是源码研发与试用启动交付，不能据此直接投入集团正式财务出表。
