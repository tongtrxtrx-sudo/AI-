#!/usr/bin/env python3
"""Local-only EPM Docker launcher. Uses only the bundled Python standard library."""
from __future__ import annotations
import argparse
import base64
from contextlib import contextmanager
import datetime as dt
import json
import hashlib
import hmac
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parents[1]
PLATFORM = ROOT / "platform"
DATA = ROOT / "data"
PROJECT = "epmdev"
VERSION = "1.0.0"
DOCKER = shutil.which("docker")
if not DOCKER and os.name == "nt":
    candidate = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Docker/Docker/resources/bin/docker.exe"
    if candidate.is_file():
        DOCKER = str(candidate)
SECRET_VALUES: list[str] = []
LOG = None
START_STATE = None


def record_start_phase(phase):
    if START_STATE is not None:
        START_STATE["phase"] = phase
        START_STATE["updated_at"] = dt.datetime.now(dt.timezone.utc).isoformat()
        (DATA / "last-validation.json").write_text(json.dumps(START_STATE, ensure_ascii=False, indent=2), encoding="utf-8")


def emit(value):
    value = str(value)
    for secret in SECRET_VALUES:
        if secret:
            value = value.replace(secret, "[已隐藏]")
    print(value, flush=True)
    if LOG:
        LOG.write(value + "\n")
        LOG.flush()


def read_env():
    values = {}
    f = DATA / ".env"
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                values[k] = v
    SECRET_VALUES[:] = [v for k, v in values.items() if any(t in k for t in ("PASSWORD", "SECRET", "TOKEN"))]
    return values


def initialize():
    DATA.mkdir(exist_ok=True)
    (DATA / "logs").mkdir(exist_ok=True)
    (DATA / "backups").mkdir(exist_ok=True)
    envfile = DATA / ".env"
    if not envfile.exists():
        values = {
            "COMPOSE_PROJECT_NAME": PROJECT,
            "ADMIN_PASSWORD": secrets.token_hex(16),
            "DB_ROOT_PASSWORD": secrets.token_hex(16),
            "CLICKHOUSE_PASSWORD": secrets.token_hex(16),
            "CUBEJS_API_SECRET": secrets.token_hex(32),
            "SITE_NAME": "konsolidat.local", "SITE_DOMAIN": "localhost", "SITE_SCHEME": "http",
            "FRAPPE_PORT": "18069", "CLICKHOUSE_HTTP_PORT": "18123", "CLICKHOUSE_NATIVE_PORT": "19000",
            "EXCEL_ODBC_PORT": "15432", "CUBEJS_PORT": "14000", "HTTP_PORT": "18080",
            "CLICKHOUSE_USER": "default", "DBT_TARGET": "dev", "CUBEJS_DEV_MODE": "false",
        }
        # Exclusive creation preserves an existing configuration, even under concurrent launches.
        with envfile.open("x", encoding="utf-8", newline="\n") as f:
            f.write("# 本机首次启动随机生成。不要分享或提交此文件。\n")
            for key, value in values.items():
                f.write(f"{key}={value}\n")
        if os.name != "nt":
            envfile.chmod(0o600)
        emit("已为本机生成独立密码；未输出到控制台。")
    values = read_env()
    login = DATA / "login-info.txt"
    # This file is local and intentionally excluded from the delivered ZIP.
    login.write_text(
        "自研 EPM 本机登录信息（请妥善保管，不要分享此文件）\n"
        + f"网页：http://localhost:{values.get('HTTP_PORT', '18080')}/login\n"
        + "账号：Administrator\n"
        + f"密码：{values.get('ADMIN_PASSWORD', '')}\n\n"
        + "首次启动后，密码若已在系统中修改，请以系统实际密码为准；此文件不重置数据库密码。\n"
        + "完整数据库与应用密钥保存在同目录 .env，备份/迁移时须单独妥善保存。\n",
        encoding="utf-8",
    )
    if os.name != "nt":
        login.chmod(0o600)
    return values


def run(args, *, capture=False, check=True):
    if capture:
        p = subprocess.run(args, cwd=PLATFORM, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, encoding="utf-8", errors="replace")
        if check and p.returncode:
            emit(p.stdout)
            raise RuntimeError(f"命令失败（退出码 {p.returncode}），请检查 Docker/网络与日志。")
        return p
    p = subprocess.Popen(args, cwd=PLATFORM, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, encoding="utf-8", errors="replace", bufsize=1)
    for line in p.stdout:
        emit(line.rstrip("\r\n"))
    status = p.wait()
    if status and check:
        raise RuntimeError(f"命令失败（退出码 {status}），请查看 data/logs 中本次日志。")
    return status


def dc(*args, capture=False, check=True):
    if not DOCKER:
        raise RuntimeError("未找到 Docker Desktop。请先安装并启动 Docker Desktop，启用 WSL2 与 Linux 容器。")
    command = [DOCKER, "compose", "--project-directory", str(PLATFORM), "--env-file", str(DATA / ".env"),
               "--project-name", PROJECT, "--file", str(PLATFORM / "compose.runtime.json")]
    # Optional local enterprise CA/proxy overrides. Never included in the delivery ZIP.
    extra = DATA / "compose.extra.json"
    if extra.exists():
        command.extend(["--file", str(extra)])
    return run([*command, *args],
               capture=capture, check=check)


def check_prerequisites():
    if not DOCKER:
        raise RuntimeError("需要 Docker Desktop。官网：https://www.docker.com/products/docker-desktop/ 。无需自行安装 Python。")
    emit("检查 Docker Desktop / Linux 容器 / Compose / 资源……")
    result = run([DOCKER, "info", "--format", "{{.OSType}}|{{.NCPU}}|{{.MemTotal}}|{{.Architecture}}"], capture=True)
    parts = result.stdout.strip().split("|")
    if len(parts) != 4 or parts[0] != "linux":
        raise RuntimeError("Docker 必须切换到 Linux containers（Linux 容器）模式。")
    if parts[3] not in ("x86_64", "amd64"):
        raise RuntimeError("本交付包面向 Windows x64 / Docker Linux amd64，不支持 ARM 原生镜像构建。")
    cpu, memory = int(parts[1]), int(parts[2]) / (1024**3)
    emit(f"Docker：{cpu} CPU，{memory:.1f} GiB 内存。")
    if cpu < 4 or memory < 7:
        raise RuntimeError("请在 Docker Desktop/WSL2 中分配至少 4 CPU 与 8 GB 内存；建议 16 GB。")
    emit(run([DOCKER, "compose", "version", "--short"], capture=True).stdout.strip())
    free = shutil.disk_usage(ROOT).free / (1024**3)
    emit(f"解压目录所在磁盘可用空间：{free:.1f} GiB；Docker 磁盘建议另留至少 30 GB。")
    if free < 5:
        raise RuntimeError("本机磁盘空间过低，请先腾出空间。Docker 磁盘还须至少 30 GB。")
    if os.name == "nt":
        wsl = shutil.which("wsl")
        if wsl:
            p = subprocess.run([wsl, "--status"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            emit("WSL 状态命令：" + ("可用" if p.returncode == 0 else "请检查（以 Docker 实际 Linux 引擎状态为准）"))
    emit("前提检查通过。首次构建仍须联网下载 Docker、Debian、npm、PyPI 等依赖。")


def check_project_owner():
    """A second extracted copy must never attach to this project's existing data."""
    if not DOCKER:
        raise RuntimeError("未找到 Docker Desktop。")
    marker = DATA / "project-owner.json"
    canonical = lambda value: os.path.normcase(os.path.abspath(value)).replace("\\", "/").rstrip("/")
    expected = canonical(str(PLATFORM.resolve()))
    if marker.exists():
        recorded = json.loads(marker.read_text(encoding="utf-8")).get("working_directory", "")
        if canonical(recorded) != expected:
            raise RuntimeError("此 data 目录属于另一个解压位置。请返回原位置操作，或按迁移手册处理；没有切换或覆盖旧数据。")
    result = run([DOCKER, "ps", "-a", "--filter", f"label=com.docker.compose.project={PROJECT}", "--format", "{{.ID}}"], capture=True)
    containers = result.stdout.splitlines()
    for cid in containers:
        owner = run([DOCKER, "inspect", "--format", '{{index .Config.Labels "com.docker.compose.project.working_dir"}}', cid], capture=True).stdout.strip()
        if not owner or canonical(owner) != expected:
            raise RuntimeError("本机已存在另一个目录创建的 epmdev 项目。请使用原运行包操作；本次操作已停止，现有数据和服务未修改。")
    if not containers and not marker.exists():
        volumes = run([DOCKER, "volume", "ls", "--filter", f"label=com.docker.compose.project={PROJECT}", "--format", "{{.Name}}"], capture=True).stdout.strip()
        if volumes:
            raise RuntimeError("发现没有容器但仍有 epmdev 数据卷，且无法证明属于当前目录。请先核对原运行包/备份，避免误接旧数据。")
    marker.write_text(json.dumps({"project": PROJECT, "working_directory": str(PLATFORM.resolve())}, ensure_ascii=False, indent=2), encoding="utf-8")


def application_checks(values):
    """Check every long-running component and the Cube HTTP semantics layer."""
    wait_health(["frappe_backend"], timeout=120)
    services = ["mariadb", "redis_cache", "redis_queue", "clickhouse", "frappe_backend", "frappe_worker", "frappe_scheduler", "cubejs", "caddy"]
    baseline = {}
    for sample in range(2):
        for service in services:
            cid = dc("ps", "-q", service, capture=True).stdout.strip()
            if not cid:
                raise RuntimeError(f"服务 {service} 没有运行；平台尚未完整就绪。")
            state = run([DOCKER, "inspect", "--format", "{{.State.Status}}|{{.RestartCount}}|{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}", cid], capture=True).stdout.strip()
            status, count, health = state.split("|")
            if status != "running":
                raise RuntimeError(f"服务 {service} 状态为 {status}。")
            if health not in ("healthy", "none"):
                raise RuntimeError(f"服务 {service} 健康状态为 {health}。")
            if sample and int(count) != baseline[service]:
                raise RuntimeError(f"服务 {service} 正在反复重启；请检查日志。")
            baseline[service] = int(count)
        if sample == 0:
            time.sleep(8)
    base = f"http://localhost:{values.get('CUBEJS_PORT', '14000')}"
    header = base64.urlsafe_b64encode(b'{"alg":"HS256","typ":"JWT"}').rstrip(b"=")
    now = int(time.time())
    payload = base64.urlsafe_b64encode(json.dumps({"iat": now, "exp": now + 120}, separators=(",", ":")).encode()).rstrip(b"=")
    signing = header + b"." + payload
    signature = base64.urlsafe_b64encode(hmac.new(values["CUBEJS_API_SECRET"].encode(), signing, hashlib.sha256).digest()).rstrip(b"=")
    token = (signing + b"." + signature).decode()
    last_error = None
    for attempt in range(20):
        try:
            with urllib.request.urlopen(base + "/readyz", timeout=5) as response:
                if response.status != 200:
                    raise RuntimeError("Cube readiness failed")
            request = urllib.request.Request(base + "/cubejs-api/v1/meta", headers={"Authorization": token})
            with urllib.request.urlopen(request, timeout=10) as response:
                metadata = json.load(response)
                if response.status != 200 or not isinstance(metadata.get("cubes"), list) or not metadata["cubes"]:
                    raise RuntimeError("Cube metadata is not ready")
            emit(f"所有后台服务稳定运行，Cube /readyz 与认证模型元数据检查通过（{len(metadata['cubes'])} 个模型）。")
            return {"services_running": services, "cube_readyz": "passed", "cube_meta_models": len(metadata["cubes"])}
        except Exception as error:
            last_error = type(error).__name__
            time.sleep(3)
    raise RuntimeError(f"Cube HTTP/语义模型检查未通过（{last_error}），不能认为经营分析已就绪。")


def wait_health(services, timeout=240):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        pending = []
        for service in services:
            cid = dc("ps", "-q", service, capture=True).stdout.strip()
            if not cid:
                pending.append(service)
                continue
            state = run([DOCKER, "inspect", "--format", "{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}", cid], capture=True).stdout.strip()
            if state != "healthy":
                pending.append(service)
        if not pending:
            emit("基础服务健康检查通过。")
            return
        emit("等待服务：" + ", ".join(pending))
        time.sleep(5)
    raise RuntimeError("基础服务未按时就绪。请使用菜单查看状态和日志，排查资源、端口或镜像下载错误。")


def http_check(values, wait=120):
    url = f"http://localhost:{values.get('HTTP_PORT', '18080')}/api/method/ping"
    deadline = time.monotonic() + wait
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=5) as r:
                payload = json.load(r)
                if r.status == 200 and payload.get("message") == "pong":
                    emit("平台 HTTP 检查通过：ping=pong。")
                    return True
        except Exception:
            pass
        time.sleep(3)
    raise RuntimeError("网页未正常响应；平台尚未验证就绪，请检查服务日志。")


def start(values):
    record_start_phase("prerequisites")
    check_prerequisites()
    record_start_phase("infrastructure")
    emit("1/6 启动 MariaDB、Redis、ClickHouse（仅 epmdev 项目）……")
    dc("up", "-d", "mariadb", "redis_cache", "redis_queue", "clickhouse")
    wait_health(["mariadb", "redis_cache", "redis_queue", "clickhouse"])
    record_start_phase("build")
    emit("2/6 构建固定源码 Frappe + Konsol 镜像（首次耗时较长，可复用构建缓存）……")
    dc("--profile", "setup", "--profile", "backup", "build", "frappe_backend")
    record_start_phase("site_and_migrations")
    emit("3/6 创建站点 / 安装应用 / 执行迁移……")
    dc("--profile", "setup", "run", "--rm", "-T", "configurator")
    record_start_phase("application_and_http")
    emit("4/6 启动应用、后台任务、Cube 与本地网页入口……")
    dc("up", "-d", "frappe_backend", "frappe_worker", "frappe_scheduler", "cubejs", "caddy")
    http_check(values)
    record_start_phase("fx_precheck")
    emit("5/6 检查集团汇率治理前置条件（模型内部同时有强校验）……")
    result = dc("--profile", "setup", "run", "--rm", "-T", "dbt_init", "show", "--profiles-dir", "/home/frappe/dbt_project",
                "--project-dir", "/home/frappe/dbt_project", "--limit", "201", "--output", "json", "--inline", "{{ fx_precheck() }}", capture=True, check=False)
    emit(result.stdout)
    if "FX_TABLE_MISSING" in result.stdout:
        raise RuntimeError("受控集团汇率表缺失，先解决迁移问题再运行 dbt。")
    if result.returncode:
        emit("汇率预检查未通过，继续由模型内强校验确定具体错误；不会跳过 dbt 验证。")
    record_start_phase("dbt_build")
    emit("6/6 运行 dbt build（种子、模型及数据质量测试）……")
    status = dc("--profile", "setup", "run", "--rm", "-T", "dbt_init", check=False)
    summary = {"time": dt.datetime.now(dt.timezone.utc).isoformat(), "launcher": VERSION,
               "http_ping": "passed", "dbt_exit_code": status}
    if START_STATE is not None:
        START_STATE.update(summary)
        record_start_phase("dbt_build")
    if status:
        raise RuntimeError("网页服务已启动，但 dbt 构建/数据校验未通过；不得据此认为仓库及合并结果可用。请查看日志并修复。")
    record_start_phase("background_services_and_cube")
    summary.update(application_checks(values))
    if START_STATE is not None:
        START_STATE.update(summary)
    emit(f"启动及 dbt 验证完成。访问 http://localhost:{values.get('HTTP_PORT', '18080')}/login")
    emit("登录账号 Administrator；密码见 data/login-info.txt（菜单 6）。")


def backup():
    emit("备份期间暂停应用写入，完成后恢复应用服务；不删除历史备份。")
    services = ["frappe_backend", "frappe_worker", "frappe_scheduler"]
    running = dc("ps", "--status", "running", "--services", capture=True).stdout.splitlines()
    restart = [s for s in services if s in running]
    if restart:
        dc("stop", *restart)
    try:
        dc("--profile", "backup", "run", "--rm", "-T", "backup")
    finally:
        if restart:
            dc("start", *restart)
    emit("备份已写入 data/backups；请另行备份 .env 和 login-info.txt。备份目录含敏感财务数据和配置。")


def reveal(path):
    if os.name == "nt":
        os.startfile(str(path))
    else:
        emit(f"请在文件管理器打开：{path}")


@contextmanager
def operation_lock():
    """Prevent concurrent migrations or backups from two launcher windows."""
    # Shared across extracted copies for the same OS user / Docker Desktop engine.
    handle = (Path(tempfile.gettempdir()) / "self-developed-epmdev.operation.lock").open("a+b")
    handle.seek(0, 2)
    if handle.tell() == 0:
        handle.write(b"0")
        handle.flush()
    handle.seek(0)
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close()
        raise RuntimeError("另一个启动器正在启动、迁移或备份，请等待它完成。")
    try:
        yield
    finally:
        if os.name == "nt":
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(handle, fcntl.LOCK_UN)
        handle.close()


def dispatch(action, values):
    global START_STATE
    if action == "check":
        check_prerequisites()
    elif action == "start":
        with operation_lock():
            START_STATE = {"run_id": secrets.token_hex(8), "started_at": dt.datetime.now(dt.timezone.utc).isoformat(), "status": "Starting"}
            record_start_phase("ownership")
            try:
                check_project_owner()
                start(values)
            except BaseException as error:
                START_STATE.update(status="Failed", error_type=type(error).__name__, ended_at=dt.datetime.now(dt.timezone.utc).isoformat())
                record_start_phase(START_STATE["phase"])
                raise
            else:
                START_STATE.update(status="Passed", ended_at=dt.datetime.now(dt.timezone.utc).isoformat())
                record_start_phase("complete")
    elif action == "status":
        check_project_owner()
        dc("ps", "-a")
        marker = DATA / "last-validation.json"
        if marker.exists():
            emit("最近一次启动记录（历史记录，不代表当前全部健康）：" + marker.read_text(encoding="utf-8"))
    elif action == "open":
        check_project_owner()
        webbrowser.open(f"http://localhost:{values.get('HTTP_PORT', '18080')}/login")
    elif action == "stop":
        with operation_lock():
            check_project_owner()
            dc("stop")
        emit("已停止 epmdev 服务，数据卷保留。")
    elif action == "credentials":
        reveal(DATA / "login-info.txt")
    elif action == "backup":
        with operation_lock():
            check_project_owner()
            backup()
    elif action == "logs":
        dc("logs", "--tail", "100", "--no-color")
    else:
        raise ValueError(action)


def main():
    global LOG
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description="自研 EPM 本地 Docker 启动器；无需自行安装 Python")
    parser.add_argument("action", nargs="?", choices=["check", "start", "status", "open", "stop", "credentials", "backup", "logs"])
    args = parser.parse_args()
    values = initialize()
    logfile = DATA / "logs" / (dt.datetime.now().strftime("launcher-%Y%m%d-%H%M%S-%f") + ".log")
    LOG = logfile.open("a", encoding="utf-8")
    if args.action:
        try:
            dispatch(args.action, values)
            return 0
        except Exception as ex:
            emit(f"错误：{ex}")
            return 1
    emit("自研 EPM · Konsolidat / Konsol 研发与试用运行包")
    emit("需 Docker Desktop（WSL2 + Linux 容器），无需另装 Python；这是本地研发环境。")
    menu = {"1": "check", "2": "start", "3": "status", "4": "open", "5": "stop", "6": "credentials", "7": "backup", "8": "logs"}
    while True:
        emit("\n1 前提检查　2 初始化/启动　3 状态　4 打开网页\n5 停止（保留数据）　6 查看登录信息　7 完整备份　8 日志　0 退出")
        try:
            choice = input("请选择：").strip()
        except (EOFError, KeyboardInterrupt):
            return 0
        if choice == "0":
            emit("启动器已退出；已启动的 Docker 服务继续在后台运行。")
            return 0
        if choice not in menu:
            emit("请输入菜单数字。")
            continue
        try:
            dispatch(menu[choice], values)
        except KeyboardInterrupt:
            emit("已取消当前操作；容器可能仍在运行，请查看状态。")
        except Exception as ex:
            emit(f"错误：{ex}")


if __name__ == "__main__":
    raise SystemExit(main())
