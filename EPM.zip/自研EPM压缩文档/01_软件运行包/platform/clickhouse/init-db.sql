-- Open EPM: ClickHouse database initialization
-- Creates medallion architecture databases + staging

CREATE DATABASE IF NOT EXISTS epm;
CREATE DATABASE IF NOT EXISTS epm_bronze;
CREATE DATABASE IF NOT EXISTS epm_silver;
CREATE DATABASE IF NOT EXISTS epm_gold;
CREATE DATABASE IF NOT EXISTS epm_staging;

-- Staging table for planning assumptions
CREATE TABLE IF NOT EXISTS epm_staging.planning_assumptions (
    scenario_id String,
    assumption_key String,
    assumption_value String,
    legal_entity_id String DEFAULT '',
    fiscal_year UInt16 DEFAULT 0,
    updated_by String,
    updated_at DateTime DEFAULT now()
) ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (scenario_id, assumption_key, legal_entity_id, fiscal_year);

-- Staging table for scenario metadata
CREATE TABLE IF NOT EXISTS epm_staging.scenario_definitions (
    scenario_id String,
    scenario_name String,
    scenario_type String,
    base_scenario_id String DEFAULT '',
    is_active UInt8 DEFAULT 1,
    created_by String,
    created_at DateTime DEFAULT now(),
    updated_at DateTime DEFAULT now()
) ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (scenario_id);

-- ============================================================
-- PRD-8: Consolidation hierarchy (multi-level groups)
-- ============================================================
-- F2: no ownership column here. It used to carry effective_ownership_pct, which
-- in fact held the DIRECT percentage (konsol wrote `ownership_pct or 100`) and
-- had no date grain, so it could never expire. Ownership is temporal and lives
-- only in epm_staging.ownership_periods.
CREATE TABLE IF NOT EXISTS epm_staging.consolidation_hierarchy (
    consolidation_group String,
    data_area_id String,
    parent_group String DEFAULT '',
    hierarchy_level UInt8 DEFAULT 1,
    path String DEFAULT '',
    updated_at DateTime DEFAULT now()
) ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (consolidation_group, data_area_id);

-- ============================================================
-- PRD-10: Historical FX rates for equity accounts (IAS 21)
-- ============================================================
CREATE TABLE IF NOT EXISTS epm_staging.historical_equity_rates (
    consolidation_group String,
    data_area_id String,
    main_account String,
    rate_date Date,
    historical_rate Decimal(18,6),
    updated_at DateTime DEFAULT now()
) ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (consolidation_group, data_area_id, main_account, rate_date);

-- ============================================================
-- PRD-9 / PRD-11 / PRD-12: Ownership periods (temporal ownership,
--   step acquisitions, disposals)
-- ============================================================
CREATE TABLE IF NOT EXISTS epm_staging.ownership_periods (
    consolidation_group String,
    data_area_id String,
    effective_date Date,
    end_date Date DEFAULT '9999-12-31',
    ownership_pct Decimal(5,2),
    consolidation_method String DEFAULT 'full',
    -- PRD-11: Acquisition fields
    acquisition_date Date DEFAULT '1900-01-01',
    is_first_acquisition UInt8 DEFAULT 0,
    acquisition_price Decimal(18,2) DEFAULT 0,
    fair_value_adjustment Decimal(18,2) DEFAULT 0,
    -- PRD-12: Disposal fields
    disposal_date Date DEFAULT '9999-12-31',
    disposal_price Decimal(18,2) DEFAULT 0,
    is_disposal UInt8 DEFAULT 0,
    updated_at DateTime DEFAULT now()
) ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (consolidation_group, data_area_id, effective_date);

-- ============================================================
-- PRD-16: Extended consolidation adjustments (workflow fields)
-- ============================================================
CREATE TABLE IF NOT EXISTS epm_staging.consolidation_adjustments (
    consolidation_group String,
    adjustment_type String,
    journal_id String,
    data_area_id String,
    fiscal_year UInt16,
    fiscal_period UInt8,
    main_account String,
    debit_amount Decimal(18,2) DEFAULT 0,
    credit_amount Decimal(18,2) DEFAULT 0,
    description String DEFAULT '',
    posted_by String DEFAULT '',
    -- PRD-16: Workflow fields
    status String DEFAULT 'Approved',
    approved_by String DEFAULT '',
    approved_at DateTime DEFAULT '1970-01-01 00:00:00',
    reversal_journal_id String DEFAULT '',
    created_at DateTime DEFAULT now(),
    -- konsol#305-D2-11: the journal names its reversal period; 0/0 = no reversal.
    -- Identical to konsol's DDL (J05a), which owns this table.
    reverse_fiscal_year UInt16 DEFAULT 0,
    reverse_fiscal_period UInt8 DEFAULT 0
) ENGINE = MergeTree()
ORDER BY (consolidation_group, journal_id, fiscal_year, fiscal_period, main_account);

-- ============================================================
-- PRD-15: IC elimination rules (extended) & IC balances
-- ============================================================
CREATE TABLE IF NOT EXISTS epm_staging.ic_elimination_rules (
    rule_id String,
    rule_name String,
    debit_account String,
    credit_account String,
    debit_entity_pattern String DEFAULT '*',
    credit_entity_pattern String DEFAULT '*',
    description String DEFAULT '',
    -- PRD-15: Enhanced fields
    rule_type String DEFAULT 'balance',
    margin_pct Decimal(5,2) DEFAULT 0,
    asset_account String DEFAULT '',
    updated_at DateTime DEFAULT now()
) ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (rule_id);

CREATE TABLE IF NOT EXISTS epm_staging.ic_balances (
    selling_entity String,
    buying_entity String,
    fiscal_year UInt16,
    fiscal_period UInt8,
    ic_sales_amount Decimal(18,2) DEFAULT 0,
    ending_inventory_from_ic Decimal(18,2) DEFAULT 0,
    updated_at DateTime DEFAULT now()
) ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (selling_entity, buying_entity, fiscal_year, fiscal_period);

-- F8: trial-balance submission landing + control tables. Two owners, two jobs:
-- this file bootstraps a fresh install; konsol's Trial Balance Submission
-- doctype (_ensure_tables) self-heals at runtime. KEEP THE TWO IN SYNC — the
-- schemas are IF NOT EXISTS, so drift never errors at creation time, only at
-- konsol's INSERT or bronze's SELECT.
CREATE DATABASE IF NOT EXISTS epm_raw;

-- konsol#159: partner_data_area_id is the intercompany partner entity on a row
-- ('' = none). konsol's ensure_raw_tables() adds it to a table created before.
CREATE TABLE IF NOT EXISTS epm_raw.trial_balance_submissions (
    batch_id String, data_area_id String, fiscal_year UInt16,
    fiscal_period UInt8, main_account String,
    debit_amount Float64, credit_amount Float64,
    description String, submission_name String, submitted_at DateTime,
    partner_data_area_id String DEFAULT ''
) ENGINE = MergeTree ORDER BY (batch_id, main_account);

-- ReplacingMergeTree keyed on batch_id: a duplicated claim (an at-least-once
-- retry of konsol's on_submit) collapses to one row instead of fanning out the
-- bronze join — the same idempotency choice as epm_staging.sync_watermark.
-- konsolidat#199: amount_basis is what the batch's amounts are ('Period
-- movement', 'Year-to-date movement', 'Period-end balance'); '' = undeclared,
-- refused by assert_tb_submission_has_basis. tests/test_raw_submission_ddl.py
-- pins this body to konsol's _RAW_TABLE_DDL.
CREATE TABLE IF NOT EXISTS epm_raw.trial_balance_submission_control (
    batch_id String, submission_name String, data_area_id String,
    fiscal_year UInt16, fiscal_period UInt8, row_count UInt32,
    claimed_at DateTime, amount_basis String DEFAULT ''
) ENGINE = ReplacingMergeTree(claimed_at) ORDER BY batch_id;

-- F3: governed reference data written through from konsol (Dimension Mapping,
-- Cash Flow Category, Reporting Hierarchy) — these were CSV seeds regenerated
-- into the dbt repo on every save and migrate. One metadata path now: Frappe
-- doctype -> epm_staging -> dbt source. konsol's sync (TRUNCATE+INSERT of
-- Published rows) populates them; reconcile_all repairs after fixture import.
-- entity in the KEY, between erp_source and source_value: D365 gives each
-- legal entity its own dimension value set (cost centre 100 = Sales in USMF,
-- Manufacturing in DEMF), and ClickHouse cannot insert a column into the
-- middle of an existing MergeTree sort key later. entity='' = the ERP-wide
-- default; entity-specific rows take precedence (konsol #111).
CREATE TABLE IF NOT EXISTS epm_staging.dimension_mappings (
    dimension String, erp_source String, entity String, source_value String,
    canonical_value String, canonical_label String, status String
) ENGINE = MergeTree ORDER BY (dimension, erp_source, entity, source_value);

-- konsol#197: no `sign` column. Nothing read it — gold_cash_flow_indirect and
-- gold_consolidated_cash_flow read is_cash, cf_category and cf_line_item and
-- negate the signed movement themselves. Pinned, verbatim with konsol's
-- _REFERENCE_TABLE_DDL, by tests/test_cash_flow_categories_ddl.py.
CREATE TABLE IF NOT EXISTS epm_staging.cash_flow_categories (
    main_account String, cf_category String, cf_line_item String,
    is_cash UInt8, status String
) ENGINE = MergeTree ORDER BY main_account;

-- konsolidat#220: one row per member TRANCHE. A renamed, moved or ended node
-- is a second row of the same member_code with its own member_effective_from /
-- member_effective_to window (open = 2299-12-31); effective_from / effective_to
-- (String) are the hierarchy HEADER's dates. The gold hierarchy models resolve
-- the tree per period from the two Date32 columns (Date32 spans 1900-01-01..2299-12-31;
-- plain Date would clamp both ends to 1970-01-01..2149-06-06). Pinned, verbatim with konsol's
-- _REFERENCE_TABLE_DDL, by tests/test_reporting_hierarchies_ddl.py.
CREATE TABLE IF NOT EXISTS epm_staging.reporting_hierarchies (
    hierarchy_name String, dimension String, member_code String,
    member_label String, parent_member_code String, is_group UInt8,
    hierarchy_level UInt16, path String, effective_from String,
    effective_to String, is_default UInt8, status String,
    member_effective_from Date32 DEFAULT '1900-01-01',
    member_effective_to Date32 DEFAULT '2299-12-31'
) ENGINE = MergeTree ORDER BY (hierarchy_name, member_code);

-- F2: the consolidation structure and its link closure.
--
-- epm_gold.consolidation_groups was created by `dbt seed` from
-- seeds/consolidation_groups.csv — the SAME relation konsol TRUNCATE+INSERTs,
-- so a governed build and a bench migrate overwrote each other's ownership
-- figures. The seed is deleted and this is the DDL; konsol's
-- ensure_reference_tables() creates it on volumes that predate F2.
-- konsol#159: a group node also carries its intercompany-difference account
-- and tolerance (gold_ic_reconciliation, gold_ic_eliminations). konsol's
-- ensure_reference_tables() adds both to a table created before.
-- konsolidat#198: the root row (data_area_id = '') also carries the group's
-- Consolidation Policy (nci_measurement 'partial'|'full', accounting_framework,
-- goodwill_treatment 'Impairment only'|'Amortise' + years,
-- acquisition_costs_treatment 'Expense'|'Capitalise', measurement_period,
-- bargain_purchase 'Recognise gain'|'Refuse') and its declared deal accounts;
-- the acquisition and disposal journals read them and never assume a code.
-- tests/test_deal_tables_ddl.py pins this body to konsol's.
CREATE TABLE IF NOT EXISTS epm_gold.consolidation_groups (
    consolidation_group String, data_area_id String, entity_name String,
    reporting_currency String, ic_difference_account String DEFAULT '',
    ic_difference_tolerance Float64 DEFAULT 0,
    nci_measurement String DEFAULT '', accounting_framework String DEFAULT '', framework_note String DEFAULT '', goodwill_treatment String DEFAULT '', goodwill_amortisation_years UInt16 DEFAULT 0, acquisition_costs_treatment String DEFAULT '', measurement_period String DEFAULT '', bargain_purchase String DEFAULT '', goodwill_account String DEFAULT '', fair_value_adjustment_account String DEFAULT '', investment_account String DEFAULT '', nci_account String DEFAULT '', bargain_purchase_gain_account String DEFAULT '', disposal_gain_loss_account String DEFAULT '', disposal_proceeds_account String DEFAULT '', goodwill_amortisation_expense_account String DEFAULT '', acquisition_costs_account String DEFAULT ''
) ENGINE = MergeTree ORDER BY (consolidation_group, data_area_id);

-- One row per (ancestor group, entity, link on the chain between them), written
-- by konsol's tree walk. gold_entity_ownership multiplies each link's dated
-- percentage, which is how a 60%-owned subsidiary of an 80%-owned sub-group
-- reaches the top group at 48% instead of not reaching it at all.
CREATE TABLE IF NOT EXISTS epm_staging.consolidation_ancestry (
    consolidation_group String, data_area_id String, link_group String,
    link_data_area_id String, link_depth UInt8, depth UInt8, path String
) ENGINE = MergeTree ORDER BY (consolidation_group, data_area_id, link_depth);

-- konsol#110: the governed entity registry, written through from konsol's Entity
-- doctype. The warehouse used to know entities only from ERP extraction
-- (silver_legal_entities), so a subsidiary with no connector had no accounting
-- currency and gold_consolidated_trial_balance dropped it at the join.
-- konsol's ensure_reference_tables() creates it on volumes that predate this.
CREATE TABLE IF NOT EXISTS epm_staging.entities (
    data_area_id String, entity_name String, parent_entity String,
    is_group UInt8, status String, accounting_currency String,
    country String, erp_source String
) ENGINE = MergeTree ORDER BY data_area_id;

-- konsol#103 / konsolidat#93: the group's governed exchange rates, written
-- through from konsol's Group Exchange Rate (submitted rows only).
-- gold_consolidated_trial_balance translates from this table and nothing else;
-- the ERP rate feed only pre-fills drafts in konsol. konsol's
-- ensure_reference_tables() creates it on volumes that predate it. Keep
-- identical to _REFERENCE_TABLE_DDL.
-- rate is the TRUE rate, units of to_currency per 1 from_currency, published by
-- konsol (the single source of FX rates); the warehouse never scales or inverts
-- it.
CREATE TABLE IF NOT EXISTS epm_staging.group_exchange_rates (to_currency String, from_currency String, fiscal_year UInt16, fiscal_period UInt8, rate_type String, rate Float64, document String) ENGINE = MergeTree ORDER BY (to_currency, from_currency, fiscal_year, fiscal_period, rate_type);
-- konsol#159: the intercompany flag on the group chart, written through from
-- konsol's Intercompany Account doctype (Published rows). counterpart_account
-- is the account the partner books the other side on ('' = the same account).
-- Keep in step with konsol's _REFERENCE_TABLE_DDL.
CREATE TABLE IF NOT EXISTS epm_staging.intercompany_accounts (
    main_account String, counterpart_account String, description String,
    status String
) ENGINE = MergeTree ORDER BY main_account;
-- konsol#182: the group chart of accounts, written through from konsol's Main
-- Account (Published rows, groups included). It is silver_main_accounts' only
-- source, and its fx_method drives translation. konsol's
-- ensure_reference_tables() creates it on volumes that predate it. Identical to
-- konsol's _REFERENCE_TABLE_DDL.
CREATE TABLE IF NOT EXISTS epm_staging.main_accounts (main_account String, account_name String, chart_of_accounts String, parent_account String, is_group UInt8, account_type String, statement_section String, sub_section String, normal_balance String, time_balance String, fx_method String, is_posting UInt8, is_suspended UInt8, allow_ic UInt8, cf_category String, cf_line_item String, is_cash UInt8, main_account_category String, status String, is_retained_earnings UInt8 DEFAULT 0) ENGINE = MergeTree ORDER BY main_account;
-- konsolidat#199: the fiscal calendar, owned and written through by konsol (one row per fiscal year
-- and period, period_type 'Regular' or 'Closing'); silver_tb_movements reads the Closing period from it. Identical to konsol's _REFERENCE_TABLE_DDL.
CREATE TABLE IF NOT EXISTS epm_staging.fiscal_periods (fiscal_year UInt16, fiscal_period UInt8, period_code String, period_label String, period_type String, start_date Date, end_date Date, quarter String, status String) ENGINE = MergeTree ORDER BY (fiscal_year, fiscal_period);

-- konsolidat#198: the deal documents. konsol owns them (Business Combination and Business Disposal
-- doctypes, submitted rows only); the acquisition/disposal journals read them. Header: the deal and konsol's Result figures in group currency.
CREATE TABLE IF NOT EXISTS epm_staging.business_combinations (name String, consolidation_group String, acquired_entity String, acquisition_date Date, share_acquired_pct Float64, consideration_currency String, total_consideration Float64, net_assets_acquired Float64, fair_value_adjustments Float64, goodwill Float64, bargain_purchase_gain Float64, nci_at_acquisition Float64, ownership_period String, nci_measurement String DEFAULT '', nci_fair_value Float64 DEFAULT 0) ENGINE = MergeTree ORDER BY name;
-- konsolidat#198: consideration lines of a Business Combination (konsol, submitted rows only), one per
-- IFRS 3 component (Cash / Deferred / Contingent / Equity instruments / ...), each in its own currency.
CREATE TABLE IF NOT EXISTS epm_staging.business_combination_consideration (parent String, idx UInt16, component String, amount Float64, currency String, settlement_date Date, description String) ENGINE = MergeTree ORDER BY (parent, idx);
-- konsolidat#198: the acquired balance sheet of a Business Combination (konsol, submitted rows only), entity
-- currency, Dr positive / Cr negative, with the fair-value step-up per line; empty when the entity's TB is measured instead.
CREATE TABLE IF NOT EXISTS epm_staging.business_combination_acquired_balances (parent String, idx UInt16, main_account String, book_amount Float64, fair_value_adjustment Float64, note String) ENGINE = MergeTree ORDER BY (parent, idx);
-- konsolidat#198: acquisition costs of a Business Combination (konsol, submitted rows only), posted per the
-- group's acquisition_costs_treatment (Expense to the costs account, or Capitalise into consideration).
CREATE TABLE IF NOT EXISTS epm_staging.business_combination_costs (parent String, idx UInt16, kind String, amount Float64, currency String, description String) ENGINE = MergeTree ORDER BY (parent, idx);
-- konsolidat#198: the disposal documents (konsol's Business Disposal, submitted rows only): loss of control
-- of an entity, its proceeds in group currency; the disposal journal derecognises the entity from this row.
CREATE TABLE IF NOT EXISTS epm_staging.business_disposals (name String, consolidation_group String, disposed_entity String, disposal_date Date, share_disposed_pct Float64, retained_interest_pct Float64, proceeds_currency String, total_proceeds Float64, ownership_period String) ENGINE = MergeTree ORDER BY name;
-- konsolidat#198: proceeds lines of a Business Disposal (konsol, submitted rows only), one per component
-- (Cash / Deferred / Contingent / Other), each in its own currency.
CREATE TABLE IF NOT EXISTS epm_staging.business_disposal_proceeds (parent String, idx UInt16, component String, amount Float64, currency String, settlement_date Date, description String) ENGINE = MergeTree ORDER BY (parent, idx);

-- konsolidat#146: two more relations that a dbt seed and a konsol write-through
-- both owned. Seeds materialise into epm_gold (`seeds: +schema: gold`), so
-- seeds/spread_profiles.csv WAS epm_gold.spread_profiles — the same table the
-- Spread Profile doctype TRUNCATE+INSERTs, and whichever of `dbt seed` and
-- `bench migrate` ran last won. The seeds are deleted; konsol is the source and
-- konsol's ensure_reference_tables() creates these on volumes that predate the
-- change. Keep both in step with _REFERENCE_TABLE_DDL.
CREATE TABLE IF NOT EXISTS epm_gold.spread_profiles (
    profile_id String, profile_name String, fiscal_period Int32, weight Float32
) ENGINE = MergeTree ORDER BY (profile_id, fiscal_period);

CREATE TABLE IF NOT EXISTS epm_gold.scenario_definitions (
    scenario_id String, scenario_name String, scenario_type String, is_active Int32
) ENGINE = MergeTree ORDER BY scenario_id;

-- konsolidat#146: the ISO 4217 reference list, published from Frappe's Currency
-- records by konsol.currency_sync. It was seeds/currencies.csv.
-- konsolidat#93 / konsol#103: usd_log10 is roughly log10 of the currency's units
-- per 1 USD, the reference magnitude the FX sanity rule checks rates against
-- (dbt macros/fx_magnitude.sql; konsol.group_rates.magnitude_problem). NaN =
-- no reference value, and a rate involving it fails the check. Identical to
-- konsol's _REFERENCE_TABLE_DDL; keep them identical.
CREATE TABLE IF NOT EXISTS epm_gold.currencies (currency_code String, currency_name String, symbol String, minor_unit UInt8, usd_log10 Float64 DEFAULT nan) ENGINE = MergeTree ORDER BY currency_code;

-- konsolidat#146: which fiscal calendar each ERP legal entity posts against,
-- from konsol's Entity Fiscal Calendar doctype. It was
-- seeds/entity_fiscal_calendars.csv.
CREATE TABLE IF NOT EXISTS epm_gold.entity_fiscal_calendars (
    data_area_id String, fiscal_calendar_id String
) ENGINE = MergeTree ORDER BY data_area_id;

-- konsolidat#146: the two halves of budget input, both from konsol.
-- budget_annual_input was seeds/budget_annual_input.csv — a top-down annual
-- figure that gold_spread_budget spreads into months by profile.
-- budget_monthly_input is the bottom-up half, written by Budget Sheet; it has
-- always been a konsol write-through with nothing that creates it, which is why
-- gold_spread_budget has been failing every build.
-- konsol#287: neither table names a dimension. Which dim_* columns they carry is
-- the site's Published Dimensions ticked in_budget, which konsol adds by ALTER
-- (schema_apply._sync_budget_dimension_columns); gold_spread_budget reads that
-- same set through get_budget_dimensions(). They used to be created with two
-- customers' dimensions as literal columns.
CREATE TABLE IF NOT EXISTS epm_gold.budget_annual_input (
    scenario_id String, data_area_id String, fiscal_year UInt16,
    main_account String,
    annual_amount Decimal(18,2), spread_profile_id String, submitted_by String
) ENGINE = MergeTree ORDER BY (scenario_id, data_area_id, fiscal_year, main_account);

CREATE TABLE IF NOT EXISTS epm_gold.budget_monthly_input (
    scenario_id String, data_area_id String, fiscal_year UInt16,
    main_account String,
    fiscal_period UInt8, amount Decimal(18,2), layer String
) ENGINE = MergeTree ORDER BY (scenario_id, data_area_id, fiscal_year, layer);

