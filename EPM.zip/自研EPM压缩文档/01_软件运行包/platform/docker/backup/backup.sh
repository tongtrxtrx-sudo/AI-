#!/bin/bash
# Local delivery backup. No retention cleanup; any failed export is fatal.
set -euo pipefail
DATE=$(date -u +%Y%m%dT%H%M%SZ)
DEST="${BACKUP_DIR:-/backups}/${DATE}"
mkdir -p "$DEST/clickhouse"
export DEST
: "${DB_ROOT_PASSWORD:?missing DB_ROOT_PASSWORD}"
: "${CLICKHOUSE_PASSWORD:?missing CLICKHOUSE_PASSWORD}"
echo "[1/4] MariaDB transactional dump"
mariadb-dump -h "${DB_HOST:-mariadb}" -P "${DB_PORT:-3306}" -u root \
  -p"$DB_ROOT_PASSWORD" --all-databases --single-transaction --quick | gzip > "$DEST/mariadb.sql.gz"
echo "[2/4] ClickHouse schemas and native table data"
chquery() {
  curl --fail --silent --show-error "http://${CLICKHOUSE_HOST:-clickhouse}:${CLICKHOUSE_PORT:-8123}/" \
    --user "${CLICKHOUSE_USER:-default}:${CLICKHOUSE_PASSWORD}" --data-binary "$1"
}
DATABASES=$(chquery "SELECT name FROM system.databases WHERE name NOT IN ('system', 'information_schema', 'INFORMATION_SCHEMA', '_temporary_and_external_tables') ORDER BY name FORMAT TabSeparatedRaw")
for db in $DATABASES; do
  [[ "$db" =~ ^[a-zA-Z0-9_]+$ ]] || { echo "Unsupported database identifier; backup stopped."; exit 1; }
  chquery "SHOW CREATE DATABASE $db FORMAT TabSeparatedRaw" > "$DEST/clickhouse/${db}__database.sql"
  chquery "SELECT name, engine FROM system.tables WHERE database='$db' ORDER BY name FORMAT TabSeparated" > "$DEST/clickhouse/${db}__tables.tsv"
  while IFS=$'\t' read -r table engine; do
    [ -n "$table" ] || continue
    chquery "SHOW CREATE TABLE \`$db\`.\`$table\` FORMAT TabSeparatedRaw" > "$DEST/clickhouse/${db}__${table}.sql"
    case "$engine" in View|MaterializedView|Dictionary) continue;; esac
    chquery "SELECT * FROM \`$db\`.\`$table\` FORMAT Native" | gzip > "$DEST/clickhouse/${db}__${table}.native.gz"
  done < "$DEST/clickhouse/${db}__tables.tsv"
done
echo "[3/4] Frappe site files (contains confidential configuration)"
tar czf "$DEST/frappe_sites.tar.gz" -C /home/frappe/frappe-bench sites/
echo "[4/4] Checksums and completion marker"
/home/frappe/frappe-bench/env/bin/python - <<'PY'
import os,hashlib,json
from pathlib import Path
root=Path(os.environ['DEST']); entries={}
for path in sorted(root.rglob('*')):
 if path.is_file():
  h=hashlib.sha256()
  with path.open('rb') as f:
   for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
  entries[path.relative_to(root).as_posix()]=h.hexdigest()
(root/'SHA256.json').write_text(json.dumps(entries,indent=2))
(root/'BACKUP_COMPLETE.txt').write_text('Complete local EPM export. Keep original .env separately. Restore only to an isolated compatible stack first.\n')
PY
echo "Backup complete: ${DATE} (data/backups)"
