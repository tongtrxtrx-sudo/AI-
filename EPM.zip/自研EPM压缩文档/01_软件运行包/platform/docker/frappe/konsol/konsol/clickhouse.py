"""Shared ClickHouse write helper for EPM data doctypes.

Provides reusable functions to sync Frappe doctype data to ClickHouse
tables via HTTP API. Supports both legacy gold.* tables (seed replacement)
and epm_staging.* tables (PRD-8+ consolidation features).

Each data doctype calls sync_doctype() in its on_update / on_trash hook.
"""
from contextvars import ContextVar
from datetime import date, datetime, timezone

import functools
import secrets

import frappe
import requests

# Track sync failures for monitoring. Key = table name, value = last error info.
_sync_failures = {}


def get_connection():
    """Read ClickHouse connection settings from EPM Settings.

    Returns dict with host, port, user, password, secure, verify.

    When ``clickhouse_secure`` is enabled the connection uses HTTPS so that
    credentials and query results are not sent in clear text. ``verify`` maps
    to ``clickhouse_verify_tls`` and controls certificate validation (leave on
    unless using a self-signed cert in a trusted network).
    """
    settings = frappe.get_single("EPM Settings")
    host = settings.clickhouse_host or "localhost"
    secure = bool(getattr(settings, "clickhouse_secure", 0))
    # Default to verifying TLS; only relax when explicitly disabled in settings.
    verify = bool(getattr(settings, "clickhouse_verify_tls", 1))
    return {
        "host": host,
        "port": settings.clickhouse_port or "8123",
        "user": settings.clickhouse_user or "default",
        "password": settings.get_password("clickhouse_password", raise_exception=False) or "",
        "secure": secure,
        "verify": verify,
    }


def connection_url(conn):
    """Build the ClickHouse HTTP(S) base URL for a connection dict.

    Uses HTTPS when ``conn['secure']`` is truthy so credentials are encrypted
    in transit. Loopback hosts stay on HTTP by default for local dev.
    """
    scheme = "https" if conn.get("secure") else "http"
    return f"{scheme}://{conn['host']}:{conn['port']}/"


def execute(sql, params=None):
    """Execute a ClickHouse SQL statement via HTTP POST.

    Args:
        sql: SQL string to execute.
        params: Optional dict of query parameters.

    Returns:
        Response text (stripped).
    """
    conn = get_connection()
    url = connection_url(conn)
    query_params = dict(params or {})

    resp = requests.post(
        url,
        params=query_params,
        data=sql.encode("utf-8"),
        auth=(conn["user"], conn["password"]),
        timeout=30,
        verify=conn.get("verify", True),
    )
    if resp.status_code >= 400:
        # Still an HTTPError (callers catch that type), but with ClickHouse's
        # own text: requests' message is only "500 Server Error … for url", and
        # callers classify failures by the body (e.g. UNKNOWN_IDENTIFIER for a
        # column an older stack has not migrated yet; tasks._batches_without_basis).
        raise requests.HTTPError(
            f"{resp.status_code} from ClickHouse: {resp.text.strip()[:500]}", response=resp)
    return resp.text.strip()


_WATERMARK_TABLE = "epm_staging.sync_watermark"

# grynn-in/konsolidat#246, option #246-1 (Deepak Pai, 11 Oct 2026): every
# watermark reconcile_all() writes carries that run's id; a write-through
# leaves the column at its type default, ''. assert_staging_not_stale then
# calls a table LAGGING when it has no row from the latest run, instead of
# comparing it with the newest stamp of an unrelated table (one hierarchy
# publish made 26 untouched tables "lag"). Rejected: #246-2 drop LAGGING,
# #246-3 raise the lag hours.
#
# String, not Nullable(String). '' already means "not stamped by a run", and
# that is also what the rows written before the column existed read. A NULL
# would be a third state that join_use_nulls=0 turns back into '' in any
# LEFT JOIN, and a Nullable column cannot be in the sorting key without
# allow_nullable_key.
#
# The column is in the sorting key. ReplacingMergeTree keeps one row per key,
# so keyed on table_name alone a write-through after a reconcile REPLACES that
# table's run row when the parts merge, and the table falls out of the run it
# was in. Keyed on (table_name, reconcile_run_id), each table keeps one row
# per run plus its latest write-through. No DEFAULT clause: ClickHouse refuses
# to put a newly added column with a default expression into the sorting key.
# konsolidat's dbt_project.yml on-run-start creates the same table; keep the
# two bodies identical.
_WATERMARK_DDL = (
    f"CREATE TABLE IF NOT EXISTS {_WATERMARK_TABLE} ("
    "table_name String, "
    "synced_at DateTime, "
    "row_count UInt64, "
    "source_max_modified DateTime, "
    "reconcile_run_id String"
    ") ENGINE = ReplacingMergeTree(synced_at) ORDER BY (table_name, reconcile_run_id)"
)
_WATERMARK_UPGRADE = (
    f"ALTER TABLE {_WATERMARK_TABLE} "
    "ADD COLUMN IF NOT EXISTS reconcile_run_id String, "
    "MODIFY ORDER BY (table_name, reconcile_run_id)"
)

#: The id of the reconcile_all() call in progress, or None outside one. A
#: ContextVar, not a module global or frappe.flags, so it is scoped to the call
#: (reset in a finally, an abort included) and to the thread running it.
_reconcile_run_id = ContextVar("konsol_reconcile_run_id", default=None)


def _new_reconcile_run_id():
    """UTC start time plus 8 random hex digits: readable, and unique even for
    two reconciles started in the same second."""
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(4)


def _watermark_upgrade_ddl():
    """The ALTER that gives an existing watermark the run id, or nothing.

    Asked first, like _retired_watermark_cleanup: an ALTER that changes nothing
    still rewrites the table's metadata_modification_time (measured on 24.8),
    and assert_staging_not_stale measures its no-run-yet grace from that time,
    so re-issuing the ALTER on every reconcile would restart the grace for
    ever. A missing table is left to the first stamp, which creates it with
    the new body.
    """
    try:
        key = execute(
            "SELECT sorting_key FROM system.tables "
            "WHERE database = 'epm_staging' AND name = 'sync_watermark'"
        )
    except Exception:  # noqa: BLE001 — unreachable: the next reconcile asks again
        return []
    key = (key or "").strip()
    if not key or "reconcile_run_id" in key:
        return []
    return [_WATERMARK_UPGRADE]


def _stamp_watermark(table, row_count, source_max_modified=None):
    """Record that ``table`` was successfully synced, for dbt to check.

    D11 wanted ClickHouse to read Frappe's MariaDB directly so metadata could
    never go stale. That was reversed (F4) — write-through avoids making every
    dbt run a live dependency on the Frappe database — but it gives up the
    "never stale" guarantee. This restores it: every successful sync stamps a
    row here, and a dbt test fails the run when what it claims no longer holds.

    ``_sync_failures`` already tracks breakage, but only in memory in the
    Frappe process: it dies on restart and dbt cannot see it. This is the
    durable, ClickHouse-side half.

    Inside reconcile_all() the stamp carries the run id (konsolidat#246).
    Outside one, the INSERT does not name the column at all, so a write-through
    also stamps a watermark that has not been upgraded yet.

    Best-effort — a watermark failure must never break a document save.
    """
    try:
        execute(_WATERMARK_DDL)
        src = source_max_modified or "1970-01-01 00:00:00"
        run_id = _reconcile_run_id.get()
        if run_id:
            execute(
                f"INSERT INTO {_WATERMARK_TABLE} "
                "(table_name, synced_at, row_count, source_max_modified, reconcile_run_id) "
                f"VALUES ('{table}', now(), {int(row_count)}, '{src}', '{run_id}')"
            )
        else:
            execute(
                f"INSERT INTO {_WATERMARK_TABLE} "
                "(table_name, synced_at, row_count, source_max_modified) VALUES "
                f"('{table}', now(), {int(row_count)}, '{src}')"
            )
    except Exception as e:  # noqa: BLE001 — never break a save over telemetry
        frappe.logger().warning(f"watermark stamp failed for {table}: {e}")


def sync_table(table, columns, rows, source_max_modified=None, force=False):
    """TRUNCATE and INSERT all rows into a ClickHouse table.

    An unforced sync is best-effort: it logs, records the failure and returns
    None instead of raising, so ClickHouse downtime does not break the Frappe
    document save that triggered it.

    A forced sync (``force=True``) re-raises after recording, on every failure
    branch — connection, timeout and HTTP alike. Those callers are deliberate
    repairs, not document events: reconcile_all catches it per doctype and logs
    that table as skipped, and a manual ``bench execute`` fails loudly instead
    of reporting a clean repair over a table that never synced (konsol#194).

    Args:
        table: Fully qualified table name (e.g. 'epm_gold.consolidation_groups').
        columns: List of column names.
        rows: List of tuples/lists matching column order.
        force: Sync during migrate/patch, and raise on failure (see above).
    """
    # Skip during app install / migrate / fixture import: fixtures must not
    # push to ClickHouse (EPM Settings — and the CH password — may not be
    # configured yet, and a write here would crash install-app). Explicit
    # syncs (apply_schema, manual bench execute) run outside these phases.
    # in_install / in_import always block: EPM Settings (and the CH password)
    # may not exist yet, and a write here would crash install-app.
    if frappe.flags.in_install or frappe.flags.in_import:
        return
    # in_migrate / in_patch normally block for the same reason, but reconcile
    # runs *after* migrate specifically to repair tables that document events
    # could not reach, so it passes force=True.
    if not force and (frappe.flags.in_migrate or frappe.flags.in_patch):
        return

    try:
        _sync_table_inner(table, columns, rows)
        # Clear any previous failure for this table
        _sync_failures.pop(table, None)
        _stamp_watermark(table, len(rows), source_max_modified)
        return len(rows)
    except requests.exceptions.ConnectionError as e:
        _record_sync_failure(table, "connection_refused", str(e))
        frappe.logger().error(
            f"ClickHouse SYNC FAILED (connection refused): {table} — "
            f"check ClickHouse is running and EPM Settings are correct"
        )
        frappe.publish_realtime(
            "clickhouse_sync_error",
            {"table": table, "error": "connection_refused", "message": str(e)},
        )
        if force:
            raise
    except requests.exceptions.Timeout as e:
        _record_sync_failure(table, "timeout", str(e))
        frappe.logger().error(
            f"ClickHouse SYNC FAILED (timeout): {table} — "
            f"ClickHouse may be overloaded"
        )
        frappe.publish_realtime(
            "clickhouse_sync_error",
            {"table": table, "error": "timeout", "message": str(e)},
        )
        if force:
            raise
    except requests.exceptions.HTTPError as e:
        _record_sync_failure(table, "http_error", str(e))
        frappe.logger().error(
            f"ClickHouse SYNC FAILED (HTTP {e.response.status_code}): {table} — "
            f"table may not exist yet; run dbt build to create it"
        )
        frappe.publish_realtime(
            "clickhouse_sync_error",
            {"table": table, "error": "http_error", "message": str(e)},
        )
        if force:
            raise


def _sql_value(v):
    """Render one Python value as a ClickHouse VALUES literal.

    An unset field is written as the ``DEFAULT`` keyword, which means "whatever
    this column declares" and is therefore right for every column type: '' for a
    String, 0 for a number, 1970-01-01 for a Date, NULL for a Nullable. The two
    obvious alternatives are both wrong somewhere:

    * a literal ``NULL`` into a non-Nullable column is accepted only while
      ClickHouse keeps ``input_format_null_as_default`` on, and is rejected
      mid-INSERT — one publish of a Dimension Mapping with a blank entity
      emptied the whole crosswalk (konsol #112, finding 4; since konsol#194
      that rejection is confined to the temp table and the live rows survive,
      but the sync still loses its own rows);
    * a literal ``''`` fixes that for String columns and breaks every Date one.
      It is why epm_staging.ownership_periods stopped syncing entirely: an
      Ownership Period with no acquisition_date sent '' into a Date column.

    Datetimes are truncated to whole seconds: ClickHouse's DateTime has
    one-second resolution and rejects a microsecond timestamp outright with a
    400. Frappe's now_datetime() carries microseconds, so any column fed from
    it would otherwise fail to reconcile — invisibly, because reconcile_all
    reported frappe.db.count() whenever a sync returned nothing instead of
    the number it actually wrote.
    """
    if v is None:
        return "DEFAULT"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, datetime):
        return "'" + v.strftime("%Y-%m-%d %H:%M:%S") + "'"
    if isinstance(v, date):
        return "'" + v.strftime("%Y-%m-%d") + "'"
    escaped = str(v).replace("\\", "\\\\").replace("'", "\\'")
    return f"'{escaped}'"


def _sync_table_inner(table, columns, rows):
    """Internal: fill a sibling temp table and swap it in. Raises on failure.

    The live table is never TRUNCATEd. It used to be, as the first statement,
    so a sync that failed part way — a rejected literal, a dropped connection,
    a timeout — left the table EMPTY with nothing to put the rows back
    (konsol#194). Every row now goes into ``<table>_sync_tmp``, and only a
    complete fill is swapped in with EXCHANGE TABLES (atomic, and available
    because the databases are Atomic on ClickHouse 24.8). Any failure before
    the swap leaves the live table exactly as it was.

    An empty row list still empties the live table — reconcile_all relies on
    that — but through the same swap. The temp table is emptied afterwards
    (the EXCHANGE leaves the previous rows in it) rather than dropped, so a
    concurrent reader never sees it disappear mid-swap.

    The temp table is rebuilt from the live one at the start of every sync,
    because the EXCHANGE swaps the two NAMES: a surviving ``<table>_sync_tmp``
    is last sync's table, not this sync's shape. ensure_reference_tables and
    _ADDED_COLUMNS ALTER only the live name, so a tmp that was merely reused
    when present would keep the old column set, and every later
    ``INSERT INTO <tmp> (<new column list>)`` would fail until someone dropped
    it by hand.
    """
    tmp = f"{table}_sync_tmp"
    execute(f"DROP TABLE IF EXISTS {tmp}")
    execute(f"CREATE TABLE {tmp} AS {table}")

    if rows:
        col_list = ", ".join(columns)
        value_rows = [f"({', '.join(_sql_value(v) for v in row)})" for row in rows]

        batch_size = 1000
        for i in range(0, len(value_rows), batch_size):
            batch = value_rows[i:i + batch_size]
            values_sql = ", ".join(batch)
            execute(f"INSERT INTO {tmp} ({col_list}) VALUES {values_sql}")

    execute(f"EXCHANGE TABLES {table} AND {tmp}")
    execute(f"TRUNCATE TABLE IF EXISTS {tmp}")


def sync_rows(table, columns, rows, key_columns, key_values):
    """Delete rows matching key, then insert new rows. Incremental sync.

    Unlike sync_table (TRUNCATE all), this only replaces rows matching the
    given key — safe for concurrent writes from different docs.

    Args:
        table: Fully qualified table name (e.g. 'epm_gold.budget_monthly_input').
        columns: List of column names for INSERT.
        rows: List of tuples/lists matching column order.
        key_columns: List of column names forming the unique key.
        key_values: Dict mapping key column names to values for DELETE WHERE.
    """
    try:
        _sync_rows_inner(table, columns, rows, key_columns, key_values)
        _sync_failures.pop(table, None)
    except requests.exceptions.ConnectionError as e:
        _record_sync_failure(table, "connection_refused", str(e))
        frappe.logger().error(
            f"ClickHouse SYNC FAILED (connection refused): {table}"
        )
    except requests.exceptions.Timeout as e:
        _record_sync_failure(table, "timeout", str(e))
        frappe.logger().error(f"ClickHouse SYNC FAILED (timeout): {table}")
    except requests.exceptions.HTTPError as e:
        _record_sync_failure(table, "http_error", str(e))
        frappe.logger().error(
            f"ClickHouse SYNC FAILED (HTTP {e.response.status_code}): {table}"
        )


def _sync_rows_inner(table, columns, rows, key_columns, key_values):
    """Internal: DELETE by key + INSERT. Raises on failure."""
    # Build WHERE clause for DELETE
    where_parts = []
    for col in key_columns:
        val = key_values[col]
        if isinstance(val, (int, float)):
            where_parts.append(f"{col} = {val}")
        else:
            escaped = str(val).replace("\\", "\\\\").replace("'", "\\'")
            where_parts.append(f"{col} = '{escaped}'")
    where_clause = " AND ".join(where_parts)

    execute(f"ALTER TABLE {table} DELETE WHERE {where_clause} SETTINGS mutations_sync = 1")

    if not rows:
        return

    col_list = ", ".join(columns)
    value_rows = [f"({', '.join(_sql_value(v) for v in row)})" for row in rows]

    batch_size = 1000
    for i in range(0, len(value_rows), batch_size):
        batch = value_rows[i:i + batch_size]
        values_sql = ", ".join(batch)
        execute(f"INSERT INTO {table} ({col_list}) VALUES {values_sql}")


def resolve_sync_filters(doctype):
    """Which rows of ``doctype`` belong in ClickHouse. The single answer.

    Two rules, in order:

    * the controller declares ``CH_SYNC_FILTERS`` — governed reference data
      (Dimension Mapping, Cash Flow Category) is published deliberately, and
      only Published rows may reach the warehouse;
    * a *submittable* doctype syncs docstatus=1 (submitted) rows only: drafts
      (0) and cancelled (2) must never reach ClickHouse. Without this the full
      TRUNCATE+INSERT re-synced drafts and cancelled docs — so on_cancel
      re-inserted the just-cancelled row and drafts leaked in on the next
      submit of any doc (grynn-in/konsolidat#92, finding #1). Keyed on the
      doctype's own ``is_submittable`` so it covers every submittable
      consolidation doctype at once (Ownership Period, IC Balance,
      Consolidation Journal, Historical Equity Rate, …). Consolidation
      Adjustment was here until it was retired outright by konsol#292.

    Both write paths go through here — the document hooks and
    ``reconcile_all`` — because they used to disagree. publish() synced
    Published rows only; reconcile synced *every* row of a non-submittable
    doctype, so one `bench migrate` re-filled epm_staging.cash_flow_categories
    with Drafts and Inactives that no consumer filters out.
    """
    declared = getattr(_controller(doctype), "CH_SYNC_FILTERS", None)
    if declared:
        return dict(declared)
    return {"docstatus": 1} if frappe.get_meta(doctype).is_submittable else None


def _controller(doctype):
    """The doctype's controller class, or None when it has no importable one."""
    from frappe.model.base_document import get_controller

    try:
        return get_controller(doctype)
    except Exception:  # noqa: BLE001 — no controller simply means no declaration
        return None


def sync_doctype(doctype, table, field_map, force=False):
    """Fetch the doctype's warehouse-eligible docs and sync them to ClickHouse.

    Which rows are eligible is ``resolve_sync_filters(doctype)`` — never a
    per-call-site decision.

    Args:
        doctype: Frappe DocType name (e.g. 'Entity').
        table: ClickHouse table name (e.g. 'epm_staging.entities').
        field_map: Dict mapping CH column names to Frappe field names.
            e.g. {'entity_name': 'entity_name', 'accounting_currency': 'accounting_currency'}
    """
    return sync_doctype_filtered(
        doctype, table, field_map,
        filters=resolve_sync_filters(doctype), force=force,
    )


def after_commit_once(key, fn):
    """Run ``fn()`` once, after the current transaction commits (konsol#124).

    Document hooks must not write ClickHouse directly. ClickHouse has no
    transaction, so an INSERT made in a hook is final at once: a save that later
    rolls back leaves its row in the warehouse. The sync also reads its rows
    through the same uncommitted transaction. After the commit, it publishes
    exactly what MariaDB committed, and a rollback publishes nothing.

    ``CallbackManager.add`` doesn't dedupe, so a bulk edit of N documents would
    queue N full-table syncs. ``key`` keeps one per transaction: the queue
    itself is asked, so there's no marker to go stale after a failed commit.

    Nothing is queued where the inline sync would have been skipped (install,
    import, migrate, patch: ``sync_table``'s own guard): the queue runs at a
    commit after those flags are cleared, so an install would sync fixtures
    before the warehouse exists. reconcile_all repairs the tables after a
    migrate. A queued sync that fails is logged, never raised: the save it
    follows has already committed, and a raise would turn it into an error
    response and drop the syncs queued behind it (#141 review).
    """
    flags = frappe.flags
    if flags.in_install or flags.in_import or flags.in_migrate or flags.in_patch:
        return
    queued = getattr(frappe.db.after_commit, "_functions", ())
    if any(getattr(f, "_konsol_key", None) == key for f in queued):
        return

    def job():
        try:
            fn()
        except Exception:
            # This runs after the request's last commit, so a plain Error Log
            # insert would never be committed. Log to file and defer the row.
            frappe.logger().exception(f"ClickHouse sync after commit failed: {key}")
            frappe.log_error(title=f"ClickHouse sync after commit failed: {key}", defer_insert=True)

    job._konsol_key = key
    frappe.db.after_commit.add(job)


def sync_doctype_after_commit(doctype, table, field_map):
    """``sync_doctype`` for a document hook: once, after the commit (konsol#124)."""
    after_commit_once(("sync_doctype", doctype, table), functools.partial(sync_doctype, doctype, table, field_map))


def _record_sync_failure(table, error_type, message):
    """Track sync failure for monitoring/health check."""
    _sync_failures[table] = {
        "error_type": error_type,
        "message": message,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def check_health():
    """Check ClickHouse connectivity and return health status.

    Returns dict with:
        - status: 'healthy' | 'degraded' | 'down'
        - clickhouse_reachable: bool
        - recent_sync_failures: list of failed tables
        - message: human-readable status
    """
    result = {
        "status": "healthy",
        "clickhouse_reachable": False,
        "recent_sync_failures": [],
        "message": "",
    }

    # Test connectivity
    try:
        resp = execute("SELECT 1")
        result["clickhouse_reachable"] = resp == "1"
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
        result["clickhouse_reachable"] = False
        result["status"] = "down"
        result["message"] = "ClickHouse is unreachable"
        return result
    except Exception as e:
        result["clickhouse_reachable"] = False
        result["status"] = "down"
        result["message"] = f"ClickHouse error: {str(e)}"
        return result

    # Check for recent sync failures
    if _sync_failures:
        result["recent_sync_failures"] = [
            {"table": k, **v} for k, v in _sync_failures.items()
        ]
        result["status"] = "degraded"
        result["message"] = f"{len(_sync_failures)} table(s) have sync failures"
    else:
        result["message"] = "All systems operational"

    return result


def sync_doctype_filtered(doctype, table, field_map, filters=None, force=False):
    """Fetch filtered Frappe docs and sync to ClickHouse.

    Like sync_doctype() but with optional filters (e.g. docstatus=1 for
    submitted-only sync).

    Args:
        doctype: Frappe DocType name.
        table: ClickHouse table name.
        field_map: Dict mapping CH column names to Frappe field names.
        filters: Optional Frappe filter dict (e.g. {'docstatus': 1}).
    """
    ch_columns = list(field_map.keys())
    frappe_fields = list(field_map.values())

    # Fetch `modified` alongside so the sync can stamp how fresh the source was
    # at the time. Only added when the field_map does not already carry it.
    fetch_fields = list(frappe_fields)
    if "modified" not in fetch_fields:
        fetch_fields.append("modified")

    docs = frappe.get_all(
        doctype,
        filters=filters or {},
        fields=fetch_fields,
        limit_page_length=0,
    )
    # An unset field reaches _sql_value as None and is written as DEFAULT — the
    # column's own declared default, whatever its type. See _sql_value: neither
    # a literal NULL nor a literal '' is right for every column here.
    rows = [[doc.get(f) for f in frappe_fields] for doc in docs]

    modified = [d.get("modified") for d in docs if d.get("modified")]
    source_max_modified = (
        max(modified).strftime("%Y-%m-%d %H:%M:%S") if modified else None
    )

    return sync_table(
        table,
        ch_columns,
        rows,
        source_max_modified=source_max_modified,
        force=force,
    )


# ---------------------------------------------------------------------------
# Bootstrap DDL for the F3 reference tables
# ---------------------------------------------------------------------------
# KEEP IN SYNC with clickhouse/init-db.sql in konsolidat — the fresh-install
# owner of these three tables. Docker runs init-db.sql ONLY against an empty
# ClickHouse volume, so every stack that existed before F3 (including the
# demo server and every developer laptop) never receives them: the seeds that
# used to carry this data are deleted, the doctypes now write through, and
# each sync fails with "table does not exist" until someone runs the DDL by
# hand. Creating them here makes the upgrade path idempotent, the same way
# Trial Balance Submission._ensure_tables does for the epm_raw pair.
#
# The column types must match init-db.sql exactly; ORDER BY in particular
# cannot be changed later without dropping the table.
_REFERENCE_TABLE_DDL = {
    "epm_staging.dimension_mappings": (
        "(dimension String, erp_source String, entity String, source_value String, "
        "canonical_value String, canonical_label String, status String) "
        "ENGINE = MergeTree ORDER BY (dimension, erp_source, entity, source_value)"
    ),
    "epm_staging.cash_flow_categories": (
        "(main_account String, cf_category String, cf_line_item String, "
        "is_cash UInt8, status String) "
        "ENGINE = MergeTree ORDER BY main_account"
    ),
    # konsol#220: each member row is one dated tranche of its code; its window
    # is Date32 (1900-01-01..2299-12-31; Date clamps both ends), an open end
    # being 2299-12-31. Added to existing tables by _ADDED_COLUMNS below.
    # Identical to konsolidat's clickhouse/init-db.sql; keep them identical.
    "epm_staging.reporting_hierarchies": (
        "(hierarchy_name String, dimension String, member_code String, "
        "member_label String, parent_member_code String, is_group UInt8, "
        "hierarchy_level UInt16, path String, effective_from String, "
        "effective_to String, is_default UInt8, status String, "
        "member_effective_from Date32 DEFAULT '1900-01-01', "
        "member_effective_to Date32 DEFAULT '2299-12-31') "
        "ENGINE = MergeTree ORDER BY (hierarchy_name, member_code)"
    ),
    # F2: the consolidation structure. epm_gold.consolidation_groups used to be
    # created by `dbt seed` from seeds/consolidation_groups.csv — the SAME
    # relation konsol TRUNCATE+INSERTs, so every governed build overwrote the
    # live tree with a June CSV and every migrate overwrote it back. The seed is
    # deleted, so this is now the only thing that creates the table.
    # konsol#159: a group node also carries where its intercompany differences
    # are booked, and the tolerance they are shown against (decision 4, 13 Sep
    # 2026). Added to existing tables by _ADDED_COLUMNS below.
    # konsolidat#198: the group root's Consolidation Policy (design 1a;
    # nci_measurement is the doctype's goodwill_method) and the declared
    # accounts the consolidation journals post to (design 1), so dbt reads
    # the policy and never assumes a code. Identical to konsolidat's
    # clickhouse/init-db.sql; keep them identical.
    "epm_gold.consolidation_groups": (
        "(consolidation_group String, data_area_id String, entity_name String, "
        "reporting_currency String, ic_difference_account String DEFAULT '', "
        "ic_difference_tolerance Float64 DEFAULT 0, nci_measurement String DEFAULT '', "
        "accounting_framework String DEFAULT '', framework_note String DEFAULT '', "
        "goodwill_treatment String DEFAULT '', goodwill_amortisation_years UInt16 DEFAULT 0, "
        "acquisition_costs_treatment String DEFAULT '', measurement_period String DEFAULT '', "
        "bargain_purchase String DEFAULT '', goodwill_account String DEFAULT '', "
        "fair_value_adjustment_account String DEFAULT '', investment_account String DEFAULT '', "
        "nci_account String DEFAULT '', bargain_purchase_gain_account String DEFAULT '', "
        "disposal_gain_loss_account String DEFAULT '', disposal_proceeds_account String DEFAULT '', "
        "goodwill_amortisation_expense_account String DEFAULT '', "
        "acquisition_costs_account String DEFAULT '') "
        "ENGINE = MergeTree ORDER BY (consolidation_group, data_area_id)"
    ),
    # konsol#159: the intercompany flag on the group chart (decision 3). One row
    # per Published Intercompany Account; counterpart_account is the account the
    # partner books the other side on ('' = the same account).
    "epm_staging.intercompany_accounts": (
        "(main_account String, counterpart_account String, description String, "
        "status String) "
        "ENGINE = MergeTree ORDER BY main_account"
    ),
    # F2: the flat tree. Listed here because _RETIRED_COLUMNS ALTERs it — on a
    # stack that has never run dbt the table would not exist, the ALTER would
    # fail, and the sync after it would fail too, invisibly.
    "epm_staging.consolidation_hierarchy": (
        "(consolidation_group String, data_area_id String, "
        "parent_group String DEFAULT '', hierarchy_level UInt8 DEFAULT 1, "
        "path String DEFAULT '', updated_at DateTime DEFAULT now()) "
        "ENGINE = ReplacingMergeTree(updated_at) "
        "ORDER BY (consolidation_group, data_area_id)"
    ),
    # konsolidat#146: two more relations a dbt seed and this write-through both
    # owned — seeds materialise into epm_gold, so seeds/spread_profiles.csv WAS
    # epm_gold.spread_profiles. The seeds are deleted, so nothing else creates
    # these. The other three colliding relations (allocation_rules,
    # ic_elimination_rules, consolidation_adjustments) had no reader left once
    # their dbt models moved to the staging tables, so their legacy write-through
    # is gone entirely rather than given DDL here.
    "epm_gold.spread_profiles": (
        "(profile_id String, profile_name String, fiscal_period Int32, "
        "weight Float32) "
        "ENGINE = MergeTree ORDER BY (profile_id, fiscal_period)"
    ),
    # konsolidat#146: the top-down annual budget, from the Budget Annual Input
    # doctype. It was seeds/budget_annual_input.csv.
    #
    # konsol#287: neither budget table names a dimension. Which dim_* columns
    # they carry is the site's Published Dimensions ticked in_budget, added by
    # schema_apply._sync_budget_dimension_columns. They used to be created
    # with two customers' dimensions as literals, so a site budgeting by
    # dim_region wrote a column the table did not have, and the write-through
    # failed.
    "epm_gold.budget_annual_input": (
        "(scenario_id String, data_area_id String, fiscal_year UInt16, "
        "main_account String, "
        "annual_amount Decimal(18,2), spread_profile_id String, "
        "submitted_by String) "
        "ENGINE = MergeTree ORDER BY (scenario_id, data_area_id, fiscal_year, main_account)"
    ),
    # The bottom-up half, written by Budget Sheet. It has always been a konsol
    # write-through with NOTHING that creates it — no seed, no DDL — which is
    # why gold_spread_budget is one of the three baseline build failures
    # ("Unknown table expression identifier 'epm_gold.budget_monthly_input'").
    "epm_gold.budget_monthly_input": (
        "(scenario_id String, data_area_id String, fiscal_year UInt16, "
        "main_account String, "
        "fiscal_period UInt8, amount Decimal(18,2), layer String) "
        "ENGINE = MergeTree ORDER BY (scenario_id, data_area_id, fiscal_year, layer)"
    ),
    # konsolidat#146: which fiscal calendar each ERP legal entity posts against.
    # It was seeds/entity_fiscal_calendars.csv, and it decides which calendar
    # every GL line is dated into.
    "epm_gold.entity_fiscal_calendars": (
        "(data_area_id String, fiscal_calendar_id String) "
        "ENGINE = MergeTree ORDER BY data_area_id"
    ),
    # konsolidat#146: the ISO 4217 reference list. It was seeds/currencies.csv —
    # the one seed with no second writer, but still a table the warehouse
    # validates against living in the dbt repo rather than the app.
    "epm_gold.currencies": (
        "(currency_code String, currency_name String, symbol String, "
        "minor_unit UInt8, usd_log10 Float64 DEFAULT nan) "
        "ENGINE = MergeTree ORDER BY currency_code"
    ),
    "epm_gold.scenario_definitions": (
        "(scenario_id String, scenario_name String, scenario_type String, "
        "is_active Int32) "
        "ENGINE = MergeTree ORDER BY scenario_id"
    ),
    # F2: the link closure that makes consolidation multi-level. One row per
    # (ancestor group, entity, link between them), so dbt can multiply a chain of
    # dated ownership percentages without a recursive CTE.
    "epm_staging.consolidation_ancestry": (
        "(consolidation_group String, data_area_id String, link_group String, "
        "link_data_area_id String, link_depth UInt8, depth UInt8, path String) "
        "ENGINE = MergeTree ORDER BY (consolidation_group, data_area_id, link_depth)"
    ),
    # konsol#110: the governed entity registry, from the Entity doctype. The
    # warehouse knew entities only from ERP extraction, so one with no connector
    # had no accounting currency and was dropped at the consolidation join.
    "epm_staging.entities": (
        "(data_area_id String, entity_name String, parent_entity String, "
        "is_group UInt8, status String, accounting_currency String, "
        "country String, erp_source String) "
        "ENGINE = MergeTree ORDER BY data_area_id"
    ),
    # konsol#103: the governed group exchange rates, from Group Exchange Rate
    # (submitted rows only). gold_consolidated_trial_balance translates from
    # this, never from the ERP feed; `document` names the approving record.
    # `rate` is the TRUE rate, units of to_currency per 1 from_currency, as
    # Float64: konsol computes it once (quote / quoted_per) when it publishes,
    # and the warehouse never scales or inverts it. One source of truth for FX
    # rates (decided 13 Sep 2026).
    "epm_staging.group_exchange_rates": (
        "(to_currency String, from_currency String, fiscal_year UInt16, "
        "fiscal_period UInt8, rate_type String, rate Float64, document String) "
        "ENGINE = MergeTree ORDER BY (to_currency, from_currency, fiscal_year, fiscal_period, rate_type)"
    ),
    # konsol#182: the group chart of accounts, from Main Account (Published
    # rows, groups included). silver_main_accounts reads only this: there is no
    # ERP chart fallback (decided 13 Sep 2026). Identical to konsolidat's
    # clickhouse/init-db.sql; keep them identical. is_retained_earnings
    # (konsolidat#199) came after the table shipped: LAST here and in
    # _ADDED_COLUMNS, so a fresh table and an upgraded one agree.
    "epm_staging.main_accounts": (
        "(main_account String, account_name String, chart_of_accounts String, "
        "parent_account String, is_group UInt8, account_type String, "
        "statement_section String, sub_section String, normal_balance String, "
        "time_balance String, fx_method String, is_posting UInt8, "
        "is_suspended UInt8, allow_ic UInt8, cf_category String, "
        "cf_line_item String, is_cash UInt8, main_account_category String, "
        "status String, is_retained_earnings UInt8 DEFAULT 0) "
        "ENGINE = MergeTree ORDER BY main_account"
    ),
    # konsol#189: the declared fiscal periods, one row per Fiscal Year Period
    # (with the effective status); konsolidat reads it for period dates.
    # Identical to konsolidat's clickhouse/init-db.sql, keep them identical.
    "epm_staging.fiscal_periods": (
        "(fiscal_year UInt16, fiscal_period UInt8, period_code String, "
        "period_label String, period_type String, start_date Date, end_date Date, "
        "quarter String, status String) "
        "ENGINE = MergeTree ORDER BY (fiscal_year, fiscal_period)"
    ),
    # konsolidat#198 (design 2a): the deal documents. A Business Combination
    # (submitted rows only) is the declared input for goodwill, the fair-value
    # step-up and NCI at acquisition; a Business Disposal for the disposal
    # gain or loss. Each child table is its own doctype and syncs by
    # (parent, idx). The Result columns on the header are what konsol
    # computed with the group's Consolidation Policy, so dbt posts them and
    # never recomputes. Identical to konsolidat's clickhouse/init-db.sql;
    # keep them identical.
    "epm_staging.business_combinations": (
        "(name String, consolidation_group String, acquired_entity String, "
        "acquisition_date Date, share_acquired_pct Float64, "
        "consideration_currency String, total_consideration Float64, "
        "net_assets_acquired Float64, fair_value_adjustments Float64, "
        "goodwill Float64, bargain_purchase_gain Float64, "
        "nci_at_acquisition Float64, ownership_period String, "
        "nci_measurement String DEFAULT '', nci_fair_value Float64 DEFAULT 0) "
        "ENGINE = MergeTree ORDER BY name"
    ),
    "epm_staging.business_combination_consideration": (
        "(parent String, idx UInt16, component String, amount Float64, "
        "currency String, settlement_date Date, description String) "
        "ENGINE = MergeTree ORDER BY (parent, idx)"
    ),
    "epm_staging.business_combination_acquired_balances": (
        "(parent String, idx UInt16, main_account String, book_amount Float64, "
        "fair_value_adjustment Float64, note String) "
        "ENGINE = MergeTree ORDER BY (parent, idx)"
    ),
    "epm_staging.business_combination_costs": (
        "(parent String, idx UInt16, kind String, amount Float64, "
        "currency String, description String) "
        "ENGINE = MergeTree ORDER BY (parent, idx)"
    ),
    "epm_staging.business_disposals": (
        "(name String, consolidation_group String, disposed_entity String, "
        "disposal_date Date, share_disposed_pct Float64, "
        "retained_interest_pct Float64, proceeds_currency String, "
        "total_proceeds Float64, ownership_period String) "
        "ENGINE = MergeTree ORDER BY name"
    ),
    "epm_staging.business_disposal_proceeds": (
        "(parent String, idx UInt16, component String, amount Float64, "
        "currency String, settlement_date Date, description String) "
        "ENGINE = MergeTree ORDER BY (parent, idx)"
    ),
    # konsol#305-D2-11 (Deepak Pai, 27 Sep 2026): the Consolidation Journal's
    # warehouse table. The journal names its reversal period, so
    # auto_reverse_period is replaced by reverse_fiscal_year and
    # reverse_fiscal_period (0/0 = no reversal): LAST here and in
    # _ADDED_COLUMNS, and the old column is in _RETIRED_COLUMNS. konsol owns
    # the DDL from here on; keep it in sync with konsolidat's
    # clickhouse/init-db.sql, which follows it (V01). Deploy with V01 in one
    # window (Problems P24): the dbt model before V01 reads auto_reverse_period.
    "epm_staging.consolidation_adjustments": (
        "(consolidation_group String, adjustment_type String, journal_id String, "
        "data_area_id String, fiscal_year UInt16, fiscal_period UInt8, "
        "main_account String, debit_amount Decimal(18,2) DEFAULT 0, "
        "credit_amount Decimal(18,2) DEFAULT 0, description String DEFAULT '', "
        "posted_by String DEFAULT '', status String DEFAULT 'Approved', "
        "approved_by String DEFAULT '', approved_at DateTime DEFAULT '1970-01-01 00:00:00', "
        "reversal_journal_id String DEFAULT '', created_at DateTime DEFAULT now(), "
        "reverse_fiscal_year UInt16 DEFAULT 0, reverse_fiscal_period UInt8 DEFAULT 0) "
        "ENGINE = MergeTree() ORDER BY (consolidation_group, journal_id, fiscal_year, "
        "fiscal_period, main_account)"
    ),
}

# Relations a previous release wrote and this one abandoned. Nothing truncates a
# table once its last writer is gone, so the rows sit there forever looking live
# — konsolidat#146 left three of them holding whichever of `dbt seed` and
# `bench migrate` had written last, which is exactly the stale-second-source
# confusion this work exists to remove. Dropped outright; every dbt reader moved
# to the staging tables.
# Retired 11 Sep 2026 (konsolidat#146). This list is permanent and unconditional:
# if a future release legitimately recreates one of these relations it must be
# removed from here first, or every migrate will drop it again. Nothing may
# appear in both this and _REFERENCE_TABLE_DDL —
# test_abandoned_relations_are_dropped_not_left_looking_live asserts that.
_RETIRED_TABLES = (
    "epm_gold.allocation_rules",
    "epm_gold.ic_elimination_rules",
    "epm_gold.consolidation_adjustments",
    "epm_gold.allocation_drivers_headcount",
    "epm_gold.allocation_drivers_revenue",
    "epm_gold.allocation_drivers_sqm",
    # konsol#264 (Deepak Pai, 18 Sep 2026): cost allocation is removed
    # entirely. All four tables are EMPTY on every live stack — no migration,
    # no customer impact — so this is a plain DROP, not a data migration.
    # dbt's allocation models, macros and sources, and their CREATE TABLE
    # statements in konsolidat's clickhouse/init-db.sql, are already deleted.
    "epm_staging.allocation_rules",
    "epm_staging.allocation_drivers",
    "epm_staging.allocation_tiers",
    "epm_staging.allocation_runs",
)

# Whole databases a previous release created and this one abandoned. Separate
# from _RETIRED_TABLES because DROP TABLE leaves the empty database standing:
# konsolidat#226 found `epm_allocated` still in system.databases on the live
# stack after the allocation removal and its migrate, because deleting
# `CREATE DATABASE IF NOT EXISTS epm_allocated` from konsolidat's
# clickhouse/init-db.sql only stops a FRESH volume creating it.
#
# EMPTY-ONLY RULE — do not replace this with a bare `DROP DATABASE IF EXISTS`.
# Each name here is dropped only once system.tables reports the database holds
# no tables; a non-empty one is left alone and logged by name. What we are
# cleaning up is an empty leftover, and that is all we are entitled to clean
# up. A database someone has since put data in — a customer's own schema, a
# restored backup, a relation a later release recreates — is not ours to
# delete, and unlike a dropped table nobody would find out until they needed
# it. The check is enforced by
# test_a_retired_database_is_dropped_only_when_it_is_empty.
_RETIRED_DATABASES = (
    # konsolidat#226 / konsol#264: cost allocation is removed entirely. dbt's
    # allocation models were this database's only contents and are deleted, so
    # on a stack that ran the removal it is empty and goes; on one where it is
    # not, the rule above keeps it.
    "epm_allocated",
)

# Columns that a previous release created and F2 retired. ClickHouse keeps a
# column the writer stopped sending, silently filled with its default — an
# ownership percentage that no longer updates is exactly the kind of second
# source of truth this work exists to delete, so drop them outright.
_RETIRED_COLUMNS = {
    # ownership is temporal and lives only in Ownership Period now
    "epm_staging.consolidation_hierarchy": ["effective_ownership_pct"],
    "epm_gold.consolidation_groups": ["ownership_pct", "consolidation_method"],
    # konsol#197: no dbt model ever selected it — the cash-flow models read
    # is_cash, cf_category and cf_line_item and negate the movement themselves
    "epm_staging.cash_flow_categories": ["sign"],
    # konsol#305-D2-11: the journal names its reversal period
    # (reverse_fiscal_year, reverse_fiscal_period) instead
    "epm_staging.consolidation_adjustments": ["auto_reverse_period"],
}

# The trial-balance landing and control tables (F8). KEEP IN SYNC with
# clickhouse/init-db.sql in konsolidat, which creates them on a fresh volume.
# Trial Balance Submission lands and claims its rows here, and bronze reads
# raw INNER JOIN control. ReplacingMergeTree on the control table: a duplicated
# claim collapses instead of fanning out the bronze join.
_RAW_TABLE_DDL = {
    "epm_raw.trial_balance_submissions": (
        "(batch_id String, data_area_id String, fiscal_year UInt16, "
        "fiscal_period UInt8, main_account String, "
        "debit_amount Float64, credit_amount Float64, "
        "description String, submission_name String, submitted_at DateTime, "
        "partner_data_area_id String DEFAULT '') "
        "ENGINE = MergeTree ORDER BY (batch_id, main_account)"
    ),
    "epm_raw.trial_balance_submission_control": (
        "(batch_id String, submission_name String, data_area_id String, "
        "fiscal_year UInt16, fiscal_period UInt8, row_count UInt32, "
        "claimed_at DateTime, amount_basis String DEFAULT '') "
        "ENGINE = ReplacingMergeTree(claimed_at) ORDER BY batch_id"
    ),
}

# Columns a later release added to a table that already exists on older
# stacks. CREATE TABLE IF NOT EXISTS never touches an existing table, so each
# is added here too; ADD COLUMN IF NOT EXISTS is metadata-only and idempotent.
# The same column must be in the CREATE above, at the end, so a fresh table
# and an upgraded one agree.
_ADDED_COLUMNS = {
    # konsol#159: the intercompany partner on every trial balance row
    "epm_raw.trial_balance_submissions": [("partner_data_area_id", "String DEFAULT ''")],
    # konsolidat#199: what a claimed batch's amounts are (period movement,
    # year-to-date movement, period-end balance); '' = claimed before the
    # column existed, so not declared
    "epm_raw.trial_balance_submission_control": [("amount_basis", "String DEFAULT ''")],
    # konsolidat#199: the chart's retained-earnings account, which the year-end
    # close of a period-end-balance trial balance posts into
    "epm_staging.main_accounts": [("is_retained_earnings", "UInt8 DEFAULT 0")],
    # konsol#159: where a group books intercompany differences, and their tolerance
    "epm_gold.consolidation_groups": [
        ("ic_difference_account", "String DEFAULT ''"),
        ("ic_difference_tolerance", "Float64 DEFAULT 0"),
        # konsolidat#198: the Consolidation Policy and the declared accounts
        ("nci_measurement", "String DEFAULT ''"),
        ("accounting_framework", "String DEFAULT ''"),
        ("framework_note", "String DEFAULT ''"),
        ("goodwill_treatment", "String DEFAULT ''"),
        ("goodwill_amortisation_years", "UInt16 DEFAULT 0"),
        ("acquisition_costs_treatment", "String DEFAULT ''"),
        ("measurement_period", "String DEFAULT ''"),
        ("bargain_purchase", "String DEFAULT ''"),
        ("goodwill_account", "String DEFAULT ''"),
        ("fair_value_adjustment_account", "String DEFAULT ''"),
        ("investment_account", "String DEFAULT ''"),
        ("nci_account", "String DEFAULT ''"),
        ("bargain_purchase_gain_account", "String DEFAULT ''"),
        ("disposal_gain_loss_account", "String DEFAULT ''"),
        ("disposal_proceeds_account", "String DEFAULT ''"),
        ("goodwill_amortisation_expense_account", "String DEFAULT ''"),
        ("acquisition_costs_account", "String DEFAULT ''"),
    ],
    # konsol#204: the NCI measurement a deal was measured under and, under the
    # full method, the minority's declared fair value
    "epm_staging.business_combinations": [
        ("nci_measurement", "String DEFAULT ''"),
        ("nci_fair_value", "Float64 DEFAULT 0"),
    ],
    # konsol#220: the window of each dated Reporting Hierarchy member tranche
    "epm_staging.reporting_hierarchies": [
        ("member_effective_from", "Date32 DEFAULT '1900-01-01'"),
        ("member_effective_to", "Date32 DEFAULT '2299-12-31'"),
    ],
    # konsol#103: ISO Currency's magnitude reference for the group rate guard;
    # NaN until the ISO Currency write-through fills it
    "epm_gold.currencies": [("usd_log10", "Float64 DEFAULT nan")],
    # konsol#305-D2-11: the period a journal reverses in; 0/0 = no reversal
    "epm_staging.consolidation_adjustments": [
        ("reverse_fiscal_year", "UInt16 DEFAULT 0"),
        ("reverse_fiscal_period", "UInt8 DEFAULT 0"),
    ],
}


def _added_column_ddl(tables):
    return [f"ALTER TABLE {t} ADD COLUMN IF NOT EXISTS {c} {typ}"
            for t, cols in _ADDED_COLUMNS.items() if t in tables for c, typ in cols]


def ensure_raw_tables():
    """Create the trial-balance landing tables and add any newer columns.

    Raises on failure: a submission must never land rows into a table that is
    missing a column it writes. ensure_reference_tables() calls it best-effort,
    so a migrate also upgrades a stack nobody has submitted to since.
    """
    execute("CREATE DATABASE IF NOT EXISTS epm_raw")
    for table, body in _RAW_TABLE_DDL.items():
        execute(f"CREATE TABLE IF NOT EXISTS {table} {body}")
    for sql in _added_column_ddl(_RAW_TABLE_DDL):
        execute(sql)


def ensure_reference_tables():
    """Create the write-through reference tables, and drop the retired columns.

    Also adds the site's declared budget dimension columns to the two budget
    input tables, which name none (konsol#287). That step reads the Dimension
    registry, so it needs a site; outside one it is skipped with a warning,
    like every other step here.

    Best-effort and idempotent: CREATE TABLE IF NOT EXISTS never touches an
    existing table, and an unreachable ClickHouse must not fail a migrate — the
    sync that follows reports its own failure. Each statement is guarded on its
    own so a server that refuses CREATE DATABASE (the database already exists
    on every real stack) still gets its tables.

    Retired DATABASES (_RETIRED_DATABASES) are handled last and conditionally:
    each is dropped only if system.tables reports it holds nothing, so a
    migrate can clear an empty leftover without ever destroying a database
    someone put data in. See _retired_database_cleanup().
    """
    def _run(sql):
        try:
            execute(sql)
        except Exception:  # noqa: BLE001 — never fail a migrate over bootstrap DDL
            frappe.logger().warning(
                f"reference table bootstrap skipped: {sql[:60]}…", exc_info=True)

    for sql in [
        "CREATE DATABASE IF NOT EXISTS epm_staging",
        "CREATE DATABASE IF NOT EXISTS epm_gold",
        *[f"CREATE TABLE IF NOT EXISTS {t} {body}"
          for t, body in _REFERENCE_TABLE_DDL.items()],
        *_added_column_ddl(_REFERENCE_TABLE_DDL),
        *[f"ALTER TABLE {t} DROP COLUMN IF EXISTS {c}"
          for t, cols in _RETIRED_COLUMNS.items() for c in cols],
        *[f"DROP TABLE IF EXISTS {t}" for t in _RETIRED_TABLES],
        *_retired_watermark_cleanup(),
        # konsolidat#246: before reconcile_all stamps its run id
        *_watermark_upgrade_ddl(),
    ]:
        _run(sql)
    # konsolidat#226: the retired databases, built AFTER the loop above has
    # run — the emptiness check must see the post-drop state, so a database
    # whose last tables this very migrate removed is recognised as empty on
    # that same run rather than the next one.
    for sql in _retired_database_cleanup():
        _run(sql)
    # konsol#287: the budget input tables name no dimension, so the site's
    # declared budget dimensions are added here, the moment the tables exist.
    # reconcile_all calls this before it rewrites Budget Annual Input, so the
    # columns that rewrite names are there even on a fresh site. Imported here:
    # schema_apply imports this module.
    try:
        from konsol.schema_apply import _sync_budget_dimension_columns
        _sync_budget_dimension_columns()
    except Exception:  # noqa: BLE001 — never fail a migrate over bootstrap DDL
        frappe.logger().warning("budget dimension column sync skipped", exc_info=True)
    # konsol#159: the raw landing tables too, so a migrate adds the partner
    # column even on a stack where nobody has submitted a trial balance since
    # — bronze reads it.
    try:
        ensure_raw_tables()
    except Exception:  # noqa: BLE001 — never fail a migrate over bootstrap DDL
        frappe.logger().warning("raw table bootstrap skipped", exc_info=True)


def _retired_watermark_cleanup():
    """DELETE statements for retired tables' watermark rows — only if any exist.

    A retired table's stamp has to go with it: sync_table writes one per
    successful sync and assert_staging_not_stale compares them, so a row for a
    table that no longer has a writer stays frozen while every live table
    re-stamps, and the test reports it LAGGING and fails the build. It would
    also assert a row count for a relation that no longer exists.

    Checked first rather than issued blind, because ClickHouse records an entry
    in system.mutations for an `ALTER TABLE ... DELETE` even when it matches
    nothing — six of those per `bench migrate`, three times a day, forever. One
    SELECT replaces them, and after the first migrate there is nothing to do.
    """
    try:
        quoted = ", ".join(f"'{t}'" for t in _RETIRED_TABLES)
        stale = execute(
            f"SELECT DISTINCT table_name FROM {_WATERMARK_TABLE} "
            f"WHERE table_name IN ({quoted})"
        )
    except Exception:  # noqa: BLE001 — the watermark table may not exist yet
        return []
    return [
        f"ALTER TABLE {_WATERMARK_TABLE} DELETE WHERE table_name = '{name}'"
        for name in (line.strip() for line in stale.splitlines()) if name
    ]


def _retired_database_cleanup():
    """DROP DATABASE statements for _RETIRED_DATABASES — only for EMPTY ones.

    Never returns a bare `DROP DATABASE IF EXISTS`. Each retired name is asked
    about first — `SELECT name FROM system.tables WHERE database = ...` — and
    only a database that holds no tables is dropped. One that holds any is
    left exactly as it is and logged, naming the tables it holds.

    The reason is the asymmetry of the mistake. What konsolidat#226 is
    cleaning up is an empty leftover: `epm_allocated` survived the allocation
    removal because dropping its tables never drops the database, and removing
    `CREATE DATABASE` from init-db.sql only affects a fresh volume. Deleting
    that costs nobody anything. But this statement runs on every `bench
    migrate` on every stack, forever, and a `DROP DATABASE` is not recoverable
    from the warehouse — if anyone has put a table in a database that shares
    the name, an unconditional drop destroys it silently, on a migrate they
    ran for an unrelated reason. Emptiness is the one condition under which we
    can be sure we are deleting only our own leftover.

    Asking first also keeps the common case quiet: after the first migrate the
    database is gone, system.tables returns nothing for it, and the DROP that
    follows is a cheap no-op on an absent database.
    """
    statements = []
    for database in _RETIRED_DATABASES:
        try:
            found = execute(
                f"SELECT name FROM system.tables WHERE database = '{database}'")
        except Exception:  # noqa: BLE001 — unreachable server: try again next migrate
            frappe.logger().warning(
                f"retired database {database} not checked: system.tables "
                f"unreadable", exc_info=True)
            continue
        tables = sorted(line.strip() for line in found.splitlines() if line.strip())
        if tables:
            frappe.logger().warning(
                f"retired database {database} kept, not dropped: it holds "
                f"{len(tables)} table(s) — {', '.join(tables)}. Only an empty "
                f"retired database is dropped; drop these deliberately if they "
                f"are also abandoned."
            )
            continue
        statements.append(f"DROP DATABASE IF EXISTS {database}")
    return statements


def reconcile_all():
    """Re-sync every write-through table, regardless of document events.

    Syncing is driven entirely by on_update / on_submit / on_trash. A doctype
    that nobody touches therefore never re-syncs — and if its records vanish in
    a way that skips those hooks (a migration, a fixture reload, a site rebuilt
    against a ClickHouse volume that outlived it), the old rows stay in
    ClickHouse forever with nothing left to edit that would clear them.

    That is not hypothetical: epm_staging.ownership_periods held three rows
    dated 2026-06-19 for records Frappe no longer had, and one of them — AMDE at
    75% — was the ownership percentage every consolidated statement used, because
    gold_consolidated_trial_balance resolves ownership_periods before the
    hierarchy. Frappe's own Consolidation Group said 100%.

    TRUNCATE+INSERT means re-syncing an empty doctype empties its table, so this
    repairs exactly that class of drift. Best-effort per table: one
    misconfigured doctype must not stop the rest.

    Every watermark this call stamps carries one run id (konsolidat#246), set
    for the duration of the call and reset in a finally. The stamps are
    written as each table syncs, not collected for the end, so a reconcile
    that fails or is killed partway leaves its partial run in the watermark,
    where assert_staging_not_stale reports every table it did not reach.

    Returns a dict of table -> row count synced, for logging and tests.
    """
    ensure_reference_tables()

    run_id = _new_reconcile_run_id()
    frappe.logger().info(f"reconcile: run {run_id}")
    token = _reconcile_run_id.set(run_id)
    try:
        return _reconcile_tables()
    finally:
        _reconcile_run_id.reset(token)


def _reconcile_tables():
    """reconcile_all's loop: one sync per write-through table."""
    from frappe.model.base_document import get_controller

    synced = {}
    for doctype in _write_through_doctypes():
        try:
            cls = get_controller(doctype)
            if getattr(cls, "CH_TABLE", None):
                # The CH_LEGACY_FIELD_MAP alias is gone with the three "legacy
                # sync to gold.*" write-throughs it named (konsolidat#146): each
                # of those relations was also a dbt seed, and every dbt reader
                # moved to the staging table.
                _record(synced, cls.CH_TABLE,
                        sync_doctype(doctype, cls.CH_TABLE, cls.CH_FIELD_MAP,
                                     force=True))

            # The second table. Three controllers use the generic map pattern;
            # Consolidation Group computes its rows (tree walk) and exposes
            # resync_staging() for exactly this call. A doctype at 0 records
            # still syncs — TRUNCATE+INSERT of nothing empties the table,
            # which is the point.
            if getattr(cls, "resync_staging", None):
                _record(synced, cls.CH_STAGING_TABLE, cls.resync_staging(force=True))
            elif getattr(cls, "CH_STAGING_TABLE", None) and getattr(cls, "CH_STAGING_FIELD_MAP", None):
                _record(synced, cls.CH_STAGING_TABLE,
                        sync_doctype(doctype, cls.CH_STAGING_TABLE,
                                     cls.CH_STAGING_FIELD_MAP, force=True))
        except Exception:
            frappe.logger().warning(
                f"reconcile: {doctype} skipped", exc_info=True
            )
    return synced


def _record(synced, table, written):
    """Record what a sync actually wrote — ``None`` when it did not write.

    ``sync_table`` swallows connection/timeout/HTTP failures and returns None.
    This used to substitute ``frappe.db.count(doctype)`` for that None, so a
    reconcile that reached nothing still reported a row count per table and the
    migrate log read as a clean repair. A table that did not sync now says so,
    and the watermark (which is only stamped on success) agrees with it.
    """
    synced[table] = written
    if written is None:
        frappe.logger().warning(
            f"reconcile: {table} NOT synced — see the ClickHouse SYNC FAILED "
            f"entry above, or check_health()"
        )


def _write_through_doctypes():
    """Every konsol doctype whose controller declares a ClickHouse target."""
    # frappe.get_controller does not exist at the top level in v15 — it lives in
    # frappe.model.base_document. Importing it explicitly rather than reaching
    # through frappe keeps the failure loud if that ever moves again.
    from frappe.model.base_document import get_controller

    modules = frappe.get_all(
        "Module Def", filters={"app_name": "konsol"}, pluck="name"
    )
    if not modules:
        frappe.logger().warning("reconcile: no Module Def rows for app 'konsol'")
        return []
    found = []
    for doctype in frappe.get_all(
        "DocType", filters={"module": ["in", modules]}, pluck="name"
    ):
        try:
            cls = get_controller(doctype)
        except Exception:
            # A doctype without an importable controller simply has no CH target.
            continue
        staging = getattr(cls, "CH_STAGING_TABLE", None)
        if (getattr(cls, "CH_TABLE", None) and getattr(cls, "CH_FIELD_MAP", None)) \
                or (staging and getattr(cls, "resync_staging", None)) \
                or (staging and getattr(cls, "CH_STAGING_FIELD_MAP", None)):
            # Three ways to be a write-through doctype, and reconcile_all's body
            # already handles all three: a flat field-mapped gold table, rows
            # COMPUTED by resync_staging (Reporting Hierarchy, Consolidation
            # Group), or a field-mapped STAGING table with no gold counterpart.
            #
            # That last arm was missing. It did not matter while every such
            # controller also had a CH_TABLE — but konsolidat#146 deleted the
            # legacy gold write-through from Allocation Rule, IC Elimination
            # Rule and Consolidation Adjustment, and all three silently dropped
            # out of reconcile with it. Their staging tables would then never be
            # repaired after a fixture import, which is the drift reconcile
            # exists for. (Consolidation Adjustment itself was later retired
            # outright by konsol#292; its staging table, still named
            # consolidation_adjustments, now belongs to Consolidation Journal.)
            found.append(doctype)
    if not found:
        frappe.logger().warning(
            "reconcile: no write-through doctypes discovered — expected several; "
            "check that controllers still declare CH_TABLE/CH_FIELD_MAP"
        )
    return found
