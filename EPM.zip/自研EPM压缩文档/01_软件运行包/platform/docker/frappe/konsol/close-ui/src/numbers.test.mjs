// konsol#305 U41: numbers.test.mjs
//
// Exercises numbers.js against statement_api.get_statement's real payload
// shape (N51: konsol/close/statement_api.py, konsol/close/statement_model.py).
// The "ok" cases load the golden fixture statement_api's own host test
// commits (W4-E19) and build every other case as a mutation of it, never a
// hand-built payload.
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { createRouter, createMemoryHistory } from "vue-router";
import {
	statementView,
	tabRows,
	isDrillable,
	amountText,
	drillView,
	commentaryBody,
	canComment,
	commentaryByText,
	beforeAfter,
} from "./numbers.js";

const FIXTURE_PATH = fileURLToPath(
	new URL("../../konsol/tests/fixtures/close_statement_payload.json", import.meta.url),
);
// R41d's own golden fixture, generated from the real `_call(site)` producer
// in test_close_statement_api.py: an undeclared BS heading side, state
// "setup_gap" (S5). Used here to wire numbers.js up to it (R41i).
const SETUP_GAP_FIXTURE_PATH = fileURLToPath(
	new URL("../../konsol/tests/fixtures/close_statement_payload_setup_gap.json", import.meta.url),
);
const DRILL_FIXTURE_PATH = fileURLToPath(
	new URL("../../konsol/tests/fixtures/close_drill_payload.json", import.meta.url),
);
const JOURNAL_ITEM_FIXTURE_PATH = fileURLToPath(
	new URL("../../konsol/tests/fixtures/close_approvals_journal_item.json", import.meta.url),
);
const ROUTER_JS_PATH = fileURLToPath(new URL("./router.js", import.meta.url));

function golden() {
	return JSON.parse(readFileSync(FIXTURE_PATH, "utf8"));
}

function goldenSetupGap() {
	return JSON.parse(readFileSync(SETUP_GAP_FIXTURE_PATH, "utf8"));
}

function goldenDrill() {
	return JSON.parse(readFileSync(DRILL_FIXTURE_PATH, "utf8"));
}

// U1 (W4 review): a router built from router.js's OWN base and route
// pattern, read out of its source rather than copied by hand, so a change
// to either one breaks this test instead of leaving it silently stale.
// `createCloseRouter` itself can't run under plain `node --test`: it calls
// `createWebHistory` (needs `window.history`, absent in Node) and
// `import.meta.glob` (a Vite build-time macro) — router.test.mjs keeps the
// same boundary for `landingPath`. `createMemoryHistory` needs neither, and
// resolves through the identical route table vue-router would use at
// runtime.
function realRouteTable() {
	const source = readFileSync(ROUTER_JS_PATH, "utf8");
	const baseMatch = source.match(/createWebHistory\(\s*(["'])([^"']+)\1\s*\)/);
	const pathMatch = source.match(/\{\s*path:\s*(["'])([^"']+)\1,\s*component:\s*ScreenLoader/);
	assert.ok(baseMatch, "router.js: expected createWebHistory(\"...\") with a literal base");
	assert.ok(pathMatch, "router.js: expected a { path: \"...\", component: ScreenLoader } route");
	return createRouter({
		history: createMemoryHistory(baseMatch[2]),
		routes: [{ path: pathMatch[2], component: {} }],
	});
}

// W41's golden journal item (test_close_approvals_api.py, built from the REAL
// journal_model.statement_effect, never a JS port). Its two `effect.headings`
// entries are PL heading "4" (net_debit -500) and BS heading "2" (net_debit
// 500) — both present in the golden statement payload's chart (4100/2100,
// W41's fixture note).
function goldenJournalItem() {
	return JSON.parse(readFileSync(JOURNAL_ITEM_FIXTURE_PATH, "utf8"));
}

// The fixture's one commentary entry is at 2025-08-01T10:00:00+01:00, which
// is 10:00 local time in Europe/London in August (BST). `now` is later the
// same London calendar day, so formatTime's "today" branch applies.
const NOW = new Date("2025-08-01T18:00:00Z");
const TZ = "Europe/London";

// --- header, label, legend --------------------------------------------------

test("header names the period, group and currency", () => {
	const view = statementView(golden(), NOW, TZ);
	assert.equal(golden().period.code, "P07", "the fixture carries the live period_code shape");
	assert.equal(view.header, "Numbers · FY2025 P07 · G1 · USD");
});

test("U1: the header's period is the fiscal year and period, never the bare period_code", () => {
	for (const code of ["P07", "Jul", "", null]) {
		const p = golden();
		p.period.code = code;
		assert.equal(statementView(p, NOW, TZ).header, "Numbers · FY2025 P07 · G1 · USD", `code ${code}`);
	}
	const dec = golden();
	dec.period.fiscal_year = 2024;
	dec.period.fiscal_period = 12;
	dec.period.code = "P12";
	assert.equal(statementView(dec, NOW, TZ).header, "Numbers · FY2024 P12 · G1 · USD");
});

test("U1: a period with no fiscal year or period throws, naming the key, rather than a blank header", () => {
	for (const key of ["fiscal_year", "fiscal_period"]) {
		const p = golden();
		delete p.period[key];
		assert.throws(() => statementView(p, NOW, TZ), new RegExp(key));
	}
});

test("label follows the sign-off run, not the statement: provisional on the golden payload", () => {
	const view = statementView(golden(), NOW, TZ);
	assert.deepEqual(view.label, { text: "Provisional", tone: "warn" });
});

test("label: signed and resign_needed", () => {
	const signed = golden();
	signed.signoff.state = "signed";
	assert.deepEqual(statementView(signed, NOW, TZ).label, { text: "Signed", tone: "ok" });

	const resign = golden();
	resign.signoff.state = "resign_needed";
	assert.deepEqual(statementView(resign, NOW, TZ).label, {
		text: "Re-sign needed — numbers changed after signing",
		tone: "block",
	});
});

test("failure path: an unknown sign-off state throws", () => {
	const payload = golden();
	payload.signoff.state = "mystery";
	assert.throws(() => statementView(payload, NOW, TZ), /mystery/);
});

test("legend is the AMENDED 4 Oct wording, shown on an ok payload", () => {
	const view = statementView(golden(), NOW, TZ);
	assert.equal(
		view.legend,
		"Profit and loss: income positive, costs in brackets. Balance sheet: assets, liabilities and equity positive.",
	);
	assert.equal(view.legend, golden().statement.legend);
});

// U11: the legend is READ from `payload.statement.legend` on `ok`, not
// duplicated from this module's own constant — proven by mutating the
// fixture's own legend and checking the view follows it, not the constant.
test("U11: legend on an ok payload tracks payload.statement.legend, not this module's own constant", () => {
	const payload = golden();
	payload.statement.legend = "A changed legend from the server.";
	const view = statementView(payload, NOW, TZ);
	assert.equal(view.legend, "A changed legend from the server.");
});

// The non-ok states carry no `statement` to read a legend from, so this
// module's own constant is still shown there (the one declared exception).
test("legend on a non-ok payload falls back to this module's own constant (no statement to read)", () => {
	const payload = golden();
	payload.state = "no_chart";
	payload.message = "Publish the group chart (Main Account) first.";
	payload.statement = null;
	const view = statementView(payload, NOW, TZ);
	assert.equal(
		view.legend,
		"Profit and loss: income positive, costs in brackets. Balance sheet: assets, liabilities and equity positive.",
	);
});

// R41j (U8): `statement_api.get_statement` assigns `groups` unconditionally
// from `frappe.get_all(...)` before any state branch — never null. A null
// there is a broken contract.
test("failure path: a null groups throws, naming it", () => {
	const payload = golden();
	payload.groups = null;
	assert.throws(() => statementView(payload, NOW, TZ), /Numbers payload has no groups\./);
});

// R41j (U8): on `ok`, `_commentary(...)`'s dict is never null (see
// statementView's own comment) — a null there is a broken contract.
test("failure path: a null commentary on an ok payload throws, naming it", () => {
	const payload = golden();
	payload.commentary = null;
	assert.throws(() => statementView(payload, NOW, TZ), /Numbers payload has no commentary\./);
});

// R41j (U8): on `ok`, `not_included` is always a `{count, ...}` dict (set
// unconditionally by `get_statement`'s `ok` path, konsol/close/
// statement_api.py:427) — a null there is a broken contract, never "zero
// entities missing".
test("failure path: a null not_included on an ok payload throws, naming it", () => {
	const payload = golden();
	payload.not_included = null;
	assert.throws(() => statementView(payload, NOW, TZ), /Numbers: ok payload has no not_included\./);
});

// --- state, groupChoice, gapText, notIncluded -------------------------------

test("state is null and no group choice when the payload is ok", () => {
	const view = statementView(golden(), NOW, TZ);
	assert.equal(view.state, null);
	assert.equal(view.groupChoice, null);
	assert.equal(view.gapText, null);
	assert.equal(view.consolidationGroup, "G1");
});

// U5: the fixed client-side title is gone — the banner shows
// statement_api.get_statement's own two sentences verbatim
// (statement_api.py:351/354-356), one per number of declared groups.
test("choose_group, several groups declared: the server's own sentence, plus both to pick from", () => {
	const payload = golden();
	payload.groups = [
		{ consolidation_group: "G1", reporting_currency: "USD" },
		{ consolidation_group: "G2", reporting_currency: "EUR" },
	];
	payload.state = "choose_group";
	payload.message = "Choose a consolidation group.";
	payload.consolidation_group = null;
	payload.reporting_currency = null;
	payload.statement = null;
	const view = statementView(payload, NOW, TZ);
	assert.deepEqual(view.state, { kind: "choose_group", message: "Choose a consolidation group." });
	assert.deepEqual(view.groupChoice, ["G1", "G2"]);
	assert.equal(view.consolidationGroup, null);
	assert.deepEqual(view.tabs, []);
});

test("choose_group, zero groups declared: the server's own 'create one' sentence, and nothing to pick from", () => {
	const payload = golden();
	payload.groups = [];
	payload.state = "choose_group";
	payload.message = "No consolidation group is declared yet: create one in Consolidation Group.";
	payload.consolidation_group = null;
	payload.reporting_currency = null;
	payload.statement = null;
	const view = statementView(payload, NOW, TZ);
	assert.deepEqual(view.state, {
		kind: "choose_group",
		message: "No consolidation group is declared yet: create one in Consolidation Group.",
	});
	assert.equal(view.groupChoice, null, "nothing to switch to with zero declared groups");
});

// U5 "Related": once a group resolves (here, several groups exist but one
// is already chosen — an ordinary "ok" payload), the choice must still be
// offered — the fix is a switcher that is never one-way.
test("ok, several groups declared: groupChoice still offers every group, even though one is already chosen", () => {
	const payload = golden();
	payload.groups = [
		{ consolidation_group: "G1", reporting_currency: "USD" },
		{ consolidation_group: "G2", reporting_currency: "EUR" },
	];
	const view = statementView(payload, NOW, TZ);
	assert.equal(view.state, null);
	assert.deepEqual(view.groupChoice, ["G1", "G2"]);
	assert.equal(view.consolidationGroup, "G1");
});

test("no_chart/not_built/error/setup_gap show the server's own message, never tabs", () => {
	for (const [state, message] of [
		["no_chart", "Publish the group chart (Main Account) first."],
		["not_built", "ChRelationNotBuilt"],
		["error", "OSError (timeout)"],
		["setup_gap", "statement_heading_side_undeclared: 1 has no normal_balance declared."],
	]) {
		const payload = golden();
		payload.state = state;
		payload.message = message;
		payload.statement = null;
		const view = statementView(payload, NOW, TZ);
		assert.deepEqual(view.state, { kind: state, message });
		assert.deepEqual(view.tabs, []);
		assert.equal(view.comparisonNote, null);
	}
});

// R41d/R41i, S5: a real `setup_gap` payload (the golden fixture generated
// from the real producer) — a known state, never a thrown "unknown payload
// state", with the server's own message shown verbatim and no tabs.
test("setup_gap: the real R41d fixture's own sentence, no tabs, no comparisonNote", () => {
	const payload = goldenSetupGap();
	assert.equal(payload.state, "setup_gap", "fixture sanity: it really is the setup_gap state");
	const view = statementView(payload, NOW, TZ);
	assert.deepEqual(view.state, { kind: "setup_gap", message: payload.message });
	assert.match(view.state.message, /normal_balance/);
	assert.deepEqual(view.tabs, []);
	assert.equal(view.comparisonNote, null);
	// The fixture already has a group chosen (one declared group) — setup_gap
	// is a statement-building problem, not a group-choice one, so the group
	// is still resolved and there is nothing to switch between.
	assert.equal(view.consolidationGroup, "G1");
	assert.equal(view.groupChoice, null);
});

test("gapText carries the declared-accounts setup gap's message", () => {
	const payload = golden();
	payload.gap = { code: "statement_accounts_undeclared", message: "Declare the CTA account…" };
	const view = statementView(payload, NOW, TZ);
	assert.equal(view.gapText, "Declare the CTA account…");
});

test("notIncluded: singular, with no hidden suffix, all codes shown and no moreText on the golden payload", () => {
	const view = statementView(golden(), NOW, TZ);
	assert.equal(view.notIncluded.text, "1 entity in scope is not in these numbers");
	assert.deepEqual(view.notIncluded.codes, ["ZZB"]);
	assert.deepEqual(view.notIncluded.shown, ["ZZB"]);
	assert.equal(view.notIncluded.moreText, null);
	assert.equal(view.notIncluded.scopeText, null);
});

test("notIncluded: plural, and the out-of-scope suffix as its own field", () => {
	const payload = golden();
	payload.not_included = { count: 2, entities: ["CA_OVIVO", "US_OVIVO"], hidden: 3 };
	const view = statementView(payload, NOW, TZ);
	assert.equal(view.notIncluded.text, "2 entities in scope are not in these numbers");
	assert.deepEqual(view.notIncluded.shown, ["CA_OVIVO", "US_OVIVO"]);
	assert.equal(view.notIncluded.moreText, null);
	assert.equal(view.notIncluded.scopeText, "and 3 outside your scope");
});

test("notIncluded: null when nothing is missing", () => {
	const payload = golden();
	payload.not_included = { count: 0, entities: [], hidden: 0 };
	assert.equal(statementView(payload, NOW, TZ).notIncluded, null);
});

// L42b: L41 live showed 265 not-included entities as one unreadable block of
// codes. `codes` always carries the full list (never dropped); the screen
// shows only the first 10 (`shown`) plus a local-state "show all" toggle.
function notIncludedEntities(n) {
	return Array.from({ length: n }, (_, i) => `ZZ${String(i).padStart(3, "0")}`);
}

test("L42b: 265 not-included entities (the real L41 live count) — count sentence, full list kept, first 10 shown, moreText for the rest", () => {
	const payload = golden();
	payload.not_included = { count: 265, entities: notIncludedEntities(265), hidden: 0 };
	const view = statementView(payload, NOW, TZ);
	assert.equal(view.notIncluded.text, "265 entities in scope are not in these numbers");
	assert.equal(view.notIncluded.codes.length, 265, "the full list is never dropped");
	assert.deepEqual(view.notIncluded.shown, view.notIncluded.codes.slice(0, 10));
	assert.equal(view.notIncluded.shown.length, 10);
	assert.equal(view.notIncluded.moreText, "and 255 more");
	assert.equal(view.notIncluded.scopeText, null);
});

test("L42b: exactly 10 not-included entities — all shown, no moreText", () => {
	const payload = golden();
	payload.not_included = { count: 10, entities: notIncludedEntities(10), hidden: 0 };
	const view = statementView(payload, NOW, TZ);
	assert.equal(view.notIncluded.shown.length, 10);
	assert.equal(view.notIncluded.moreText, null);
});

test("L42b: 11 not-included entities — 10 shown, 'and 1 more'", () => {
	const payload = golden();
	payload.not_included = { count: 11, entities: notIncludedEntities(11), hidden: 0 };
	const view = statementView(payload, NOW, TZ);
	assert.equal(view.notIncluded.shown.length, 10);
	assert.equal(view.notIncluded.moreText, "and 1 more");
});

test("L42b: 265 not-included entities AND out-of-scope hidden — both suffixes are independent", () => {
	const payload = golden();
	payload.not_included = { count: 265, entities: notIncludedEntities(265), hidden: 7 };
	const view = statementView(payload, NOW, TZ);
	assert.equal(view.notIncluded.moreText, "and 255 more");
	assert.equal(view.notIncluded.scopeText, "and 7 outside your scope");
});

// --- tabs: Profit and Loss --------------------------------------------------

test("P&L tab: columns include Year to date; two rows, heading row carries commentary", () => {
	const view = statementView(golden(), NOW, TZ);
	const pl = view.tabs.find((t) => t.section === "Profit and Loss");
	assert.deepEqual(pl.columns, ["This period", "Comparison", "Variance", "Year to date"]);
	assert.deepEqual(tabRows(view, "Profit and Loss"), [
		{
			kind: "heading",
			heading: "4",
			label: "COST OF SALES",
			current: "241.43",
			comparison: "not loaded",
			variance: "not loaded",
			ytd: "241.43",
			commentary: { text: "Strong quarter.", byText: "Zz Analyst · 10:00" },
			commentable: true,
		},
		{
			kind: "net_result",
			label: "Net result",
			current: "241.43",
			comparison: "not loaded",
			variance: "not loaded",
			ytd: "241.43",
		},
	]);
});

// R41j (U8): `statement_model._pl_line` sets `"ytd"` on every Profit and
// Loss heading/no_heading/net_result line unconditionally
// (konsol/close/statement_model.py:275-296) — confirmed against
// close_statement_payload.json, where every P&L line carries it. A P&L
// line missing it is a broken contract: it must throw, naming the
// heading, never render "—" for a cell the server promised.
test("failure path: a P&L heading line missing ytd throws, naming the heading", () => {
	const payload = golden();
	const pl = payload.statement.sections.find((s) => s.section === "Profit and Loss");
	delete pl.lines.find((l) => l.kind === "heading").ytd;
	assert.throws(() => statementView(payload, NOW, TZ), /heading 4 has no ytd/);
});

test("failure path: a P&L net_result line missing ytd throws", () => {
	const payload = golden();
	const pl = payload.statement.sections.find((s) => s.section === "Profit and Loss");
	delete pl.lines.find((l) => l.kind === "net_result").ytd;
	assert.throws(() => statementView(payload, NOW, TZ), /Net result.*has no ytd/);
});

test("comparisonNote is carried from the statement, and drives the not-loaded cells", () => {
	const view = statementView(golden(), NOW, TZ);
	assert.equal(view.comparisonNote, "No rows in the warehouse for FY2025 P06");
});

// R41h/U7: a cleared commentary record (text: "") is still a record — the
// server keeps it (commentary_model.event_detail: a blank save is recorded,
// never omitted). The statement row must not show it as a byline-less
// comment ("" — Zz Analyst · 10:00"); it must read as having no commentary,
// same as a heading with no record at all.
test("U7: a cleared (blank-text) commentary entry renders as having no commentary — never an empty byline", () => {
	const payload = golden();
	payload.commentary["4"].text = "";
	const view = statementView(payload, NOW, TZ);
	const row = tabRows(view, "Profit and Loss").find((r) => r.kind === "heading");
	assert.equal(row.commentary, null, "a blank-text entry must not produce a commentary row");
});

test("isDrillable: only heading rows", () => {
	const view = statementView(golden(), NOW, TZ);
	const rows = tabRows(view, "Profit and Loss");
	assert.equal(isDrillable(rows[0]), true); // heading
	assert.equal(isDrillable(rows[1]), false); // net_result
});

// --- tabs: Balance Sheet -----------------------------------------------------

test("BS tab: no Year to date column; includes render as indented of-which rows; residual is ok at 0.00", () => {
	const view = statementView(golden(), NOW, TZ);
	const bs = view.tabs.find((t) => t.section === "Balance Sheet");
	assert.deepEqual(bs.columns, ["This period", "Comparison", "Variance"]);

	const rows = tabRows(view, "Balance Sheet");
	assert.deepEqual(
		rows.map((r) => r.kind),
		["heading", "heading", "heading", "cta", "current_year_result", "residual"],
	);
	assert.equal(rows.every((r) => !("ytd" in r)), true);

	const equity = rows[2];
	assert.equal(equity.heading, "3");
	assert.equal(equity.current, "931.40");
	assert.equal(isDrillable(equity), true);

	const ctaRow = rows[3];
	assert.equal(ctaRow.indent, true);
	assert.equal(ctaRow.label, "of which currency translation (CTA)");
	assert.equal(ctaRow.current, "5.07");
	assert.equal(ctaRow.comparison, "not loaded");
	assert.equal(isDrillable(ctaRow), false);

	const resultRow = rows[4];
	assert.equal(resultRow.current, "241.43");
	assert.equal(isDrillable(resultRow), false);

	const residual = rows[5];
	assert.equal(residual.tone, "ok");
	assert.equal(residual.current, "0.00");
	assert.equal("explained" in residual, false);
	assert.equal(isDrillable(residual), false);
});

test("failure path: a non-zero residual is block tone and shows both not-placed lines", () => {
	const payload = golden();
	const bsSection = payload.statement.sections.find((s) => s.section === "Balance Sheet");
	const residualLine = bsSection.lines.find((l) => l.kind === "residual");
	residualLine.current = 246.5;
	residualLine.explained = [
		{ label: "CTA not placed (declare the CTA account)", amount: -5.07 },
		{ label: "Current-year result not placed (declare the current-year result account)", amount: -241.43 },
	];
	residualLine.unexplained = 0;

	const view = statementView(payload, NOW, TZ);
	const residual = tabRows(view, "Balance Sheet").find((r) => r.kind === "residual");
	assert.equal(residual.tone, "block");
	assert.equal(residual.current, "246.50");
	assert.deepEqual(residual.explained, [
		{ label: "CTA not placed (declare the CTA account)", amount: "(5.07)" },
		{
			label: "Current-year result not placed (declare the current-year result account)",
			amount: "(241.43)",
		},
	]);
	assert.equal(residual.unexplained, "0.00");
});

// R41j (U8): `statement_model.statement` sets `explained`/`unexplained` on
// the residual line exactly when `residual_raw` is non-zero
// (konsol/close/statement_model.py:491-493) — the same condition this
// module uses for `tone === "block"`. So a block residual missing
// `explained` is a broken contract: it must throw, never silently read as
// "nothing to explain" via `|| []`.
test("failure path: a block residual missing explained throws", () => {
	const payload = golden();
	const bsSection = payload.statement.sections.find((s) => s.section === "Balance Sheet");
	const residualLine = bsSection.lines.find((l) => l.kind === "residual");
	residualLine.current = 246.5;
	residualLine.unexplained = 0;
	// explained deliberately left unset — a broken contract, not an empty list.
	assert.throws(() => statementView(payload, NOW, TZ), /block residual line has no explained/);
});

// --- failure paths that must throw -----------------------------------------

test("failure path: a missing top-level key throws, naming it", () => {
	const payload = golden();
	delete payload.statement;
	assert.throws(() => statementView(payload, NOW, TZ), /Numbers payload has no statement\./);
});

test("failure path: every required top-level key is checked", () => {
	for (const key of [
		"period",
		"groups",
		"consolidation_group",
		"group_note",
		"reporting_currency",
		"state",
		"message",
		"signoff",
		"gap",
		"not_included",
		"commentary",
		"can_comment",
	]) {
		const payload = golden();
		delete payload[key];
		assert.throws(
			() => statementView(payload, NOW, TZ),
			new RegExp(`Numbers payload has no ${key}\\.`),
			`expected a throw for missing ${key}`,
		);
	}
});

test("failure path: a null current cell throws rather than showing 0.00", () => {
	const payload = golden();
	const pl = payload.statement.sections.find((s) => s.section === "Profit and Loss");
	pl.lines.find((l) => l.kind === "heading").current = null;
	assert.throws(() => statementView(payload, NOW, TZ), /missing amount/);
});

test("failure path: an unknown line kind throws", () => {
	const payload = golden();
	const pl = payload.statement.sections.find((s) => s.section === "Profit and Loss");
	pl.lines.push({ kind: "mystery_kind", current: 1, comparison: null, variance: null });
	assert.throws(() => statementView(payload, NOW, TZ), /mystery_kind/);
});

test("failure path: an unknown includes kind throws", () => {
	const payload = golden();
	const bs = payload.statement.sections.find((s) => s.section === "Balance Sheet");
	const equity = bs.lines.find((l) => l.heading === "3");
	equity.includes.push({ kind: "mystery", label: "of which mystery", current: 1, comparison: null });
	assert.throws(() => statementView(payload, NOW, TZ), /mystery/);
});

test("failure path: an unknown statement section throws", () => {
	const payload = golden();
	payload.statement.sections.push({ section: "Cash Flow", lines: [] });
	assert.throws(() => statementView(payload, NOW, TZ), /Cash Flow/);
});

test("tabRows: an unknown section throws", () => {
	const view = statementView(golden(), NOW, TZ);
	assert.throws(() => tabRows(view, "Cash Flow"), /Cash Flow/);
});

// --- amountText --------------------------------------------------------------

test("amountText: 2dp, thousands grouping, negatives in brackets", () => {
	assert.equal(amountText(1234.5), "1,234.50");
	assert.equal(amountText(-1234.5), "(1,234.50)");
	assert.equal(amountText(0), "0.00");
	assert.equal(amountText(-0.0), "0.00");
});

test("amountText: null/undefined throws, never renders 0.00", () => {
	assert.throws(() => amountText(null), /missing amount/);
	assert.throws(() => amountText(undefined), /missing amount/);
});

// konsol#305 R41g/U2: amountText(NaN) used to return the string "NaN" — a
// silent fallback. NaN/Infinity are never a real amount, so they throw,
// naming the value, exactly like the null/undefined case above.
test("amountText: NaN/Infinity throws, never renders \"NaN\"", () => {
	assert.throws(() => amountText(NaN), /non-finite amount/);
	assert.throws(() => amountText(Infinity), /non-finite amount/);
	assert.throws(() => amountText(-Infinity), /non-finite amount/);
});

// --- drillView (U42) ---------------------------------------------------------
//
// Exercises drillView against statement_api.get_drill's real payload shape
// (N52: konsol/close/statement_api.py, konsol/close/drill_model.py). The "ok"
// case loads the golden fixture (close_drill_payload.json, N52's own host
// test commit); every other case is a mutation of it, never a hand-built
// payload.

test("drillView: entity rows carry entity codes, the CTA row has none", () => {
	const view = drillView(goldenDrill());
	const entityRows = view.rows.filter((r) => r.layer === "entity");
	assert.deepEqual(entityRows.map((r) => r.entity), ["ZZA", "ZZB", "ZZC"]);

	const cta = view.rows.find((r) => r.layer === "cta");
	assert.equal(cta.entity, null);
	assert.equal(cta.label, "Currency translation (CTA)");
});

test("drillView: an entity row's amount, accounts and tb source link", () => {
	const view = drillView(goldenDrill());
	const zza = view.rows.find((r) => r.layer === "entity" && r.entity === "ZZA");
	assert.equal(zza.amount, "300.00");
	assert.deepEqual(zza.accounts, [{ mainAccount: "1110", accountName: "Cash", amount: "300.00" }]);
	// U1 (W4 review): no `/close` prefix — the router's history base IS
	// `/close` (router.js's createWebHistory("/close")), so a route's own
	// path never repeats it. See "resolves through the real route table"
	// below, which proves this against router.js itself, not just a pinned
	// string.
	assert.equal(zza.link, "/2025/7/trial-balances");
});

test("drillView: an IC elimination row has no source link and no entity text", () => {
	const view = drillView(goldenDrill());
	const ic = view.rows.find((r) => r.layer === "ic_elimination");
	assert.equal(ic.entity, null);
	assert.equal(ic.label, "Intercompany eliminations");
	assert.equal(ic.link, null);
});

test("drillView: a top-side row's journals link to Adjustments, in the payload's own period", () => {
	const view = drillView(goldenDrill());
	const topside = view.rows.find((r) => r.layer === "topside");
	assert.equal(topside.entity, null);
	assert.equal(topside.label, "Top-side journals");
	assert.equal(topside.link, "/2025/7/adjustments"); // U1 (W4 review): no `/close` prefix
	assert.deepEqual(topside.journals, [
		{
			journalId: "J-1",
			description: "Reclass intercompany loan",
			amount: "40.00",
			postedBy: "alice@example.com",
			approvedBy: "bob@example.com",
			autoReversal: false,
		},
		{
			journalId: "J-2",
			description: "Accrue audit fee",
			amount: "10.00",
			postedBy: "alice@example.com",
			approvedBy: "bob@example.com",
			autoReversal: false,
		},
		{
			// #305 story 6.5: an earlier period's journal reversing here.
			journalId: "J-P6",
			description: "June bonus",
			amount: "(10.00)",
			postedBy: "alice@example.com",
			approvedBy: "bob@example.com",
			autoReversal: true,
		},
	]);
	assert.equal(topside.journalsBasis, "posted in this period (the heading's amount is cumulative)");
});

test("drillView: every drill source link resolves through router.js's REAL route table (U1)", () => {
	const router = realRouteTable();
	const view = drillView(goldenDrill());
	const links = view.rows.map((r) => r.link).filter((link) => link != null);

	assert.ok(links.length > 0, "fixture should produce at least one link to check");
	for (const link of links) {
		const resolved = router.resolve(link);
		assert.ok(resolved.matched.length > 0, `${link} matched 0 routes`);
		// The resolved href carries the router's own /close base exactly
		// once — this is what a broken /close/... link in the source
		// string would double up (U1's bug: matched: 0, href
		// /close/close/2025/7/trial-balances).
		assert.equal(resolved.href, `/close${link}`);
	}
});

test("drillView: dimensionsNote and heading/section are passed through", () => {
	const view = drillView(goldenDrill());
	assert.equal(view.heading, "1");
	assert.equal(view.headingName, "ASSETS");
	assert.equal(view.section, "Balance Sheet");
	assert.equal(view.dimensionsNote, "Not broken down by dimension yet (konsolidat#245).");
	assert.equal(view.state, null);
});

test("drillView: unknown layer labels are shown as sent, not rewritten", () => {
	const payload = goldenDrill();
	payload.drill.rows.push({
		layer: "some_future_adjustment_type",
		label: "some_future_adjustment_type",
		entity: null,
		amount: 12.34,
		accounts: [],
		source: null,
	});
	const view = drillView(payload);
	const row = view.rows.find((r) => r.layer === "some_future_adjustment_type");
	assert.equal(row.label, "some_future_adjustment_type");
	assert.equal(row.amount, "12.34");
});

test("failure path: a drill state other than ok shows the server message and no rows", () => {
	const payload = goldenDrill();
	payload.state = "error";
	payload.message = "OSError (timeout)";
	payload.drill = null;
	const view = drillView(payload);
	assert.deepEqual(view.state, { kind: "error", message: "OSError (timeout)" });
	assert.deepEqual(view.rows, []);
});

test("failure path: an unknown drill state throws", () => {
	const payload = goldenDrill();
	payload.state = "mystery";
	assert.throws(() => drillView(payload), /mystery/);
});

test("failure path: a missing top-level key throws, naming it", () => {
	for (const key of ["period", "consolidation_group", "heading", "state", "message", "drill"]) {
		const payload = goldenDrill();
		delete payload[key];
		assert.throws(
			() => drillView(payload),
			new RegExp(`Numbers payload has no ${key}\\.`),
			`expected a throw for missing ${key}`,
		);
	}
});

test("failure path: an unknown drill source kind throws", () => {
	const payload = goldenDrill();
	payload.drill.rows[0].source.kind = "mystery_source";
	assert.throws(() => drillView(payload), /mystery_source/);
});

// --- commentaryBody, canComment, commentaryByText (U42) -----------------------

test("commentaryBody: exactly the six M44 parameters, from the view and the given heading/text", () => {
	const body = commentaryBody(goldenDrill(), "1", "Strong quarter.", null);
	assert.deepEqual(body, {
		fiscal_year: 2025,
		fiscal_period: 7,
		consolidation_group: "G1",
		heading: "1",
		text: "Strong quarter.",
		modified: null,
	});
});

test("failure path: a body built from a draft carrying owner, docstatus, name has exactly the six keys", () => {
	const draft = {
		owner: "zz-analyst@example.com",
		docstatus: 0,
		name: "SC-G1-2025-7-1",
		modified: "2025-08-01 09:00:00.000000",
	};
	const body = commentaryBody(goldenDrill(), "1", "text", draft);
	assert.deepEqual(Object.keys(body).sort(), [
		"consolidation_group",
		"fiscal_period",
		"fiscal_year",
		"heading",
		"modified",
		"text",
	]);
	assert.equal(body.modified, "2025-08-01 09:00:00.000000");
});

test("commentaryBody: blank/whitespace text is carried through unchanged (a clear, not refused)", () => {
	const body = commentaryBody(goldenDrill(), "1", "   ", null);
	assert.equal(body.text, "   ");
});

test("canComment: true only when can_comment is exactly true", () => {
	const payload = golden();
	assert.equal(canComment(payload), true);

	payload.can_comment = false;
	assert.equal(canComment(payload), false);
});

test("failure path: canComment throws when can_comment is missing, never silently false", () => {
	const payload = golden();
	delete payload.can_comment;
	assert.throws(() => canComment(payload), /can_comment/);
});

test("commentaryByText: '<by> · <formatted time>', mirroring the statement row's own commentary text", () => {
	const entry = { text: "Strong quarter.", by: "Zz Analyst", at: "2025-08-01T10:00:00+01:00" };
	const text = commentaryByText(entry, NOW, TZ);
	assert.equal(text, "Zz Analyst · 10:00");
});

// --- beforeAfter (W42) -------------------------------------------------------
//
// W42 was blocked until N54 added each heading line's own display-sign
// multiplier (`line.sign`) to statement_model's payload. beforeAfter reads
// that sign straight off the matched heading row of the real statement
// payload riding along on `view.statement` — it never re-derives the
// Debit/Credit -> multiplier mapping and never hardcodes a heading code.
// change = sign * net_debit (the 4 Oct amendment to #305-W4-2 2a-ii; the
// pre-amendment "-net_debit for P&L, net_debit for BS" formula is stale).

test("beforeAfter: BS liability heading — the amended per-heading sign turns a debit paydown into a reduction", () => {
	const view = statementView(golden(), NOW, TZ);
	const item = goldenJournalItem();
	const rows = beforeAfter(item.effect, view);

	const liability = rows.find((r) => r.heading === "2");
	// golden statement: heading "2" LIABILITIES, current 803.70, sign -1
	// (Credit-normal). net_debit +500 (a paydown) -> change = -1 * 500 =
	// -500 -> after 303.70, never the stale formula's 1303.70.
	assert.deepEqual(liability, {
		section: "Balance Sheet",
		heading: "2",
		headingName: "Liabilities",
		before: "803.70",
		change: "(500.00)",
		after: "303.70",
	});
});

test("beforeAfter: P&L heading — reuses the section-wide -1 flip", () => {
	const view = statementView(golden(), NOW, TZ);
	const item = goldenJournalItem();
	const rows = beforeAfter(item.effect, view);

	const pl = rows.find((r) => r.heading === "4" && r.section === "Profit and Loss");
	// golden statement: PL heading "4", current 241.43, sign -1. net_debit
	// -500 -> change = -1 * -500 = 500 -> after 741.43.
	assert.deepEqual(pl, {
		section: "Profit and Loss",
		heading: "4",
		headingName: "Revenue",
		before: "241.43",
		change: "500.00",
		after: "741.43",
	});
});

test("failure path: a heading in the effect absent from the statement shows 'not in the statement', after null", () => {
	const view = statementView(golden(), NOW, TZ);
	const item = goldenJournalItem();
	item.effect.headings[0].heading = "99";
	item.effect.headings[0].heading_name = "Mystery";

	const rows = beforeAfter(item.effect, view);
	const missing = rows.find((r) => r.heading === "99");
	assert.deepEqual(missing, {
		section: "Profit and Loss",
		heading: "99",
		headingName: "Mystery",
		before: "not in the statement",
		change: null,
		after: null,
	});
});

test("failure path: a view in a non-ok state throws", () => {
	const payload = golden();
	payload.state = "error";
	payload.message = "OSError (timeout)";
	payload.statement = null;
	const view = statementView(payload, NOW, TZ);
	const item = goldenJournalItem();
	assert.throws(() => beforeAfter(item.effect, view), /state/);
});

// konsol#305 R41g/U2: a heading whose net_debit is missing/non-finite (the
// shape `approvals.js`'s `effectView` produces, which has no `net_debit` at
// all) must throw through amountText rather than render "NaN" for change/
// after. This is beforeAfter's own non-finite guard, exercised directly
// (Approvals.vue's screen-level regression test lives in
// screens/approvals.screen.test.mjs).
test("failure path: beforeAfter throws (never \"NaN\") when a heading's net_debit is not a finite number", () => {
	const view = statementView(golden(), NOW, TZ);
	const item = goldenJournalItem();
	item.effect.headings[0].net_debit = undefined;
	assert.throws(() => beforeAfter(item.effect, view), /non-finite amount/);
});

// --- module hygiene ----------------------------------------------------------

// route.test.mjs (B07) already scans every file under close-ui/src for the
// browser-storage literal, this test file included — no copy of that check
// (and no copy of the literal itself) belongs here.
test("the source imports no vue, frappe or xstate", () => {
	const path = fileURLToPath(new URL("./numbers.js", import.meta.url));
	const source = readFileSync(path, "utf8");
	for (const term of ["vue", "frappe", "xstate"]) {
		assert.ok(!source.includes(`"${term}`) && !source.includes(`'${term}`), `unexpected import of ${term}`);
	}
});
