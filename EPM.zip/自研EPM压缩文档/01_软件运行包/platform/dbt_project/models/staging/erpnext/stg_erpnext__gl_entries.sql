{{ config(enabled = 'erpnext' in var('erp_sources', [])) }}
{#
    Enabled here, not in dbt_project.yml: var() inside a dbt_project.yml
    +enabled config does not see the project's own vars: block and silently
    falls back to the default, while this model body does see it. That
    disagreement disabled these models while the canonical loop still
    ref'd them, which failed the whole dbt parse.
#}
{#
    ERPNext GL entries adapter.
    Maps the `GL Entry` doctype → canonical stg_gl_entries schema.

    ERPNext stores each posting as a separate debit OR credit row (one of the
    two is always zero) with analytical dimensions carried as flat columns
    (cost_center, project) rather than D365's LedgerDimensionValuesJson blob.

    record_id: ERPNext `name` is a string ("ACC-GLE-2024-00001"); the canonical
    record_id is numeric (D365 SourceKey) and bronze casts it via toInt64.
    We derive a deterministic Int64 surrogate from the name hash so the column
    is numeric, stable across runs, and UNION-compatible with the D365 adapter.

    amount: ERPNext's per-row debit/credit collapse to a single SIGNED amount
    (amount = debit - credit). Silver derives debit/credit from the SIGN of that
    amount (positive = debit, negative = credit), so no separate flag is needed.

    Dimension values are emitted raw here; harmonization to canonical values
    happens centrally in the canonical stg_gl_entries model (keyed on the
    per-row erp_source), so every adapter benefits without restating columns.

    Adapter contract (signed amounts, canonical columns, balance tests):
    models/staging/README.md. test_canonical_gl_journals_balance fails the
    build, naming the voucher_no, when a voucher does not net to zero.
    Known gap: amount is not cast, so a Float64 debit/credit feed fails the
    canonical UNION with D365's Decimal(38, 9) (NO_COMMON_TYPE).
#}

select
    'erpnext' as erp_source,
    reinterpretAsInt64(cityHash64(coalesce(name, ''))) as record_id,
    upper(coalesce(company, '')) as entity_id,
    toString(substring(coalesce(toString(posting_date), '1900-01-01'), 1, 10)) as posting_date,
    toInt32OrZero(substring(coalesce(fiscal_year, ''), 1, 4)) as fiscal_year,
    toMonth(toDate(substring(coalesce(toString(posting_date), '1900-01-01'), 1, 10))) as fiscal_period,
    coalesce(account, '') as main_account,
    '' as account_name,
    coalesce(debit, 0) - coalesce(credit, 0) as amount,
    coalesce(debit, 0) - coalesce(credit, 0) as transaction_currency_amount,
    coalesce(account_currency, '') as transaction_currency,
    coalesce(remarks, against, '') as description,
    coalesce(voucher_no, '') as journal_number,
    coalesce(voucher_type, '') as posting_type,
    coalesce(account, '') as ledger_account,
    {# konsol#159: NULL until an ERP mapping exists (ERPNext's `party` is a
       customer or supplier, not a group entity). #}
    cast(null as Nullable(String)) as partner_data_area_id,
    coalesce(cost_center, '') as dim_cost_center,
    '' as dim_department,
    coalesce(project, '') as dim_business_unit,
    _airbyte_extracted_at as _loaded_at,
    _airbyte_raw_id as _raw_id
from {{ source('erpnext_raw', 'gl_entry') }}
where coalesce(toString(is_cancelled), '0') not in ('1', 'yes', 'true')
