{{ config(enabled = 'd365_fo' in var('erp_sources', [])) }}
{#
    D365 F&O GL entries adapter.
    Joins GeneralJournalAccountEntryBiEntities with GeneralJournalEntryBiEntities.
    Parses LedgerDimensionValuesJson for MainAccount and dimension values.
    Output matches canonical stg_gl_entries schema.

    NOTE: D365 stores both debits and credits as a SIGNED AccountingCurrencyAmount.
    We pass the signed amount through; silver derives debit/credit from its sign
    (debit - credit = amount). The legacy IsCredit flag is not carried — it never
    drives the split (konsolidat#118).

    The amount must arrive SIGNED. A source that ships magnitudes plus a flag
    books every credit as a debit, and every trial balance goes one-sided
    (konsolidat#155: the demo generator did exactly that).
    assert_d365_gl_vouchers_balance fails the build, naming the voucher, when a
    voucher does not net to zero here.

    Adapter contract (signed amounts, canonical columns, balance tests):
    models/staging/README.md.
    partner_data_area_id (konsol#159) is NULL: D365's intercompany partner is
    not mapped from the ledger yet, so no D365 line is ever eliminated as
    intercompany (an intercompany account's D365 rows show as unmatched).
    Replace the NULL when an ERP mapping exists.
#}

with entries as (
    select * from {{ source('d365_raw', 'general_journal_account_entry_bi_entities') }}
),

headers as (
    select * from {{ source('d365_raw', 'general_journal_entry_bi_entities') }}
),

joined as (
    select
        -- Canonical columns
        'd365_fo' as erp_source,
        entries.SourceKey as record_id,
        upper(coalesce(headers.SubledgerVoucherDataAreaId, '')) as entity_id,
        toString(substring(coalesce(toString(headers.AccountingDate), '1900-01-01'), 1, 10)) as posting_date,
        coalesce(headers.FiscalCalendarYear, 0) as fiscal_year,
        coalesce(headers.FiscalCalendarPeriod, 0) as fiscal_period,
        coalesce(
            JSON_VALUE(
                replaceAll(coalesce(entries.LedgerDimensionValuesJson, '[]'), '''', '"'),
                '$[0].MAINACCOUNT'
            ),
            splitByChar('-', coalesce(entries.LedgerAccount, ''))[1]
        ) as main_account,
        '' as account_name,
        entries.AccountingCurrencyAmount as amount,
        coalesce(entries.ReportingCurrencyAmount, 0) as reporting_currency_amount,
        coalesce(entries.TransactionCurrencyAmount, 0) as transaction_currency_amount,
        coalesce(entries.TransactionCurrencyCode, '') as transaction_currency,
        coalesce(entries.Text, '') as description,
        coalesce(headers.JournalNumber, '') as journal_number,
        coalesce(entries.PostingType, '') as posting_type,
        coalesce(entries.LedgerAccount, '') as ledger_account,
        cast(null as Nullable(String)) as partner_data_area_id,
        coalesce(
            JSON_VALUE(
                replaceAll(coalesce(entries.LedgerDimensionValuesJson, '[]'), '''', '"'),
                '$[0].COSTCENTER'
            ),
            ''
        ) as dim_cost_center,
        coalesce(
            JSON_VALUE(
                replaceAll(coalesce(entries.LedgerDimensionValuesJson, '[]'), '''', '"'),
                '$[0].DEPARTMENT'
            ),
            ''
        ) as dim_department,
        coalesce(
            JSON_VALUE(
                replaceAll(coalesce(entries.LedgerDimensionValuesJson, '[]'), '''', '"'),
                '$[0].BUSINESSUNIT'
            ),
            ''
        ) as dim_business_unit,
        entries._airbyte_extracted_at as _loaded_at,
        entries._airbyte_raw_id as _raw_id,
        entries.GeneralJournalEntry as general_journal_entry_recid
    from entries
    left join headers
        on entries.GeneralJournalEntry = headers.SourceKey
)

select * from joined
