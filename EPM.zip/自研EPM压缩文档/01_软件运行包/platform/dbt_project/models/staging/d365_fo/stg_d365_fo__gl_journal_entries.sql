{{ config(enabled = 'd365_fo' in var('erp_sources', [])) }}
{#
    D365 F&O GL journal entry headers.
    Internal helper — not part of canonical interface.
    Maps GeneralJournalEntryBiEntities fields.
#}

select
    SourceKey as RecId,
    upper(coalesce(SubledgerVoucherDataAreaId, '')) as dataAreaId,
    toString(substring(coalesce(toString(AccountingDate), '1900-01-01'), 1, 10)) as AccountingDate,
    coalesce(JournalNumber, '') as JournalNumber,
    coalesce(JournalCategory, '') as JournalCategory,
    coalesce(DocumentNumber, '') as DocumentNumber,
    toString(substring(coalesce(toString(DocumentDate), '1900-01-01'), 1, 10)) as DocumentDate,
    coalesce(SubledgerVoucher, '') as Description,
    coalesce(PostingLayer, '') as PostingLayer,
    toString(coalesce(FiscalCalendarPeriod, 0)) as FiscalCalendarPeriod,
    coalesce(FiscalCalendarYear, 0) as FiscalCalendarYear,
    _airbyte_extracted_at,
    _airbyte_raw_id
from {{ source('d365_raw', 'general_journal_entry_bi_entities') }}
