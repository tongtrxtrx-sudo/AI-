{# konsolidat#206: gold_variance_at_hierarchy_node keeps each budget scenario
   apart. gold_variance_analysis has one set of rows per active budget-type
   scenario (budget_scenario_id), the actuals repeated against each. Summed
   over the leaf rows (hierarchy_is_group = 0) of one hierarchy and dimension,
   the node model's actual_amount for a (budget_scenario_id, entity, year,
   period, account) must equal gold_variance_analysis' actual_amount over the
   rows whose dimension value is a leaf of that hierarchy. So must its
   budget_amount (PR #211 review 4): a node that adds two budget scenarios
   together, or shows one scenario's budget under another, fails. The budget
   is compared NULL-safely: two missing budgets (null) agree, and a null
   against a number differs.

   A node model that does not carry budget_scenario_id is compared on the rest
   of the key, so each budget scenario's actuals meet the node's sum across
   scenarios: with two budget scenarios the actuals are counted twice and the
   test fails rather than erroring. One row per mismatched key.

   Output aliases differ from the joined columns' names: ClickHouse strips the
   qualifier from the left table's columns in a join, so a same-named alias
   would shadow them. #}

{% set node_cols = [] %}
{% if execute %}
    {% set node_cols = adapter.get_columns_in_relation(ref('gold_variance_at_hierarchy_node')) | map(attribute='name') | list %}
{% endif %}
{% set node_has_scenario = 'budget_scenario_id' in node_cols %}

with leaves as (
    select hierarchy_name, dimension, member_code, member_effective_from, member_effective_to
    from {{ ref('gold_reporting_hierarchy') }}
    where is_group = 0
),

{# konsolidat#220: a code may be a leaf in several dated tranches (a moved leaf). A variance row matches only the
   leaf tranche whose window covers its period's end_date (declared calendar, epm_staging.fiscal_periods; a period
   the calendar does not list is judged at the last day of its month), or its amount is counted once per tranche. #}
periods as (
    select
        toUInt16(fiscal_year) as fiscal_year,
        toUInt16(fiscal_period) as fiscal_period,
        max(end_date) as end_date
    from {{ source('epm_staging', 'fiscal_periods') }}
    group by fiscal_year, fiscal_period
),

variance_dated as (
    select
        vd.*,
        {# an unmatched LEFT JOIN row carries Date's default (1970-01-01), not NULL #}
        if(
            p.end_date = toDate(0),
            toLastDayOfMonth({{ build_date_from_year_period('vd.fiscal_year', 'vd.fiscal_period') }}),
            p.end_date
        ) as period_end_date
    from (
        {{ variance_dimension_long_sql('v') }}
    ) as vd
    left join periods as p
        on p.fiscal_year = toUInt16(vd.fiscal_year)
        and p.fiscal_period = toUInt16(vd.fiscal_period)
),

expected as (
    select
        l.hierarchy_name as hierarchy_name,
        l.dimension as dimension,
        vl.budget_scenario_id as budget_scenario_id,
        vl.data_area_id as data_area_id,
        vl.fiscal_year as fiscal_year,
        vl.fiscal_period as fiscal_period,
        vl.main_account as main_account,
        sum(vl.actual_amount) as actual_amount,
        sum(vl.budget_amount) as budget_amount
    from variance_dated as vl
    inner join leaves as l
        on l.dimension = vl.hierarchy_dimension
        and l.member_code = vl.dimension_member_code
    where vl.period_end_date >= l.member_effective_from
      and vl.period_end_date <= l.member_effective_to
    group by
        l.hierarchy_name, l.dimension, vl.budget_scenario_id,
        vl.data_area_id, vl.fiscal_year, vl.fiscal_period, vl.main_account
),

node as (
    select
        nm.hierarchy_name as node_hierarchy,
        nm.hierarchy_dimension as node_dimension,
        {% if node_has_scenario %}nm.budget_scenario_id as node_scenario,{% endif %}
        nm.data_area_id as node_entity,
        nm.fiscal_year as node_year,
        nm.fiscal_period as node_period,
        nm.main_account as node_account,
        sum(nm.actual_amount) as node_actual,
        sum(nm.budget_amount) as node_budget
    from {{ ref('gold_variance_at_hierarchy_node') }} as nm
    where nm.hierarchy_is_group = 0
    group by
        node_hierarchy, node_dimension, {% if node_has_scenario %}node_scenario,{% endif %}
        node_entity, node_year, node_period, node_account
)

select
    if(coalesce(e.hierarchy_name, '') != '', e.hierarchy_name, n.node_hierarchy) as hierarchy,
    if(coalesce(e.hierarchy_name, '') != '', e.dimension, n.node_dimension) as dimension_column,
    if(coalesce(e.hierarchy_name, '') != '', e.budget_scenario_id, {% if node_has_scenario %}n.node_scenario{% else %}''{% endif %}) as scenario_id,
    if(coalesce(e.hierarchy_name, '') != '', e.data_area_id, n.node_entity) as entity,
    if(coalesce(e.hierarchy_name, '') != '', e.fiscal_year, n.node_year) as key_year,
    if(coalesce(e.hierarchy_name, '') != '', e.fiscal_period, n.node_period) as key_period,
    if(coalesce(e.hierarchy_name, '') != '', e.main_account, n.node_account) as account,
    e.actual_amount as analysis_actual_amount,
    n.node_actual as node_actual_amount,
    e.budget_amount as analysis_budget_amount,
    n.node_budget as node_budget_amount
from expected as e
full outer join node as n
    on e.hierarchy_name = n.node_hierarchy
    and e.dimension = n.node_dimension
    and e.data_area_id = n.node_entity
    and e.fiscal_year = n.node_year
    and e.fiscal_period = n.node_period
    and e.main_account = n.node_account
    {% if node_has_scenario %}and e.budget_scenario_id = n.node_scenario{% endif %}
where coalesce(e.hierarchy_name, '') = ''
   or coalesce(n.node_hierarchy, '') = ''
   or abs(toFloat64(e.actual_amount) - toFloat64(n.node_actual)) > {{ materiality_floor() }}
   {# NULL-safe, spelled out (isNotDistinctFrom in this WHERE was a Database
      Error on the stack's ClickHouse): null against a number differs, two
      nulls agree, two numbers differ beyond the floor #}
   or (e.budget_amount is null) != (n.node_budget is null)
   or abs(toFloat64(e.budget_amount) - toFloat64(n.node_budget)) > {{ materiality_floor() }}
