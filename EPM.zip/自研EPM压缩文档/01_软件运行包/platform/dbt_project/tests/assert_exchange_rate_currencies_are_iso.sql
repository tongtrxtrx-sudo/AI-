-- grynn-in/konsolidat#91: every currency code used in FX must be a known ISO 4217
-- code present in the currencies seed. from_currency / to_currency are otherwise
-- unvalidated free strings — a typo or an unmapped code silently mis-translates
-- (or drops to the 1.0 fallback) instead of failing the build.
--
-- Uses NOT IN (not a left-join null check): ClickHouse left joins fill a miss
-- with the column default ('') rather than NULL when join_use_nulls=0.
--
-- konsol#182: no ERP quotes built (a trial-balance-only site, or a selection
-- that does not build silver_exchange_rates) means nothing to check.

{%- set quotes = erp_rate_quotes_relation() %}
{% if execute and quotes is none %}

select '' as currency_code where 0

{% else %}

with used as (
    select from_currency as currency_code from {{ ref('silver_exchange_rates') }}
    union distinct
    select to_currency as currency_code from {{ ref('silver_exchange_rates') }}
)

select currency_code
from used
where currency_code != ''
  {# konsolidat#146: published by konsol's ISO Currency doctype, not a seed in
     this repo and NOT from Frappe's own Currency doctype — that one is
     autonamed on the display name, so giving a code its real name renames the
     record, and it ships fraction_units = 100 for every currency including the
     zero-decimal ones. See the ISO Currency controller docstring. Wiring Frappe
     Currency to this table would recreate the second writer #146 removed. #}
  and currency_code not in (
      select currency_code from {{ source('epm_gold', 'currencies') }}
  )

{% endif %}
