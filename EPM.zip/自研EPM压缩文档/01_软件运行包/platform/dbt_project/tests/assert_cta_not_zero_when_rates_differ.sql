-- PRD-2 Test: CTA must be non-zero when an entity-period translated at more than one rate.
--
-- What CTA is: gold_fx_revaluation.cta_amount is the residual of currency translation,
-- -sum(group_amount) per entity-period. Balance-sheet rows translate at the closing
-- rate, P&L rows at the average rate and (with an approved Historical Equity Rate)
-- equity rows at that historical rate. Because the local trial balance sums to zero,
-- the translated one only fails to sum to zero when more than one rate was applied; that gap is
-- the CTA.
--
-- When CTA must be non-zero: an entity-period in which at least one row translated at
-- a rate other than its closing_rate. A zero CTA there means gold_fx_revaluation lost
-- the residual, and this test flags it.
--
-- Why a rate difference alone is not enough: closing_rate != average_rate only says
-- two rates were *available*. A balance-sheet-only entity (no P&L rows, no historical
-- equity rate) translates every row at closing_rate, so its CTA is 0 by construction
-- and must not be flagged (konsolidat#195). Since konsolidat#176 a missing historical
-- equity rate is a warning, not an error, and such equity rows fall back to the
-- closing rate, which makes balance-sheet-only entities with CTA 0 a normal case.
-- Hence the extra `countIf(translation_rate != closing_rate and group_amount != 0) > 0`
-- condition below (a row that put nothing into the group translated nothing, whatever its rate).
--
-- konsolidat#259 (option #259-1, 6 Oct 2026): an entity-period that carries the year-end close
-- silver_tb_movements synthesizes is not checked. Its P&L reversal translates at the average
-- rate, but retained earnings takes exactly the translated result, so its CTA is 0 by
-- construction; assert_year_end_close_carries_no_cta requires that 0.
with rate_check as (
    select
        consolidation_group,
        data_area_id,
        fiscal_year,
        fiscal_period,
        max(closing_rate) as max_closing_rate,
        max(average_rate) as max_average_rate
    from {{ ref('gold_consolidated_trial_balance') }}
    where accounting_currency != reporting_currency
      and (data_area_id, fiscal_year, fiscal_period) not in (
          select data_area_id, fiscal_year, fiscal_period
          from {{ ref('gold_trial_balance_by_partner') }}
          where is_year_end_close = 1
      )
    group by consolidation_group, data_area_id, fiscal_year, fiscal_period
    -- Not `closing_rate != average_rate`: with equal closing and average rates an
    -- equity row at a historical rate still produces a residual, and that CTA
    -- must not be 0 either. translation_rate is Nullable: a NULL comparison is
    -- not true, so countIf ignores those rows (a NULL rate is
    -- assert_translation_rate_resolved's job).
    -- and only rows that put something into the group: CTA is -sum(group_amount), so a
    -- row with group_amount 0 (a zero movement, or 0% ownership before acquisition /
    -- after disposal) translated nothing into the residual, and a CTA of 0 is right
    having countIf(translation_rate != closing_rate and group_amount != 0) > 0
)

select
    rc.consolidation_group,
    rc.data_area_id,
    rc.fiscal_year,
    rc.fiscal_period,
    rc.max_closing_rate,
    rc.max_average_rate,
    coalesce(fx.cta_amount, 0) as cta_amount
from rate_check as rc
left join {{ ref('gold_fx_revaluation') }} as fx
    on rc.consolidation_group = fx.consolidation_group
    and rc.data_area_id = fx.data_area_id
    and rc.fiscal_year = fx.fiscal_year
    and rc.fiscal_period = fx.fiscal_period
where coalesce(fx.cta_amount, 0) = 0
