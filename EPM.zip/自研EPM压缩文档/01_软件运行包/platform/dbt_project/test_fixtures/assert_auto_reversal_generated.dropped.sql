-- gate: build +assert_auto_reversal_generated
-- gate: expect assert_auto_reversal_generated pass
-- V01 fixture (konsol#305-D2-11), dropped variant: tables epm_staging.consolidation_adjustments without auto_reverse_period (proves the model no longer reads it)
ALTER TABLE epm_staging.consolidation_adjustments ADD COLUMN IF NOT EXISTS reverse_fiscal_year UInt16 DEFAULT 0;
ALTER TABLE epm_staging.consolidation_adjustments ADD COLUMN IF NOT EXISTS reverse_fiscal_period UInt8 DEFAULT 0;
ALTER TABLE epm_staging.consolidation_adjustments DROP COLUMN IF EXISTS auto_reverse_period;
INSERT INTO epm_staging.consolidation_adjustments (consolidation_group, adjustment_type, journal_id, data_area_id, fiscal_year, fiscal_period, main_account, debit_amount, credit_amount, description, posted_by, status, approved_by, reverse_fiscal_year, reverse_fiscal_period) VALUES ('ZZG','topside','ZZJ-00001','ZZE1',2025,6,'ZZ1100',100,0,'d','zz','Approved','zz',2025,9), ('ZZG','topside','ZZJ-00001','ZZE2',2025,6,'ZZ2100',0,100,'c','zz','Approved','zz',2025,9), ('ZZG','topside','ZZJ-00002','ZZE1',2025,6,'ZZ1100',50,0,'d','zz','Approved','zz',0,0), ('ZZG','topside','ZZJ-00002','ZZE1',2025,6,'ZZ2100',0,50,'c','zz','Approved','zz',0,0);
