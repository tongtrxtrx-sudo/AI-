-- gate: build +assert_auto_reversal_period_declared
-- gate: expect assert_auto_reversal_period_declared flag 2
-- Flags 2: ZZJ-00001 reverses into FY2025 P13, a Closing period; ZZJ-00002 reverses into P6, before its own P9.
-- V01 fixture (konsol#305-D2-11): tables epm_staging.consolidation_adjustments
ALTER TABLE epm_staging.consolidation_adjustments ADD COLUMN IF NOT EXISTS reverse_fiscal_year UInt16 DEFAULT 0;
ALTER TABLE epm_staging.consolidation_adjustments ADD COLUMN IF NOT EXISTS reverse_fiscal_period UInt8 DEFAULT 0;
INSERT INTO epm_staging.consolidation_adjustments (consolidation_group, adjustment_type, journal_id, data_area_id, fiscal_year, fiscal_period, main_account, debit_amount, credit_amount, description, posted_by, status, approved_by, reverse_fiscal_year, reverse_fiscal_period) VALUES ('ZZG','topside','ZZJ-00001','ZZE1',2025,6,'ZZ1100',100,0,'d','zz','Approved','zz',2025,13), ('ZZG','topside','ZZJ-00001','ZZE2',2025,6,'ZZ2100',0,100,'c','zz','Approved','zz',2025,13), ('ZZG','topside','ZZJ-00002','ZZE1',2025,9,'ZZ1100',50,0,'d','zz','Approved','zz',2025,6), ('ZZG','topside','ZZJ-00002','ZZE1',2025,9,'ZZ2100',0,50,'c','zz','Approved','zz',2025,6);
-- tables: epm_staging.fiscal_periods
INSERT INTO epm_staging.fiscal_periods VALUES (2025,6,'P06','Jun','Regular','2025-06-01','2025-06-30','Q2','Open'),(2025,7,'P07','Jul','Regular','2025-07-01','2025-07-31','Q3','Open'),(2025,8,'P08','Aug','Regular','2025-08-01','2025-08-31','Q3','Open'),(2025,9,'P09','Sep','Regular','2025-09-01','2025-09-30','Q3','Open'),(2025,13,'P13','Closing','Closing','2025-12-31','2025-12-31','Q4','Open');
