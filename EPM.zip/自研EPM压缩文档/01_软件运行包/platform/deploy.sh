#!/bin/bash
# =============================================================================
# Konsolidat — One-Click Deployment
# =============================================================================
# Usage:
#   ./deploy.sh                          First-time setup (everything)
#   ./deploy.sh --domain epm.company.com Setup with custom domain + auto-SSL
#   ./deploy.sh backup                   Run backup now
#   ./deploy.sh restore --from <path>    Restore from backup
#   ./deploy.sh status                   Show service status
#   ./deploy.sh logs                     Tail all logs
#   ./deploy.sh down                     Stop everything
# =============================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${BLUE}[INFO]${NC} $1"; }
ok()    { echo -e "${GREEN}[OK]${NC} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()   { echo -e "${RED}[ERROR]${NC} $1"; }

# Portable in-place sed: GNU sed wants `-i`, BSD/macOS sed wants `-i ''`.
sedi() {
  if sed --version >/dev/null 2>&1; then
    sed -i "$@"
  else
    sed -i '' "$@"
  fi
}

# Upsert KEY=VALUE in .env (update in place, or append if the key is absent —
# so an existing .env predating a new setting still gets it).
set_env() {
  local key="$1" val="$2"
  if grep -q "^${key}=" .env; then
    sedi "s|^${key}=.*|${key}=${val}|" .env
  else
    printf '%s=%s\n' "$key" "$val" >> .env
  fi
}

# Pick the Caddy scheme for a site value: https for a real DNS hostname (enables
# Caddy auto-HTTPS / Let's Encrypt), plain http for an IP or localhost — a bare
# host/IP makes Caddy issue an internal-CA cert the browser rejects (#59).
domain_scheme() {
  case "$1" in
    ""|localhost) echo "http" ;;
    *:*)          echo "http" ;;   # contains ':' → IPv6 literal → http (#59)
    *[!0-9.]*)    echo "https" ;;  # has a non-(digit/dot) char → hostname
    *)            echo "http" ;;   # only digits/dots → IPv4 → http
  esac
}

# ---------------------------------------------------------------------------
# Sub-commands
# ---------------------------------------------------------------------------
case "${1:-}" in
  backup)
    info "Running backup..."
    # backup has no build: of its own; it runs the image frappe_backend builds,
    # and pull_policy: never stops Compose from looking for it on Docker Hub.
    # Backup NEVER builds: it runs unattended from cron, and a full image build
    # (bench init + a ~700 MB vite build) next to a running ClickHouse on a
    # small host can OOM, and then there is no backup either. If the image is
    # missing, fail loudly so the missed backup is visible in the cron log.
    # `config --images backup` also lists backup's dependencies (mariadb, redis,
    # clickhouse), so keep only the project-scoped Frappe tag. An empty result
    # (config failed, or no match) is treated as "not found".
    FRAPPE_IMAGE="$(docker compose --profile backup config --images backup | grep -- '-frappe:latest$' | head -n 1 || true)"
    if [ -z "$FRAPPE_IMAGE" ] || ! docker image inspect "$FRAPPE_IMAGE" >/dev/null 2>&1; then
      err "Frappe image ${FRAPPE_IMAGE:-<unresolved>} not found. Run ./deploy.sh first; backup does not build." >&2
      exit 1
    fi
    docker compose --profile backup run --rm backup
    exit 0
    ;;
  restore)
    if [ -z "${3:-}" ] || [ "$2" != "--from" ]; then
      err "Usage: ./deploy.sh restore --from /path/to/backup"
      exit 1
    fi
    RESTORE_PATH="$3"
    info "Restoring from ${RESTORE_PATH}..."

    # Restore MariaDB
    if [ -f "${RESTORE_PATH}/mariadb.sql.gz" ]; then
      info "Restoring MariaDB..."
      gunzip -c "${RESTORE_PATH}/mariadb.sql.gz" | \
        docker compose exec -T mariadb mariadb -u root -p"${DB_ROOT_PASSWORD:-rootpassword}"
      ok "MariaDB restored."
    fi

    # Restore Frappe files
    if [ -f "${RESTORE_PATH}/frappe_sites.tar.gz" ]; then
      info "Restoring Frappe files..."
      docker compose cp "${RESTORE_PATH}/frappe_sites.tar.gz" frappe_backend:/tmp/
      docker compose exec frappe_backend bash -c "cd /home/frappe/frappe-bench && tar xzf /tmp/frappe_sites.tar.gz"
      ok "Frappe files restored."
    fi

    # Restore ClickHouse
    if [ -d "${RESTORE_PATH}/clickhouse" ]; then
      info "Restoring ClickHouse tables..."
      for file in "${RESTORE_PATH}/clickhouse/"*.native.gz; do
        basename_noext=$(basename "$file" .native.gz)
        # Filename format: db__table.native.gz (double-underscore separator)
        db="${basename_noext%%__*}"
        table="${basename_noext#*__}"
        info "  Restoring ${db}.${table}..."
        gunzip -c "$file" | curl -sf "http://localhost:${CLICKHOUSE_HTTP_PORT:-8123}/" \
          -u "${CLICKHOUSE_USER:-default}:${CLICKHOUSE_PASSWORD:-open_epm_dev}" \
          --data-binary @- -H "X-ClickHouse-Query: INSERT INTO ${db}.${table} FORMAT Native" || true
      done
      ok "ClickHouse restored."
    fi

    ok "Restore complete. Restart services: docker compose restart"
    exit 0
    ;;
  status)
    docker compose ps
    exit 0
    ;;
  logs)
    docker compose logs -f --tail=50
    exit 0
    ;;
  down)
    docker compose down
    exit 0
    ;;
esac

# ---------------------------------------------------------------------------
# Parse flags
# ---------------------------------------------------------------------------
DOMAIN=""
while [[ $# -gt 0 ]]; do
  case $1 in
    --domain)
      DOMAIN="$2"
      shift 2
      ;;
    *)
      shift
      ;;
  esac
done

# ---------------------------------------------------------------------------
# Prerequisites
# ---------------------------------------------------------------------------
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║         Konsolidat — One-Click Deploy           ║${NC}"
echo -e "${CYAN}║     Excellent analysis thrives on Excel          ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════╝${NC}"
echo ""

# Check Docker
if ! command -v docker &>/dev/null; then
  err "Docker not found. Install it first:"
  echo "  curl -fsSL https://get.docker.com | sh"
  exit 1
fi

# Check Docker Compose
if ! docker compose version &>/dev/null; then
  err "Docker Compose not found. It should come with Docker."
  exit 1
fi

ok "Docker $(docker --version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)"
ok "Docker Compose $(docker compose version --short)"

# ---------------------------------------------------------------------------
# Generate .env if needed
# ---------------------------------------------------------------------------
if [ ! -f .env ]; then
  info "Generating .env with random passwords..."
  cp .env.example .env

  # Generate random passwords
  GENERATED_ADMIN_PW=$(openssl rand -base64 12 | tr -d '/+=' | head -c 16)
  GENERATED_DB_PW=$(openssl rand -base64 12 | tr -d '/+=' | head -c 16)
  GENERATED_CH_PW=$(openssl rand -base64 12 | tr -d '/+=' | head -c 16)
  GENERATED_CUBEJS_SECRET=$(openssl rand -hex 16)

  sedi "s|ADMIN_PASSWORD=.*|ADMIN_PASSWORD=${GENERATED_ADMIN_PW}|" .env
  sedi "s|DB_ROOT_PASSWORD=.*|DB_ROOT_PASSWORD=${GENERATED_DB_PW}|" .env
  sedi "s|CLICKHOUSE_PASSWORD=.*|CLICKHOUSE_PASSWORD=${GENERATED_CH_PW}|" .env
  sedi "s|CUBEJS_API_SECRET=.*|CUBEJS_API_SECRET=${GENERATED_CUBEJS_SECRET}|" .env

  if [ -n "$DOMAIN" ]; then
    SCHEME=$(domain_scheme "$DOMAIN")
    set_env SITE_DOMAIN "$DOMAIN"
    set_env SITE_SCHEME "$SCHEME"
  fi

  ok "Generated .env with secure passwords"
else
  ok "Using existing .env"
  if [ -n "$DOMAIN" ]; then
    SCHEME=$(domain_scheme "$DOMAIN")
    set_env SITE_DOMAIN "$DOMAIN"
    set_env SITE_SCHEME "$SCHEME"
  fi
fi

# Source env for printing later
set -a
source .env
set +a

# ---------------------------------------------------------------------------
# Step 1: Start infrastructure
# ---------------------------------------------------------------------------
echo ""
info "Step 1/5: Starting infrastructure (MariaDB, Redis, ClickHouse)..."
docker compose up -d mariadb redis_cache redis_queue clickhouse

# Wait for all healthchecks
info "Waiting for services to be healthy..."
for svc in mariadb redis_cache redis_queue clickhouse; do
  for i in $(seq 1 120); do
    status=$(docker inspect --format='{{.State.Health.Status}}' "konsolidat_${svc}" 2>/dev/null || echo "starting")
    if [ "$status" = "healthy" ]; then
      ok "${svc} is healthy"
      break
    fi
    if [ "$i" -eq 120 ]; then
      err "${svc} failed to become healthy after 120s"
      docker compose logs "$svc" --tail=20
      exit 1
    fi
    sleep 1
  done
done

# ---------------------------------------------------------------------------
# Step 2: Stage konsol app + build Frappe image
# ---------------------------------------------------------------------------
echo ""
info "Step 2/5: Building Frappe + Konsol image (this takes a few minutes on first run)..."

# Stage konsol app for Docker build
KONSOL_DIR="docker/frappe/konsol"
KONSOL_REPO="${KONSOL_REPO:-https://github.com/grynn-in/konsol.git}"
KONSOL_BRANCH="${KONSOL_BRANCH:-main}"

if [ ! -d "$KONSOL_DIR/.git" ]; then
    info "Cloning konsol app..."
    [ -n "$KONSOL_DIR" ] && rm -rf "$KONSOL_DIR"
    git clone "$KONSOL_REPO" --branch "$KONSOL_BRANCH" --depth 1 "$KONSOL_DIR" 2>&1 \
        || { err "Failed to clone konsol. If it's a private repo, run:"; \
             echo "  git clone $KONSOL_REPO docker/frappe/konsol"; \
             echo "  Then re-run ./deploy.sh"; exit 1; }
else
    # Pin the staged checkout to KONSOL_BRANCH regardless of its current local
    # state. The old `git pull --ff-only || true` pulled whatever branch was
    # checked out (not necessarily main) and silently no-opped on failure, so
    # the image could be built from a stale — or a DO-NOT-MERGE — branch, and
    # KONSOL_BRANCH was ignored on every re-run. Fetch the requested branch by
    # URL (no assumption about the local remote name) and hard-reset to it.
    info "Updating konsol app to ${KONSOL_BRANCH}..."
    git -C "$KONSOL_DIR" fetch --depth 1 "$KONSOL_REPO" "$KONSOL_BRANCH" \
        || { err "Failed to fetch konsol branch ${KONSOL_BRANCH} from ${KONSOL_REPO}"; exit 1; }
    git -C "$KONSOL_DIR" checkout -B "$KONSOL_BRANCH" FETCH_HEAD
    git -C "$KONSOL_DIR" reset --hard FETCH_HEAD
fi

# Build the Frappe + Konsol image ONCE. frappe_backend is the only service with
# a `build:` section; it tags <project>-frappe:latest (e.g. repo-frappe:latest
# for a checkout in ./repo), and frappe_worker, frappe_scheduler, configurator,
# dbt_init and backup all run that same tag.
# One shared tag means a redeploy cannot leave any of them on old app code
# (the version skew of grynn-in/konsolidat#58). One build means one
# `bench get-app` / vite build instead of six in parallel, which OOM-killed the
# build and ClickHouse with it on an 8 GiB host (grynn-in/konsolidat#152).
#
# The setup/backup profiles stay active so that a build-carrying service added
# to either profile later is still rebuilt here. COMPOSE_PARALLEL_LIMIT=1 is a
# cheap guard, a no-op while exactly one service builds: if a second `build:`
# ever comes back, it serialises the builds with the classic builder (verified
# on Compose 5.1.4 without buildx). It may not apply when Compose builds through
# buildx/Bake, so the real protection is keeping a single `build:`. It is scoped
# to this command only, so the `up` steps stay parallel.
COMPOSE_PARALLEL_LIMIT=1 docker compose --profile setup --profile backup build

# ---------------------------------------------------------------------------
# Step 3: Run configurator (create site, install app)
# ---------------------------------------------------------------------------
echo ""
info "Step 3/5: Setting up Frappe site and installing Konsol app..."
docker compose --profile setup run --rm configurator

# ---------------------------------------------------------------------------
# Step 4: Start application services
# ---------------------------------------------------------------------------
echo ""
info "Step 4/5: Starting application services..."
docker compose up -d frappe_backend frappe_worker frappe_scheduler cubejs caddy

# Wait for Frappe to respond
info "Waiting for Frappe to start..."
for i in $(seq 1 60); do
  if curl -sf -H "Host: ${SITE_NAME:-konsolidat.local}" "http://localhost:${FRAPPE_PORT:-8069}/api/method/ping" >/dev/null 2>&1; then
    ok "Frappe is responding"
    break
  fi
  if [ "$i" -eq 60 ]; then
    warn "Frappe not responding yet (may still be starting). Check: docker compose logs frappe_backend"
  fi
  sleep 2
done

# ---------------------------------------------------------------------------
# Before step 5: governed group exchange rates (konsolidat#93)
# ---------------------------------------------------------------------------
# gold_consolidated_trial_balance translates only from the governed rates in
# epm_staging.group_exchange_rates (konsol#174) and refuses a run with any key
# lacking a usable rate, before it deletes anything. This runs the SAME macros
# through the dbt_init service, inside the compose network
# (`dbt show --inline "{{ fx_precheck() }}"`), so it covers every reason the
# guard refuses on (missing, duplicate, invalid, implausible) and never drifts.
#
#   * the table does not exist: the konsol migration that creates and fills it
#     (konsol #174) has not run. ABORT, whatever is translated: the guard and
#     the model read the table regardless. A fresh stack has it from
#     init-db.sql, so this only fires on an old volume without #174.
#   * the table exists but keys have no usable rate: WARN with the list and
#     continue. The check reads the last build's gold tables, so aborting here
#     would deadlock a fix made in konsol (a currency or ownership change)
#     that only this build can bring in. At step 5 every model not
#     downstream of gold_consolidated_trial_balance refreshes; the
#     consolidated TB and the models that read it keep their last figures,
#     and step 5 fails the deploy.
#   * the check itself fails: WARN with dbt's error and continue; the model's
#     guard still refuses before it replaces anything.
FX_DBT_CMD="${FX_DBT_CMD:-docker compose --profile setup run --rm -T dbt_init}"
FX_DBT_PROJECT="${FX_DBT_PROJECT:-/home/frappe/dbt_project}"
if FX_OUT="$($FX_DBT_CMD show --profiles-dir "$FX_DBT_PROJECT" --project-dir "$FX_DBT_PROJECT" \
        --limit 201 --output json --inline '{{ fx_precheck() }}' 2>&1)"; then FX_OK=1; else FX_OK=0; fi
# JSON, not the text table: dbt show truncates wide text columns. Each value is
# a marker line without quotes, so a grep over the JSON is enough (no jq).
FX_LINES="$(printf '%s\n' "$FX_OUT" | grep -oE '"fx_check": *"FX_[^"]*"' | sed -E 's/^"fx_check": *"//; s/"$//' || true)"
FX_HEAD="$(printf '%s\n' "$FX_LINES" | head -1)"
case "$FX_OK:$FX_HEAD" in
    1:FX_NOTHING_BUILT)
        info "Governed group exchange rates: no trial balance or ownership built yet, so nothing to check."
        ;;
    1:FX_TABLE_MISSING*)
        FX_N="${FX_HEAD#FX_TABLE_MISSING }"
        err "epm_staging.group_exchange_rates does not exist (${FX_N} foreign-currency key(s) are translated today); gold_consolidated_trial_balance reads it on every build."
        err "Run the konsol migration (konsol #174) first, then re-run this deploy."
        exit 1
        ;;
    1:FX_GAPS_TOTAL*)
        FX_N="${FX_HEAD#FX_GAPS_TOTAL }"
        if [ "$FX_N" -gt 0 ] 2>/dev/null; then
            warn "${FX_N} translated key(s) have no usable governed rate (from->to, year, period, reason):"
            printf '%s\n' "$FX_LINES" | grep '^FX_GAP ' | sed 's/^FX_GAP /    /'
            [ "$FX_N" -gt 200 ] && echo "    ... and $((FX_N - 200)) more (assert_every_translated_currency_has_a_governed_rate lists all)"
            warn "Continuing: at step 5 every model not downstream of gold_consolidated_trial_balance refreshes; the consolidated TB and the models that read it keep their last figures (nothing is deleted), and step 5 fails the deploy until these rates are approved in konsol (Group Exchange Rate)."
        else
            info "Governed group exchange rates: every translated foreign-currency key has a usable rate."
        fi
        ;;
    *)
        warn "FX pre-check failed, so the governed group exchange rates were NOT checked. dbt said:"
        printf '%s\n' "$FX_OUT" | grep -iE 'error|exception|not found|refused' | head -5 | sed 's/^/    /'
        warn "Continuing: if a rate is missing, gold_consolidated_trial_balance refuses before it replaces anything."
        ;;
esac

# ---------------------------------------------------------------------------
# Step 5: Run dbt build
# ---------------------------------------------------------------------------
echo ""
info "Step 5/5: Running dbt build (gold models)..."
# A bare `|| warn` here swallowed everything, including a Compilation Error that
# meant dbt parsed nothing and built no models at all — while the deploy still
# printed "Konsolidat is ready!". Data-quality test failures on demo data are
# genuinely tolerable; a build that produced nothing is not. Tell them apart.
DBT_LOG="$(mktemp "${TMPDIR:-/tmp}/konsolidat-dbt.XXXXXX")"
docker compose --profile setup run --rm dbt_init 2>&1 | tee "$DBT_LOG"
DBT_STATUS=${PIPESTATUS[0]}   # exit status of dbt, not of tee
if [ "$DBT_STATUS" -eq 0 ]; then
    ok "dbt build completed"
else
    if grep -qE "Compilation Error|Encountered an error|Database Error|Parsing Error|ERROR creating|SKIP=[1-9]" "$DBT_LOG"; then
        err "dbt build FAILED — a model errored or was skipped, so the warehouse is stale. Deploy aborted."
        echo ""
        grep -E -A3 "Compilation Error|Encountered an error|Database Error|Parsing Error|ERROR creating|SKIP=[1-9]" "$DBT_LOG" | head -20
        echo ""
        err "The stack is up but the warehouse is stale. Fix the error above and re-run."
        rm -f "$DBT_LOG"
        exit 1
    fi
    warn "dbt build had test failures (tolerated for demo data); models were built"
fi
rm -f "$DBT_LOG"

# ---------------------------------------------------------------------------
# Done!
# ---------------------------------------------------------------------------
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         Konsolidat is ready!                     ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""

if [ -n "$DOMAIN" ]; then
  echo -e "  ${CYAN}Frappe:${NC}     https://${DOMAIN}"
  echo -e "  ${CYAN}Cube.js:${NC}    https://${DOMAIN}:4443"
else
  echo -e "  ${CYAN}Frappe:${NC}     http://localhost:${FRAPPE_PORT:-8069}"
  echo -e "  ${CYAN}Cube.js:${NC}    http://localhost:${CUBEJS_PORT:-4000}"
fi
echo -e "  ${CYAN}Excel ODBC:${NC} localhost:${EXCEL_ODBC_PORT:-15432}"
echo ""
echo -e "  ${CYAN}Admin login:${NC} Administrator (password saved to ./.credentials)"
echo ""
echo -e "  ${YELLOW}Commands:${NC}"
echo -e "    ./deploy.sh status     Show service status"
echo -e "    ./deploy.sh backup     Run backup now"
echo -e "    ./deploy.sh logs       Tail logs"
echo -e "    ./deploy.sh down       Stop everything"
echo ""

# Save credentials to a file for reference
cat > .credentials <<EOF
# Konsolidat Credentials (generated by deploy.sh)
# Keep this file secure!

Frappe Admin:     Administrator / ${ADMIN_PASSWORD:-admin123}
MariaDB Root:     root / ${DB_ROOT_PASSWORD:-rootpassword}
ClickHouse:       ${CLICKHOUSE_USER:-default} / ${CLICKHOUSE_PASSWORD:-open_epm_dev}
Cube.js Secret:   ${CUBEJS_API_SECRET}

URLs:
  Frappe:     http://localhost:${FRAPPE_PORT:-8069}
  Cube.js:    http://localhost:${CUBEJS_PORT:-4000}
  Excel ODBC: localhost:${EXCEL_ODBC_PORT:-15432}
EOF
chmod 600 .credentials
info "Credentials saved to .credentials (chmod 600)"
