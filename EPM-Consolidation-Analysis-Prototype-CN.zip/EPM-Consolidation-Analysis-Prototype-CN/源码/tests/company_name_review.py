"""Focused independent company-name and responsive-layout review.

This review does not rerun the historical six financial workflow suites.
"""
from pathlib import Path
import datetime
import hashlib
import json
import re
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/independent/company-name'
OUT.mkdir(parents=True, exist_ok=True)
COMPANY = '杭州天元宠物用品有限公司'
OLD = '华远产业集团'
report = {'scope': 'Company-name update only: two exact generated HTML files, forty navigation views, responsive selected name, organization/settings/subgroup/CSV and lean reserved budget boundaries',
          'transport': 'Exact HTML read_text -> Playwright set_content; file:// and Windows not tested',
          'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'variants': [], 'findings': []}

def require(value, name, details=None):
    if not value:
        report['findings'].append({'check': name, 'details': details})

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                                args=['--disable-dev-shm-usage'])
    report['browser_version'] = browser.version
    for variant, entry in [('full', '01_完整产品交互原型.html'),
                           ('lean', '02_合并与经营分析交互原型.html')]:
        source = (ROOT / 'dist' / entry).read_text()
        assert COMPANY in source and OLD not in source, 'Wait for rebuilt company-name HTML'
        context = browser.new_context(viewport={'width': 1366, 'height': 1000}, accept_downloads=True)
        page = context.new_page()
        errors, requests = [], []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('request', lambda r: requests.append(r.url) if re.match('https?://', r.url) else None)
        page.set_content(source, wait_until='load')
        page.wait_for_function('window.EPMPrototype')
        record = {'variant': variant, 'entry_html': entry,
                  'html_sha256': hashlib.sha256(source.encode()).hexdigest(),
                  'navigation': [], 'layout': []}
        routes = page.locator('[data-route]').evaluate_all('(els)=>els.map(e=>e.dataset.route)')
        require(len(routes) == 20, variant + ': twenty routes', routes)
        for route in routes:
            page.locator('[data-route="' + route + '"]').click()
            body = page.locator('body').inner_text()
            visible = page.locator('.demo').is_visible()
            require(OLD not in body and visible, variant + ': route company/demo ' + route)
            if variant == 'lean' and route.startswith('budget-'):
                enabled = page.locator('#app button:enabled,#app input:enabled,#app select:enabled,#app textarea:enabled').count()
                require(enabled == 0 and page.evaluate('EPMPrototype.inspect().budget===null'),
                        variant + ': budget remains static ' + route, enabled)
            record['navigation'].append({'route': route, 'h1': page.locator('h1').inner_text(),
                                         'old_name_absent': OLD not in body, 'demo_visible': visible})
        page.locator('[data-route="overview"]').click()
        for width in (1366, 1024, 768, 390):
            page.set_viewport_size({'width': width, 'height': 1000})
            dimensions = page.locator('#context-group').evaluate('''e => {
                const cs=getComputedStyle(e), rect=e.getBoundingClientRect(),
                    parent=e.closest('.topbar').getBoundingClientRect(),
                    canvas=document.createElement('canvas'), ctx=canvas.getContext('2d');
                ctx.font=cs.font;
                return {selected:e.selectedOptions[0].textContent, x:rect.x, right:rect.right,
                    width:rect.width, topbar_left:parent.left, topbar_right:parent.right,
                    text_width:ctx.measureText(e.selectedOptions[0].textContent).width,
                    available_text_width:e.clientWidth-parseFloat(cs.paddingLeft)-parseFloat(cs.paddingRight)-18,
                    document_scroll_width:document.documentElement.scrollWidth,
                    viewport_width:innerWidth};
            }''')
            dimensions['width'] = width
            dimensions['name_fully_fits'] = dimensions['text_width'] <= dimensions['available_text_width']
            dimensions['in_topbar'] = dimensions['x'] >= dimensions['topbar_left'] and dimensions['right'] <= dimensions['topbar_right'] + 1
            dimensions['no_page_horizontal_overflow'] = dimensions['document_scroll_width'] <= width + 1
            require(dimensions['selected'] == COMPANY and dimensions['name_fully_fits'] and dimensions['in_topbar'],
                    variant + ': visible long company name at ' + str(width), dimensions)
            require(dimensions['no_page_horizontal_overflow'], variant + ': page width ' + str(width), dimensions)
            page.screenshot(path=str(OUT / f'{variant}-overview-{width}.png'), full_page=True)
            record['layout'].append(dimensions)
        page.set_viewport_size({'width': 1366, 'height': 1000})
        page.locator('[data-route="org"]').click()
        record['organization_root'] = COMPANY in page.locator('.tree-node').first.inner_text()
        require(record['organization_root'], variant + ': organization root')
        page.screenshot(path=str(OUT / f'{variant}-organization.png'), full_page=True)
        page.locator('[data-route="settings"]').click()
        record['settings_company'] = page.locator('label').filter(has_text='集团名称').locator('input').input_value()
        require(record['settings_company'] == COMPANY, variant + ': settings company')
        page.screenshot(path=str(OUT / f'{variant}-settings.png'), full_page=True)
        page.select_option('#context-group', 'manufacturing')
        page.locator('[data-route="intercompany"]').click()
        record['subgroup_return_hint'] = '请在顶栏切回' + COMPANY in page.locator('#app').inner_text()
        require(record['subgroup_return_hint'], variant + ': subgroup return hint')
        page.select_option('#context-group', 'group')
        page.locator('[data-route="statements"]').click()
        with page.expect_download() as download:
            page.locator('[data-action="export-statement"]').click()
        csv = OUT / f'{variant}-company-scope.csv'
        download.value.save_as(str(csv))
        exported = csv.read_text(encoding='utf-8-sig')
        record['csv_scope_company'] = COMPANY in exported and OLD not in exported
        require(record['csv_scope_company'], variant + ': export scope')
        record['lean_budget_null'] = page.evaluate('EPMPrototype.inspect().budget===null') if variant == 'lean' else None
        record['page_errors'] = errors
        record['external_requests'] = requests
        require(not errors and not requests, variant + ': no errors or requests', {'errors': errors, 'requests': requests})
        report['variants'].append(record)
        context.close()
    browser.close()
report['passed'] = not report['findings']
report['navigation_views_checked'] = sum(len(x['navigation']) for x in report['variants'])
report['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT / 'company-name-review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': report['passed'], 'navigation_views_checked': report['navigation_views_checked'],
                  'findings': report['findings']}, ensure_ascii=False, indent=2))
raise SystemExit(0 if report['passed'] else 1)
