#!/usr/bin/env python3
"""Exercise delivered XLSX templates through the released Demo's real HTTP API.

No product ledger/calculator module is imported. All servers own fresh temporary
SQLite data directories; original Demo source, release ZIPs and user data stay read-only.
"""
from pathlib import Path
from copy import deepcopy
from datetime import datetime
from zoneinfo import ZoneInfo
from decimal import Decimal
import argparse,base64,hashlib,json,re,sys,tempfile,traceback,zipfile
from openpyxl import load_workbook

KIT=Path(__file__).resolve().parents[1]
SOURCE=Path('/workspace/epm-demo-vouchers')
sys.path.insert(0,str(SOURCE/'acceptance'))
from support import Server,manifest
from run_multilevel_api import reopen,run_approve
from run_erp_api import full_consolidation,trace_field

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
RESULTS=KIT/'acceptance'
INPUTS=RESULTS/'filled-from-blank-template'
INPUTS.mkdir(exist_ok=True)

def find_files():
    # Accept the generator's manifest if present; do not guess ready example data.
    candidates=[KIT/'template-manifest.json',KIT/'output/template-manifest.json']
    for p in candidates:
        if p.is_file():
            m=json.loads(p.read_text())
            items=m.get('templates',[])
            out={}
            for t in items:
                ident=t.get('id');name=t.get('file') or t.get('path')
                if ident and name:
                    q=Path(name);out[ident]={**t,'path':q if q.is_absolute() else KIT/q}
                    example=t.get('exampleFile')
                    if example:
                        eq=Path(example);out[ident]['examplePath']=eq if eq.is_absolute() else KIT/eq
            if {'mapping','opening','nc65','generic'}<=set(out):return out
    raise RuntimeError('模板manifest尚未就绪，须含mapping/opening/nc65/generic的file/exampleFile。')

def uploaded(path,**extra):
    path=Path(path)
    return {'fileBase64':base64.b64encode(path.read_bytes()).decode(),'fileName':path.name,'sourceName':path.name,'amountUnit':'元',**extra}

def normalization(text):return re.sub(r'\s+','',str(text or '').strip().lstrip('*'))

def fill(template,name,rows):
    wb=load_workbook(template);ws=wb.worksheets[0]
    width=ws.max_column
    # Clearing existing styled input rows keeps validation/style and later sheets.
    for row in ws.iter_rows(min_row=2):
        for cell in row:cell.value=None
    for ri,values in enumerate(rows,2):
        assert len(values)==width,(name,width,len(values))
        for ci,value in enumerate(values,1):ws.cell(ri,ci).value=value
    p=INPUTS/name;wb.save(p);return p

def fill_dict(template,name,rows):
    wb=load_workbook(template);heads=[normalization(c.value) for c in wb.worksheets[0][1]]
    return fill(template,name,[[row.get(h,'') for h in heads] for row in rows])

def fresh_prepare(c):
    for unit in ('HW_GROUP','OS_GROUP','TY_GROUP'):reopen(c,unit)

def assert_money(v,want,label):assert Decimal(str(v))==Decimal(str(want)),(label,v,want)

def import_config(c,book='0000001'):
    c.act('erp_adapter_save',{'adapter':'nc65','bookMappings':[{'bookCode':book,'entityId':'HW','functionalCurrency':'CNY'}], 'counterpartyMappings':[{'code':'EXTERNAL-0001','entityId':'EXTERNAL'}], 'importOptions':{'auxiliaryColumns':['辅助核算1'],'referenceColumn':'结算号'}})

def reject_zero_write(c,action,payload,fragment,expected=(400,409,422)):
    before=deepcopy(c.state);rev=before['revision']
    result=c.act(action,payload,expected=expected)
    message=result.get('message') or result.get('error',{}).get('message') or str(result.get('error'))
    assert fragment in message,(fragment,message)
    c.bootstrap();assert c.state['revision']==rev,(action,'失败写入了revision')
    for key in ('mappings','openings','vouchers','batches'):assert c.state['erp'][key]==before['erp'][key],(action,key,'失败改变了数据')
    return message

MAP=[['HW','001001','现金与银行存款','cash','借'],['HW','004001','实收资本','capital','贷'],['HW','006001','主营业务收入','revenue','贷'],['HW','002501','长期借款','longloan','贷']]
OPEN=[['HW','2026','001001','CNY','100.00','0.00','','','0'],['HW','2026','004001','CNY','0.00','100.00','','','0']]

def nc_row(account,debit='0.00',credit='0.00',**overrides):
    out={'核算账簿':'0000001','凭证类别编码':'01','凭证号':'000001','附单据数':'1','制单人编码':'NC_TEST','制单日期':'2026-09-01','摘要':'空模板独立粘贴测试','科目编码':account,'币种':'美元','原币借方金额':'1.00' if Decimal(debit) else '0.00','本币借方金额':debit,'集团本币借方金额':'999.00' if Decimal(debit) else '0.00','全局本币借方金额':'888.00' if Decimal(debit) else '0.00','原币贷方金额':'1.00' if Decimal(credit) else '0.00','本币贷方金额':credit,'集团本币贷方金额':'999.00' if Decimal(credit) else '0.00','全局本币贷方金额':'888.00' if Decimal(credit) else '0.00','辅助核算1':'EXTERNAL-0001'}
    out.update(overrides);return out

def case_structure(files):
    details=[]
    for ident,spec in files.items():
        p=spec['path'];assert p.exists(),p
        assert sha(p)==spec['sha256'],(p,'模板与manifest摘要不符')
        if spec.get('examplePath'):assert sha(spec['examplePath'])==spec['exampleSha256'],(ident,'已填示例与manifest摘要不符')
        with zipfile.ZipFile(p) as z:assert z.testzip() is None
        wb=load_workbook(p)
        assert not any(c.data_type=='f' for ws in wb for row in ws for c in row),(p,'模板含公式')
        first=wb.worksheets[0]
        if ident in ('mapping','opening','nc65','generic'):
            want={'mapping':5,'opening':9,'nc65':48,'generic':15}[ident]
            headers=[c.value for c in first[1]];assert len(headers)==want,(ident,len(headers))
            assert len(set(map(normalization,headers)))==want
            assert not first.merged_cells.ranges
            assert all(c.value is None for row in first.iter_rows(min_row=2) for c in row),(p,'空模板首sheet混入了说明或样例')
        details.append({'id':ident,'file':str(p.relative_to(KIT)),'sheets':wb.sheetnames,'sha256':sha(p),'firstSheetColumns':first.max_column,'firstSheetStyledRows':first.max_row})
    return {'模板检查':details,'配置与现金准备表': '照页面维护，不伪称拥有独立导入入口。'}

def case_blank_rejection(files):
    actions={'mapping':('erp_mapping_save',{}),'opening':('erp_opening_import',{}),'nc65':('erp_voucher_import',{'format':'nc65','postedConfirmed':True}),'generic':('erp_voucher_import',{'format':'generic','postedConfirmed':True})}
    out=[]
    with Server() as s:
        c=s.client
        for ident,(action,extra) in actions.items():
            message=reject_zero_write(c,action,uploaded(files[ident]['path'],**extra),'没有数据行')
            out.append({'模板':ident,'返回':'未填写不能导入；整批零写入','提示':message})
    return {'空模板拒绝':out}

def case_from_blank_nc(files):
    mapping=fill(files['mapping']['path'],'01_独立粘贴_前导零科目.xlsx',MAP)
    opening=fill(files['opening']['path'],'02_独立粘贴_年初余额.xlsx',OPEN)
    nc_rows=[nc_row('001001',debit='7.01'),nc_row('006001',credit='7.01')]
    voucher=fill_dict(files['nc65']['path'],'03_独立粘贴_NC48列.xlsx',nc_rows)
    with Server() as s:
        c=s.client;fresh_prepare(c);import_config(c)
        c.act('erp_mapping_save',uploaded(mapping))
        assert {'001001','004001','006001'}<={x['code'] for x in c.state['erp']['mappings'] if x.get('active',True)}
        badmaps=deepcopy(MAP);badmaps[0][3]='不存在的报表字段'
        p=fill(files['mapping']['path'],'反例_未知报表字段.xlsx',badmaps)
        bad_mapping=reject_zero_write(c,'erp_mapping_save',uploaded(p),'报表字段')
        badopening=deepcopy(OPEN);badopening[0][4]='101.00'
        p=fill(files['opening']['path'],'反例_期初不平.xlsx',badopening)
        bad_opening=reject_zero_write(c,'erp_opening_import',uploaded(p),'不平衡')
        c.act('erp_opening_import',uploaded(opening))
        no_confirm=reject_zero_write(c,'erp_voucher_import',uploaded(voucher,format='nc65'),'确认')
        formula=load_workbook(voucher);ws=formula.worksheets[0];heads=[normalization(x.value) for x in ws[1]];ws.cell(2,heads.index('本币借方金额')+1).value='=7+0.01';p=INPUTS/'反例_凭证公式.xlsx';formula.save(p)
        formula_error=reject_zero_write(c,'erp_voucher_import',uploaded(p,format='nc65',postedConfirmed=True),'公式')
        wrong=deepcopy(nc_rows);wrong[1]['本币贷方金额']='7.02';p=fill_dict(files['nc65']['path'],'反例_凭证不平.xlsx',wrong)
        balance_error=reject_zero_write(c,'erp_voucher_import',uploaded(p,format='nc65',postedConfirmed=True),'不平衡')
        unknown=deepcopy(nc_rows);unknown[1]['科目编码']='999999';p=fill_dict(files['nc65']['path'],'反例_未知科目.xlsx',unknown)
        unknown_error=reject_zero_write(c,'erp_voucher_import',uploaded(p,format='nc65',postedConfirmed=True),'尚未映射')
        c.act('erp_voucher_import',uploaded(voucher,format='nc65',postedConfirmed=True))
        duplicate_error=reject_zero_write(c,'erp_voucher_import',uploaded(voucher,format='nc65',postedConfirmed=True),'重复',expected=409)
        rows=c.state['erp']['vouchers'];assert len(rows)==2
        assert all(x['bookCode']=='0000001' and x['rawVoucherNo']=='000001' and x['date']=='2026-09-01' for x in rows)
        assert all(len(x['rawFields'])==48 and x['currency']=='CNY' and x['transactionCurrency']=='美元' for x in rows)
        c.act('erp_report_generate',{'entityIds':['HW']})
        report=c.state['erp']['reports']['HW'];assert report['valid'] and all(x['passed'] for x in report['checks'])
        assert_money(report['source']['profit']['revenue'],'.000701','本币7.01元收入')
        assert_money(report['source']['closing']['cash'],'.010701','期末现金107.01元')
        trace=trace_field(c,'HW','profit','revenue');assert len(trace['rows'])==1 and trace['rows'][0]['credit']=='7.01'
        return {'由空白模板手填':{'科目映射':len(MAP),'期初余额':2,'NC分录':2},'本币记账收入元':'7.01','原币美元':'1.00','集团币核对金额':'999.00','报表收入万元':.000701,'期末现金万元':.010701,'前导零保持':['账簿0000001','凭证000001','科目001001/006001'],'NC48列保留':True,'收入精确追1行':True,'真实拒绝且零写入':{'未知映射字段':bad_mapping,'期初不平':bad_opening,'未确认已记账':no_confirm,'公式':formula_error,'凭证不平':balance_error,'未知科目':unknown_error,'重复凭证':duplicate_error}}

def case_from_blank_generic(files):
    mapping=fill(files['mapping']['path'],'01_通用路径_科目.xlsx',MAP)
    opening=fill(files['opening']['path'],'02_通用路径_期初.xlsx',OPEN)
    rows=[['HW','2026-09-01','记','000001','1','001001','7.01','0.00','CNY','通用现金收入','EXTERNAL','','','经营','业务'],['HW','2026-09-01','记','000001','2','006001','0.00','7.01','CNY','通用现金收入','EXTERNAL','','','','业务']]
    p=fill(files['generic']['path'],'06_独立粘贴_通用凭证.xlsx',rows)
    with Server() as s:
        c=s.client;fresh_prepare(c)
        c.act('erp_mapping_save',uploaded(mapping));c.act('erp_opening_import',uploaded(opening));c.act('erp_voucher_import',uploaded(p,format='generic',postedConfirmed=True))
        c.act('erp_report_generate',{'entityIds':['HW']});report=c.state['erp']['reports']['HW']
        assert report['valid'];assert_money(report['source']['profit']['revenue'],'.000701','通用收入');assert_money(report['source']['cashflow']['operating'],'.000701','通用经营现金流')
        current=[x for x in c.state['erp']['vouchers'] if x['accountCode']=='001001'][0];assert current['cashflow']=='operating'
        return {'通用模板实际导入':True,'替代而非叠加NC':True,'现金行明确经营分类':True,'收入万元':.000701,'经营现金流万元':.000701}

def case_cashflow_annotations(files):
    mapping=fill(files['mapping']['path'],'01_现金流补注路径_科目.xlsx',MAP)
    opening=fill(files['opening']['path'],'02_现金流补注路径_期初.xlsx',OPEN)
    rows=[nc_row('001001',debit='50.00'),nc_row('006001',credit='50.00'),nc_row('001001',debit='40.00'),nc_row('002501',credit='40.00')]
    p=fill_dict(files['nc65']['path'],'03_两现金行待分别分类.xlsx',rows)
    with Server() as s:
        c=s.client;fresh_prepare(c);import_config(c)
        c.act('erp_mapping_save',uploaded(mapping));c.act('erp_opening_import',uploaded(opening));c.act('erp_voucher_import',uploaded(p,format='nc65',postedConfirmed=True))
        error=reject_zero_write(c,'erp_report_generate',{'entityIds':['HW']},'多种')
        cash=sorted([x for x in c.state['erp']['vouchers'] if x['accountCode']=='001001'],key=lambda x:x['sourceRow']);raw=deepcopy([x['rawFields'] for x in cash]);ids=[x['id'] for x in cash]
        for row,kind in zip(cash,['operating','financing']):c.act('erp_voucher_annotations_save',{'rowIds':[row['id']],'cashflow':kind,'reason':'按真实业务依据分别标注两条现金行：收入50元、借款40元。'})
        c.act('erp_report_generate',{'entityIds':['HW']});source=c.state['erp']['reports']['HW']['source'];assert_money(source['cashflow']['operating'],'.005','经营50元');assert_money(source['cashflow']['financing'],'.004','筹资40元')
        updated={x['id']:x for x in c.state['erp']['vouchers']};assert [updated[i]['rawFields'] for i in ids]==raw;assert all(len(updated[i]['annotations'])==1 for i in ids)
        return {'NC不增自定义cashflow列':True,'未分类阻断提示':error,'分别标注两条原现金分录':True,'经营现金流元':'50.00','筹资现金流元':'40.00','原NC48列与金额不改':True,'限制':'单一现金行不支持多类别金额分摊，真实混合行应回ERP按业务依据拆分。'}

def case_ready_demo(files):
    for ident in ('mapping','opening','nc65','generic'):assert files[ident].get('examplePath') and files[ident]['examplePath'].exists(),(ident,'缺少已填xlsx案例')
    config=json.loads((SOURCE/'documentation-set/assets/产品案例NC65/04_NC65适配配置_仅本案例.json').read_text())
    with Server() as s:
        c=s.client;fresh_prepare(c)
        # This is the same maintenance form's documented API, not an import of the preparation workbook.
        c.act('erp_adapter_save',config)
        c.act('erp_mapping_save',uploaded(files['mapping']['examplePath']))
        c.act('erp_opening_import',uploaded(files['opening']['examplePath']))
        c.act('erp_voucher_import',uploaded(files['nc65']['examplePath'],format='nc65',postedConfirmed=True))
        counts={k:len(c.state['erp'][k]) for k in ('mappings','openings','vouchers')};assert counts=={'mappings':84,'openings':14,'vouchers':48},counts
        c.act('erp_report_generate',{'entityIds':['TY','HW','HW_CAT','HW_ELEC','OTHER','OS_A','OS_B']})
        reports=c.state['erp']['reports'];assert all(r['valid'] and all(x['passed'] for x in r['checks']) for r in reports.values())
        matches,results=full_consolidation(c)
        assert len(matches['HW_GROUP']['matches'])==3 and len(matches['TY_GROUP']['matches'])==1
        hw=results['HW_GROUP']['statement']['actual'];ty=results['TY_GROUP']['statement']['actual']
        for key,want in [('revenue',1400),('net',450),('assets',650)]:assert_money(hw[key],want,'鸿旺'+key)
        for key,want in [('revenue',2650),('net',770),('assets',2370),('cta',74),('cashFx',90)]:assert_money(ty[key],want,'集团'+key)
        snap=results['TY_GROUP']['sourceSnapshots']['HW']['ledgerSnapshot']['vouchers'];assert all(len(x['rawFields'])==48 for x in snap)
        result={'输入行数':counts,'已填案例实际首sheet上传':True,'鸿旺准确匹配数':3,'集团准确匹配数':1,'鸿旺小合并':{k:hw[k] for k in ['revenue','net','assets']},'集团合并':{k:ty[k] for k in ['revenue','net','assets','cta','cashFx']},'NC原48列保留':True,'配置操作':'调用同维护表单的erp_adapter_save；准备表没有独立导入入口。','NC在线连接':False}
    with Server() as s:
        c=s.client;fresh_prepare(c)
        c.act('erp_mapping_save',uploaded(files['mapping']['examplePath']))
        c.act('erp_opening_import',uploaded(files['opening']['examplePath']))
        c.act('erp_voucher_import',uploaded(files['generic']['examplePath'],format='generic',postedConfirmed=True))
        counts={k:len(c.state['erp'][k]) for k in ('mappings','openings','vouchers')}
        assert counts=={'mappings':84,'openings':14,'vouchers':48}
        c.act('erp_report_generate',{'entityIds':['TY','HW','HW_CAT','HW_ELEC','OTHER','OS_A','OS_B']})
        matches,results=full_consolidation(c)
        assert len(matches['HW_GROUP']['matches'])==3 and len(matches['TY_GROUP']['matches'])==1
        root=results['TY_GROUP']['statement']['actual']
        for key,want in [('revenue',2650),('net',770),('assets',2370),('cta',74),('cashFx',90)]:assert_money(root[key],want,'已填通用凭证集团'+key)
        result['通用已填XLSX替代案例']={'输入行数':counts,'独立新账套不与NC叠加':True,'鸿旺收入':results['HW_GROUP']['statement']['actual']['revenue'],'集团收入':root['revenue'],'净利':root['net'],'CTA':root['cta'],'现金汇率影响':root['cashFx']}
    return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--only',default='all');args=parser.parse_args()
    files=find_files();before=manifest();cases=[]
    input_paths=sorted({spec[key] for spec in files.values() for key in ('path','examplePath') if spec.get(key)})
    inputs_before={str(p.relative_to(KIT)):sha(p) for p in input_paths}
    suite=[('结构与首sheet',case_structure),('空模板不能误导入',case_blank_rejection),('空模板独立填写NC路径',case_from_blank_nc),('空模板独立填写通用路径',case_from_blank_generic),('NC现金流两行分别补注',case_cashflow_annotations),('已填XLSX完整小大合并',case_ready_demo)]
    for name,func in suite:
        if args.only!='all' and args.only not in name:continue
        try:detail=func(files);cases.append({'case':name,'passed':True,'detail':detail});print(name,'PASS',flush=True)
        except Exception as ex:cases.append({'case':name,'passed':False,'error':str(ex),'traceback':traceback.format_exc()});print(name,'FAIL',str(ex),flush=True)
    after=manifest();inputs_after={str(p.relative_to(KIT)):sha(p) for p in input_paths}
    result={'passed':bool(cases) and all(x['passed'] for x in cases) and before==after and inputs_before==inputs_after,'softwareBaseline':'ERP-20261021','supportingDelivery':'Excel导入模板与截图说明补充，不修改软件版本或数据库','verifiedAt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'method':'全新私有SQLite账套、实际本机HTTP接口上传本次xlsx；不导入产品计算函数。','sourceUnchangedDuringRun':before==after,'inputFilesUnchangedDuringRun':inputs_before==inputs_after,'inputSha256':inputs_after,'sourceSha256':after,'templateSha256':{str(x['path'].relative_to(KIT)):sha(x['path']) for x in files.values()},'harnessSha256':sha(__file__),'cases':cases,'limitations':['NC在线接口未连接。','NC适配配置、现金分类准备表无独立Excel导入入口，需页面照填或原现金行补注。','仅2026/CNY-USD全资普通场景。']}
    (RESULTS/'Excel模板真实导入验收.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    lines=['# Excel模板真实导入核验','',f'软件基线ERP-20261021；补充资料交付，不修改运行源码。验证时间：{result["verifiedAt"]}。','',f'结论：{"通过" if result["passed"] else "未通过"}。使用真实HTTP服务和全新私有SQLite，上传本次交付XLSX；未以产品计算函数代替接口。','', '|检查组|结果|','|---|---|']
    for case in cases:lines.append(f'|{case["case"]}|{"通过" if case["passed"] else "失败"}|')
    lines+=['','精确输入、返回、模板与源码SHA256见同名JSON。预期失败为明确的零写入校验，不把空模板或仅文件存在描述为导入成功。','', '已填NC案例输入84映射、14期初、48分录；鸿旺准确匹配3项、集团1项；鸿旺收入1400/净利450/资产650，集团收入2650/净利770/资产2370/CTA74/现金汇率影响90（均万元）。','', '配置准备表须在“维护NC6.5适配”照填，现金流准备表须在原现金行“补充核对信息”维护；本版没有这两类准备表独立Excel导入按钮。NC与通用凭证两条路径二选一，禁止同批业务重复入账。']
    (RESULTS/'Excel模板真实导入验收.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'passed':result['passed'],'cases':len(cases),'sourceUnchanged':before==after},ensure_ascii=False));return 0 if result['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
