#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil,zipfile
from verify_kit import ROOT,main as verify
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 checked=verify();stage=ROOT/'package/天元EPM_NC65_Excel模板与导入说明_D1.0'
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir(parents=True)
 for folder in ['Excel模板','已填示例']:shutil.copytree(ROOT/'output'/folder,stage/folder)
 stem='天元EPM_Excel模板填写与导入操作说明'
 shutil.copy2(ROOT/'output'/(stem+'.docx'),stage/(stem+'.docx'))
 (stage/'PDF').mkdir();shutil.copy2(ROOT/'output'/(stem+'.pdf'),stage/'PDF'/(stem+'.pdf'))
 shutil.copy2(ROOT/'先读我_从这里开始.md',stage/'先读我_从这里开始.md')
 source=stage/'可编辑原稿';source.mkdir();shutil.copytree(ROOT/'content',source/'content');shutil.copytree(ROOT/'screenshots',source/'screenshots')
 for name in ['render_guide.py','release.json']:shutil.copy2(ROOT/name,source/name)
 ev=stage/'制作与验收记录';ev.mkdir()
 for folder in ['evidence','acceptance']:
  for p in (ROOT/folder).iterdir():
   if p.is_file() and p.suffix in {'.json','.md','.py'}:shutil.copy2(p,ev/p.name)
 for name in ['template-manifest.json','verify_kit.py','package_kit.py']:shutil.copy2(ROOT/name,ev/name)
 scripts=ev/'scripts';scripts.mkdir()
 for p in (ROOT/'scripts').glob('*.py'):shutil.copy2(p,scripts/p.name)
 files=sorted(p for p in stage.rglob('*') if p.is_file());forbidden={'.db','.sqlite','.sqlite3','.log','.private','.pyc','.pdb','.xls'}
 for p in files:
  assert p.suffix not in forbidden and p.name not in {'instance.json','launcher.lock','.env'}
  assert not any(x in {'filled-from-blank-template','已填演示文件','__pycache__','logs'} for x in p.relative_to(stage).parts)
 records=[{'file':p.relative_to(stage).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
 manifest={'passed':True,'softwareBaseline':checked['softwareBaseline'],'kitVersion':checked['kitVersion'],'softwareChanged':False,'documents':checked['documents'],'files':records,'recordScope':'本清单记录自身与SHA256SUMS以外的全部交付文件；ZIP自身SHA记录在外部.sha256文件，避免自引用。'}
 (stage/'交付文件与校验.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 files=sorted(p for p in stage.rglob('*') if p.is_file());(stage/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(stage).as_posix()+'\n' for p in files))
 output=ROOT/'TianyuanEPM-NC65-Excel-Import-Kit-D1.0.zip'
 with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(stage.rglob('*')):
   if p.is_file():z.write(p,arcname=stage.name+'/'+p.relative_to(stage).as_posix())
 with zipfile.ZipFile(output) as z:assert z.testzip() is None
 output.with_suffix('.zip.sha256').write_text(sha(output)+'  '+output.name+'\n')
 print(json.dumps({'path':str(output),'bytes':output.stat().st_size,'sha256':sha(output),'files':len(files)+1},ensure_ascii=False))
if __name__=='__main__':main()
