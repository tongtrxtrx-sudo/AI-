#!/usr/bin/env python3
"""Capture current product screens using real isolated HTTP/Chromium actions."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,csv,io,json,hashlib,sys,tempfile,traceback
ROOT=Path('/workspace/epm-demo-vouchers');KIT=Path('/workspace/epm-import-kit')
sys.path.insert(0,str(ROOT/'acceptance'))
from support import Server,manifest
from nc65_fixtures import BOOKS,CURRENCIES,ENTITIES,sample_rows,nc_csv
from run_erp_api import maps_csv,openings_csv
from run_multilevel_browser import state,wait,go,click,action,scope,reopen,approve,retain_response_bodies
from playwright.sync_api import sync_playwright

SHOTS=KIT/'screenshots';RECORDS=[]

def photo(page,name,title,menu,button,action_name,purpose,*,selector=None,dialog_scroll=None):
    page.locator('#toast').wait_for(state='hidden',timeout=10000)
    assert 'token=' not in page.url
    if dialog_scroll is not None:
        page.get_by_role('dialog').evaluate('(e,y)=>e.scrollTop=y',dialog_scroll)
    if selector:
        page.locator(selector).first.evaluate("e=>{e.dataset.captureOutline=e.style.outline;e.style.outline='3px solid #e9594f';e.style.outlineOffset='3px';}")
    page.screenshot(path=str(SHOTS/name),full_page=False)
    if selector:
        page.locator(selector).first.evaluate("e=>{e.style.outline=e.dataset.captureOutline||'';e.style.outlineOffset='';delete e.dataset.captureOutline;}")
    RECORDS.append({'file':name,'title':title,'menu':menu,'button':button,'apiAction':action_name,'purpose':purpose,'context':state(page)['context'],'highlight':'仅截图时通过浏览器DOM描边突出目标，无产品源文件变更。' if selector else '无额外标注','sha256':hashlib.sha256((SHOTS/name).read_bytes()).hexdigest()})
    print('PHOTO',name,flush=True)

def make_fixture_files(folder):
    import openpyxl
    folder.mkdir(parents=True,exist_ok=True)
    pairs=[('mapping','01_科目映射_已填示例.xlsx',maps_csv()),('opening','02_年初余额_已填示例.xlsx',openings_csv()),('nc65','03_用友NC65_48列凭证_已填示例.xlsx',nc_csv(sample_rows()))]
    files={}
    for kind,name,text in pairs:
        wb=openpyxl.Workbook();ws=wb.active;ws.title='导入数据'
        for row in csv.reader(io.StringIO(text.lstrip('\ufeff'))):ws.append(row)
        for row in ws:
            for c in row:c.number_format='@'
        path=folder/name;wb.save(path);files[kind]=path
    return files

def nc_configure(page):
    go(page,'erp-import');click(page,'erp-nc-form')
    for i,eid in enumerate(ENTITIES):
        if i:click(page,'erp-nc-add-book')
        row=page.locator('[data-nc-book-row]').nth(i);row.locator('[data-book-code]').fill(BOOKS[eid]);row.locator('[data-book-entity]').select_option(eid);row.locator('[data-book-currency]').select_option(CURRENCIES[eid])
    for loc in page.locator('[data-nc-aux-column]').all():loc.uncheck()
    page.locator('[data-nc-aux-column][value="辅助核算1"]').check();page.locator('#erp-nc-reference').select_option('结算号')
    for i,(code,eid) in enumerate([('NC-'+x,x) for x in ENTITIES]+[('NC-EXTERNAL','EXTERNAL')]):
        if i:click(page,'erp-nc-add-party')
        row=page.locator('[data-nc-party-row]').nth(i);row.locator('[data-party-code]').fill(code);row.locator('[data-party-entity]').select_option(eid)
    photo(page,'02A_NC适配_账簿与本位币.png','维护NC适配：账簿与本位币','ERP凭证与期初','维护NC6.5适配→新增账簿映射','erp_adapter_save','配置准备表需逐行照填，系统没有配置Excel导入按钮。',dialog_scroll=0)
    photo(page,'02B_NC适配_辅助列关联号客商.png','维护NC适配：辅助列、共同号、客商','ERP凭证与期初','维护NC6.5适配→保存NC6.5适配','erp_adapter_save','辅助核算列可多选；共同号选结算号或核销号；明确外部客商。',dialog_scroll=650)
    out=action(page,'erp-nc-save');assert len(out['erp']['bookMappings'])==7

def upload(page,kind,path,n,title):
    go(page,'erp-import');page.locator(f'[data-action="erp-import-form"][data-kind="{kind}"]').first.click()
    page.locator('#erp-import-file').set_input_files(str(path));page.wait_for_function('name=>document.querySelector("#erp-import-name").value===name',arg=path.name)
    page.locator('#erp-import-unit').select_option('元');page.locator('#erp-import-sheet').fill('导入数据')
    if kind in ('voucher','nc65'):page.locator('#erp-posted-confirm').check()
    api={'mapping':'erp_mapping_save','opening':'erp_opening_import','nc65':'erp_voucher_import'}[kind]
    photo(page,n,title,'ERP凭证与期初','选择文件并导入' if kind!='nc65' else '导入NC6.5凭证',api,'选择真实XLSX、金额单位元、导入数据工作表；凭证须确认已记账。',dialog_scroll=0)
    return action(page,'erp-import-save')

def convert_match_approve(page,unit,*,photos=False):
    scope(page,unit);go(page,'erp-matching')
    if page.locator('[data-action="erp-demo-mode-form"]').count():
        if photos:photo(page,'09A_停用本层预置抵销.png','先转入凭证合并模式','内部交易匹配与差异','确认停用本层预置交易抵销','erp_demo_eliminations_replace','避免初始化手工交易与原凭证自动抵销重复扣减。',selector='[data-action="erp-demo-mode-form"]')
        click(page,'erp-demo-mode-form');page.locator('#erp-demo-mode-reason').fill('按实际导入的NC原凭证匹配，避免与初始化预置交易重复抵销。');action(page,'erp-demo-mode-save')
    result=action(page,'erp-match-run');m=result['erp']['matching'];assert not m['differences']
    if photos:photo(page,'09B_内部交易准确匹配.png','扫描后的准确匹配项','内部交易匹配与差异','扫描本层内部交易→准确匹配项生成抵销草稿','erp_match_run / erp_elimination_generate','本组鸿旺三项：内部销售80+20，应收应付20；均保存双方原凭证来源。')
    if m['matches']:
        action(page,'erp-match-generate');click(page,'erp-auto-approve-form');page.locator('#erp-bulk-approve-reason').fill('已逐项核对双方原始凭证和共同交易号，确认本层抵销。')
        if photos:photo(page,'09C_负责人审批自动抵销.png','财务负责人审批抵销草稿','内部交易匹配与差异','审批本层自动抵销草稿→确认批量审批','erp_eliminations_approve','准确匹配仍先形成草稿，经负责人审批后才进入本层合并。')
        action(page,'erp-auto-approve-save')
    return approve(page)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--example-dir',type=Path);args=parser.parse_args()
    before=manifest();errors=[];SHOTS.mkdir(exist_ok=True,parents=True)
    files=make_fixture_files(Path(tempfile.mkdtemp(prefix='epm-import-photo-fixtures-')))
    if args.example_dir:
        for kind,name in [('mapping','01_科目映射_已填示例.xlsx'),('opening','02_年初余额_已填示例.xlsx'),('nc65','03_NC65原48列凭证_已填示例.xlsx')]:
            p=args.example_dir/name
            assert p.is_file(),str(p)
            files[kind]=p
    with Server() as server,sync_playwright() as play:
        browser=play.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1600,'height':1160},locale='zh-CN',accept_downloads=True);page.set_default_timeout(45000);retain_response_bodies(page);page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(server.info['url'],wait_until='networkidle');page.wait_for_selector('#nav [data-route="erp-import"]');page.wait_for_function('()=>!location.hash.includes("token=")')
        for unit in ('HW_GROUP','OS_GROUP','TY_GROUP'):scope(page,unit);reopen(page)
        scope(page,'HW_GROUP');go(page,'erp-import')
        photo(page,'01_导入入口总览.png','三个资料入口和NC专用入口','ERP凭证与期初','科目映射／年初余额／完整凭证卡片及NC6.5区域','erp_mapping_save / erp_opening_import / erp_voucher_import','截图与用户当前同一功能点，四个文件入口用途不同，不可混导。')
        nc_configure(page)
        upload(page,'mapping',files['mapping'],'03_科目映射Excel导入.png','导入科目映射Excel')
        upload(page,'opening',files['opening'],'04_年初余额Excel导入.png','导入年初余额Excel')
        data=upload(page,'nc65',files['nc65'],'05_NC48凭证Excel导入.png','导入NC6.5原48列凭证Excel')
        assert (len(data['erp']['mappings']),len(data['erp']['openings']),len(data['erp']['vouchers']))==(84,14,48)
        go(page,'erp-import');click(page,'erp-import-form') if False else None
        page.locator('[data-action="erp-import-form"][data-kind="voucher"]').click()
        photo(page,'06_通用凭证替代入口.png','通用凭证替代入口','ERP凭证与期初','完整已记账凭证→选择文件并导入','erp_voucher_import format=generic','通用凭证与NC48为替代入口，不要同一批凭证两种格式重复导入。')
        click(page,'close-modal');go(page,'erp-import')
        page.locator('.panel-title').filter(has_text='导入批次与原始来源').scroll_into_view_if_needed()
        photo(page,'07_导入成功批次与映射.png','导入成功的批次及映射','ERP凭证与期初','整批校验并导入→导入批次与原始来源','erp_mapping_save / erp_opening_import / erp_voucher_import','84条映射、14行期初、48行凭证整批保存，原始批次与来源保留。')
        go(page,'erp-reports');data=action(page,'erp-generate-all');page.locator('#erp-entity-filter').select_option('HW');wait(page)
        assert data['erp']['reports']['HW']['statement']['actual']['revenue']==1000
        photo(page,'08_生成法人三表效果.png','凭证生成鸿旺单体三表','法人凭证与三表','生成全部已导入法人／生成当前法人三表源','erp_report_generate','凭证导入并不会自动签核合并；先生成法人三表，核对收入、净利及现金。')
        click(page,'erp-voucher-list');row=next(r for r in state(page)['erp']['vouchers'] if r['entityId']=='HW' and r['accountCode']=='1001')
        page.get_by_role('dialog').locator(f'[data-action="erp-annotate-form"][data-id="{row["id"]}"]').first.click()
        page.locator('#erp-annotate-cashflow').check();page.locator('#erp-annotation-cashflow').select_option('operating');page.locator('#erp-annotation-reason').fill('依据现金流水与对方科目，确认经营活动；截图仅展示填法，本次不提交。')
        photo(page,'12_现金流分类页面维护.png','现金行的现金流分类补注','法人凭证与三表','查看该法人原凭证→补充核对信息→更新此现金行的现金流分类','erp_voucher_annotations_save','现金流准备Excel无独立导入入口；原NC48列不增列，用现金行页面补注或通用凭证cashflow字段。')
        click(page,'close-modal')
        hw=convert_match_approve(page,'HW_GROUP',photos=True);a=hw['statement']['actual'];assert (a['revenue'],a['net'],a['assets'])==(1400,450,650)
        photo(page,'10A_鸿旺小合并已签核.png','鸿旺小合并计算及签核','分级合并与结果','计算本层新版本→签核当前结果','run / approve','引用三家独立法人源和本层已审批抵销，下级结果保存版本。')
        go(page,'statements');photo(page,'10B_鸿旺小合并报表效果.png','鸿旺小合并财务报表','集团三张报表','利润表／资产负债表／现金流量表','GET /api/bootstrap','本例鸿旺收入1400、净利450、资产650万元；报表可追溯到法人与凭证。')
        scope(page,'OS_GROUP');approve(page)
        root=convert_match_approve(page,'TY_GROUP');a=root['statement']['actual'];assert (a['revenue'],a['net'],a['assets'],a['cta'],a['cashFx'])==(2650,770,2370,74,90)
        go(page,'statements');photo(page,'11_集团上卷合并效果.png','集团人民币上卷效果','集团三张报表','先签核鸿旺与海外，再计算及签核集团','run / approve','集团收入2650、净利770、资产2370、CTA74、现金汇率影响90万元。')
        browser.close()
    after=manifest();assert before==after and not errors
    report={'passed':True,'capturedUtc':datetime.now(timezone.utc).isoformat(),'captureScriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'softwareBaseline':'ERP-20261021','productSourceUnchanged':before==after,'sourceSha256':after,'browser':{'engine':'Chromium','viewport':'1600x1160','locale':'zh-CN','isolatedTemporaryServer':True},'javascriptErrors':errors,'sample':{'source':'acceptance/nc65_fixtures.py independent original48 data, not sample_load','mappings':84,'openingRows':14,'voucherRows':48,'HW':{'revenue':1400,'net':450,'assets':650},'TY':{'revenue':2650,'net':770,'assets':2370,'cta':74,'cashFx':90}},'files':RECORDS,'xlsxInputs':{k:{'file':v.name,'sha256':hashlib.sha256(v.read_bytes()).hexdigest(),'source':'provided example' if args.example_dir and args.example_dir in v.parents else 'independent screenshot fixture only'} for k,v in files.items()},'notes':['图片为实际隔离本机服务，不是原型。','工作簿配置及现金流准备表不能直接导入；页面维护步骤在对应图列明。','截图不含启动凭据。']}
    (KIT/'evidence/截图与功能点索引.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':True,'photos':len(RECORDS),'HW':1400,'TY':2650},ensure_ascii=False))
if __name__=='__main__':main()
