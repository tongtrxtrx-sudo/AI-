"""One-time documentation-only XLSX edit: keep sheet1 XML and all business cells unchanged."""
from pathlib import Path
import hashlib,json,sys,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
S='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
OLD_MONEY='本套金额全部为法人本位币元，借贷金额最多两位小数；导入对话框选择“元”。日期推荐YYYY-MM-DD文本（2026年）。不要保留公式或宏。'
NEW_MONEY='法人入账只采用“本币借方金额/本币贷方金额”，按账簿本位币元保留两位；导入金额单位选“元”。NC原币金额按交易币、集团/全局金额按各原币种原值保留，不重复入账，不在模板中换算。单价、数量、汇率保留ERP原始精度，不按本币记账金额两位截断。日期推荐YYYY-MM-DD文本（2026年），只粘贴值，不保留公式或宏。'
OLD_PRICE='按NC源数据，金额建议两位'
NEW_PRECISION='保留ERP原始精度，不按本币记账金额两位截断'
OLD_USE='保留原值，集团/全局金额不重复入账，不在本模板做汇率公式。'
NEW_PRICE_USE='单价为原始参考字段，不直接参与法人记账；保留原值，不截断精度，不在模板中做换算公式。'
manifest=ROOT/'template-manifest.json';meta=json.loads(manifest.read_text());results=[]
for name in ['output/Excel模板/03_NC65原48列凭证_空白模板.xlsx','output/已填示例/03_NC65原48列凭证_已填示例.xlsx']:
 p=ROOT/name
 with zipfile.ZipFile(p) as z:
  infos=z.infolist();contents={i.filename:z.read(i.filename) for i in infos};before_sheet=hashlib.sha256(contents['xl/worksheets/sheet1.xml']).hexdigest();before_style=hashlib.sha256(contents['xl/styles.xml']).hexdigest();changed=[]
  for key,raw in list(contents.items()):
   # Header comments are explanatory text, in a separate XML part; sheet1 data/style stays byte-identical.
   if not ((key.startswith('xl/worksheets/sheet') or key.startswith('xl/comments/')) and key.endswith('.xml')):continue
   if key=='xl/worksheets/sheet1.xml':continue
   root=ET.fromstring(raw);modified=False
   if key.startswith('xl/worksheets/'):
    for row in root.findall('.//'+S+'row'):
     cells=row.findall(S+'c');values=[''.join(c.itertext()) for c in cells]
     if values and values[0]=='单价':
      for c in cells:
       for t in c.findall('.//'+S+'t'):
        if t.text==OLD_PRICE:t.text=NEW_PRECISION;modified=True
        if t.text==OLD_USE:t.text=NEW_PRICE_USE;modified=True
     elif values and values[0] in ['借方数量','贷方数量','组织本币汇率','集团本币汇率','全局本币汇率']:
      # Format guidance is column C in the four-column field dictionary only.
      for c in cells:
       if c.attrib.get('r','').startswith('C'):
        for t in c.findall('.//'+S+'t'):
         t.text='按NC原值保留ERP原始精度，不按金额两位截断';modified=True
    for t in root.findall('.//'+S+'t'):
     if t.text==OLD_MONEY:t.text=NEW_MONEY;modified=True
   else:
    for t in root.findall('.//'+S+'t'):
     if t.text and OLD_PRICE in t.text:
      t.text=t.text.replace(OLD_PRICE,NEW_PRECISION).replace(OLD_USE,NEW_PRICE_USE);modified=True
   if modified:contents[key]=ET.tostring(root,encoding='utf-8',xml_declaration=True);changed.append(key)
  assert contents['xl/worksheets/sheet1.xml']==z.read('xl/worksheets/sheet1.xml')
  assert contents['xl/styles.xml']==z.read('xl/styles.xml')
 assert changed,(p,'no edit found')
 with zipfile.ZipFile(p,'w') as z:
  for info in infos:z.writestr(info,contents[info.filename])
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  assert hashlib.sha256(z.read('xl/worksheets/sheet1.xml')).hexdigest()==before_sheet
  assert hashlib.sha256(z.read('xl/styles.xml')).hexdigest()==before_style
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 for t in meta['templates']:
  if t['file']==name:t['sha256']=h;t['bytes']=p.stat().st_size
  if t.get('exampleFile')==name:t['exampleSha256']=h
 results.append({'file':name,'sha256':h,'changedXmlParts':changed,'sheet1XmlUnchanged':True,'stylesXmlUnchanged':True})
manifest.write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
(ROOT/'evidence').mkdir(exist_ok=True)
(ROOT/'evidence/NC模板精度说明修订.json').write_text(json.dumps({'softwareChanged':False,'businessDataChanged':False,'results':results},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
