#!/usr/bin/env python3
"""Build paste-ready spreadsheets for the unchanged ERP-20261021 Demo.
No company data, formulas, macros or application changes are used.
"""
from pathlib import Path
import csv, hashlib, io, json, re, sys
from collections import defaultdict
from decimal import Decimal
from datetime import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.comments import Comment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.utils import get_column_letter
ROOT=Path(__file__).resolve().parents[1]
APP=Path('/workspace/epm-demo-vouchers')
SAMPLES=APP/'documentation-set/assets/产品案例NC65'
sys.path.insert(0,str(APP/'backend'))
from ledger import MAPPING_HEADERS,OPENING_HEADERS,VOUCHER_HEADERS,FIELD_NAMES
from multilevel_seed import seed_multilevel
ENTITIES=seed_multilevel()['entities'];BYID={e['id']:e for e in ENTITIES}
CONFIG=json.loads((SAMPLES/'04_NC65适配配置_仅本案例.json').read_text())
BLUE='173F6E';LIGHT='EAF0F9';ORANGE='FFF1DB';GRAY='60728C';BORDER='D8E1ED'
OUT=ROOT/'output';BLANK=OUT/'Excel模板';FILLED=OUT/'已填示例'
for p in [OUT,BLANK,FILLED]:p.mkdir(parents=True,exist_ok=True)

def csv_rows(name):
 with (SAMPLES/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.reader(f))
MAPPING=csv_rows('01_科目映射.csv');OPENING=csv_rows('02_2026年初余额.csv');NC=csv_rows('03_NC65_48列完整凭证.csv');NC_HEADERS=NC[0]
assert len(NC_HEADERS)==48

def normal(s):return re.sub(r'\s+','',s.lstrip('*').strip())

def base(title):
 w=Workbook();w.remove(w.active);w.properties.title=title;w.properties.subject='杭州天元宠物用品有限公司 · ERP-20261021 导入辅助资料'
 w.properties.creator='天元EPM交付';w.properties.description='虚构示例与空白模板分开；仅导入首表；无公式宏。';w.properties.created=datetime(2026,10,21)
 return w

def table_sheet(w,name,headers,rows=(),blank_rows=0,text_columns=None,money_columns=None,widths=None,comments=None):
 s=w.create_sheet(name);s.sheet_view.showGridLines=False;s.freeze_panes='A2';s.sheet_properties.pageSetUpPr.fitToPage=True;s.sheet_properties.outlinePr.summaryRight=False
 s.append(headers);s.row_dimensions[1].height=39
 for c in s[1]:c.fill=PatternFill('solid',fgColor=BLUE);c.font=Font(name='微软雅黑',color='FFFFFF',bold=True,size=10);c.alignment=Alignment(vertical='center',wrap_text=True)
 for i,h in enumerate(headers,1):
  s.column_dimensions[get_column_letter(i)].width=(widths or {}).get(h,23 if len(h)<=7 else 30)
  if comments and h in comments:s.cell(1,i).comment=Comment(comments[h],'填写规则')
 data=list(rows)
 for row in data:s.append(row)
 last=max(1+len(data),1+blank_rows)
 for row in s.iter_rows(min_row=2,max_row=last,max_col=len(headers)):
  for c in row:
   c.font=Font(name='微软雅黑',size=10,color='1C2F49');c.alignment=Alignment(vertical='top',wrap_text=False)
   c.border=Border(bottom=Side(style='hair',color=BORDER))
   if c.row%2==0:c.fill=PatternFill('solid',fgColor='F5F8FC')
   head=headers[c.column-1]
   c.number_format='0.00' if head in (money_columns or set()) else '@' if text_columns is None or head in text_columns else 'General'
  s.row_dimensions[row[0].row].height=22
 s.auto_filter.ref=f'A1:{get_column_letter(len(headers))}{max(2,last)}'
 s.print_options.horizontalCentered=False;s.print_title_rows='1:1';s.sheet_properties.pageSetUpPr.fitToPage=True
 s.page_setup.orientation='landscape';s.page_setup.paperSize=s.PAPERSIZE_A4;s.page_setup.fitToWidth=1;s.page_setup.fitToHeight=0
 s.oddHeader.center.text='杭州天元宠物用品有限公司 · ERP-20261021';s.oddFooter.right.text='第 &P 页 / 共 &N 页'
 return s

def note_sheet(w,title,items):
 s=table_sheet(w,title,['项目','说明'],items,widths={'项目':29,'说明':110})
 for row in s.iter_rows(min_row=2):
  for c in row:c.alignment=Alignment(wrap_text=True,vertical='top')
  s.row_dimensions[row[0].row].height=max(32,18*(1+len(str(row[1].value or ''))//72))
 return s

def dictionary(w,fields):
 s=table_sheet(w,'字段说明',['字段','填写要求','格式与枚举','作用或注意事项'],fields,widths={'字段':26,'填写要求':29,'格式与枚举':34,'作用或注意事项':85})
 for row in s.iter_rows(min_row=2):
  for c in row:c.alignment=Alignment(wrap_text=True,vertical='top')
  s.row_dimensions[row[0].row].height=max(40,18*(1+len(str(row[3].value or ''))//50))
 return s

def refs(w):
 s=table_sheet(w,'法人及字段字典',['法人编码','系统法人名称','法人本位币','集团报表字段','字段中文名称','正常方向建议'],[(e['id'],e['name'],e['currency'],'','','') for e in ENTITIES],widths={'系统法人名称':48,'字段中文名称':33})
 for n,(f,label) in enumerate(FIELD_NAMES.items(),2):
  s.cell(n,4,f);s.cell(n,5,label);s.cell(n,6,'借' if f in ['cash','receivable','inventory','prepaid','investment','fixed','intangible','deferred_asset','cost','expense','finance','tax'] else '贷')
 for name,col,end in [('EPM法人',1,len(ENTITIES)+1),('EPM报表字段',4,len(FIELD_NAMES)+1)]:
  w.defined_names.add(DefinedName(name,attr_text=f"'法人及字段字典'!${get_column_letter(col)}$2:${get_column_letter(col)}${end}"))
 return s

def validation(s,col,values=None,name=None,stop=True):
 v=DataValidation(type='list',formula1='='+name if name else '"'+','.join(values)+'"',allow_blank=True);v.showErrorMessage=stop;v.errorTitle='请核对填写值';v.error='请使用下拉选项或按字段说明填写。';v.showInputMessage=True;v.promptTitle='填表提示';v.prompt='只粘贴值，不修改表头；公式需先转为值。';s.add_data_validation(v);v.add(f'{get_column_letter(col)}2:{get_column_letter(col)}10001')

def common_notes(import_path,kind):
 return [('适用版本','ERP-20261021；本次为配套Excel资料，不改变已交付软件。'),('用途',kind),('系统入口',import_path),('只导入首表','直接导入文件时，工作表名称留空默认读取首表“导入数据”；也可明确填写“导入数据”。后面的填写说明/字段说明/填写示例不会一起导入。'),('从哪里开始粘贴','第一行是固定表头，从A2开始按列选择性粘贴“值”；不要粘贴标题、合计行、空列或额外备注列。先把来源编码设为文本，避免前导0/长数字已在源Excel中丢失。'),('空模板不是业务数据','首表不含任何示例业务行；全部留空导入会被拒绝“没有数据行”。只粘贴需要导入的真实完整数据。样例在后表及单独已填演示文件中。'),('金额与日期','本套金额全部为法人本位币元，借贷金额最多两位小数；导入对话框选择“元”。日期推荐YYYY-MM-DD文本（2026年）。不要保留公式或宏。'),('现有结果已签核','先按提示重开受影响合并层及祖先，再导入；首次使用真实凭证模式，负责人按页面确认停用本层预置演示销售抵销，保留投资权益及真实手工事项。'),('覆盖与纠错','同一有效凭证/期初不可重复导入。需纠错时先填写原因停用旧批次，再重导完整正确批次；不删除历史，不与已填演示数据混导。'),('导入不等于出报表','成功保存批次后，还须生成法人三表、扫描内部交易、处理差异、生成抵销草稿、审批及逐层计算签核。'),('Excel校验的边界','下拉和格式只帮助填表，粘贴可能绕过Excel校验；系统仍会校验法人、映射、日期、借贷平衡、重复及会计口径。'),('当前业务边界','本机Demo限定2026、100%全资全额、CNY/USD普通主体；在线NC接口未配置。复杂权益、商誉、少数股东、存货未实现内部利润等不在本版自动处理范围。')]

M_FIELDS=[
('法人编码','必填','HW、HW_CAT、HW_ELEC等；见法人字典','填写系统已存在的法人ID/编码/完整名称之一，推荐ID。不能填核算账簿码或未维护主体。'),
('科目编码','必填，按文本','如1001、1122、6001，保留前导0','同一法人下唯一；采用本法人NC实际科目编码。不同法人可有同一科目码。'),
('科目名称','建议填写','原科目名称，最长120字符','未填时系统以科目编码代替名称。'),
('报表字段','必填','选字段技术键，如cash/revenue/cost','也接受字典列出的字段中文名称。多个不同科目可归入同一报表字段；不能只把科目列在表里而不映射。nci/cta非本全资普通示例常规录入项。'),
('余额方向','必填','借、贷','为该科目的正常余额方向，不是当前行实际借贷发生方向；应与科目性质一致。')]
O_FIELDS=[
('法人编码','必填','系统法人ID','见法人字典；三家鸿旺账套独立且不重叠。'),('会计年度','必填','2026','指2026年年初，不是9月月初。'),('科目编码','必填，文本','已导入映射的ERP科目码','必须先导入科目映射；完整平衡期初须包含资产负债及权益等所有适用余额。'),('币种','必填','CNY或USD','须等于法人记账本位币。'),('期初借方余额','金额，空视为0','元，两位小数','同一行不允许借贷两边同时非0；逐法人借贷总额相等。负余额按真实源数据核对后保留。'),('期初贷方余额','金额，空视为0','元，两位小数','不能只导内部往来或资产而漏掉权益、负债。损益科目的年初余额应为0。'),('内部往来对方','内部应收/应付非0时须明确','内部法人ID；明确外部可填EXTERNAL','内部AR/AP期初按科目+对方+共同关联号分行；不能用科目总余额强配。外部及非往来字段按实际情况填写。'),('交易关联号','内部应收/应付非0时须明确','交易双方共享的业务关联号','须与对方辅助期初明细相符；不是给两边各自随机编一个号。'),('期初人民币留存收益','条件填写','人民币元，两位小数','USD法人期初留存收益非0时，需提供经确认的人民币历史余额用于折算；无留存可留空或0。不是填本期利润，也不是对每笔美元余额都填人民币换算数。')]
G_FIELDS=[
('法人编码','必填','系统法人ID','同NC替代：此文件按法人入账，不读取NC账簿映射。'),('凭证日期','必填','2026-09-15','本版只接收2026；同一凭证各行日期/本位币一致。'),('凭证类别','建议填写','如01、记','空时按“记”；同号不同类别不混。'),('凭证号','必填，文本','如0001','保留前导0，凭证唯一键包含法人、年月、类别和号。'),('分录序号','建议填写','1—999999整数','同一凭证内逐行唯一；空时系统按原行顺序生成。'),('科目编码','必填，文本','映射中的ERP科目码','不能用报表字段替代科目编码。'),('借方金额','至少一边非0','法人本币元，两位小数','一行不能借贷同时非0；整张凭证必须借贷平衡并完整导入。'),('贷方金额','至少一边非0','法人本币元，两位小数','真实红字负借/负贷可保留，内部负净交易本版可能列待人工差异。'),('币种','必填','CNY或USD','必须是法人本位币；含外币交易的NC原币请使用NC48格式保留。'),('摘要','建议填写','业务说明，最长500字符','包含“结转本年利润/本期损益/损益”的摘要会触发受限结转识别；不得把普通业务误写成结转。'),('内部往来对方','内部业务须明确','内部法人ID或EXTERNAL','通用格式不经过NC客商码映射，不能填NC-HW等ERP原客商码。'),('交易关联号','内部业务须明确','双方共同业务号','收入成本按双方、共同号、月份和币种匹配；AR/AP还核期初/期末余额。'),('内部交易类型','可填枚举；建议与科目一致','内部销售、内部成本、内部应收、内部应付','也接受sales/cost/receivable/payable；非内部业务可留空，不要把“EXTERNAL”填到交易类型。'),('现金流类别','条件填写，只填现金科目行','经营、投资、筹资，非现金行留空','混合经营/投资/筹资凭证需给现金行明确分类；不会自动倒挤现金差。'),('凭证类型','建议填写','业务或损益结转','损益结转仅允许整张平衡凭证由损益和留存类构成，原行与排除原因仍保留；其他权益变动不默认支持。')]

NC_MONEY_NOTE='法人入账只采用“本币借方金额/本币贷方金额”，按账簿本位币元保留两位；导入金额单位选“元”。NC原币金额按交易币、集团/全局金额按各原币种原值保留，不重复入账，不在模板中换算。原币借贷金额也受当前导入器元两位校验，不可截断数据绕过校验。单价、数量、汇率保留ERP原始精度，不按本币记账金额两位截断。日期推荐YYYY-MM-DD文本（2026年），只粘贴值，不保留公式或宏。'

def nc_fields():
 out=[]
 for h in NC_HEADERS:
  k=normal(h);star=h.lstrip().startswith('*');req='保留原导出列；NC原星号字段' if star else '保留原导出列；按源数据填写'
  fmt='文本，保留原值';use='只保留原始字段供追溯/核对，不直接参与本版法人记账。'
  if k=='核算账簿':req='必须能映射到系统法人';use='维护NC6.5适配→账簿映射，确定法人及记账本位币；不是填法人ID替换原账簿。'
  elif k in ['凭证类别编码','凭证号']:req='必须非空';use='与核算账簿、年月及源行共同区分凭证，保留前导0；不跨月/跨类别混号。'
  elif k=='制单日期':req='必须有效';fmt='YYYY-MM-DD，2026年';use='用于确定凭证日期和期间；NC导出无记账状态，须用户确认仅已记账业务。'
  elif k=='科目编码':req='必须已映射';use='在“①科目字段映射”导入本法人的实际ERP科目映射。'
  elif k=='币种':fmt='NC交易币种原值，如人民币/美元';use='这是交易币，不作为法人本位币；本位币来自账簿映射。'
  elif k in ['本币借方金额','本币贷方金额']:req='两列均保留，每行至少一边非0';fmt='元，两位小数';use='本版仅这两列形成法人账；同一行借贷不能同时非0，整张凭证借贷相等。'
  elif k in ['原币借方金额','原币贷方金额']:fmt='源导出金额，两位小数';use='保留原币金额，不与本币/集团币相加记账。此列金额也应是可解析数字，空按0。'
  elif k=='单价':fmt='保留ERP原始精度，不按本币记账金额两位截断';use='单价为原始参考字段，不直接参与法人记账；保留原值，不截断精度，不在模板中做换算公式。'
  elif k in ['借方数量','贷方数量']:fmt='按NC原值保留ERP原始精度，不按金额两位截断';use='按源导出保留数量，不参与本币金额计算。'
  elif '金额' in k:fmt='按NC源数据，金额建议两位';use='保留原值，集团/全局金额不重复入账，不在本模板做汇率公式。'
  elif k in ['制单人编码','附单据数']:fmt='按NC原值';use='保留审计来源；NC星号并不表示本版已经联网向NC核验此字段。'
  elif k=='摘要':fmt='原摘要文本，最长500字符';use='保留业务说明；受限损益结转按明确摘要识别并校验整张凭证，不误清零管理损益。'
  elif k in ['结算号','核销号']:req='按页面选定其中一个作为关联号';use='只读取“维护NC6.5适配”中选择的字段，交易双方内部业务须共用同一号；不是只凭相同金额猜配。'
  elif k.startswith('辅助核算'):req='按实际选中列配置';use='保留原客商码；在适配页面选实际使用的辅助列，并维护该列客商→内部法人或EXTERNAL。多列冲突或未映射不会默认为外部。'
  elif '日期' in k:fmt='推荐YYYY-MM-DD或原导出值';use='保留原字段核对；凭证入账期间以制单日期为准。'
  elif '汇率' in k:fmt='按NC原值保留ERP原始精度，不按金额两位截断';use='只保留核对，Demo不按这些列再次换算已入本币账；集团折算另有分类汇率。'
  out.append((h,req,fmt,use))
 return out

manifest={'softwareBaseline':'ERP-20261021','kitVersion':'IMPORT-KIT-20261021-D1.0','companyName':'杭州天元宠物用品有限公司','softwareChanged':False,'templates':[],'demoConfigFile':'output/已填示例/04_NC65适配配置_仅已填示例参照.json','amountUnit':'元','sourceHeaders':'用户确认的NC6.5全部48列原表头；星号及空格保留','notes':['所有直接导入文件首表为导入数据；说明/示例在后表。','配置准备表及现金流准备表没有独立文件导入入口；照页面维护/补注。','NC48与通用凭证二选一，同一业务不得两种都导入。']}

def build_import(tid,filename,headers,fields,sample,route,action,required,money_cols=None,types=None):
 w=base(filename);s=table_sheet(w,'导入数据',headers,blank_rows=1000,money_columns=set(money_cols or []),comments={f[0]:'；'.join(f[1:]) for f in fields})
 notes=common_notes(route,'空白粘贴模板；首表没有样例业务，避免误入账。')
 if tid=='nc65':notes=[(a,NC_MONEY_NOTE if a=='金额与日期' else b) for a,b in notes]
 note_sheet(w,'填写说明',notes)
 dictionary(w,fields);table_sheet(w,'填写示例_不要直接导入',headers,sample,money_columns=set(money_cols or []))
 refs(w)
 if tid in ('mapping','opening','generic'):validation(s,1,name='EPM法人',stop=False)
 if tid=='mapping':validation(s,4,name='EPM报表字段');validation(s,5,values=['借','贷'])
 if tid=='opening':validation(s,2,values=['2026']);validation(s,4,values=['CNY','USD']);validation(s,7,values=[e['id'] for e in ENTITIES]+['EXTERNAL'],stop=False)
 if tid=='generic':validation(s,9,values=['CNY','USD']);validation(s,11,values=[e['id'] for e in ENTITIES]+['EXTERNAL'],stop=False);validation(s,13,values=['内部销售','内部成本','内部应收','内部应付']);validation(s,14,values=['经营','投资','筹资']);validation(s,15,values=['业务','损益结转'])
 w.active=0;target=BLANK/filename;w.save(target)
 filledname=filename.replace('_空白模板.xlsx','_已填示例.xlsx').replace('_替代方案模板.xlsx','_已填示例.xlsx');fw=base(filledname)
 table_sheet(fw,'导入数据',headers,sample,money_columns=set(money_cols or []),comments={f[0]:'；'.join(f[1:]) for f in fields})
 note_sheet(fw,'演示说明',[('数据性质','全部为虚构。与本资料包空白模板分开存放，不可与真实数据或内置396行样例混导。'),('对应场景','独立NC48文件案例：84科目映射、14年初余额、48凭证分录，全部7家；鸿旺3匹配/集团1匹配。'),('预期结果','鸿旺收入1400/净利450/资产650万元；集团收入2650/净利770/资产2370/CTA74/现金汇率影响90万元。'),('适配配置','NC48导入前照04_NC65适配配置_仅已填示例参照.json维护7账簿、内部客商和EXTERNAL，辅助核算1/结算号。JSON没有直接导入按钮。'),('导入入口',route),('选表与单位','工作表留空默认首表导入数据；金额选元；凭证导入勾选已记账确认。')])
 if tid=='nc65':
  ws=fw['演示说明'];ws.append(['金额与原始精度',NC_MONEY_NOTE]);ws.cell(ws.max_row,2).alignment=Alignment(wrap_text=True,vertical='top');ws.row_dimensions[ws.max_row].height=135
 fw.save(FILLED/filledname)
 manifest['templates'].append({'id':tid,'file':target.relative_to(ROOT).as_posix(),'exampleFile':(FILLED/filledname).relative_to(ROOT).as_posix(),'importable':True,'sheetName':'导入数据','headers':headers,'columnCount':len(headers),'required':required,'importAction':action,'systemPath':route,'blankInputRows':1000,'notes':'默认首表只有固定表头和空输入区；后表说明不入账。NC与通用为替代路径。'})
 return target

# Keep all source CSV values as text; source numeric strings then retain exact cents and codes.
map_target=build_import('mapping','01_科目映射_空白模板.xlsx',MAPPING_HEADERS,M_FIELDS,MAPPING[1:],'ERP凭证工作台 → ERP凭证与期初 → ①科目字段映射 → 选择文件并导入','erp_mapping_save',['法人编码','科目编码','报表字段','余额方向'])
open_target=build_import('opening','02_年初余额_空白模板.xlsx',OPENING_HEADERS,O_FIELDS,OPENING[1:],'ERP凭证工作台 → ERP凭证与期初 → ②年初科目余额 → 选择文件并导入','erp_opening_import',['法人编码','会计年度','科目编码','币种'],money_cols=['期初借方余额','期初贷方余额','期初人民币留存收益'])
nc_target=build_import('nc65','03_NC65原48列凭证_空白模板.xlsx',NC_HEADERS,nc_fields(),NC[1:],'ERP凭证工作台 → ERP凭证与期初 → NC6.5导出适配 → 导入NC6.5凭证','erp_voucher_import(format=nc65)',['核算账簿','凭证类别编码','凭证号','制单日期','摘要','科目编码','币种','本币借方金额','本币贷方金额'],money_cols=[h for h in NC_HEADERS if '金额' in h])
# Derive the alternative generic file from the exact same independent NC transactions.
book={b['bookCode']:b for b in CONFIG['bookMappings']};cp={x['code']:x['entityId'] for x in CONFIG['counterpartyMappings']};maps={(r[0],r[1]):r[3] for r in MAPPING[1:]}
counts=defaultdict(int);generic=[]
for row in NC[1:]:
 x=dict(zip([normal(h) for h in NC_HEADERS],row));b=book[x['核算账簿']];eid=b['entityId'];key=(x['核算账簿'],x['制单日期'][:7],x['凭证类别编码'],x['凭证号']);counts[key]+=1;field=maps[(eid,x['科目编码'])]
 voucher=[dict(zip([normal(h) for h in NC_HEADERS],y)) for y in NC[1:] if (y[0],y[5][:7],y[1],y[2])==key]
 others={maps[(eid,v['科目编码'])] for v in voucher if maps[(eid,v['科目编码'])]!='cash'}
 cf='筹资' if field=='cash' and others & {'longloan','shortloan','capital'} else '经营' if field=='cash' else ''
 ic={'revenue':'内部销售','cost':'内部成本','receivable':'内部应收','payable':'内部应付'}.get(field,'') if cp[x['辅助核算1']]!='EXTERNAL' else ''
 generic.append([eid,x['制单日期'],x['凭证类别编码'],x['凭证号'],str(counts[key]),x['科目编码'],x['本币借方金额'],x['本币贷方金额'],b['functionalCurrency'],x['摘要'],cp[x['辅助核算1']],x['结算号'],ic,cf,'业务'])
generic_target=build_import('generic','06_通用凭证_替代方案模板.xlsx',VOUCHER_HEADERS,G_FIELDS,generic,'ERP凭证工作台 → ERP凭证与期初 → ③完整已记账凭证 → 选择文件并导入（与NC入口二选一）','erp_voucher_import(format=generic)',['法人编码','凭证日期','凭证号','科目编码','币种'],money_cols=['借方金额','贷方金额'])
# Manual configuration preparation; its first sheet deliberately identifies no file import API.
w=base('04_NC适配配置准备表');note_sheet(w,'填写说明_本表不直接导入',[
('重要：没有Excel导入入口','本准备表不能在任何文件导入按钮上传。填写后到“ERP凭证与期初→NC6.5导出适配→维护NC6.5适配”逐项照表维护并保存。'),('工作表1：账簿法人对应','一个NC核算账簿对应一个系统法人及本位币；法人需先在集团组织与持股维护。'),('工作表2：内部客商对应','客商编码须与辅助核算实际值一致；内部映到具体法人，已确认外部映EXTERNAL。可按辅助列限定，避免同码不同列冲突。'),('工作表3：辅助列和关联号','辅助核算1—9可选实际使用的多列；关联号只能选择结算号、核销号或不使用，内部自动匹配须有双方共同号。'),('同凭证唯一承接','原辅助值为空的收入/成本/应收/应付行，可仅承接同张凭证唯一已映射客商/关联号；多对方或多号不任取，原字段不改。'),('保存后的效果','保存配置只解释后续导入。更改规则不会改写已导入行；旧批次须停用后按新规则重导。'),('真实编码未提供','后表的HW_BOOK、NC-HW等均为已填示例编码。实际NC核算账簿/客商必须从你们自己的导出确认，不能把示例码当成企业真实码。')])
bookheaders=['NC核算账簿编码','系统法人编码','系统法人名称（核对）','法人记账本位币','备注（不录入系统）']
s=table_sheet(w,'账簿法人对应',bookheaders,blank_rows=200);validation(s,2,values=[e['id'] for e in ENTITIES],stop=False);validation(s,4,values=['CNY','USD'])
partyheaders=['NC内部或外部客商编码','限定辅助核算列（可空）','映射到系统法人或EXTERNAL','业务名称（核对）','是否已核实真实客商','备注（不录入系统）']
s=table_sheet(w,'内部客商对应',partyheaders,blank_rows=1000);validation(s,2,values=[f'辅助核算{i}' for i in range(1,10)]);validation(s,3,values=[e['id'] for e in ENTITIES]+['EXTERNAL'],stop=False);validation(s,5,values=['是','待核实'])
ruleheaders=['选中的辅助核算列（每行一列）','共同交易关联号字段','选择依据与双方共用情况（核对）']
s=table_sheet(w,'辅助列和关联号',ruleheaders,blank_rows=20);validation(s,1,values=[f'辅助核算{i}' for i in range(1,10)]);validation(s,2,values=['结算号','核销号','不使用'])
table_sheet(w,'已填示例_账簿',bookheaders,[[x['bookCode'],x['entityId'],BYID[x['entityId']]['name'],x['functionalCurrency'],'虚构示例'] for x in CONFIG['bookMappings']])
table_sheet(w,'已填示例_客商',partyheaders,[[x['code'],'辅助核算1',x['entityId'],BYID.get(x['entityId'],{'name':'明确外部客商'})['name'],'是','仅本演示例'] for x in CONFIG['counterpartyMappings']])
table_sheet(w,'已填示例_规则',ruleheaders,[['辅助核算1','结算号','虚构示例，内部业务双方使用共同业务号；真实使用时重新核实。']])
refs(w);target=BLANK/'04_NC适配_页面配置准备表.xlsx';w.save(target)
manifest['templates'].append({'id':'config','file':target.relative_to(ROOT).as_posix(),'exampleFile':None,'importable':False,'sheetName':'填写说明_本表不直接导入','headers':bookheaders,'columnCount':len(bookheaders),'importAction':None,'systemPath':'ERP凭证与期初 → NC6.5导出适配 → 维护NC6.5适配 → 逐项填写并保存','notes':'没有Excel或JSON一键配置导入入口；此表作为手工维护清单。'})
# Cashflow classification worksheet is a preparation list, not an invented standalone input API.
w=base('05_现金流分类准备表');note_sheet(w,'填写说明_本表不直接导入',[
('重要：没有独立导入入口','本表用于整理需要判断的现金凭证，不是在“期初余额”或“NC凭证”入口单独导入的财务数据。'),('NC48列如何处理','不增加第49列。NC完整文件先导入；系统对单一无歧义对方科目推导现金类别。无法分类时定位具体现金行，按真实依据点击“补充核对信息”补经营/投资/筹资及原因，再重新生成法人源。'),('补注入口','法人凭证与三表→查看该法人原凭证（或ERP凭证与期初→批次→查看原始行）→有效现金行的“补充核对信息”；已签结果先按提示重开。'),('通用替代路径','若在导入前即可明确分类，可使用06通用凭证模板的“现金流类别”列，仅填现金科目行。06与03为替代路径，同一凭证不可重复导入。'),('分类依据','经营：销售/采购/日常费用等；投资：适用资产取得处置等；筹资：适用借款/还款等。须依据真实业务，不按摘要关键词或金额大小猜。'),('混合分类边界','同一凭证含多类现金流时，本Demo要求现金行本身能够明确分类；如果一条现金行不能唯一归类，不能自动按比例猜拆。先由财务在ERP按业务明细拆分并核对真实现金分录后重导；不能将一条多类现金行任意整行归到一种，也不能倒挤补平。'),('不能改原凭证金额','补注只改规范化现金分类/关联信息，原NC金额和字段保持；金额错误须回ERP更正、停用旧导入批次并重导。')])
cfheaders=['系统法人编码','NC核算账簿编码','凭证日期','凭证类别编码','凭证号','NC原文件行号','现金科目编码','摘要（核对）','本币借方金额（元）','本币贷方金额（元）','现金流类别','分类依据与补注原因','处理状态（仅清单）','系统导入批次ID（导入后补）','处理方式']
s=table_sheet(w,'待归类现金行',cfheaders,blank_rows=1000,money_columns={'本币借方金额（元）','本币贷方金额（元）'});validation(s,1,values=[e['id'] for e in ENTITIES],stop=False);validation(s,11,values=['经营','投资','筹资']);validation(s,13,values=['待核对','已补注待生成','已生成核对'])
table_sheet(w,'填写示例_不要单独导入',cfheaders,[['HW','HW_BOOK','2026-09-15','01','0001','2','1001','鸿旺外部销售收款','8500000.00','0.00','经营','已核对同凭证收入科目，销售收款，虚构示例','待核对','','核对后按页面提示补注；无歧义业务也可自动推导'],['OS_A','OS_A_BOOK','2026-09-15','01','0001','依实际原行填写','1001','取得借款，虚构分类示例','400000.00','0.00','筹资','核对真实借款依据；此行为分类说明，不是本套完整凭证额外数据','待核对','','仅作分类示例；非本套待导凭证']],money_columns={'本币借方金额（元）','本币贷方金额（元）'})
refs(w);target=BLANK/'05_现金流分类_准备表.xlsx';w.save(target)
manifest['templates'].append({'id':'cashflow','file':target.relative_to(ROOT).as_posix(),'exampleFile':None,'importable':False,'sheetName':'填写说明_本表不直接导入','headers':cfheaders,'columnCount':len(cfheaders),'importAction':None,'systemPath':'有效原始凭证现金行 → 补充核对信息；或将06通用凭证中的现金流类别随整张凭证导入','notes':'不是独立导入数据，不向NC48表头增加现金类别列；非现金科目行不得填现金类别。'})
# Copy exact reference JSON; manual UI only, not an advertised JSON import.
(FILLED/'04_NC65适配配置_仅已填示例参照.json').write_text(json.dumps(CONFIG,ensure_ascii=False,indent=2)+'\n')
(FILLED/'先读我_演示与真实资料不可混导.md').write_text('''# 已填示例的使用范围

全部为虚构业务，只用于ERP-20261021新测试账套。01为84行映射，02为14行期初，03为NC48列48行凭证；06是同一交易集的通用格式替代，03与06只能二选一，不能双重入账。

04 JSON只是逐项照页面维护的配置参照，没有JSON导入按钮。模板中的HW_BOOK/NC-HW等不是你们真实NC编码。

顺序：重开相关层→维护NC适配（用03时）→导入01→导入02→导入03或06→生成七家法人→扫描鸿旺→确认停用本层预置交易抵销→准确项生成草稿并批审→鸿旺签核→海外签核→集团本层扫描/转换/审批→集团签核。

鸿旺本文件案例内部销售已结80+未结20，应收应付20；准确匹配3项，收入1400/净利450/资产650万元。集团本层1项50万元销售，集团收入2650/净利770/资产2370/CTA74/现金FX90万元。不要与产品内置396行/18+9匹配样例混用。

真实资料粘贴到Excel模板目录的空模板，从A2开始粘贴值，完整原凭证借贷平衡，金额元、日期2026。不得把表外示例合计或说明作为业务分录导入。
''',encoding='utf-8')
manifest['templates'].sort(key=lambda x:x['file'])
for item in manifest['templates']:
 p=ROOT/item['file'];item['bytes']=p.stat().st_size;item['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 if item['exampleFile']:
  p=ROOT/item['exampleFile'];item['exampleSha256']=hashlib.sha256(p.read_bytes()).hexdigest();item['exampleRows']=load_workbook(p,read_only=True).worksheets[0].max_row-1
manifest['sourceSha256']={str(p.relative_to(APP)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [APP/'backend/ledger.py',APP/'backend/erp_domain.py',APP/'frontend/dist/index.html']}
(ROOT/'template-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'templates':len(manifest['templates']),'importable':sum(t['importable'] for t in manifest['templates']),'files':[t['file'] for t in manifest['templates']],'exampleRows':{t['id']:t.get('exampleRows') for t in manifest['templates']}},ensure_ascii=False))
