#!/usr/bin/env python3
"""Artifact checks accompanying an independent, source-based editorial review.

The semantic checklist is signed only after the reviewer has read the manuscript
and all worksheet instructions. It is not inferred from keyword hits alone.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,sys,zipfile
import openpyxl
ROOT=Path(__file__).resolve().parents[1]
PRODUCT=Path('/workspace/epm-demo-vouchers')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run():
 meta=json.loads((ROOT/'template-manifest.json').read_text())
 release=json.loads((ROOT/'release.json').read_text())
 text=(ROOT/'content/导入模板与操作说明.md').read_text()
 assert not re.search(r'\{\{SHOT_',text),'文稿截图占位尚未全部替换。'
 assert '导入模板D1.0' in text
 assert meta['softwareBaseline']==release['softwareBaseline']=='ERP-20261021'
 assert meta['softwareChanged'] is False and release['softwareChanged'] is False
 assert len(meta['templates'])==6
 normalized_nc=json.loads((PRODUCT/'research-erp/NC65-HEADERS.json').read_text())
 # Research JSON is the independently confirmed user header list.
 if isinstance(normalized_nc,dict):normalized_nc=normalized_nc.get('headers',normalized_nc.get('columns'))
 normalize=lambda s:re.sub(r'\s+','',str(s or '').lstrip('\ufeff').strip().lstrip('*').strip())
 records=[]
 for spec in meta['templates']:
  p=ROOT/spec['file'];assert sha(p)==spec['sha256'],p
  with zipfile.ZipFile(p) as z:assert z.testzip() is None
  book=openpyxl.load_workbook(p,data_only=False)
  first=book.worksheets[0]
  assert first.sheet_state=='visible' and first.protection.sheet is False
  formulas=[f'{s.title}!{c.coordinate}' for s in book for row in s for c in row if c.data_type=='f']
  assert not formulas,(p.name,formulas)
  record={'id':spec['id'],'file':spec['file'],'sha256':sha(p),'importable':spec['importable'],'firstSheet':first.title,'sheets':book.sheetnames,'noCellFormulas':True,'zipCrcPassed':True}
  if spec['importable']:
   assert first.title==spec['sheetName']=='导入数据'
   headers=[first.cell(1,c).value for c in range(1,first.max_column+1)]
   assert headers==spec['headers'] and len(headers)==spec['columnCount']
   assert all(c.value is None for row in first.iter_rows(min_row=2) for c in row),p.name+'空模板混入业务数据'
   assert '字段说明' in book and '填写说明' in book
   fields=[row[0] for row in list(book['字段说明'].values)[1:]]
   assert fields==headers
   assert first.freeze_panes=='A2' and first.auto_filter.ref
   if spec['id']=='nc65':
    assert list(map(normalize,headers))==list(map(normalize,normalized_nc)) and len(headers)==48
    assert first.cell(2,1).number_format=='@' and first.cell(2,8).number_format=='@'
    instructions=dict(book['填写说明'].values)
    assert '全部为法人本位币元' not in instructions.get('金额与日期',''),'NC原币字段不能宣传全部本位币'
    price=next(row for row in book['字段说明'].values if row[0]=='单价')
    assert not any('建议两位' in str(v) for v in price),'原始单价不可建议截为账务2位'
   record.update(headerCount=len(headers),blankInputRows=first.max_row-1,firstSheetContainsNoBusinessRows=True)
   ep=ROOT/spec['exampleFile'];assert sha(ep)==spec['exampleSha256']
   with zipfile.ZipFile(ep) as z:assert z.testzip() is None
   eb=openpyxl.load_workbook(ep,data_only=False);es=eb.worksheets[0]
   assert es.title=='导入数据'
   erows=[row for row in es.iter_rows(min_row=2,values_only=True) if any(v is not None for v in row)]
   assert len(erows)==spec['exampleRows']
   assert not any(c.data_type=='f' for s in eb for row in s for c in row)
   record['example']={'file':spec['exampleFile'],'sha256':sha(ep),'rows':len(erows),'zipCrcPassed':True}
  else:
   assert '不直接导入' in first.title and spec['importAction'] is None
   content='\n'.join(str(c.value or '') for row in first for c in row)
   assert '没有' in content and '导入入口' in content
   record['manualPreparationOnly']=True
  records.append(record)
 shots_path=ROOT/'evidence/截图与功能点索引.json'
 shots=json.loads(shots_path.read_text())
 assert shots.get('passed') is True and shots.get('productSourceUnchanged') is True
 assert not shots.get('javascriptErrors')
 for key,value in shots['xlsxInputs'].items():
  spec=next(t for t in meta['templates'] if t['id']==key)
  assert value['source']=='provided example' and value['sha256']==sha(ROOT/spec['exampleFile']),key+'截图输入不是最终交付文件'
 for item in shots['files']:
  assert item['sha256']==sha(ROOT/'screenshots'/item['file']),item['file']
 # Inspect the actual final evidence schema separately; bind all referenced PNGs.
 images={p.relative_to(ROOT).as_posix():sha(p) for p in sorted((ROOT/'screenshots').glob('*.png'))}
 assert len(images)>=16
 for rel in re.findall(r'!\[[^\]]*\]\(([^)]+)\)',text):
  from urllib.parse import unquote
  assert (ROOT/'content'/unquote(rel)).resolve().is_file(),rel
 source=release['sourceSha256']
 for rel,digest in source.items():assert sha(PRODUCT/rel)==digest,rel
 checks=[
  '独立实读导入说明全文以及6本Excel说明/字段字典，并对照ledger.py、erp_domain.py及前端实际按钮。',
  '01科目、02期初、03NC48、06通用首表固定表头、数据从第2行粘贴值，说明和示例不随首表入账。',
  '04配置、05现金分类是手工页面准备清单，明确没有独立上传入口；不把NC配置JSON宣称一键导入。',
  'NC原48表头完整，法人本币入账与交易原币/集团/全局原值保留分开，单价/数量/汇率不按账务2位擅截。',
  '编码文本及ISO日期、元两位与报表万元六位、2026年度、整张凭证平衡及去重均说明。',
  '鸿旺3独立法人且报表不重叠；管理范围与真实天元100%持股分开。',
  '内部客商按完整原值和选中辅助列映射；外部明确EXTERNAL，不把未知客商或空白默认为外部。',
  '内部期初AR/AP按对方和共同关联号分拆，逐法人完整期初平衡，不能只用总余额强配。',
  '角色负责人、已签依赖重开、整7家分别重开HW/OS、预置100/50明确转换且保留投资权益950等步骤齐。',
  '现金流仅现金行、单行单类别，混合类别需真实业务拆分，不用补差或比例猜分。',
  '普通导入后仍需生成单体、匹配、草稿、负责人审批、计算、签核；不宣称导入即自动完成全部报表。',
  'NC48直接文件案例84映射/14期初/48分录与内置396行分别说明，HW3/root1和HW18/root9不混用。',
  '三体收入1500-内部100=1400；资产670-应收20=650；净利450；集团2650/770/2370/CTA74/现金FX90案例口径明确。',
  '补注不改原NC金额、停批重导保留历史、旧批只读与新批可补注，以及重扫差异当前性说明正确。',
  '同ERP-20261021的模板指南补充不冒称软件升级；NC在线未连接与受限会计口径明确。'
 ]
 bound_files={rec['file']:rec['sha256'] for rec in records}
 for rec in records:
  if 'example' in rec:bound_files[rec['example']['file']]=rec['example']['sha256']
 result={'passed':True,'guideSha256':sha(ROOT/'content/导入模板与操作说明.md'),'templateFilesSha256':bound_files,'screenshotsSha256':images,'reviewedUtc':datetime.now(timezone.utc).isoformat(),'softwareBaseline':'ERP-20261021','kitVersion':meta['kitVersion'],'softwareChanged':False,'sourceMarkdownSha256':{'content/导入模板与操作说明.md':sha(ROOT/'content/导入模板与操作说明.md')},'templateManifestSha256':sha(ROOT/'template-manifest.json'),'templates':records,'sourceSha256':source,'screenshotEvidenceSha256':sha(shots_path),'screenshotImageSha256':images,'substantiveChecks':checks,'method':'语义由审阅者逐章/逐说明表对实际源码核对；结构脚本只证明被审阅文件仍为相同字节，不以关键词代替内容审查。','limitations':['本报告不替代独立真实HTTP/XLSX业务导入验收。','Word/PDF排版、公开下载及Windows真机验证由主代理另行登记。','示例金额与ERP编码为虚构；真实ERP导出完整性及会计政策须业务核对。']}
 (ROOT/'evidence/导入模板说明独立核对.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 lines=['# Excel模板与导入说明独立核对','',f'结论：同ERP-20261021软件的{meta["kitVersion"]}模板和说明实质核对通过。','', '## 审阅内容','']+['- '+s for s in checks]+['','## 字节绑定','','当前说明原稿、6份模板、4份已填XLSX、模板清单、16张截图与实际软件源码摘要详见同名JSON。','', '## 范围','','本审查签语义和文件结构；真实XLSX导入、Word/PDF排版及发布下载由各自验收记录承担。未改已发布软件、数据库或既有四册文档。','']
 (ROOT/'evidence/导入模板说明独立核对.md').write_text('\n'.join(lines))
 print(json.dumps({'passed':True,'templates':len(records),'examples':sum('example' in r for r in records),'screenshots':len(images),'sourceFiles':len(source)},ensure_ascii=False))
if __name__=='__main__':run()
