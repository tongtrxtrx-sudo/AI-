#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 meta=json.loads((ROOT/'release.json').read_text());assert meta['softwareChanged'] is False
 product=Path('/workspace/epm-demo-vouchers');sys.path.insert(0,str(product/'acceptance'));from support import manifest
 current=manifest();assert current==meta['sourceSha256'],'本次操作意外改动软件源码'
 template=json.loads((ROOT/'template-manifest.json').read_text());assert len(template['templates'])==6 and template['kitVersion']==meta['kitVersion']
 for t in template['templates']:
  assert sha(ROOT/t['file'])==t['sha256'],t['file']
  if t.get('exampleFile'):assert sha(ROOT/t['exampleFile'])==t['exampleSha256']
 qa=json.loads((ROOT/'acceptance/Excel模板真实导入验收.json').read_text());assert qa['passed'] is True and qa['sourceUnchangedDuringRun'] is True and qa['sourceSha256']==current
 assert qa.get('inputFilesUnchangedDuringRun') is True
 for name,digest in qa['inputSha256'].items():assert sha(ROOT/name)==digest,name
 assert len(qa['cases'])==6 and all(x['passed'] for x in qa['cases'])
 shots=json.loads((ROOT/'evidence/截图与功能点索引.json').read_text());assert shots['passed'] and shots['productSourceUnchanged'] and shots['sourceSha256']==current and not shots['javascriptErrors']
 assert len(shots['files'])==16
 for s in shots['files']:assert sha(ROOT/'screenshots'/s['file'])==s['sha256'],s['file']
 for item in shots['xlsxInputs'].values():assert item['source']=='provided example' and sha(ROOT/'output/已填示例'/item['file'])==item['sha256']
 review=json.loads((ROOT/'evidence/导入模板说明独立核对.json').read_text());assert review['passed'] and review['softwareBaseline']==meta['softwareBaseline']
 guide=ROOT/'content/导入模板与操作说明.md';assert review['guideSha256']==sha(guide)
 for name,digest in review['templateFilesSha256'].items():assert sha(ROOT/name)==digest,name
 for name,digest in review['screenshotsSha256'].items():assert sha(ROOT/name)==digest,name
 build=json.loads((ROOT/'evidence/word-build.json').read_text())[0];assert build['sourceSha256']==sha(guide) and build['figures']==16
 stem='天元EPM_Excel模板填写与导入操作说明';word=ROOT/'output'/(stem+'.docx');pdf=ROOT/'output'/(stem+'.pdf')
 assert build['sha256']==sha(word)
 with zipfile.ZipFile(word) as z:
  assert z.testzip() is None;tree=ET.fromstring(z.read('word/document.xml'));ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';text=''.join(t.text or '' for t in tree.iter(ns+'t'))
  for key in ['杭州天元宠物用品有限公司','ERP-20261021','导入模板D1.0','没有独立Excel上传入口','本币借贷','EXTERNAL','1400','2650']:assert key in text,key
  assert len([n for n in z.namelist() if n.startswith('word/media/')])==16
 assert pdf.read_bytes().startswith(b'%PDF-');info=subprocess.check_output(['pdfinfo',str(pdf)],text=True);pages=int(re.search(r'^Pages:\s+(\d+)',info,re.M).group(1))
 bbox=ROOT/'evidence/说明书文字边界.html';subprocess.run(['pdftotext','-bbox-layout',str(pdf),str(bbox)],check=True);tree=ET.parse(bbox);issues=[]
 for n,p in enumerate(tree.findall('.//{http://www.w3.org/1999/xhtml}page'),1):
  w,h=float(p.attrib['width']),float(p.attrib['height'])
  for t in p.iter('{http://www.w3.org/1999/xhtml}word'):
   b=[float(t.attrib[k]) for k in ('xMin','yMin','xMax','yMax')]
   if b[0]<-.5 or b[1]<-.5 or b[2]>w+.5 or b[3]>h+.5:issues.append((n,t.text))
 assert not issues,issues[:5]
 result={'passed':True,'softwareBaseline':meta['softwareBaseline'],'kitVersion':meta['kitVersion'],'softwareChanged':False,'sourceSha256':current,'templateCount':6,'directImportTemplateCount':4,'manualPreparationTemplateCount':2,'exampleExcelCount':4,'actualXlsxAcceptanceGroups':6,'realScreenshots':16,'documents':{'word':{'file':word.name,'sha256':sha(word),'bytes':word.stat().st_size},'pdf':{'file':pdf.name,'sha256':sha(pdf),'bytes':pdf.stat().st_size,'pages':pages,'outOfPageWords':0}},'guideSha256':sha(guide),'semanticReviewSha256':sha(ROOT/'evidence/导入模板说明独立核对.json'),'actualInputFilesSha256':qa['inputSha256'],'scope':'同ERP版本模板指南补充，非EXE升级。Word/PDF边界机器检查另配代表页视检。'}
 (ROOT/'evidence/交付校验.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':True,'templates':6,'wordPdfPages':pages,'screenshots':16},ensure_ascii=False));return result
if __name__=='__main__':main()
