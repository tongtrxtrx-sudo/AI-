"""Real Chromium DOM integration using the single-file content offline.
Cloud-managed Chromium blocks file://; set_content executes identical HTML.
"""
import json,hashlib,math,datetime,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
files=[ROOT/'dist/01_完整产品交互原型.html',ROOT/'dist/02_合并与经营分析交互原型.html']
payloads={f:f.read_bytes() for f in files}
report={'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':'Linux Chromium via Playwright, HTML read_text to set_content; cloud browser policy blocks file://','windows_double_click_tested':False,'checks':[],'errors':[],'network_requests':[]}
def check(name,condition,details=None):
 report['checks'].append({'name':name,'passed':bool(condition),'details':details})
 if not condition:raise AssertionError(name+': '+str(details))
def near(a,b):return abs(a-b)<0.0001
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  contexts=[]
  for file in files:
   ctx=browser.new_context(accept_downloads=True,viewport={'width':1440,'height':1050});contexts.append(ctx)
   page=ctx.new_page();page.on('pageerror',lambda e:report['errors'].append(str(e)))
   page.on('request',lambda r:report['network_requests'].append(r.url) if r.url.startswith(('http://','https://')) else None)
   page.route('**/*',lambda route:route.abort() if route.request.url.startswith(('http://','https://')) else route.continue_())
   page.set_content(payloads[file].decode('utf-8'),wait_until='load');page.wait_for_function('window.EPMPrototype!==undefined')
   variant=page.evaluate('EPMPrototype.variant');prefix=variant+': '
   check(prefix+'persistent demonstration notice',page.locator('.demo').inner_text()=='交互原型·演示数据')
   for route in ['overview','org','master','sources','submissions','rates','ownership','intercompany','journals','closing','statements','budget-cycle','budget-sheet','budget-adjust','budget-version','analysis','reports','permissions','audit','settings']:
    page.locator(f'[data-route="{route}"]').click()
    check(prefix+'navigation '+route,page.locator('#app h1').count()==1)
   page.locator('[data-route="overview"]').click()
   snapshot=page.evaluate('EPMPrototype.inspect()');bs={r[2]:r[1] for r in snapshot['balance']};cf={r[2]:r[1] for r in snapshot['cash']}
   check(prefix+'default group revenue/net',near(snapshot['actual']['revenue'],13000) and near(snapshot['actual']['net'],1720))
   check(prefix+'default assets balance',near(bs['assets'],9580) and near(bs['assets'],bs['liabilities']+bs['equity']))
   check(prefix+'cash cross-statement tie',near(cf['cash'],bs['cash']) and near(cf['cash'],cf['openingcash']+cf['change']))
   page.select_option('#context-group','manufacturing');snapshot=page.evaluate('EPMPrototype.inspect()');bs={r[2]:r[1] for r in snapshot['balance']};cf={r[2]:r[1] for r in snapshot['cash']}
   check(prefix+'subgroup switches income',near(snapshot['actual']['revenue'],8000) and near(snapshot['actual']['net'],1125))
   check(prefix+'subgroup full statements balanced',near(bs['assets'],6212) and near(bs['assets'],bs['liabilities']+bs['equity']) and near(bs['cash'],cf['cash']) and near(cf['cash'],cf['openingcash']+cf['change']))
   page.select_option('#context-group','group');page.select_option('#context-period','8');snapshot=page.evaluate('EPMPrototype.inspect()');check(prefix+'period genuinely changes actual',near(snapshot['actual']['revenue'],11410))
   page.select_option('#context-currency','USD');page.locator('[data-route="statements"]').click()
   with page.expect_download() as info:page.locator('[data-action="export-statement"]').click()
   download=info.value;target=ROOT/'evidence'/f'{variant}-profit-usd.csv';download.save_as(target);csv=target.read_text(encoding='utf-8-sig')
   check(prefix+'CSV is real USD value not changed label only','1607.04' in csv and '演示数据' in csv)
   page.select_option('#context-period','9');page.select_option('#context-currency','CNY')
   page.locator('[data-action="statement-drill"]').first.click();check(prefix+'statement drill opens real entity amounts','8,000.00' in page.locator('.dialog').inner_text());page.locator('[data-action="close-modal"]').first.click()
   if variant=='full':
    page.locator('[data-route="budget-sheet"]').click();page.locator('[data-action="budget-spread"]').click();allocated=page.locator('.dialog tbody tr td:last-child').all_inner_texts();numbers=[float(x.replace(',','')) for x in allocated];check('full: monthly posted amounts tie to period and annual',near(sum(numbers[:9]),13800) and near(sum(numbers[:12]),18400));page.locator('[data-action="close-modal"]').first.click();check('full: initial revenue and net budget correct',page.evaluate('Math.abs(budget().revenue-13800)<0.0001 && Math.abs(budget().net-1990)<0.0001'))
    page.locator('[data-action="budget-edit-layer"]').last.click();page.fill('#layer-amount','');page.locator('[data-action="budget-save-layer"]').click();check('full: blank amount rejected',near(sum(x['amount'] for x in page.evaluate('EPMPrototype.inspect().budget.layers')),18400));page.fill('#layer-amount','633.33');page.locator('[data-action="budget-save-layer"]').click()
    s=page.evaluate('EPMPrototype.inspect()');check('full: editing budget layer updates total',near(sum(x['amount'] for x in s['budget']['layers']),18500))
    page.locator('[data-action="budget-spread"]').click();check('full: twelve-month spread real preview',page.locator('.dialog tbody tr').count()==13 and '18,500.00' in page.locator('.dialog').inner_text());page.locator('[data-action="close-modal"]').first.click()
    page.select_option('[data-filter="spread"]','seasonal');page.locator('[data-route="overview"]').click();seasonal=page.locator('polyline').first.get_attribute('points');page.locator('[data-route="budget-sheet"]').click();page.select_option('[data-filter="spread"]','even');page.locator('[data-route="overview"]').click();even=page.locator('polyline').first.get_attribute('points');check('full: seasonal curve genuinely changes',seasonal!=even)
    page.locator('[data-route="budget-cycle"]').click();page.locator('[data-action="budget-submit"]').click();page.locator('[data-action="budget-approve"]').click();page.locator('[data-action="budget-lock"]').click();check('full: submit approve lock workflow',page.evaluate('EPMPrototype.inspect().budget.status')=='已锁定')
    page.locator('[data-route="budget-sheet"]').click();check('full: locked budget cannot direct edit',page.locator('[data-action="budget-edit-layer"]:enabled').count()==0)
    page.locator('[data-route="budget-version"]').click();page.locator('[data-action="budget-copy"]').click();page.fill('#version-name','V3 经营预测');page.locator('[data-action="budget-copy-save"]').click();check('full: independent budget copy',page.evaluate('EPMPrototype.inspect().budget.versions.length')==3 and page.evaluate('EPMPrototype.inspect().budget.status')=='编制中')
    page.locator('[data-route="budget-adjust"]').click();page.locator('[data-action="budget-adjust-new"]').click();page.fill('#adjust-reason','<b id="prototype-review-text">应原样显示的原因</b>');page.locator('[data-action="budget-adjust-save"]').click();check('full: free text remains inert',page.locator('#prototype-review-text').count()==0 and '<b id=' in page.locator('#app').inner_text());page.locator('[data-action="budget-adjust-detail"]').click();page.locator('[data-action="budget-adjust-approve"]').click();current=page.evaluate('EPMPrototype.inspect().budget');check('full: adjustment approval creates independent version',len(current['versions'])==4 and near(current['versions'][-1]['annual'],18700) and near(current['versions'][-2]['annual'],18500) and current['adjustments'][0]['status']=='已批准')
   else:
    check('lean: no budget model in state/config',page.evaluate('EPMPrototype.inspect().budget===null && !Object.hasOwn(CONFIG,"budget")'))
    for route in ['budget-cycle','budget-sheet','budget-adjust','budget-version']:
     page.locator(f'[data-route="{route}"]').click();check('lean: static reservation '+route,page.locator('.reserve-panel').count()==1 and page.locator('[data-action^="budget-"]:enabled').count()==0)
    page.evaluate("document.querySelector('[data-action=budget-edit]').disabled=false")
    page.locator('[data-action="budget-edit"]').click();check('lean: forged enabled budget action blocked',page.evaluate('EPMPrototype.inspect().budget===null') and page.locator('.dialog').count()==0)
    page.locator('[data-route="analysis"]').click();check('lean: analysis compares prior year only','上年同期' in page.locator('#app').inner_text() and page.locator('.waterfall').inner_text().find('预算利润')<0)
   page.locator('[data-route="closing"]').click();page.locator('[data-action="run-checks"]').click();page.locator('[data-action="confirm-ic"]').click();page.locator('[data-action="save-ic"]').click();page.locator('[data-action="commentary"]').click();page.locator('[data-action="save-commentary"]').click();page.locator('[data-action="signoff"]').click();check(prefix+'complete closing signoff',page.evaluate('EPMPrototype.inspect().signed'))
   page.locator('[data-action="close-modal"]').first.click();page.locator('[data-route="overview"]').click();page.screenshot(path=str(ROOT/'evidence'/f'{variant}-overview.png'),full_page=True)
  # Each independently generated document has its own globals and no storage.
  fresh=contexts[1].new_page();fresh.set_content(payloads[files[1]].decode('utf-8'),wait_until='load');check('fresh lean document does not inherit full budget/session',fresh.evaluate('EPMPrototype.inspect().budget===null && EPMPrototype.inspect().signed===false && EPMPrototype.inspect().activities.length===0'))
  check('no script runtime errors',not report['errors'],report['errors']);check('no outgoing HTTP requests',not report['network_requests'],report['network_requests'])
  browser.close()
 report['passed']=True
except Exception as exc:
 report['passed']=False;report['failure']=str(exc)
finally:
 report['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();report['files']={f.name:hashlib.sha256(payloads[f]).hexdigest() for f in files}
 (ROOT/'evidence/browser-test-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'passed':report['passed'],'checks':len(report['checks']),'failure':report.get('failure')},ensure_ascii=False))
 sys.exit(0 if report['passed'] else 1)
