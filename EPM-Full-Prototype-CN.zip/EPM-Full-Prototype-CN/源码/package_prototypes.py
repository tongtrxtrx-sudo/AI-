#!/usr/bin/env python3
"""Package two independent offline prototypes from an explicit allowlist."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RELEASE=ROOT/'release';RELEASE.mkdir(exist_ok=True)
report=json.loads((ROOT/'evidence/browser-test-report.json').read_text())
independent=json.loads((ROOT/'evidence/independent/independent-final-summary.json').read_text())
if not report.get('passed') or report.get('errors') or report.get('network_requests') or independent.get('remaining_known_findings'):
 raise SystemExit('Refuse release: browser/independent verification is not clean')
variants=[('EPM-Full-Prototype-CN.zip','01_完整产品交互原型.html','full'),('EPM-Consolidation-Analysis-Prototype-CN.zip','02_合并与经营分析交互原型.html','lean')]
marker=ROOT/'默认打包版本.txt'
if marker.is_file():variants=[v for v in variants if v[2]==marker.read_text().strip()]
source_paths=['build_prototypes.py','package_prototypes.py','src/shell.html','src/style.css','src/app.js','tests/test_browser.py']
releases=[]
for filename,entry,variant in variants:
 html=ROOT/'dist'/entry; digest=hashlib.sha256(html.read_bytes()).hexdigest()
 if report['files'].get(entry)!=digest or independent['verified_file_sha256'].get(variant)!=digest:
  raise SystemExit('Refuse release: verified HTML hash changed: '+entry)
 root_name=filename.removesuffix('.zip')
 files={entry:html,'请先阅读.md':ROOT/'使用说明.md','源码/使用说明.md':ROOT/'使用说明.md','源码/evidence/browser-test-report.json':ROOT/'evidence/browser-test-report.json','源码/evidence/independent/independent-final-summary.json':ROOT/'evidence/independent/independent-final-summary.json','源码/evidence/'+variant+'-overview.png':ROOT/'evidence'/f'{variant}-overview.png','验证资料/browser-test-report.json':ROOT/'evidence/browser-test-report.json','验证资料/independent-final-summary.json':ROOT/'evidence/independent/independent-final-summary.json','验证资料/'+variant+'-overview.png':ROOT/'evidence'/f'{variant}-overview.png'}
 for relative in source_paths:files['源码/'+relative]=ROOT/relative
 payload={}
 for name,path in sorted(files.items()):
  if path.is_symlink() or not path.is_file():raise SystemExit('Refuse nonregular explicit input: '+str(path))
  payload[name]=path.read_bytes()
 payload['源码/默认打包版本.txt']=(variant+'\n').encode()
 label='完整产品交互原型' if variant=='full' else '合并报表与经营分析交互原型（预算仅预留）'
 payload['请先阅读.md']=('本压缩包仅包含：'+label+'。直接双击“'+entry+'”即可打开。另一版本请下载对应独立ZIP；共用源码可重建两套设计，不代表精简入口启用了预算。\n\n').encode()+payload['请先阅读.md']
 sums=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(payload.items()))
 payload['SHA256SUMS.txt']=sums.encode('utf-8')
 target=RELEASE/filename
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for name,data in sorted(payload.items()):
   info=zipfile.ZipInfo(root_name+'/'+name,date_time=(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
   archive.writestr(info,data)
 members=[]
 with zipfile.ZipFile(target) as archive:
  if archive.testzip() is not None:raise SystemExit('ZIP CRC verification failed')
  for name in archive.namelist():
   data=archive.read(name);relative=name.removeprefix(root_name+'/')
   if data!=payload[relative]:raise SystemExit('ZIP member roundtrip failed')
   members.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 releases.append({'filename':filename,'entry_html':entry,'html_sha256':digest,'zip_bytes':target.stat().st_size,'zip_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'zip_crc_verified':True,'all_members_sha256_verified':True,'members':members,'variant':variant})
(RELEASE/'SHA256SUMS.txt').write_text(''.join(x['zip_sha256']+'  '+x['filename']+'\n' for x in releases))
(RELEASE/'release-report.json').write_text(json.dumps({'scope':'Offline Chinese interaction prototypes only; fictional demo data; no real API/accounting data','browser_checks_passed':len(report['checks']),'windows_double_click_tested':False,'file_protocol_cloud_policy_blocked':True,'release_files':releases},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:x[k] for k in ('filename','zip_bytes','zip_sha256','zip_crc_verified','all_members_sha256_verified')} for x in releases],ensure_ascii=False,indent=2))
