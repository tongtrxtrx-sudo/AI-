#!/usr/bin/env python3
"""Build two fully offline, single-file Chinese EPM interaction prototypes."""
import hashlib,json,re,shutil,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DIST=ROOT/'dist';DIST.mkdir(exist_ok=True)
(ROOT/'evidence').mkdir(exist_ok=True)
base={'title':'自研EPM交互原型','group':'华远产业集团','currency':'CNY','default_period':9}
budget={'entityRatios':{'MFG':8600/13800,'TEC':4450/13800,'TRD':2750/13800},'version':'V2 年度目标','status':'编制中','spread':'even','layers':[{'label':'基础层','amount':16000},{'label':'挑战层','amount':1066.67},{'label':'管理层','amount':800},{'label':'董事会层','amount':533.33}],'versions':[{'name':'V1 基准预算','scenario':'年度预算','annual':18000},{'name':'V2 年度目标','scenario':'年度预算','annual':18400}],'adjustments':[],'entityRevenueRatios':{'MFG':8600/13800,'TEC':4450/13800,'TRD':2750/13800}}
variants=[('01_完整产品交互原型.html',{**base,'variant':'full','title':'自研EPM · 完整产品交互原型','features':{'budget':True},'budget':budget}),('02_合并与经营分析交互原型.html',{**base,'variant':'lean','title':'自研EPM · 合并与经营分析交互原型','features':{'budget':False}})]
html=(ROOT/'src/shell.html').read_text();css=(ROOT/'src/style.css').read_text();js=(ROOT/'src/app.js').read_text()
records=[]
for filename,config in variants:
 variant_js=js
 if not config['features']['budget']:
  variant_js=re.sub(r'^function budget\(\).*$', 'function budget(){return null;}',variant_js,flags=re.M)
  variant_js=re.sub(r'function budgetCycle\(\)[\s\S]*?(?=function analysis\()', 'function budgetCycle(){return reservedBudget();}\nfunction budgetSheet(){return reservedBudget();}\nfunction budgetAdjust(){return reservedBudget();}\nfunction budgetVersion(){return reservedBudget();}\n',variant_js)
  variant_js=re.sub(r"\n case'budget-edit-layer':[\s\S]*?(?=\n case'export-statement':)",'',variant_js)
 variant_js=js
 if config['variant']=='lean':
  variant_js=re.sub(r'^function budget\(\).*$','function budget(){return null;}',variant_js,flags=re.M)
  variant_js=re.sub(r'function budgetCycle\(\)[\s\S]*?(?=function analysis\()',"function budgetCycle(){return reservedBudget();}\nfunction budgetSheet(){return reservedBudget();}\nfunction budgetAdjust(){return reservedBudget();}\nfunction budgetVersion(){return reservedBudget();}\n",variant_js)
  variant_js=re.sub(r"\n case'budget-edit-layer':[\s\S]*?(?=\n case'export-statement':)",'',variant_js)
 content=html.replace('__TITLE__',config['title']).replace('__STYLE__',css).replace('__CONFIG__',json.dumps(config,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')).replace('__APP__',variant_js)
 path=DIST/filename;path.write_text(content,encoding='utf-8');records.append({'filename':filename,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'variant':config['variant']})
index='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>自研EPM交互原型</title><style>body{font:15px system-ui,"Microsoft YaHei";background:#f2f5fa;color:#21344e;max-width:1000px;margin:80px auto;padding:25px}h1{font-size:34px}p{color:#7b8ba3;line-height:1.9}.tag{color:#9c6b16;background:#fff3d9;padding:8px 12px;border-radius:6px;font-size:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:25px;margin-top:35px}a{color:inherit;text-decoration:none;background:#fff;padding:35px;border:1px solid #e0e7f1;border-radius:15px;display:block}a:hover{border-color:#315ef4}h2{font-size:23px}b{font-size:12px;color:#315ef4}@media(max-width:650px){.grid{grid-template-columns:1fr}}</style><span class="tag">交互原型·演示数据</span><h1>自研EPM · 产品交互原型</h1><p>下载并解压后，直接双击本页或下方两个HTML入口。无需联网、服务器、Python或Docker。<br>所有金额与状态均为演示，不连接真实账套、不向实际平台写入数据。</p><div class="grid"><a href="01_完整产品交互原型.html"><b>完整产品 · 全场景设计</b><h2>合并 · 预算 · 分析 · 治理</h2><p>集团主数据、报送、抵销、关账、三表、全面预算、差异钻取与后台权限。</p><b>打开完整产品原型 →</b></a><a href="02_合并与经营分析交互原型.html"><b>聚焦版本 · 预算预留</b><h2>合并报表 · 经营分析</h2><p>合并与经营分析正常交互。预算仅保留静态界面，全部预算操作禁用，不生成预算数据。</p><b>打开合并与分析原型 →</b></a></div></html>'''
(DIST/'请先打开.html').write_text(index,encoding='utf-8')
(ROOT/'evidence/build-manifest.json').write_text(json.dumps({'offline':True,'requires_server':False,'external_assets':False,'files':records},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(records,ensure_ascii=False,indent=2))

if '--package' in sys.argv:
 report_path=ROOT/'evidence/browser-test-report.json'
 if not report_path.is_file() or not json.loads(report_path.read_text()).get('passed'):
  raise SystemExit('Refuse package without passing browser report')
 files={}
 for path in sorted(DIST.glob('*.html')):files[path.name]=path
 files['使用说明.md']=ROOT/'使用说明.md'
 for path in [ROOT/'build_prototypes.py',*sorted((ROOT/'src').glob('*')),*sorted((ROOT/'tests').glob('*.py'))]:
  if path.is_file():files['源码/'+path.relative_to(ROOT).as_posix()]=path
 for name in ['build-manifest.json','browser-test-report.json','full-overview.png','lean-overview.png']:
  path=ROOT/'evidence'/name
  if path.is_file():files['验证资料/'+name]=path
 for path in sorted((ROOT/'evidence/independent').glob('*.json')):
  files['验证资料/独立评审/'+path.name]=path
 checks=''.join(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+name+'\n' for name,path in sorted(files.items()))
 package=ROOT/'自研EPM_双版本交互原型.zip'
 with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,path in sorted(files.items()):
   info=zipfile.ZipInfo('自研EPM双版本交互原型/'+name,date_time=(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
   z.writestr(info,path.read_bytes())
  info=zipfile.ZipInfo('自研EPM双版本交互原型/SHA256SUMS.txt',date_time=(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,checks.encode())
 with zipfile.ZipFile(package) as z:
  bad=z.testzip()
  if bad:raise SystemExit('ZIP CRC failure: '+bad)
 digest=hashlib.sha256(package.read_bytes()).hexdigest()
 package.with_suffix('.zip.sha256').write_text(digest+'  '+package.name+'\n')
 print(json.dumps({'package':str(package),'bytes':package.stat().st_size,'sha256':digest,'crc_verified':True},ensure_ascii=False))
