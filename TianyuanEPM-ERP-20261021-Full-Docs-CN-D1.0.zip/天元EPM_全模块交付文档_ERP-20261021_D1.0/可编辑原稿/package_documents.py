#!/usr/bin/env python3
"""Package complete Word/PDF documents and editable source; refuse incomplete releases."""
from pathlib import Path
import hashlib,json,shutil,zipfile
from verify_documents import run,ROOT

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 verification=run()
 meta=json.loads((ROOT/'release.json').read_text(encoding='utf-8'))
 stage=ROOT/'package/天元EPM_全模块交付文档_ERP-20261021_D1.0'
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir(parents=True)
 for spec in meta['documents']:
  for ext in ['docx','pdf']:
   dest=stage if ext=='docx' else stage/'PDF';dest.mkdir(exist_ok=True)
   shutil.copy2(ROOT/'output'/(spec['stem']+'.'+ext),dest/(spec['stem']+'.'+ext))
 for folder in ['content','assets']:
  shutil.copytree(ROOT/folder,stage/'可编辑原稿'/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for name in ['release.json','render_documents.py','verify_documents.py','package_documents.py','README-文档使用说明.md','CHANGELOG.md','鸿旺小合并_首次测试操作卡.md']:
  shutil.copy2(ROOT/name,stage/'可编辑原稿'/name if name.endswith('.py') or name=='release.json' else stage/name)
 for p in (ROOT/'evidence').glob('*'):
  if p.suffix in {'.md','.json','.txt'}: 
   (stage/'校验与案例').mkdir(exist_ok=True);shutil.copy2(p,stage/'校验与案例'/p.name)
 contracts=stage/'接口与字段契约';contracts.mkdir()
 for name in ['API-CONTRACT.md','CALCULATION-CONTRACT.md','LEDGER-CONTRACT.md']:shutil.copy2(ROOT.parent/'backend'/name,contracts/name)
 for name in ['AGENTS.md','DELIVERY-STANDARD.md']:shutil.copy2(ROOT.parent/name,stage/name)
 release_record=ROOT.parent/'dist/交付版本与校验.json'
 assert release_record.exists(),'先完成软件包和外部交付校验，避免自引用SHA。'
 shutil.copy2(release_record,stage/release_record.name)
 files=sorted(p for p in stage.rglob('*') if p.is_file())
 forbidden={'.db','.sqlite','.sqlite3','.log','.private','.pyc','.pdb'}
 assert not any(p.suffix in forbidden or p.name in {'instance.json','.env','launcher.lock'} for p in files)
 (stage/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(stage).as_posix()+'\n' for p in files),encoding='utf-8')
 output=ROOT/'TianyuanEPM-ERP-20261021-Full-Docs-CN-D1.0.zip'
 with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(stage.rglob('*')):
   if p.is_file():z.write(p,arcname=stage.name+'/'+p.relative_to(stage).as_posix())
 with zipfile.ZipFile(output) as z:assert z.testzip() is None
 output.with_suffix('.zip.sha256').write_text(sha(output)+'  '+output.name+'\n',encoding='utf-8')
 print(json.dumps({'path':str(output),'bytes':output.stat().st_size,'sha256':sha(output)},ensure_ascii=False))
if __name__=='__main__':main()
