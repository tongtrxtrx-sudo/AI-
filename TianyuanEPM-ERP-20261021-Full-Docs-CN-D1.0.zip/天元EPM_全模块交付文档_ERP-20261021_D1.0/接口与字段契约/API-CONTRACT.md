# ERP凭证与多层合并中文 Demo 接口契约（ERP-20261021）

本版本与旧 Demo 数据目录独立。schemaVersion=3，product=`SelfDevelopedEPM-ERP-Demo`。仅监听127.0.0.1，Python标准库，支持`python -I backend/server.py --data-dir PATH --port 0 --no-browser --static-dir PATH`。健康/启动器控制、会话、CSRF、runtime/open-data-dir/shutdown沿用旧协议；会话cookie改`epm_erp_session`避免旧软件冲突。启动凭据只在私有进程管道/实例文件中，不公开。

## 读取与提交

GET `/api/bootstrap?group=TY_GROUP&month=9&currency=CNY&entity=all`。

context.group为动态合并单元id（初始TY_GROUP/HW_GROUP/OS_GROUP），month为1..12，entity=all或当前单元中法人ID。报表币种由所选单元/法人本位币决定；context.currency只接受与其一致的值，不能用旧单一汇率把整张报表任意换币。全资示例年度固定2026。

POST `/api/action`：`{action,payload,revision,context}`，同源Origin、cookie与`X-CSRF-Token`必须有效。成功返回完整bootstrap；失败`{error:{code,message},message}`。只有`revision_conflict`409需刷新；其他409显示准确业务原因。

## bootstrap 顶层字段

- 保留revision/companyName/settings/sessionRole/capabilities/budget/activities/accounts/statement/report/checks/context。
- `units:[{id,name,currency,members:[{type:'entity'|'unit',id}],version}]`。
- `entities:[{id,code,name,short,owner,currency,parentId,percent,...}]`，初始 TY/HW/HW_CAT/HW_ELEC/OTHER/OS_A/OS_B。管理成员与真实持股关系分开。
- `sources:{entityId:source}` 当前月的法人报送。source含version/currency/opening/closing/profit/monthlyProfit/cashflow/monthlyCashflow/capitalMovement。金额单位为各法人本位币万元（USD即万美元）。source closing.retained 已包括当期损益；不能重复结转。
- `rateSets:[{id,month,version,sourceCurrency,targetCurrency,opening,closing,historicalCapital,averages,flowRates,active}]` 当前月汇率历史；各表报价均为1USD=多少CNY。averages/flowRates的key是月份字符串。
- `eliminations` 当前月本层及下层抵销配置，含id/sourceId/unitId/month/kind/sellerId/buyerId/currency/amount/status/version/effects。
- `results` 当前月各单元全部版本详情。每项含id/unitId/month/version/origin/createdAt/approvedAt/approvalStatus/valid/staleReason、statement/report/checks/passed/leafIds/eliminationIds/inputs/trace/dependencies。origin初始为系统初始化演示，其他为用户计算。历史结果快照保留，不覆盖。
- `currentResult` 当前单元active结果或null。`unitStatus:{unitId,locked,activeResultId,valid,status,staleReason}`，`unitStates:{unitId:unitStatus}`。
- `preconditions:[{code,label,passed,message}]` 当前单元计算前置检查。上级只允许有效已签核下级结果。
- `reportMode` 为已签核/已计算/历史失效结果/预览；主statement必须与此状态一致，不能把预览算成已签核。
- `ownership` 真实全资股权配置；`budgetComparable`仅集团人民币all法人视图为true。预算比较基准由budget.comparisonAnnual提供，不与USD实绩混加。

## 动作（本表为唯一正式名称）

| action | payload | 说明 |
| --- | --- | --- |
| role_switch | `{role}` | 会话演示角色，非生产身份；不改业务版本 |
| entity_save | `{id,code,name,short,owner,currency,parentId?,percent?}` | 负责人；币种CNY/USD，演示仅100%权益 |
| ownership_save | `{entityId,parentId,percent,method:'全额合并'}` | 真实股权；不随管理范围自动改 |
| unit_save | `{id,name,currency,members:[{type,id}]}` | 负责人；拒绝环、重复叶子/节点；有结果需先重新开启 |
| source_save | `{entityId,source:{opening,closing,profit,monthlyProfit,cashflow,monthlyCashflow,capitalMovement,equityHistory?}}` | 当前月；typed字段校验，币种由法人固定；服务端递增版本 |
| source_import | `{csv,sourceName}` | 完整财务源CSV，整批原子校验；格式见下 |
| tb_import | `{csv,sourceName}` | 兼容旧5列试算：须有本期源报送，保留明确现金流源；现金流不符拒绝，不能自动估算填平 |
| rate_set_save | `{id?,sourceCurrency:'USD',targetCurrency:'CNY',opening,closing,historicalCapital,averages:{'1':7,...},flowRates:{'1':7,...}}` | 当前月，正数最多6小数；新增不可覆盖的版本激活，关联结果stale；缺期计算拒绝 |
| elimination_save | `{id?,sourceId,unitId,sellerId,buyerId,kind:'内部销售'|'投资权益',amount,currency}` | 保存草稿；服务端生成effects；内部销售必须双方最低共同单元；sourceId不可跨层重复 |
| elimination_cancel | `{id,reason}` | 负责人；先重开关联已签核层，草稿或已批准事项停用，历史快照保留；草稿误建可取消恢复计算 |
| elimination_approve | `{id}` | 负责人审批，影响本层及依赖祖先 |
| consolidation_run | `{unitId?}` | 默认context.group；本月新结果版本，严格引用有效已签核子结果，不能直接递归预览充当审批结果 |
| result_approve | `{resultId}` | 负责人；只签核当前active未失效结果且所有check通过，锁当前单元 |
| unit_reopen | `{unitId?,reason,cascade:true}` | 负责人；明确将此单元及依赖祖先解锁并标旧结果失效，保留历史批准快照 |
| commentary_save | `{text}` | 保存当前单元经营说明 |
| settings_save | `{companyName?,fiscalYear:2026}` | 固定年度2026 |
| account_save | `{code,name,type,field,normalSide}` | 内置报表字段映射；有锁定结果先重开 |

预算动作`budget_layer_save/budget_spread/budget_driver/budget_plan_save/budget_submit/budget_approve/budget_lock/budget_copy/budget_switch/budget_adjust_create/budget_adjust_approve/budget_adjust_reject`沿用旧字段，预算只做集团CNY独立演示，不改变财务结果。

旧financial动作journal_create/journal_save/journal_approve/rate_save/checks_run/submission_confirm/ic_confirm/signoff/period_reopen不再作为新合并体系旁路。界面改用本表多层动作，旧动作调用须返回准确中文不支持消息，不得成功却只写旧state。

## 完整财务源CSV

UTF-8（可带BOM），表头：`法人编码,期间,数据区,项目编码,金额,月份`。

数据区为`opening/closing/profit/cashflow/monthlyProfit/monthlyCashflow`（模板同时给中文说明）。opening/closing使用内置BS key；profit为revenue/cost/expense/finance/tax；cashflow为operating/investing/financing/fx；monthlyProfit/monthlyCashflow必须填写1..当前月的月份，累计区月份留空。整批同context月，每个法人整套必填字段齐全，禁止重复区/项目/月。cashflow是明确报送输入，不能从期末现金差倒挤经营净额。source结构与字段键以CALCULATION-CONTRACT为准。

源数据、成员或抵销有已签核依赖时先unit_reopen(cascade:true)。汇率新增版本可显式使使用该币种转换的本期结果失效，并保留原汇率/报表历史。首启seed由同一计算/审批逻辑生成预置真实演示版本，不使用hardcode报表数字。

历史权益equityHistory可维护capitalByEntity（仅当前法人且等于期初资本）、openingRetainedCny（已确认期初人民币留存收益）、dividendsByMonth（本版必须为空）。有USD期初留存收益时必须提供确认人民币数。内部销售可传monthlyAmounts逐月金额分配；不传时明确认定本事项全部发生于当前月。

结果另含sourceInfo（产品/模型/源码SHA）、sourceSnapshots、rateSnapshots、unitSnapshots、eliminationSnapshots、ownershipSnapshot；均为计算时输入留档。entityActuals按所展示结果的源快照和报表币种分项折算，basis为“法人贡献（合并抵销前）”，不能将其直接相加当合并结果。


## ERP-20261021 新增：NC6.5凭证到合并闭环

原生运行包与数据目录独立：`%LOCALAPPDATA%\TianyuanEPMVoucherDemo`。所有金额原始账务按本位币**元两位十进制字符串**，生成源与财务计算按本位币**万元六位**（一分=0.000001万元）。源三表、自动抵销和汇率不能使用旧万元两位截断。JSON最大请求正文12MB；单个上传文件最大8MB，CSV UTF-8正文最大9MB。

本版本的“接入”是CSV/XLSX文件导入，并未连接NC在线API。NC导出没有记账状态字段，需用户确认导出只含已记账业务凭证；`postedConfirmed:true`记录该确认，不冒称向ERP验证过记账状态。旧`.xls`需在Excel/WPS另存`.xlsx`或UTF-8 CSV。XLSX用本地标准ZIP/XML只读解析，不执行公式、宏或外链。

### ERP动作

以下仍POST `/api/action`并携带revision/context/会话/CSRF；所有失败整笔事务回滚。非只读可导入期初/凭证、生成报表、匹配与生成草稿；负责人专有动作在表内注明。

|action|payload|效果与前置|
|---|---|---|
|erp_adapter_save|`{adapter:'generic'\|'nc65',bookMappings:[{bookCode,entityId,functionalCurrency}],counterpartyMappings:[{code,entityId,column?}],importOptions:{auxiliaryColumn,auxiliaryColumns?,referenceColumn}}`|负责人。配置只解释后续导入，不改写已导入行；auxiliaryColumns为辅助核算1..9多选，保留单选兼容；column可限定客商编码来源列；entityId='EXTERNAL'明确外部。多个内部对方冲突或未知客商不能自动猜。|
|erp_mapping_save|`{csv,sourceName,columnMap?}`或`{rows:[{entityId,code,name,field,normalSide}],sourceName}`|负责人。按法人/科目保存映射新版本；旧映射留档；有已签核依赖先重开。|
|erp_opening_import|`{csv,sourceName,amountUnit:'元'\|'万元',columnMap?}`|导入2026年年初余额，逐法人平衡；同科目可按内部客商/交易关联号分拆；期初损益为零。|
|erp_voucher_import|`{csv,sourceName,amountUnit:'元'\|'万元',format:'generic'\|'nc65',postedConfirmed?:true,columnMap?}`|逐凭证借贷平衡，重复分录整批拒绝。NC必须postedConfirmed=true；按账簿、年月、类别、凭证号、凭证内源行序赋唯一键，保留源文件行号。|
|erp_batch_cancel|`{batchId,reason}`|负责人。仅停用当前ERP批次，原行/历史源快照保留；相关源、匹配、结果与自动抵销失效，必须重生/重新匹配。|
|erp_report_generate|`{entityIds?:[entityId,...],unitId?}`|默认当前合并单元叶子法人。由当前有效映射、期初和截至本月完整凭证生成试算及三表；保存原行、映射、批次、分类依据快照。无法确定现金分类时拒绝，不倒挤经营现金。|
|erp_match_run|`{unitId?}`|默认当前单元。本层最低共同合并层匹配；下层交易由下级已签结果继承。相符和差异均可追溯原行；差异不补平。|
|erp_demo_eliminations_replace|`{unitId?,reason}`|负责人明确确认转入凭证模式，只停用本层本期待替换的初始化示例销售抵销；不碰用户手工事项、投资权益950或历史快照。普通NC导入也必须走此步骤以防旧100/50与自动抵销双扣。|
|erp_elimination_generate|`{unitId?,matchIds?:[...ids]}`|从当前有效匹配生成草稿；同版本重复点击幂等不重复；源变化旧auto失效。尚有预置销售抵销时409，必须先明确模式转换。|
|erp_eliminations_approve|`{unitId?,ids?:[...eliminationIds],reason}`|负责人。默认本层本期ERP自动草稿，事务内逐张调用正式审批校验；任一失败整批回滚；保留每张approvedBy/approvedAt/approvalReason，不影响手工。|
|erp_sample_load|`{replace:true,reason}`|负责人明确载入全7家虚构样例，旧ERP输入归档、旧结果快照保留、相关签核解锁失效；旧示例100/50停用防重。不自动生成报表或签核；后续须逐步生成/匹配/审批/计算。|

三类文件动作可将`csv`替换为`fileBase64,fileName,sheetName?`，由服务器按CSV/XLSX实际内容读取；格式或未知字段错误给出中文原因和原行号。基于当前输入变更使相关自动抵销进入“来源失效”，不可继续审批或用于正式计算；重跑匹配后旧签名记录停用，再生成新草稿。

### NC6.5字段解释

48列实际表头见`research-erp/NC65-HEADERS.json`（允许前导`*`和空白）。法人由“核算账簿→法人/本位币”配置确定；仅使用“本币借方金额/本币贷方金额”生成法人账。“币种”为交易币，集团/全局本币金额与汇率只原样保留供核对，绝不重复入账或再换算。“结算号/核销号”按配置选作共同交易关联号；未配置共同编号或双方不一致时列差异，不靠摘要或相同金额猜。

### bootstrap.erp

`adapter,version,mappings[],openings[],vouchers[],batches[],bookMappings[],counterpartyMappings[],importOptions`为真实ERP状态；已停用记录保留且active=false。凭证行保留`id,entityId,bookCode,category,date,voucherId,rawVoucherNo,lineNo,accountCode,currency,transactionCurrency,debit,credit,summary,counterpartyId,counterpartyCode,counterpartyStatus,reference,icType,cashflow,voucherKind,batchId,sourceRow,rawFields`。

`reports:{entityId:{entityId,month,currency,sourceVersion,source,statement,trialBalance,trace,checks,ledgerFingerprint,valid,generatedAt}}`为当前期间已生成法人结果。源带`sourceType:'erp',ledgerFingerprint,ledgerTrace,ledgerSnapshot`；普通手工source_save不能提交这些元数据伪造ERP血缘。`ledgerSnapshot`冻结实际映射、期初、原凭证、批次与导入解释规则；后续新输入不回写历史结果。

`matching:{scopeId,month,matches[],differences[],erpInputFingerprint,valid,runAt,leafIds}`；match含`id,sourceId,unitId,kind:'sales'|'balances',sellerId,buyerId,currency,amount,openingAmount,reference,monthlyAmounts?,effects,openingEffects,voucherRefs,signature`。difference含`id,code,type,message,status,voucherRefs`及可用的双方金额、差额与关联号。

`demoEliminationConflicts[]`列当前本层仍有效的初始化示例销售抵销；`templates`有`mappingCsv,openingCsv,voucherCsv,nc65Csv,bookMappings,counterpartyMappings,importOptions`，全部虚构。`integration.onlineConnected:false`准确表明文件模式。

自动抵销保存`journalLines`为实际借/贷分录（万元六位）：销售借收入贷成本；内部余额借应付贷应收，同时有effects、来源match及原凭证行。金额相符才生成，审批后才进合并；不写回NC。应收应付期初和期末分别相符，期初缺客商明细不得用总额强配。

### 凭证追溯读取

GET `/api/erp/trace?entityId=HW&month=9&area=profit&field=revenue&resultId=...`，需有效会话。未传resultId读取当前法人源；传历史结果ID严格读取其`sourceSnapshots`，不能跳到最新账务。

返回`entityId,month,area,field,sourceVersion,basis,resultId,currency,amount,amountUnit:'万元',contributingFields,traceRows,rows,openingRows,relatedVoucherRows,ledgerSnapshot`。`rows`仅该字段实际归因的原分录；`relatedVoucherRows`是另列的同凭证完整借贷，不能冒称全部归属于所点项目。openingRows为期初归因。支持profit的gross/operating/pretax/net，opening/closing的assets/liabilities/equity/balance，cashflow的change/openingcash/cash派生项；未知字段400。手工源无凭证血缘返回409 no_erp_lineage，不能假显示零。

### 正式计算的ERP前置

有ERP账务的法人必须用当前ledgerFingerprint生成三表；本层内部交易必须完成当前版本匹配，所有差异核清，所有相符事项生成并审批，预置示例销售抵销明确转换。仍沿用原严格下级签核与版本依赖；未配对/金额差/币种差/未映射科目或客商不自动出补差凭证。海外USD小合并和集团CNY分类折算继续按原规则，跨法人不同本位币自动抵销不在本轮支持范围。


### 凭证核对补注（不改原账金额）

动作`erp_voucher_annotations_save`：`{rowIds:[canonicalRowId,...],counterpartyId?:entityId|'EXTERNAL',reference?:string,cashflow?:'operating'|'investing'|'financing'|'',reason}`。非只读角色可用，必须已重开相关签核链；rowIds仅允许当前范围截至所选月的有效凭证行，不重复。至少一项可改字段；payload中出现日期、科目、借贷金额、rawFields等额外字段即400，不会部分保存。现金分类只能填写在映射为cash的原行，混入非现金行整批拒绝。

补注仅修改规范化客商、共同交易关联号或现金分类，原`rawFields`、日期、科目、金额、批次/源文件行号始终不改。逐行保留`annotations:[{id,at,by,reason,rowId,before,after}]`及ERP审计说明，输入版本更新使当前源/匹配/自动抵销/相关结果失效；重新生成三表、匹配、生成抵销、审批后才可正式合并。历史ledgerSnapshot仍含原来的规范化值和原注记录。`EXTERNAL`明确外部客商，规范化counterpartyId为空、counterpartyStatus=external，原NC客商编码仍保留。

NC同一凭证内如仅有一个已解析客商和一个共同关联号，可以把该依据安全传给空的损益/往来行，保留`derivedFromVoucherRows`与推导依据；不能跨凭证传播，多个不同客商或多个关联号不猜测。保存适配器映射只影响后续导入，旧NC批次须先停用再重导，不能以重跑匹配代替重新解释原导入。
